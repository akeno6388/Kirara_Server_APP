using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 全局飞入菜单（Flyout）辅助类。
/// 统一管理应用中所有确认/提示飞入菜单的创建与交互，
/// 确保布局、样式、交互行为完全一致。
/// </summary>
public static class FlyoutHelper
{
    /// <summary>
    /// 显示一个确认飞入菜单（图标 + 标题/描述 + 取消/确认按钮）。
    /// 返回 true 表示用户点击了确认按钮，false 表示取消或关闭。
    /// </summary>
    /// <param name="anchor">锚点元素</param>
    /// <param name="placement">弹出位置</param>
    /// <param name="iconGlyph">图标 Glyph（Segoe MDL2 Assets）</param>
    /// <param name="iconColor">图标颜色</param>
    /// <param name="title">标题文本（粗体 18px）</param>
    /// <param name="description">描述文本（可选，14px 半透明）</param>
    /// <param name="confirmText">确认按钮文本</param>
    /// <param name="confirmColor">确认按钮背景色</param>
    /// <param name="cancelText">取消按钮文本（默认"取消"）</param>
    /// <param name="isMandatory">true=强制模式，仅显示确认按钮（无取消按钮）；false=显示确认+取消</param>
    /// <param name="allowLightDismiss">
    /// true=允许点击外部关闭弹窗（默认）；false=禁止点击外部关闭（含 Esc 键），
    /// 弹窗不会超时消失，只能通过按钮关闭 —— 用于更新提示等需要用户明确选择的场景
    /// </param>
    /// <returns>用户是否点击了确认按钮</returns>
    public static Task<bool> ShowConfirmAsync(
        FrameworkElement anchor,
        FlyoutPlacementMode placement,
        string iconGlyph,
        Color iconColor,
        string title,
        string? description = null,
        string confirmText = "确定",
        Color? confirmColor = null,
        string cancelText = "取消",
        bool isMandatory = false,
        bool allowLightDismiss = true)
    {
        var tcs = new TaskCompletionSource<bool>();

        var flyout = new Flyout { Placement = placement };
        var root = new StackPanel { Spacing = 16, MinWidth = 240, MaxWidth = 360, Padding = new Thickness(4) };

        if (!allowLightDismiss)
        {
            // 禁止点击外部关闭弹窗：仅当点击弹窗内按钮（或窗口销毁等极端情况）才会关闭。
            // ⚠️ WinUI 3 的 Flyout 本身没有 IsLightDismissEnabled 属性，
            //    需在 Opened 后通过视觉树找到其内部 Popup 再禁用 light dismiss；
            //    且 Esc 键默认仍会关闭 Flyout，因此下方另行拦截 Esc 键（见 root.KeyDown）。
            flyout.Opened += (_, _) =>
            {
                var current = (DependencyObject)root;
                while (current != null)
                {
                    if (current is Popup popup)
                    {
                        popup.IsLightDismissEnabled = false;
                        break;
                    }
                    current = VisualTreeHelper.GetParent(current);
                }
            };
        }

        // 图标
        root.Children.Add(new FontIcon
        {
            Glyph = iconGlyph,
            FontSize = 45,
            Foreground = new SolidColorBrush(iconColor),
            HorizontalAlignment = HorizontalAlignment.Center,
        });

        // 标题
        root.Children.Add(new TextBlock
        {
            Text = title,
            FontSize = 18,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -5, 0, 0),
        });

        // 描述（可选）
        if (!string.IsNullOrEmpty(description))
        {
            root.Children.Add(new TextBlock
            {
                Text = description,
                FontSize = 16,
                Opacity = 0.7,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, -5, 0, 12),
            });
        }
        else
        {
            // 无描述时给底部留白
            root.Children.Add(new Microsoft.UI.Xaml.Shapes.Rectangle
            {
                Height = 10,
                Fill = new SolidColorBrush(Color.FromArgb(0, 0, 0, 0)),
            });
        }

        // 按钮面板
        var buttonPanel = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Center,
            Spacing = 12,
        };

        // 非强制模式才显示取消按钮
        if (!isMandatory)
        {
            var cancelBtn = new Button
            {
                Content = cancelText,
                Style = (Style)Application.Current.Resources["GrayButtonStyle"],
                MinWidth = 100,
            };
            cancelBtn.Click += (_, _) => { flyout.Hide(); tcs.TrySetResult(false); };
            buttonPanel.Children.Add(cancelBtn);
        }

        var confirmBtn = new Button
        {
            Content = confirmText,
            MinWidth = 100,
            Style = (Style)Application.Current.Resources["PrimaryButtonStyle"],
            Background = new SolidColorBrush(confirmColor ?? Color.FromArgb(255, 0, 103, 192)),
            Foreground = new SolidColorBrush(Microsoft.UI.Colors.White),
        };
        confirmBtn.Click += (_, _) => { flyout.Hide(); tcs.TrySetResult(true); };
        buttonPanel.Children.Add(confirmBtn);

        root.Children.Add(buttonPanel);
        flyout.Content = root;

        // Flyout 关闭时（点外部关闭）也视为取消。
        // ⚠️ 强制模式 / allowLightDismiss=false 下点击外部不会触发关闭（IsLightDismissEnabled=false），
        //    仅当点击按钮（Hide）或窗口销毁等极端情况触发 Closed 时才会走到这里。
        flyout.Closed += (_, _) => tcs.TrySetResult(false);

        if (!allowLightDismiss)
        {
            // 拦截 Esc 键：IsLightDismissEnabled=false 时 Esc 默认仍会关闭 Flyout，
            // 这里在内容根元素上拦截并标记为已处理，使弹窗只能通过按钮关闭。
            root.KeyDown += (_, e) =>
            {
                if (e.Key == Windows.System.VirtualKey.Escape)
                    e.Handled = true;
            };
        }

        flyout.ShowAt(anchor);
        return tcs.Task;
    }

    /// <summary>
    /// 显示一个纯提示飞入菜单（图标 + 标题 + 描述 + 确定按钮）。
    /// </summary>
    public static void ShowInfo(
        FrameworkElement anchor,
        FlyoutPlacementMode placement,
        string iconGlyph,
        Color iconColor,
        string title,
        string? description = null,
        string confirmText = "确定",
        Color? confirmColor = null,
        Action? onConfirmed = null)
    {
        var flyout = new Flyout { Placement = placement };
        var root = new StackPanel { Spacing = 12, MinWidth = 200, MaxWidth = 360, Padding = new Thickness(4) };

        // 图标
        root.Children.Add(new FontIcon
        {
            Glyph = iconGlyph,
            FontSize = 45,
            Foreground = new SolidColorBrush(iconColor),
            HorizontalAlignment = HorizontalAlignment.Center,
        });

        // 标题
        root.Children.Add(new TextBlock
        {
            Text = title,
            FontSize = 18,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -3, 0, 4),
        });

        // 描述（可选）
        if (!string.IsNullOrEmpty(description))
        {
            root.Children.Add(new TextBlock
            {
                Text = description,
                FontSize = 16,
                Opacity = 0.7,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, -5, 0, 20),
            });
        }

        // 确定按钮（居中），颜色与图标一致
        var confirmBtn = new Button
        {
            Content = confirmText,
            MinWidth = 100,
            HorizontalAlignment = HorizontalAlignment.Center,
            Style = (Style)Application.Current.Resources["PrimaryButtonStyle"],
            Background = new SolidColorBrush(confirmColor ?? iconColor),
            Foreground = new SolidColorBrush(Microsoft.UI.Colors.White),
        };
        confirmBtn.Click += (_, _) => flyout.Hide();
        root.Children.Add(confirmBtn);

        // Flyout 关闭时触发回调（点"确定"、点外部均可）
        flyout.Closed += (_, _) => onConfirmed?.Invoke();

        flyout.Content = root;
        flyout.ShowAt(anchor);
    }

    /// <summary>
    /// 显示一个"删除确认"飞入菜单 — 删除类操作的统一方案（含同款图标）。
    /// 图标固定为警示符号 \uE783 + 红色主题（图标/确认按钮均为删除红 #E57373），
    /// 与实例删除飞入提示框完全一致。
    /// </summary>
    /// <param name="anchor">锚点元素</param>
    /// <param name="placement">弹出位置</param>
    /// <param name="title">标题文本（如"确定要删除此配置文件吗？"）</param>
    /// <param name="description">描述文本（可选，14px 半透明）</param>
    /// <param name="confirmText">确认按钮文本（默认"删除"）</param>
    /// <returns>用户是否点击了确认按钮</returns>
    public static Task<bool> ShowDeleteConfirmAsync(
        FrameworkElement anchor,
        FlyoutPlacementMode placement,
        string title,
        string? description = null,
        string confirmText = "删除")
    {
        // 删除红（与实例删除确认飞入一致：229,115,115）
        var deleteRed = Color.FromArgb(255, 229, 115, 115);
        return ShowConfirmAsync(
            anchor,
            placement,
            "\uE783",          // 同款警示图标
            deleteRed,         // 红色图标
            title,
            description,
            confirmText: confirmText,
            confirmColor: deleteRed);  // 红色确认按钮
    }

    /// <summary>
    /// 显示一个带进度条的提示飞入菜单（图标 + 标题 + 描述 + 进度条 + 状态文字）。
    /// 用于下载/长耗时操作的进度反馈；返回 <see cref="ProgressFlyoutController"/> 供更新进度与关闭。
    /// 样式与全局飞入提示一致（Flyout 弹出、居中布局）。
    /// </summary>
    /// <param name="anchor">锚点元素</param>
    /// <param name="placement">弹出位置</param>
    /// <param name="iconGlyph">图标 Glyph（Segoe MDL2 Assets）</param>
    /// <param name="iconColor">图标颜色</param>
    /// <param name="title">标题文本（粗体 18px）</param>
    /// <param name="description">描述文本（可选，14px 半透明）</param>
    /// <returns>进度控制器（Update / SetIndeterminate / Close，线程安全，内部自动切 UI 线程）</returns>
    public static ProgressFlyoutController ShowProgress(
        FrameworkElement anchor,
        FlyoutPlacementMode placement,
        string iconGlyph,
        Color iconColor,
        string title,
        string? description = null)
    {
        var flyout = new Flyout { Placement = placement };
        var root = new StackPanel { Spacing = 12, MinWidth = 240, MaxWidth = 360, Padding = new Thickness(4) };

        // 图标
        root.Children.Add(new FontIcon
        {
            Glyph = iconGlyph,
            FontSize = 45,
            Foreground = new SolidColorBrush(iconColor),
            HorizontalAlignment = HorizontalAlignment.Center,
        });

        // 标题
        root.Children.Add(new TextBlock
        {
            Text = title,
            FontSize = 18,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -5, 0, 0),
        });

        // 描述（可选）
        if (!string.IsNullOrEmpty(description))
        {
            root.Children.Add(new TextBlock
            {
                Text = description,
                FontSize = 14,
                Opacity = 0.7,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, -3, 0, 0),
            });
        }

        // 进度条（确定进度；总大小未知时由控制器切换为不确定模式）
        var progressBar = new ProgressBar
        {
            Minimum = 0,
            Maximum = 100,
            Value = 0,
            IsIndeterminate = false,
            Margin = new Thickness(0, 8, 0, 0),
        };
        root.Children.Add(progressBar);

        // 状态文字（百分比 / 已下载大小）
        var statusText = new TextBlock
        {
            Text = "准备中...",
            FontSize = 13,
            Opacity = 0.7,
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
        };
        root.Children.Add(statusText);

        flyout.Content = root;
        flyout.ShowAt(anchor);

        return new ProgressFlyoutController(flyout, progressBar, statusText);
    }
}

/// <summary>
/// 进度飞入菜单控制器 — 线程安全地更新进度条 / 状态文字 / 关闭。
/// 由 <see cref="FlyoutHelper.ShowProgress"/> 返回；后台任务可直接调用（内部自动切 UI 线程）。
/// </summary>
public sealed class ProgressFlyoutController
{
    private readonly Flyout _flyout;
    private readonly ProgressBar _progressBar;
    private readonly TextBlock _statusText;
    private readonly DispatcherQueue _dispatcherQueue;

    internal ProgressFlyoutController(Flyout flyout, ProgressBar progressBar, TextBlock statusText)
    {
        _flyout = flyout;
        _progressBar = progressBar;
        _statusText = statusText;
        _dispatcherQueue = DispatcherQueue.GetForCurrentThread();
    }

    /// <summary>更新确定进度（0~100）与状态文字（线程安全）</summary>
    public void Update(double percent, string status)
    {
        void Apply()
        {
            _progressBar.IsIndeterminate = false;
            _progressBar.Value = Math.Clamp(percent, 0, 100);
            _statusText.Text = status;
        }

        RunOnUiThread(Apply);
    }

    /// <summary>切换为不确定进度（总大小未知时）</summary>
    public void SetIndeterminate(string status)
    {
        void Apply()
        {
            _progressBar.IsIndeterminate = true;
            _statusText.Text = status;
        }

        RunOnUiThread(Apply);
    }

    /// <summary>关闭飞入菜单（线程安全；未打开时调用无副作用）</summary>
    public void Close()
    {
        RunOnUiThread(() => _flyout.Hide());
    }

    private void RunOnUiThread(Action action)
    {
        if (_dispatcherQueue.HasThreadAccess)
        {
            action();
        }
        else
        {
            // WinUI 3 的 TryEnqueue 接收 DispatcherQueueHandler（无参委托），
            // 传 Action 需显式转换，否则编译报 CS1503
            _dispatcherQueue.TryEnqueue(new Microsoft.UI.Dispatching.DispatcherQueueHandler(action));
        }
    }
}