namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 令牌类型
/// </summary>
public enum TokenType
{
    /// <summary>默认令牌（占位符，不可删除/修改）</summary>
    Default = 0,

    /// <summary>应用令牌（用户名 + 密码）</summary>
    Application = 1,

    /// <summary>AD 域账户统一令牌</summary>
    ADDomain = 2
}
