using LiteDB;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

public class TokenRepository : ITokenRepository
{
    private readonly ILiteCollection<Token> _collection;

    public TokenRepository(AppDatabase database)
    {
        _collection = database.Tokens;
        _collection.EnsureIndex(x => x.Name);
    }

    public IEnumerable<Token> GetAll() =>
        _collection.FindAll().OrderByDescending(x => x.UpdatedAt);

    public Token? GetById(Guid id) =>
        _collection.FindById(id);

    public void Insert(Token token)
    {
        token.CreatedAt = DateTime.UtcNow;
        token.UpdatedAt = DateTime.UtcNow;
        _collection.Insert(token);
    }

    public void Update(Token token)
    {
        token.UpdatedAt = DateTime.UtcNow;
        _collection.Update(token);
    }

    public void Delete(Guid id)
    {
        var token = _collection.FindById(id);
        if (token is { IsSystem: true })
            return; // 系统内置令牌不可删除
        _collection.Delete(id);
    }
}
