using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;
using System.Collections.ObjectModel;

namespace Kirara_Server_WinUI.ViewModels.Pages;

/// <summary>
/// 令牌编辑器 ViewModel — 三步向导：令牌名称 → 令牌类型 → 凭据信息
/// </summary>
public partial class TokenEditorViewModel : ObservableObject
{
    private readonly ITokenService _tokenService;
    private readonly IDialogService _dialogService;
    private readonly INavigationService _navigationService;
    private readonly ILoginService _loginService;

    private const int TotalSteps = 3;

    // ===== 步骤状态 =====
    [ObservableProperty]
    private int _currentStep = 0;

    [ObservableProperty]
    private ObservableCollection<StepItem> _steps = new();

    // ===== 步骤可见性 =====
    public bool IsStep0Visible => CurrentStep == 0;
    public bool IsStep1Visible => CurrentStep == 1;
    public bool IsStep2Visible => CurrentStep == 2;
    public bool IsNotFirstStep => CurrentStep > 0;
    public bool IsLastStep => CurrentStep >= TotalSteps - 1;

    /// <summary>进度条填充百分比（0.0 ~ 1.0），用于驱动进度条动画</summary>
    public double ProgressBarWidthPercent =>
        TotalSteps > 1 ? CurrentStep / (double)(TotalSteps - 1) : 0.0;

    public string NextButtonText => IsLastStep ? "完成创建" : "下一步";
    public string StepIndicatorText => $"第 {CurrentStep + 1} 步，共 {TotalSteps} 步";

    // ===== 页面标题 =====
    [ObservableProperty]
    private string _pageTitle = "令牌创建向导";

    // ===== 步骤 0: 令牌名称 =====
    [ObservableProperty]
    private string _tokenName = string.Empty;

    /// <summary>令牌名称校验错误文字（为空表示无错误）</summary>
    [ObservableProperty]
    private string _tokenNameErrorText = string.Empty;

    /// <summary>令牌名称是否有校验错误</summary>
    public bool HasTokenNameError => !string.IsNullOrEmpty(TokenNameErrorText);

    /// <summary>令牌名称是否合法无冲突</summary>
    public bool IsTokenNameValid =>
        !string.IsNullOrWhiteSpace(TokenName) && !HasTokenNameError;

    // ===== 步骤 1: 令牌类型 =====

    [ObservableProperty]
    private TokenType _tokenType = TokenType.Application;

    /// <summary>令牌类型选项列表</summary>
    public ObservableCollection<TokenTypeOption> TokenTypeOptions { get; } = new()
    {
        new TokenTypeOption("应用令牌", TokenType.Application, "一组凭据，适用于大多数服务"),
        new TokenTypeOption("AD 域账户", TokenType.ADDomain, "Active Directory 域账户统一认证令牌"),
    };

    /// <summary>当前选中的类型选项</summary>
    [ObservableProperty]
    private TokenTypeOption? _selectedTypeOption;

    partial void OnSelectedTypeOptionChanged(TokenTypeOption? value)
    {
        if (value != null)
        {
            TokenType = value.Type;
            OnPropertyChanged(nameof(IsCredentialVisible));
        }
    }

    // ===== 步骤 2: 凭据信息 =====

    [ObservableProperty]
    private string _accountName = string.Empty;

    [ObservableProperty]
    private string _accountPassword = string.Empty;

    [ObservableProperty]
    private string _confirmPassword = string.Empty;

    [ObservableProperty]
    private string _serverUrl = string.Empty;

    [ObservableProperty]
    private string _notes = string.Empty;

    /// <summary>是否显示凭据字段（非默认令牌）</summary>
    public bool IsCredentialVisible => TokenType != TokenType.Default;

    // ===== 账户名实时校验提示 =====
    [ObservableProperty]
    private string _accountNameHint = string.Empty;

    [ObservableProperty]
    private string _accountNameHintColor = "#E74856";

    // ===== 文件名非法字符（与实例名称校验一致） =====
    private static readonly HashSet<char> ForbiddenNameChars = new(@"#\/*:?""<>|");

    /// <summary>账户名非法字符（含空格，与登录页面一致）</summary>
    private static readonly HashSet<char> ForbiddenChars = new(@"#\/*:?""<>| ");

    public TokenEditorViewModel(
        ITokenService tokenService,
        IDialogService dialogService,
        INavigationService navigationService,
        ILoginService loginService)
    {
        _tokenService = tokenService;
        _dialogService = dialogService;
        _navigationService = navigationService;
        _loginService = loginService;

        InitializeSteps();

        // 默认选中应用令牌
        SelectedTypeOption = TokenTypeOptions[0];
    }

    private void InitializeSteps()
    {
        Steps = new ObservableCollection<StepItem>
        {
            new() { Number = "1", Title = "输入名称" },
            new() { Number = "2", Title = "选择类型" },
            new() { Number = "3", Title = "令牌信息" },
        };

        UpdateStepStates();
    }

    /// <summary>重置表单（新建模式）</summary>
    public void ResetForNew()
    {
        CurrentStep = 0;
        TokenName = string.Empty;
        TokenNameErrorText = string.Empty;
        AccountName = string.Empty;
        AccountPassword = string.Empty;
        AccountNameHint = string.Empty;
        OnPropertyChanged(nameof(AccountNameHint));
        OnPropertyChanged(nameof(AccountNameHintColor));
        ConfirmPassword = string.Empty;
        OnPropertyChanged(nameof(PasswordsMatch));
        OnPropertyChanged(nameof(PasswordMismatchHint));
        ServerUrl = string.Empty;
        Notes = string.Empty;
        SelectedTypeOption = TokenTypeOptions[0];
        PageTitle = "令牌创建向导";

        OnPropertyChanged(nameof(IsStep0Visible));
        OnPropertyChanged(nameof(IsStep1Visible));
        OnPropertyChanged(nameof(IsStep2Visible));
        OnPropertyChanged(nameof(IsNotFirstStep));
        OnPropertyChanged(nameof(IsLastStep));
        OnPropertyChanged(nameof(NextButtonText));
        OnPropertyChanged(nameof(StepIndicatorText));
        UpdateStepStates();
    }

    // ===== 令牌名称实时校验 =====

    /// <summary>
    /// TokenName 变化时实时校验并更新错误提示
    /// </summary>
    partial void OnTokenNameChanged(string value)
    {
        ValidateTokenName(value);
        NextStepCommand.NotifyCanExecuteChanged();
        OnPropertyChanged(nameof(IsTokenNameValid));
        OnPropertyChanged(nameof(HasTokenNameError));
    }

    private void ValidateTokenName(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            TokenNameErrorText = string.Empty;
            return;
        }

        // 检查空格
        if (name.Contains(' '))
        {
            TokenNameErrorText = "名称不能包含空格";
            return;
        }

        // 检查文件名非法字符
        if (name.Any(c => ForbiddenNameChars.Contains(c)))
        {
            TokenNameErrorText = "名称不能包含下列特殊字符：# \\ / : * ? \" < > |";
            return;
        }

        // 检查是否与现有令牌重名
        var allTokens = _tokenService?.GetTokensByUser(_loginService.CurrentUserId);
        if (allTokens != null && allTokens.Any(t =>
            t?.Name != null && t.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
        {
            TokenNameErrorText = "该名称已被其他令牌使用，请换一个名称";
            return;
        }

        // 全部通过
        TokenNameErrorText = string.Empty;
    }

    partial void OnTokenNameErrorTextChanged(string value)
    {
        OnPropertyChanged(nameof(HasTokenNameError));
        OnPropertyChanged(nameof(IsTokenNameValid));
    }

    // ===== 步骤导航 =====

    /// <summary>
    /// 控制下一步按钮是否可点击
    /// 第0步：名称合法且无冲突；第1步：始终可进；第2步：必填凭据字段已填写
    /// </summary>
    private bool CanNextStep()
    {
        if (CurrentStep == 0)
        {
            return IsTokenNameValid;
        }
        if (CurrentStep == 2)
        {
            return !string.IsNullOrWhiteSpace(AccountName)
                && !string.IsNullOrWhiteSpace(AccountPassword)
                && PasswordsMatch;
        }
        return true;
    }

    partial void OnAccountNameChanged(string value)
    {
        ValidateAccountName(value);
        if (CurrentStep == 2)
            NextStepCommand.NotifyCanExecuteChanged();
    }

    /// <summary>
    /// 账户名实时校验（与登录页面用户名校验规则一致）
    /// </summary>
    private void ValidateAccountName(string accountName)
    {
        if (string.IsNullOrWhiteSpace(accountName))
        {
            AccountNameHint = string.Empty;
            OnPropertyChanged(nameof(AccountNameHint));
            OnPropertyChanged(nameof(AccountNameHintColor));
            return;
        }

        var trimmed = accountName.Trim();

        if (trimmed.Any(c => ForbiddenChars.Contains(c)))
        {
            AccountNameHint = "账户名包含非法字符（空格或特殊符号 # \\ / : * ? \" < > |）";
            AccountNameHintColor = "#E74856";
            goto notify;
        }

        if (trimmed.Length > 32)
        {
            AccountNameHint = "账户名不能超过 32 个字符";
            AccountNameHintColor = "#E74856";
            goto notify;
        }

        // 全部通过
        AccountNameHint = string.Empty;
        AccountNameHintColor = "#E74856";

    notify:
        OnPropertyChanged(nameof(AccountNameHint));
        OnPropertyChanged(nameof(AccountNameHintColor));
    }

    // ===== 密码相同性校验 =====
    public bool PasswordsMatch => string.IsNullOrEmpty(ConfirmPassword) || AccountPassword == ConfirmPassword;
    public string PasswordMismatchHint => PasswordsMatch ? string.Empty : "两次输入的密码不一致";

    partial void OnAccountPasswordChanged(string value)
    {
        if (CurrentStep == 2)
            NextStepCommand.NotifyCanExecuteChanged();
        OnPropertyChanged(nameof(PasswordsMatch));
        OnPropertyChanged(nameof(PasswordMismatchHint));
    }

    partial void OnConfirmPasswordChanged(string value)
    {
        if (CurrentStep == 2)
            NextStepCommand.NotifyCanExecuteChanged();
        OnPropertyChanged(nameof(PasswordsMatch));
        OnPropertyChanged(nameof(PasswordMismatchHint));
    }

    [RelayCommand(CanExecute = nameof(CanNextStep))]
    private void NextStep()
    {
        if (IsLastStep)
        {
            Save();
            return;
        }

        CurrentStep++;
        OnPropertyChanged(nameof(IsStep0Visible));
        OnPropertyChanged(nameof(IsStep1Visible));
        OnPropertyChanged(nameof(IsStep2Visible));
        OnPropertyChanged(nameof(IsNotFirstStep));
        OnPropertyChanged(nameof(IsLastStep));
        OnPropertyChanged(nameof(NextButtonText));
        OnPropertyChanged(nameof(StepIndicatorText));
        UpdateStepStates();
    }

    [RelayCommand]
    private void PreviousStep()
    {
        if (CurrentStep <= 0) return;

        CurrentStep--;
        OnPropertyChanged(nameof(IsStep0Visible));
        OnPropertyChanged(nameof(IsStep1Visible));
        OnPropertyChanged(nameof(IsStep2Visible));
        OnPropertyChanged(nameof(IsNotFirstStep));
        OnPropertyChanged(nameof(IsLastStep));
        OnPropertyChanged(nameof(NextButtonText));
        OnPropertyChanged(nameof(StepIndicatorText));
        UpdateStepStates();
    }

    partial void OnCurrentStepChanged(int value)
    {
        OnPropertyChanged(nameof(IsStep0Visible));
        OnPropertyChanged(nameof(IsStep1Visible));
        OnPropertyChanged(nameof(IsStep2Visible));
        OnPropertyChanged(nameof(IsNotFirstStep));
        OnPropertyChanged(nameof(IsLastStep));
        OnPropertyChanged(nameof(NextButtonText));
        OnPropertyChanged(nameof(StepIndicatorText));
        NextStepCommand.NotifyCanExecuteChanged();
        OnPropertyChanged(nameof(ProgressBarWidthPercent));
    }

    private void UpdateStepStates()
    {
        for (int i = 0; i < Steps.Count; i++)
        {
            Steps[i].IsActive = i == CurrentStep;
            Steps[i].IsCompleted = i < CurrentStep;
        }
    }

    // ===== 完成创建 =====

    [RelayCommand]
    private void Cancel()
    {
        _navigationService.GoBack();
    }

    private void Save()
    {
        if (string.IsNullOrWhiteSpace(TokenName))
        {
            // 跳转到第 0 步提示用户输入名称
            CurrentStep = 0;
            OnPropertyChanged(nameof(IsStep0Visible));
            OnPropertyChanged(nameof(IsStep1Visible));
            OnPropertyChanged(nameof(IsStep2Visible));
            OnPropertyChanged(nameof(IsNotFirstStep));
            OnPropertyChanged(nameof(IsLastStep));
            OnPropertyChanged(nameof(NextButtonText));
            OnPropertyChanged(nameof(StepIndicatorText));
            return;
        }

        // 创建令牌
        var token = _tokenService.CreateToken(TokenName, TokenType, _loginService.CurrentUserId);
        token.AccountName = AccountName;
        token.AccountPassword = AccountPassword;
        token.ServerUrl = ServerUrl;
        token.Notes = Notes;

        _tokenService.SaveSecureToken(token);

        // 返回管理器
        _navigationService.GoBack();
    }
}

/// <summary>
/// 令牌类型选择项
/// </summary>
public class TokenTypeOption
{
    public string DisplayName { get; }
    public TokenType Type { get; }
    public string Description { get; }

    public TokenTypeOption(string displayName, TokenType type, string description)
    {
        DisplayName = displayName;
        Type = type;
        Description = description;
    }
}
