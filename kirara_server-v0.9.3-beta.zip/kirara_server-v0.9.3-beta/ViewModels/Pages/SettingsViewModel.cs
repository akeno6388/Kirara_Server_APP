using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.UI.Xaml;
using Windows.UI;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.ViewModels.Controls;

namespace Kirara_Server_WinUI.ViewModels.Pages;

public partial class SettingsViewModel : ObservableObject
{
    private readonly IExportImportService _export;
    private readonly AppThemeService _theme;
    private readonly AppBehaviorService _behavior;
    private readonly AppUpdateService _appUpdate;
    private bool _initialized;

    public LeftFunctionBarViewModel LeftBar { get; }

    /// <summary>
    /// 是否跟随系统明暗主题与主题色。
    /// 开启后明暗主题与主题色设置项置灰不可用（ThemeControlsEnabled = false）。
    /// </summary>
    [ObservableProperty]
    private bool _followSystemTheme;

    /// <summary>手动模式下的深色主题开关（仅 FollowSystemTheme = false 时可用）</summary>
    [ObservableProperty]
    private bool _isDarkTheme;

    /// <summary>手动主题色（仅 FollowSystemTheme = false 时可用）</summary>
    [ObservableProperty]
    private Color _accentColor;

    /// <summary>明暗主题与主题色设置项是否可用（跟随系统时置灰）</summary>
    [ObservableProperty]
    private bool _themeControlsEnabled = true;

    // ===== 软件行为 =====

    /// <summary>
    /// 点击标题栏「关闭」按钮时的行为：true = 最小化到任务栏；false = 直接退出。
    /// 由 AppBehaviorService 持久化，WndProc SC_CLOSE 拦截实时读取。
    /// </summary>
    [ObservableProperty]
    private bool _closeToMinimize;

    /// <summary>是否开机自启（HKCU Run 注册表项）</summary>
    [ObservableProperty]
    private bool _autoStart;

    /// <summary>
    /// 关闭行为单选索引：0 = 最小化到任务栏；1 = 直接关闭软件。
    /// 与 CloseToMinimize（bool）双向同步，供 RadioButtons.SelectedIndex 绑定。
    /// </summary>
    [ObservableProperty]
    private int _closeToMinimizeIndex;

    /// <summary>
    /// 左侧功能栏自动折叠：开启后点击「开始工作」进入实例主界面时自动折叠左侧功能栏。
    /// 开启后折叠/展开开关置灰不可用（SidebarStateControlsEnabled = false）。
    /// </summary>
    [ObservableProperty]
    private bool _autoCollapseSidebar;

    /// <summary>
    /// 侧栏启动状态：true = 启动时保持展开；false = 启动时保持折叠。
    /// 仅 AutoCollapseSidebar 关闭时可用。
    /// </summary>
    [ObservableProperty]
    private bool _sidebarStartupExpanded = true;

    /// <summary>折叠/展开开关是否可用（自动折叠开启时置灰）</summary>
    [ObservableProperty]
    private bool _sidebarStateControlsEnabled = true;

    /// <summary>
    /// 主题色色块集合（48 色）— 每个色块由 SwatchItemViewModel 数据驱动
    /// 选中态/禁用态/灰化全部通过 VM 属性绑定，不依赖视觉树遍历
    /// </summary>
    public ObservableCollection<SwatchItemViewModel> Swatches { get; } = new();

    // ===== 更新管理 =====

    /// <summary>
    /// 当前应用版本显示文本（如 "v0.9.3 Beta 不删档测试 内部软件 严禁外传"）。
    /// 版本号注释文字取自 csproj &lt;VersionNote&gt; 属性（经 AssemblyMetadata 注入），
    /// 未配置时仅显示版本号（如 "v0.9.3"），与标题栏显示一致。
    /// </summary>
    public string CurrentVersionText
    {
        get
        {
            var note = AppUpdateService.VersionNote;
            return string.IsNullOrWhiteSpace(note)
                ? $"v{AppUpdateService.CurrentVersion}"
                : $"v{AppUpdateService.CurrentVersion} {note}";
        }
    }

    /// <summary>更新检查结果提示文本（显示在检查按钮下方）</summary>
    [ObservableProperty]
    private string _updateStatusText = string.Empty;

    /// <summary>
    /// 更新检查结果提示颜色（#RRGGBB）：进行中=灰 / 最新=绿 / 有更新=琥珀 / 失败=红
    /// </summary>
    [ObservableProperty]
    private string _updateStatusColor = "#888888";

    /// <summary>当前是否正在检查更新（按钮禁用 + 提示刷新）</summary>
    [ObservableProperty]
    private bool _isCheckingUpdate;

    /// <summary>
    /// 检查更新命令 — 手动触发一次版本校对。
    /// 有新版本 → AppUpdateService 弹出更新窗口；无需更新 → 按钮下方显示提示。
    /// </summary>
    [RelayCommand]
    private async Task CheckForUpdateAsync()
    {
        if (IsCheckingUpdate) return;
        IsCheckingUpdate = true;
        UpdateStatusText = "正在检查更新...";
        UpdateStatusColor = "#888888";
        try
        {
            var result = await _appUpdate.CheckForUpdateAsync();
            switch (result)
            {
                case UpdateCheckResult.UpToDate:
                    UpdateStatusText = "当前已是最新版本";
                    UpdateStatusColor = "#4CAF50";   // 绿
                    break;
                case UpdateCheckResult.UpdateAvailable:
                    // 提示带最新版本号（如 "发现新版本 v0.9.4"）；版本号缺失时回退旧文案
                    var latest = _appUpdate.LatestVersion;
                    UpdateStatusText = latest != null
                        ? $"发现新版本 v{latest}"
                        : "发现新版本，更新窗口已弹出";
                    UpdateStatusColor = "#FFC107";   // 琥珀
                    break;
                case UpdateCheckResult.Checking:
                    UpdateStatusText = "已有检查正在进行，请稍候...";
                    UpdateStatusColor = "#888888";   // 灰
                    break;
                case UpdateCheckResult.Failed:
                    UpdateStatusText = "检查更新失败，请检查网络连接后重试";
                    UpdateStatusColor = "#E57373";   // 红
                    break;
            }
        }
        finally
        {
            IsCheckingUpdate = false;
        }
    }

    /// <summary>
    /// Win11 个性化设置风格预设色板 — 48 种固定颜色（8 列 × 6 行）
    /// </summary>
    public IReadOnlyList<Color> PresetAccentColors { get; } = CreatePresetColors();

    /// <summary>
    /// 构建 Win11 官方 48 色固定色板
    /// </summary>
    private static IReadOnlyList<Color> CreatePresetColors()
    {
        string[] hex =
        {
            "FFB900", "FF8C00", "F7630C", "CA5010", "DA3B01", "EF6950", "D13438", "FF4343",
            "E74856", "E81123", "EA005E", "C30052", "E3008C", "C239B3", "B146C2", "881798",
            "9A0089", "744DA9", "8764B8", "6B69D6", "5C2D91", "4617B4", "0027A7", "00188E",
            "004E8C", "0063B1", "0078D4", "0078D7", "00809D", "005B70", "004B50", "008272",
            "00B294", "00B7C3", "00CC6A", "107C10", "10893E", "0B6A0B", "498205", "9BB24B",
            "647C64", "525E54", "567C73", "486860", "515C6B", "4A5459", "767676", "847545",
        };
        return hex
            .Select(h => Color.FromArgb(
                0xFF,
                (byte)Convert.ToInt32(h.Substring(0, 2), 16),
                (byte)Convert.ToInt32(h.Substring(2, 2), 16),
                (byte)Convert.ToInt32(h.Substring(4, 2), 16)))
            .ToArray();
    }

    public SettingsViewModel(IExportImportService export, LeftFunctionBarViewModel leftBar, AppThemeService theme, AppBehaviorService behavior, AppUpdateService appUpdate)
    {
        _export = export;
        _theme = theme;
        _behavior = behavior;
        _appUpdate = appUpdate;
        LeftBar = leftBar;

        // 从主题服务读取当前设置（使用 backing field 直接赋值，避免触发 OnXChanged）
        _followSystemTheme = _theme.FollowSystem;
        _isDarkTheme = _theme.IsDark;
        _accentColor = _theme.AccentColor ?? GetCurrentSystemAccent();
        _themeControlsEnabled = !_theme.FollowSystem;

        // 从软件行为服务读取当前设置（使用 backing field 直接赋值，避免触发 OnXChanged）
        _closeToMinimize = _behavior.CloseToMinimize;
        _autoStart = _behavior.AutoStart;
        _closeToMinimizeIndex = _behavior.CloseToMinimize ? 0 : 1;
        _autoCollapseSidebar = _behavior.AutoCollapseSidebar;
        _sidebarStartupExpanded = _behavior.SidebarStartupExpanded;
        _sidebarStateControlsEnabled = !_behavior.AutoCollapseSidebar;

        // 构建 48 个色块项：初始选中 = 当前主题色；初始可用 = 手动模式
        foreach (var color in PresetAccentColors)
        {
            Swatches.Add(new SwatchItemViewModel(color,
                isSelected: IsSameColor(color, _accentColor),
                isEnabled: _themeControlsEnabled));
        }

        _initialized = true;
    }

    /// <summary>
    /// 跟随系统开关变化 → 持久化 + 立即应用；同时联动明暗/主题色控件可用状态
    /// </summary>
    partial void OnFollowSystemThemeChanged(bool value)
    {
        if (!_initialized) return;
        ThemeControlsEnabled = !value;
        _theme.SetFollowSystem(value);
    }

    /// <summary>
    /// 控件可用状态变化 → 同步所有色块（禁用时灰化 + 不可交互，启用时恢复）
    /// </summary>
    partial void OnThemeControlsEnabledChanged(bool value)
    {
        foreach (var s in Swatches)
            s.IsEnabled = value;
    }

    /// <summary>
    /// 明暗主题切换 → 持久化 + 立即应用（跟随系统开启时服务内部忽略）
    /// </summary>
    partial void OnIsDarkThemeChanged(bool value)
    {
        if (!_initialized) return;
        _theme.SetIsDark(value);
    }

    /// <summary>
    /// 主题色变化（色块点击）→ 更新选中标记 + 持久化 + 实时预览应用
    /// </summary>
    partial void OnAccentColorChanged(Color value)
    {
        if (!_initialized) return;
        foreach (var s in Swatches)
            s.IsSelected = IsSameColor(s.Color, value);
        _theme.SetAccentColor(value);
    }

    /// <summary>
    /// 关闭行为切换 → 持久化（WndProc SC_CLOSE 拦截实时读取 Current.CloseToMinimize）
    /// </summary>
    partial void OnCloseToMinimizeChanged(bool value)
    {
        if (!_initialized) return;
        _behavior.SetCloseToMinimize(value);
        CloseToMinimizeIndex = value ? 0 : 1;
    }

    /// <summary>
    /// 关闭行为单选索引变化（RadioButtons.SelectedIndex）→ 同步 bool 并持久化
    /// </summary>
    partial void OnCloseToMinimizeIndexChanged(int value)
    {
        if (!_initialized) return;
        // 0 = 最小化到任务栏；1 = 直接关闭软件
        CloseToMinimize = value == 0;
    }

    /// <summary>
    /// 开机自启切换 → 持久化 + 立即写入/清理 HKCU Run 注册表项
    /// </summary>
    partial void OnAutoStartChanged(bool value)
    {
        if (!_initialized) return;
        _behavior.SetAutoStart(value);
    }

    /// <summary>
    /// 左侧功能栏自动折叠切换 → 持久化 + 联动折叠/展开开关可用状态（开启时置灰）。
    /// 关闭自动折叠时：立即按折叠/展开开关恢复左侧栏状态（清除自动折叠记录），
    /// 使设置项与左侧栏状态即时一致，无需重启。
    /// </summary>
    partial void OnAutoCollapseSidebarChanged(bool value)
    {
        if (!_initialized) return;
        SidebarStateControlsEnabled = !value;
        _behavior.SetAutoCollapseSidebar(value);
        if (!value)
            LeftBar.DisableAutoCollapseAndApplyStartupState();
    }

    /// <summary>
    /// 折叠/展开开关切换 → 持久化（启动时侧栏初始状态）+ 立即同步左侧栏状态。
    /// 仅自动折叠关闭（开关可用）时立即生效：开 = 立即展开，关 = 立即折叠，
    /// 让设置项与左侧栏状态即时一致，无需重启。
    /// </summary>
    partial void OnSidebarStartupExpandedChanged(bool value)
    {
        if (!_initialized) return;
        _behavior.SetSidebarStartupState(value);

        // [立即同步] 自动折叠关闭时立即刷新左侧栏状态（与设置项保持一致）
        if (!_behavior.AutoCollapseSidebar)
            LeftBar.IsLeftPaneOpen = value;
    }

    /// <summary>颜色按 RGB 比较是否相同（忽略透明度）</summary>
    private static bool IsSameColor(Color a, Color b) =>
        a.R == b.R && a.G == b.G && a.B == b.B;

    /// <summary>
    /// 获取当前生效的系统主题色（用于初始化色盘显示；覆盖未生效时的兜底）
    /// </summary>
    private static Color GetCurrentSystemAccent()
    {
        try
        {
            if (Application.Current.Resources.TryGetValue("SystemAccentColor", out var color) &&
                color is Color c)
            {
                return c;
            }
        }
        catch { /* 资源不可用时使用默认蓝色 */ }
        return Color.FromArgb(255, 0x00, 0x78, 0xD4);
    }

    public byte[] ExportAllData() => _export.ExportAllData();

    public (int Instances, int InstancesSkipped, int Tokens, int TokensSkipped) ImportAllData(byte[] data)
    {
        var result = _export.ImportAllData(data);
        LeftBar.LoadInstances();
        return result;
    }

    /// <summary>
    /// 一键导入（自动识别：UID 加密全量文件 / 明文实例分享文件）
    /// </summary>
    public (int Instances, int InstancesSkipped, int Tokens, int TokensSkipped, bool IsInstanceOnly) ImportData(byte[] data)
    {
        var result = _export.ImportData(data);
        LeftBar.LoadInstances();
        return result;
    }
}
