using System.Collections.ObjectModel;
using System.Runtime.InteropServices.WindowsRuntime;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.ViewModels.Pages;

/// <summary>
/// 令牌管理器页面 ViewModel — 管理所有令牌（列表/搜索/导入导出/删除）
/// </summary>
public partial class TokenManagerViewModel : ObservableObject
{
    private readonly ITokenService _tokenService;
    private readonly IExportImportService _exportImportService;
    private readonly IDialogService _dialogService;
    private readonly INavigationService _navigationService;
    private readonly ILoginService _loginService;

    [ObservableProperty]
    private ObservableCollection<Token> _tokens = new();

    [ObservableProperty]
    private string? _searchText;

    /// <summary>是否正在显示搜索框</summary>
    [ObservableProperty]
    private bool _isSearchVisible;

    /// <summary>当前选中的令牌（用于上下文操作）</summary>
    [ObservableProperty]
    private Token? _selectedToken;

    public TokenManagerViewModel(
        ITokenService tokenService,
        IExportImportService exportImportService,
        IDialogService dialogService,
        INavigationService navigationService,
        ILoginService loginService)
    {
        _tokenService = tokenService;
        _exportImportService = exportImportService;
        _dialogService = dialogService;
        _navigationService = navigationService;
        _loginService = loginService;
        LoadTokens();
    }

    /// <summary>加载当前用户的所有令牌</summary>
    private void LoadTokens()
    {
        Tokens.Clear();
        var userId = _loginService.CurrentUserId;
        foreach (var token in _tokenService.GetTokensByUser(userId)
            .OrderBy(t => t.Name))
        {
            Tokens.Add(token);
        }
    }

    /// <summary>搜索文本变化时自动过滤</summary>
    partial void OnSearchTextChanged(string? value)
    {
        ApplyFilter();
    }

    private void ApplyFilter()
    {
        var userId = _loginService.CurrentUserId;
        var all = _tokenService.GetTokensByUser(userId)
            .OrderBy(t => t.Name);
        if (string.IsNullOrWhiteSpace(SearchText))
        {
            Tokens = new ObservableCollection<Token>(all);
            return;
        }

        var keyword = SearchText!.Trim();
        var filtered = all.Where(t =>
            t.Name.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
            (t.Notes?.Contains(keyword, StringComparison.OrdinalIgnoreCase) ?? false));

        Tokens = new ObservableCollection<Token>(filtered);
    }

    /// <summary>切换搜索栏可见性</summary>
    [RelayCommand]
    private void ToggleSearch()
    {
        IsSearchVisible = !IsSearchVisible;
        if (!IsSearchVisible)
        {
            SearchText = string.Empty;
        }
    }

    /// <summary>导航到编辑器 — 新建令牌</summary>
    [RelayCommand]
    private void CreateToken()
    {
        _navigationService.NavigateTo(typeof(Views.Pages.TokenEditorPage));
    }

    /// <summary>重命名令牌 — 在当前页弹出重命名对话框</summary>
    [RelayCommand]
    private async Task EditToken(Token? token)
    {
        if (token == null) return;

        var newName = await _dialogService.ShowRenameInputAsync(
            "重命名令牌",
            token.Name,
            validate: name =>
            {
                if (string.IsNullOrWhiteSpace(name))
                    return (false, "名称不能为空");

                if (name.Contains(' '))
                    return (false, "名称不能包含空格");

                var forbidden = new HashSet<char>(@"#\/*:?""<>|");
                if (name.Any(c => forbidden.Contains(c)))
                    return (false, "名称不能包含下列特殊字符：# \\ / : * ? \" < > |");

                var allTokens = _tokenService.GetTokensByUser(_loginService.CurrentUserId);
                if (allTokens.Any(t => t.Id != token.Id
                    && t.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
                    return (false, "该名称已被其他令牌使用，请换一个名称");

                return (true, null);
            });

        if (newName != null && newName != token.Name)
        {
            token.Name = newName;
            _tokenService.UpdateToken(token);
            LoadTokens();
        }
    }

    /// <summary>删除令牌（默认令牌不可删除）</summary>
    [RelayCommand]
    private async Task DeleteToken(Token? token)
    {
        if (token == null) return;

        // 🆕 默认令牌不可删除
        if (token.TokenType == TokenType.Default)
        {
            await _dialogService.ShowMessageAsync("无法删除", "系统默认令牌不可删除，它保存了您的自动登录凭据。");
            return;
        }

        var confirmed = await _dialogService.ShowConfirmAsync(
            "确认删除",
            $"确定要删除令牌「{token.Name}」吗？此操作不可恢复。");

        if (confirmed)
        {
            _tokenService.DeleteToken(token.Id);
            LoadTokens();
        }
    }

   /// <summary>导出单个令牌</summary>
    /// <returns>导出成功时的文件名称，取消导出返回 null</returns>
    public async Task<string?> ExportToken(Token? token)
    {
        if (token == null) return null;

        try
        {
            var data = _tokenService.ExportToken(token.Id);
            var fileName = $"token_{token.Name}_{DateTime.Now:yyyyMMdd_HHmmss}.kirara";

            var path = PickSaveFilePath(fileName);
            if (path != null)
            {
                await System.IO.File.WriteAllBytesAsync(path, data);
                return System.IO.Path.GetFileName(path);
            }
            return null;
        }
        catch
        {
            throw;
        }
    }

    /// <summary>导出所有令牌</summary>
    /// <returns>导出成功时的文件名称，取消导出返回 null</returns>
    public async Task<string?> ExportAllTokens()
    {
        try
        {
            var data = _exportImportService.ExportAllTokens();
            var fileName = $"tokens_all_{DateTime.Now:yyyyMMdd_HHmmss}.kirara";

            var path = PickSaveFilePath(fileName);
            if (path != null)
            {
                await System.IO.File.WriteAllBytesAsync(path, data);
                return System.IO.Path.GetFileName(path);
            }
            return null;
        }
        catch
        {
            throw;
        }
    }

    /// <summary>导入令牌</summary>
    /// <returns>(已导入数量, 已跳过数量)，取消导入返回 null</returns>
    public async Task<(int Imported, int Skipped)?> ImportTokens()
    {
        try
        {
            var path = PickOpenFilePath();
            if (path == null) return null;

            var data = await System.IO.File.ReadAllBytesAsync(path);
            var (imported, skipped) = _exportImportService.ImportTokens(data);

            if (imported > 0)
            {
                LoadTokens();
            }
            return (imported, skipped);
        }
        catch
        {
            throw;
        }
    }

    /// <summary>编辑令牌备注</summary>
    [RelayCommand]
    private async Task EditNotes(Token? token)
    {
        if (token == null) return;

        var newNotes = await _dialogService.ShowInputAsync(
            "编辑备注",
            "为令牌添加备注说明：",
            token.Notes ?? string.Empty);

        if (newNotes != null)
        {
            token.Notes = newNotes;
            _tokenService.UpdateToken(token);
            LoadTokens();
        }
    }

    /// <summary>设置令牌颜色标签</summary>
    [RelayCommand]
    private void SetTokenColor(Token? token)
    {
        if (token == null) return;
        // 颜色选择在 UI 层通过 Flyout 完成，此命令仅用于保存
    }

    /// <summary>保存令牌颜色标签（由 UI 直接调用）</summary>
    public void ApplyTokenColor(Token token, string colorHex)
    {
        token.ColorTag = string.IsNullOrEmpty(colorHex) ? null : colorHex;
        _tokenService.UpdateToken(token);
        LoadTokens();
    }

    /// <summary>重命名令牌（由飞入菜单调用）</summary>
    public void RenameToken(Token token)
    {
        _tokenService.UpdateToken(token);
        LoadTokens();
    }

    /// <summary>获取所有令牌（用于校验）</summary>
    public IEnumerable<Token> GetAllTokens() => _tokenService.GetTokensByUser(_loginService.CurrentUserId);

    /// <summary>更新令牌并刷新列表（由飞入菜单调用）</summary>
    public void UpdateTokenAndRefresh(Token token)
    {
        _tokenService.UpdateToken(token);
        LoadTokens();
    }

    /// <summary>按 ID 删除令牌并刷新列表（由飞入菜单调用）</summary>
    public void DeleteTokenById(Guid id)
    {
        _tokenService.DeleteToken(id);
        LoadTokens();
    }

    /// <summary>令牌类型的本地化显示</summary>
    public static string GetTokenTypeDisplay(TokenType type) => type switch
    {
        TokenType.Default => "默认令牌",
        TokenType.Application => "应用令牌",
        TokenType.ADDomain => "AD 域账户",
        _ => "未知"
    };

    // ===== 文件选择器辅助方法（Win32 原生对话框，Unpackaged 自包含模式下可靠）=====

    /// <summary>
    /// Win32 保存文件对话框 — 返回用户选择的完整路径；取消返回 null。
    /// </summary>
    private static string? PickSaveFilePath(string suggestedName)
    {
        var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(MainWindow.Current);
        // GetSaveFileNameW：末尾追加默认扩展名（用户未输入扩展名时）
        var filter = "Kirara 令牌文件 (*.kirara)|*.kirara|所有文件 (*.*)|*.*";
        return Helpers.Win32FileDialogHelper.ShowSaveFileDialog(
            filter, "导出令牌", suggestedName, ".kirara", hwnd);
    }

    /// <summary>
    /// Win32 打开文件对话框 — 返回用户选择的完整路径；取消返回 null。
    /// </summary>
    private static string? PickOpenFilePath()
    {
        var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(MainWindow.Current);
        var filter = "Kirara 令牌文件 (*.kirara)|*.kirara|所有文件 (*.*)|*.*";
        return Helpers.Win32FileDialogHelper.ShowOpenFileDialog(filter, "导入令牌", hwnd);
    }
}
