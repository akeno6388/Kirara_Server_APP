using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;
using System.Collections.ObjectModel;

namespace Kirara_Server_WinUI.ViewModels.Pages;

/// <summary>
/// 实例编辑器页面 ViewModel — 四步向导：许可协议 → 名称 → 方案 → 令牌
/// </summary>
public partial class InstanceEditorViewModel : ObservableObject
{
    private readonly IInstanceService _instanceService;
    private readonly ISchemeService _schemeService;
    private readonly ITokenService _tokenService;
    private readonly INavigationService _navigationService;
    private readonly ILoginService _loginService;
    private readonly ViewModels.Controls.LeftFunctionBarViewModel _leftFunctionBar;

    private const int TotalSteps = 4;

    // ===== 步骤状态 =====
    [ObservableProperty]
    private int _currentStep = 0;

    [ObservableProperty]
    private ObservableCollection<StepItem> _steps = new();

    // ===== 步骤可见性 =====
    public bool IsStep0Visible => CurrentStep == 0;
    public bool IsStep1Visible => CurrentStep == 1;
    public bool IsStep2Visible => CurrentStep == 2;
    public bool IsStep3Visible => CurrentStep == 3;
    public bool IsNotFirstStep => CurrentStep > 0;
    public bool IsLastStep => CurrentStep >= TotalSteps - 1;

    /// <summary>进度条填充百分比（0.0 ~ 1.0），用于驱动进度条动画</summary>
    public double ProgressBarWidthPercent =>
        TotalSteps > 1 ? CurrentStep / (double)(TotalSteps - 1) : 0.0;

    public string NextButtonText => IsLastStep ? "完成创建" : "下一步";
    public string StepIndicatorText => $"第 {CurrentStep + 1} 步，共 {TotalSteps} 步";

    // ===== 步骤 0: 许可协议 =====
    /// <summary>用户是否已点击"同意"按钮</summary>
    [ObservableProperty]
    private bool _hasAgreedToLicense = false;

    /// <summary>用户已同意时是否隐藏"同意"按钮区域</summary>
    public bool IsLicenseAgreed => HasAgreedToLicense;

    /// <summary>尚未同意（取反，用于按钮可见性）</summary>
    public bool HasNotAgreed => !HasAgreedToLicense;

    /// <summary>倒计时剩余秒数（0 表示倒计时结束）</summary>
    [ObservableProperty]
    private int _remainingSeconds = 6;

    /// <summary>同意按钮是否可点击（倒计时结束且尚未同意）</summary>
    public bool CanAgree => RemainingSeconds <= 0 && !HasAgreedToLicense;

    /// <summary>同意按钮文字（倒计时中显示剩余秒数）</summary>
    public string AgreeButtonText =>
        RemainingSeconds > 0 ? $"我同意以上协议（{RemainingSeconds}秒）" : "我同意以上协议";

    /// <summary>实例类型显示文字（用于向导标题）</summary>
    public string InstanceTypeDisplayText =>
        InstanceType switch
        {
            InstanceType.UserInstance => "用户实例",
            InstanceType.ServiceInstance => "服务实例",
            _ => "实例",
        };

    /// <summary>向导标题</summary>
    public string WizardTitle => $"{InstanceTypeDisplayText}创建向导";

    // ===== 步骤 1: 实例名称 =====
    [ObservableProperty]
    private string _instanceName = string.Empty;

    /// <summary>实例名称校验错误文字（为空表示无错误）</summary>
    [ObservableProperty]
    private string _instanceNameErrorText = string.Empty;

    /// <summary>实例名称是否有校验错误</summary>
    public bool HasInstanceNameError => !string.IsNullOrEmpty(InstanceNameErrorText);

    /// <summary>实例名称是否合法无冲突（供下一步按钮判断）</summary>
    public bool IsInstanceNameValid =>
        !string.IsNullOrWhiteSpace(InstanceName) && !HasInstanceNameError;

    [ObservableProperty]
    private InstanceType _instanceType = InstanceType.UserInstance;

        // ===== 步骤 2: 选择方案 =====
    [ObservableProperty]
    private ObservableCollection<Scheme> _availableSchemes = new();

        /// <summary>是否已选择至少一个方案（控制下一步按钮和提示）</summary>
    [ObservableProperty]
    private bool _hasSelectedSchemes = false;

        // ===== 步骤 3: 选择令牌 =====
    [ObservableProperty]
    private ObservableCollection<Token> _availableTokens = new();

    [ObservableProperty]
    private ObservableCollection<SchemeTokenBinding> _selectedSchemeTokenBindings = new();

    /// <summary>是否使用统一认证模式</summary>
    [ObservableProperty]
    private bool _useDomainAccount = false;

    /// <summary>AD 域可用令牌列表</summary>
    [ObservableProperty]
    private ObservableCollection<Token> _domainTokens = new();

    /// <summary>当前选中的 AD 域令牌</summary>
    [ObservableProperty]
    private Token? _selectedDomainToken;

    /// <summary>提示文字：显示当前选中 AD 域令牌状态</summary>
    [ObservableProperty]
    private string _domainTokenStatusText = "未选择域账户令牌";

    /// <summary>是否使用普通模式（每个方案单独配令牌）</summary>
    public bool IsNormalTokenMode => !UseDomainAccount;

    /// <summary>是否使用 AD 域账户模式</summary>
    public bool IsDomainAccountMode => UseDomainAccount;

    public InstanceEditorViewModel(
        IInstanceService instanceService,
        ISchemeService schemeService,
        ITokenService tokenService,
        INavigationService navigationService,
        ILoginService loginService,
        ViewModels.Controls.LeftFunctionBarViewModel leftFunctionBar)
    {
        _instanceService = instanceService;
        _schemeService = schemeService;
        _tokenService = tokenService;
        _navigationService = navigationService;
        _loginService = loginService;
        _leftFunctionBar = leftFunctionBar;

        // 订阅左侧栏的页面类型变化，用于离开确认
        leftFunctionBar.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(leftFunctionBar.CurrentPageType))
            {
                // 当导航离开编辑器页面时，重置向导状态
                if (leftFunctionBar.CurrentPageType != typeof(Views.Pages.InstanceEditorPage))
                {
                    leftFunctionBar.IsEditorInProgress = false;
                }
            }
        };

        InitializeSteps();
    }

    /// <summary>
    /// 在页面导航完成后初始化（接收 InstanceType 参数）
    /// </summary>
    public void InitializeWithType(InstanceType type)
    {
        InstanceType = type;
        HasAgreedToLicense = false;
        _leftFunctionBar.IsEditorInProgress = false;
        RemainingSeconds = 5;
        InstanceName = string.Empty;
        InstanceNameErrorText = string.Empty;
        OnPropertyChanged(nameof(CanAgree));
        OnPropertyChanged(nameof(AgreeButtonText));

        // 重置到第 0 步
        CurrentStep = 0;
        OnPropertyChanged(nameof(IsStep0Visible));
        OnPropertyChanged(nameof(IsStep1Visible));
        OnPropertyChanged(nameof(IsStep2Visible));
        OnPropertyChanged(nameof(IsStep3Visible));
        OnPropertyChanged(nameof(IsNotFirstStep));
        OnPropertyChanged(nameof(IsLastStep));
        OnPropertyChanged(nameof(NextButtonText));
        OnPropertyChanged(nameof(StepIndicatorText));
        OnPropertyChanged(nameof(WizardTitle));
        OnPropertyChanged(nameof(InstanceTypeDisplayText));
        UpdateStepStates();

        LoadData();
    }

    private void InitializeSteps()
    {
        Steps = new ObservableCollection<StepItem>
        {
            new() { Number = "0", Title = "许可协议" },
            new() { Number = "1", Title = "输入名称" },
            new() { Number = "2", Title = "链接方案" },
            new() { Number = "3", Title = "绑定令牌" },
        };

        // 初始化为第 0 步激活，其余灰色
        UpdateStepStates();
    }

    private void LoadData()
    {
        var schemes = _schemeService.GetSchemesByInstanceType(InstanceType).ToList();

        // 主动填充封面图标缓存路径（LiteDB 不持久化 CoverImageUrl）
        try
        {
            var iconCache = App.Services.GetRequiredService<SchemeIconCacheService>();
            foreach (var s in schemes)
                s.CoverImageUrl = iconCache.GetCachedIconUrl(s.Name);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[InstanceEditorVM] 填充封面图标失败: {ex.Message}");
        }

        AvailableSchemes = new ObservableCollection<Scheme>(schemes);

                var tokens = _tokenService.GetTokensByUser(_loginService.CurrentUserId);
        AvailableTokens = new ObservableCollection<Token>(tokens);

        // 域账户模式显示 AD 域账户 + 默认令牌两种类型
        DomainTokens = new ObservableCollection<Token>(
            tokens.Where(t => t.TokenType == TokenType.ADDomain || t.TokenType == TokenType.Default));

        // 自动预选默认令牌
        var defaultToken = DomainTokens.FirstOrDefault(t => t.TokenType == TokenType.Default);
        SelectedDomainToken = defaultToken ?? DomainTokens.FirstOrDefault();
        if (SelectedDomainToken == null)
        {
            DomainTokenStatusText = "暂无可用的令牌，请先在令牌管理器创建";
        }
    }

    /// <summary>
    /// 切换 AD 域账户模式时，更新界面可见性和绑定状态
    /// </summary>
    partial void OnUseDomainAccountChanged(bool value)
    {
        OnPropertyChanged(nameof(IsNormalTokenMode));
        OnPropertyChanged(nameof(IsDomainAccountMode));

        if (value)
        {
            foreach (var binding in SelectedSchemeTokenBindings)
                binding.SelectedToken = null;

            if (SelectedDomainToken == null)
                SelectedDomainToken = DomainTokens.FirstOrDefault();
        }
        else
        {
            // 切回单独认证：恢复默认令牌
            var defaultToken = AvailableTokens.FirstOrDefault(t => t.TokenType == TokenType.Default);
            foreach (var binding in SelectedSchemeTokenBindings)
                binding.SelectedToken = defaultToken;
        }

        NextStepCommand.NotifyCanExecuteChanged();
    }

    /// <summary>
    /// 当选中的 AD 域令牌变化时更新状态文字
    /// </summary>
    partial void OnSelectedDomainTokenChanged(Token? value)
    {
        DomainTokenStatusText = value != null
            ? $"已绑定域账户：{value.Name}"
            : "未选择域账户令牌";
    }

        /// <summary>
    /// 当方案选择变化时，同步令牌绑定列表
    /// UI 点击卡片后调用此方法刷新下一步按钮状态
    /// </summary>
    public void NotifySchemeSelectionChanged()
    {
        var selectedSchemeIds = AvailableSchemes
            .Where(s => s.IsSelected)
            .Select(s => s.Id)
            .ToHashSet();

        // 移除不再选中的方案
        for (int i = SelectedSchemeTokenBindings.Count - 1; i >= 0; i--)
        {
            if (!selectedSchemeIds.Contains(SelectedSchemeTokenBindings[i].Scheme.Id))
            {
                SelectedSchemeTokenBindings.RemoveAt(i);
            }
        }

        // 默认令牌（系统内置占位符）
        var defaultToken = AvailableTokens.FirstOrDefault(t => t.TokenType == TokenType.Default);

        // 添加新选中的方案
        foreach (var scheme in AvailableSchemes.Where(s => s.IsSelected))
        {
            if (!SelectedSchemeTokenBindings.Any(b => b.Scheme.Id == scheme.Id))
            {
                var binding = new SchemeTokenBinding
                {
                    Scheme = scheme,
                    AvailableTokens = AvailableTokens,
                };
                // 自动预设默认令牌，确保不会出现空令牌绑定
                if (defaultToken != null)
                {
                    binding.SelectedToken = defaultToken;
                }
                binding.PropertyChanged += (_, _) => NextStepCommand.NotifyCanExecuteChanged();
                SelectedSchemeTokenBindings.Add(binding);
            }
        }

        HasSelectedSchemes = SelectedSchemeTokenBindings.Count > 0;

        // 通知下一步按钮重新评估可点击状态
        NextStepCommand.NotifyCanExecuteChanged();
    }

    // ===== 模式切换命令 =====

    [RelayCommand]
    private void SwitchToNormalMode()
    {
        UseDomainAccount = false;
    }

    [RelayCommand]
    private void SwitchToDomainMode()
    {
        UseDomainAccount = true;
    }

        // ===== 步骤导航命令 =====

    /// <summary>
    /// 控制下一步按钮是否可点击
    /// 第0步：必须已点击"同意"；第1步：名称合法且无冲突；第2步：必须选择至少一个方案
    /// </summary>
    private bool CanNextStep()
    {
        if (CurrentStep == 0)
        {
            return HasAgreedToLicense;
        }

        if (CurrentStep == 1)
        {
            return IsInstanceNameValid;
        }

        if (CurrentStep == 2)
        {
            return AvailableSchemes.Any(s => s.IsSelected);
        }

        // 第3步（绑定令牌）：所有方案必须链接令牌，且统一认证时必须选择域令牌
        if (CurrentStep == 3)
        {
            if (UseDomainAccount)
            {
                return SelectedDomainToken != null;
            }
            return SelectedSchemeTokenBindings.Count > 0 &&
                   SelectedSchemeTokenBindings.All(b => b.SelectedToken != null);
        }

        return true;
    }

    /// <summary>
    /// 文件名不允许包含的字符
    /// </summary>
    private static readonly HashSet<char> ForbiddenNameChars = new(@"#\/*:?""<>|");

    /// <summary>
    /// InstanceName 变化时实时校验并更新错误提示
    /// </summary>
    partial void OnInstanceNameChanged(string value)
    {
        ValidateInstanceName(value);
        NextStepCommand.NotifyCanExecuteChanged();
        OnPropertyChanged(nameof(IsInstanceNameValid));
        OnPropertyChanged(nameof(HasInstanceNameError));
    }

    private void ValidateInstanceName(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            InstanceNameErrorText = string.Empty;
            return;
        }

        // 检查空格
        if (name.Contains(' '))
        {
            InstanceNameErrorText = "名称不能包含空格";
            return;
        }

        // 检查文件名非法字符
        if (name.Any(c => ForbiddenNameChars.Contains(c)))
        {
            InstanceNameErrorText = "名称不能包含下列特殊字符：# \\ / : * ? \" < > |";
            return;
        }

        // 检查是否与现有实例重名
        var userId = _loginService?.CurrentUserId ?? Guid.Empty;
        var allInstances = _instanceService?.GetInstancesByUser(userId);
        if (allInstances != null && allInstances.Any(i =>
            i?.Name != null && i.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
        {
            InstanceNameErrorText = "该名称已被其他实例使用，请换一个名称";
            return;
        }

        // 全部通过
        InstanceNameErrorText = string.Empty;
    }

    /// <summary>
    /// InstanceNameErrorText 变化时刷新 HasInstanceNameError
    /// </summary>
    partial void OnInstanceNameErrorTextChanged(string value)
    {
        OnPropertyChanged(nameof(HasInstanceNameError));
        OnPropertyChanged(nameof(IsInstanceNameValid));
    }

    /// <summary>
    /// "同意许可协议"按钮命令 — 标记已同意并通知左侧栏进入向导状态
    /// </summary>
    [RelayCommand]
    private void AgreeLicense()
    {
        HasAgreedToLicense = true;
        _leftFunctionBar.IsEditorInProgress = true;
    }

    /// <summary>
    /// HasAgreedToLicense 变化时刷新下一步按钮状态及关联属性
    /// </summary>
    partial void OnHasAgreedToLicenseChanged(bool value)
    {
        NextStepCommand.NotifyCanExecuteChanged();
        OnPropertyChanged(nameof(CanAgree));
        OnPropertyChanged(nameof(AgreeButtonText));
        OnPropertyChanged(nameof(IsLicenseAgreed));
        OnPropertyChanged(nameof(HasNotAgreed));
    }

    /// <summary>
    /// RemainingSeconds 变化时刷新按钮状态和文字
    /// </summary>
    partial void OnRemainingSecondsChanged(int value)
    {
        OnPropertyChanged(nameof(CanAgree));
        OnPropertyChanged(nameof(AgreeButtonText));
    }

    /// <summary>
    /// CurrentStep 变化时刷新步骤可见性、下一步按钮及进度条
    /// </summary>
    partial void OnCurrentStepChanged(int value)
    {
        OnPropertyChanged(nameof(IsStep0Visible));
        OnPropertyChanged(nameof(IsStep1Visible));
        OnPropertyChanged(nameof(IsStep2Visible));
        OnPropertyChanged(nameof(IsStep3Visible));
        OnPropertyChanged(nameof(IsNotFirstStep));
        OnPropertyChanged(nameof(IsLastStep));
        OnPropertyChanged(nameof(NextButtonText));
        OnPropertyChanged(nameof(StepIndicatorText));
        NextStepCommand.NotifyCanExecuteChanged();
        OnPropertyChanged(nameof(ProgressBarWidthPercent));
    }

    [RelayCommand(CanExecute = nameof(CanNextStep))]
    private void NextStep()
    {
        if (IsLastStep)
        {
            Save();
            return;
        }

        // 步骤 2 → 3：同步令牌绑定
        if (CurrentStep == 2)
        {
            NotifySchemeSelectionChanged();
        }

        CurrentStep++;
        OnPropertyChanged(nameof(IsStep0Visible));
        OnPropertyChanged(nameof(IsStep1Visible));
        OnPropertyChanged(nameof(IsStep2Visible));
        OnPropertyChanged(nameof(IsStep3Visible));
        OnPropertyChanged(nameof(IsNotFirstStep));
        OnPropertyChanged(nameof(IsLastStep));
        OnPropertyChanged(nameof(NextButtonText));
        OnPropertyChanged(nameof(StepIndicatorText));
        UpdateStepStates();
    }

    [RelayCommand]
    private void PreviousStep()
    {
        if (CurrentStep <= 0) return;

        CurrentStep--;
        OnPropertyChanged(nameof(IsStep0Visible));
        OnPropertyChanged(nameof(IsStep1Visible));
        OnPropertyChanged(nameof(IsStep2Visible));
        OnPropertyChanged(nameof(IsStep3Visible));
        OnPropertyChanged(nameof(IsNotFirstStep));
        OnPropertyChanged(nameof(IsLastStep));
        OnPropertyChanged(nameof(NextButtonText));
        OnPropertyChanged(nameof(StepIndicatorText));
        UpdateStepStates();
    }

    private void UpdateStepStates()
    {
        for (int i = 0; i < Steps.Count; i++)
        {
            Steps[i].IsActive = i == CurrentStep;
            Steps[i].IsCompleted = i < CurrentStep;
        }
    }

    [RelayCommand]
    private void Save()
    {
        if (string.IsNullOrWhiteSpace(InstanceName))
        {
            // 跳转到第 1 步（输入名称），提示用户输入名称
            CurrentStep = 1;
            OnPropertyChanged(nameof(IsStep0Visible));
            OnPropertyChanged(nameof(IsStep1Visible));
            OnPropertyChanged(nameof(IsStep2Visible));
            OnPropertyChanged(nameof(IsStep3Visible));
            OnPropertyChanged(nameof(IsNotFirstStep));
            OnPropertyChanged(nameof(IsLastStep));
            OnPropertyChanged(nameof(NextButtonText));
            OnPropertyChanged(nameof(StepIndicatorText));
            return;
        }

                var instance = _instanceService.CreateInstance(InstanceName, InstanceType, _loginService.CurrentUserId);

        if (UseDomainAccount && SelectedDomainToken != null)
        {
            // AD 域模式：所有方案统一使用同一个域令牌
            foreach (var binding in SelectedSchemeTokenBindings)
            {
                _instanceService.AddSchemeToInstance(
                    instance.Id,
                    binding.Scheme.Id,
                    SelectedDomainToken.Id);
            }
        }
        else
        {
            // 普通模式：每个方案使用各自选择的令牌
            // 如果某个方案未选令牌（null），使用默认令牌 ID 作为兜底
            var defaultTokenId = AvailableTokens
                .FirstOrDefault(t => t.TokenType == TokenType.Default)?.Id;
            foreach (var binding in SelectedSchemeTokenBindings)
            {
                _instanceService.AddSchemeToInstance(
                    instance.Id,
                    binding.Scheme.Id,
                    binding.SelectedToken?.Id ?? defaultTokenId);
            }
        }

        // 创建完成后返回主页
        _navigationService.NavigateTo(typeof(Views.Pages.MainPage));
        _leftFunctionBar.SetActivePage(quickStart: true);
    }
}

/// <summary>
/// 步骤指示器数据项
/// </summary>
public partial class StepItem : ObservableObject
{
    [ObservableProperty]
    private string _number = string.Empty;

    [ObservableProperty]
    private string _title = string.Empty;

    [ObservableProperty]
    private bool _isActive;

    [ObservableProperty]
    private bool _isCompleted;

    // ===== 步骤指示器状态色（由 IsActive / IsCompleted 计算） =====
    // 使用主题资源键（如 "SystemAccentColor"），由 StringToBrushConverter 解析

    /// <summary>圆点背景色（十六进制或主题资源键）</summary>
    public string IndicatorBackground =>
        IsCompleted ? "#2ECC71" : IsActive ? "SystemAccentColor" : "#D0D0D0";

    /// <summary>圆点边框色</summary>
    public string IndicatorBorder =>
        IsCompleted ? "#2ECC71" : IsActive ? "SystemAccentColor" : "#B0B0B0";

    /// <summary>圆点数字色</summary>
    public string IndicatorForeground =>
        IsCompleted || IsActive ? "#FFFFFF" : "#999999";

    /// <summary>标题文字色</summary>
    public string TitleForeground =>
        IsCompleted ? "#2ECC71" : IsActive ? "SystemAccentColor" : "#999999";

    partial void OnIsActiveChanged(bool value) => NotifyColors();
    partial void OnIsCompletedChanged(bool value) => NotifyColors();

    private void NotifyColors()
    {
        OnPropertyChanged(nameof(IndicatorBackground));
        OnPropertyChanged(nameof(IndicatorBorder));
        OnPropertyChanged(nameof(IndicatorForeground));
        OnPropertyChanged(nameof(TitleForeground));
    }
}

/// <summary>
/// 方案与令牌绑定关系（步骤 3 使用）
/// </summary>
public partial class SchemeTokenBinding : ObservableObject
{
    [ObservableProperty]
    private Scheme _scheme = null!;

    [ObservableProperty]
    private Token? _selectedToken;

    [ObservableProperty]
    private ObservableCollection<Token> _availableTokens = new();

    public string TokenStatusText =>
        SelectedToken != null ? $"已绑定：{SelectedToken.Name}" : "未绑定令牌";
}
