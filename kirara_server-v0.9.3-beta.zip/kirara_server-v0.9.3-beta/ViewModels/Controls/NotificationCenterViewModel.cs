using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml.Media.Imaging;

namespace Kirara_Server_WinUI.ViewModels.Controls;

/// <summary>
/// 通知中心 ViewModel — 管理三标签页（信息流 / 服务通知 / 日志通知）
/// 订阅 INotificationService 和 ILoggingService 实时接收通知
///
/// ## 信息流标签（Tab0）— 原生控件渲染
/// - FlipView 原生轮播（支持触控滑动）
/// - MediaPlayerElement 循环播放视频（静音、无控件）
/// - Image 原生图片渲染 + WebView2（仅 HTML 卡片）
/// - 半透明遮罩显示标题/摘要/时间
/// </summary>
public partial class NotificationCenterViewModel : ObservableObject
{
    private readonly Services.INotificationService _notificationService;
    private readonly Services.ILoggingService _loggingService;
    private readonly Services.RemoteNotificationService _remoteNotificationService;
    private readonly Services.LocalNotificationStore _localStore;
    private readonly RemoteInfoCardService _remoteInfoCardService;
    private readonly SecureCacheService _secureCache;
    private readonly DispatcherQueue _dispatcherQueue;

    /// <summary>本地媒体缓存目录</summary>
    private static readonly string MediaCacheDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "info_cards_media");

    /// <summary>本地媒体缓存目录（公开，供外部检查）</summary>
    public static string MediaCacheDirectory => MediaCacheDir;

    // ===== 信息流原生卡片集合 =====

    /// <summary>信息流卡片 ViewModel 集合（供 FlipView ItemsSource 绑定）</summary>
    [ObservableProperty]
    private ObservableCollection<InfoCardViewModel> _cards = new();

    /// <summary>FlipView 选中索引（TwoWay 绑定，与 CurrentCardIndex 同步）</summary>
    [ObservableProperty]
    private int _selectedCardIndex;

    /// <summary>防止索引同步递归</summary>
    private bool _isIndexSyncing;

    // ===== 点状指示器 =====

    /// <summary>点状导航指示器集合（每个元素是 active/inactive 状态）</summary>
    public ObservableCollection<DotState> CardDots { get; } = new();

    partial void OnSelectedCardIndexChanged(int value)
    {
        if (_isIndexSyncing) return;
        _isIndexSyncing = true;
        CurrentCardIndex = value;
        _isIndexSyncing = false;
    }

    // ===== Tab 状态 =====

    // ===== Tab1: 消息推送（信息流） =====

    [ObservableProperty]
    private ObservableCollection<Services.AppNotification> _pushNotifications = new();

    // ===== Tab2: 服务通知 =====

    [ObservableProperty]
    private ObservableCollection<Services.AppNotification> _serviceNotifications = new();

    // ===== Tab3: 日志通知 =====

    [ObservableProperty]
    private ObservableCollection<LogEntry> _logEntries = new();

    // ===== 信息流原生卡片渲染 =====

    /// <summary>当前卡片索引（0-based），与 FlipView.SelectedIndex 双向绑定</summary>
    [ObservableProperty]
    private int _currentCardIndex;

    /// <summary>卡片总数</summary>
    [ObservableProperty]
    private int _cardCount;

    /// <summary>当前卡片索引显示文本（如 "1 / 3"）</summary>
    public string CardIndexText => CardCount > 0 ? $"{CurrentCardIndex + 1} / {CardCount}" : "0 / 0";

    /// <summary>是否有上一张（控制左按钮启用状态）</summary>
    public bool HasPrevCard => CurrentCardIndex > 0;

    /// <summary>是否有下一张（控制右按钮启用状态）</summary>
    public bool HasNextCard => CurrentCardIndex < CardCount - 1;

    /// <summary>是否有卡片可显示</summary>
    public bool HasCards => CardCount > 0;

    /// <summary>当前卡片标题（用于半透明遮罩）</summary>
    [ObservableProperty]
    private string _currentCardTitle = string.Empty;

    /// <summary>当前卡片摘要</summary>
    [ObservableProperty]
    private string _currentCardSummary = string.Empty;

    /// <summary>当前卡片时间</summary>
    [ObservableProperty]
    private string _currentCardTime = string.Empty;

    // ===== 未读计数 =====

    public int PushUnreadCount => PushNotifications.Count(n => !n.IsRead);
    public int ServiceUnreadCount => ServiceNotifications.Count(n => !n.IsRead);

    /// <summary>信息流标签是否有未读项（用于标签栏绿点）</summary>
    public bool HasUnreadPushItems => PushUnreadCount > 0;

    /// <summary>服务项标签是否有未读项（用于标签栏绿点）</summary>
    public bool HasUnreadServiceItems => ServiceUnreadCount > 0;

    /// <summary>是否可以执行「全部已读」（当前标签为服务项 且 有未读项）</summary>
    public bool CanMarkAllRead => SelectedTabIndex == 1 && ServiceUnreadCount > 0;

    /// <summary>当前是否为服务项标签（用于控制「全部已读」按钮的显隐）</summary>
    public bool IsServiceTabSelected => SelectedTabIndex == 1;

    /// <summary>当前是否为信息流标签</summary>
    public bool IsPushTabSelected => SelectedTabIndex == 0;

    /// <summary>当前选中的标签索引（0=信息流, 1=服务项, 2=日志项）</summary>
    [ObservableProperty]
    private int _selectedTabIndex;

    /// <summary>当前标签页是否允许清除（信息流标签移除此功能）</summary>
    public bool IsCurrentTabEmpty => SelectedTabIndex switch
    {
        0 => true,
        1 => IsServiceEmpty,
        2 => IsLogEmpty,
        _ => true,
    };

    /// <summary>当前标签页是否有内容可清除（IsCurrentTabEmpty 的反向）</summary>
    public bool HasCurrentTabItems => !IsCurrentTabEmpty;

    /// <summary>是否显示清除按钮（信息流标签隐藏）</summary>
    public bool CanShowClearButton => SelectedTabIndex != 0;

    partial void OnSelectedTabIndexChanged(int value)
    {
        OnPropertyChanged(nameof(IsCurrentTabEmpty));
        OnPropertyChanged(nameof(HasCurrentTabItems));
        OnPropertyChanged(nameof(CanMarkAllRead));
        OnPropertyChanged(nameof(IsServiceTabSelected));
        OnPropertyChanged(nameof(IsPushTabSelected));
        OnPropertyChanged(nameof(CanShowClearButton));
    }

    partial void OnCurrentCardIndexChanged(int value)
    {
        if (_isIndexSyncing) return;
        _isIndexSyncing = true;
        SelectedCardIndex = value;
        _isIndexSyncing = false;

        OnPropertyChanged(nameof(CardIndexText));
        OnPropertyChanged(nameof(HasPrevCard));
        OnPropertyChanged(nameof(HasNextCard));
        UpdateCurrentCardProperties();
        UpdateDots();
    }

    partial void OnCardCountChanged(int value)
    {
        OnPropertyChanged(nameof(CardIndexText));
        OnPropertyChanged(nameof(HasPrevCard));
        OnPropertyChanged(nameof(HasNextCard));
        OnPropertyChanged(nameof(HasCards));
        OnPropertyChanged(nameof(IsPushEmpty));
        RebuildDots();
    }

    // ===== 空状态（供 XAML x:Bind 使用） =====

    public bool IsPushEmpty => CardCount == 0;
    public bool IsServiceEmpty => ServiceNotifications.Count == 0;
    public bool IsLogEmpty => LogEntries.Count == 0;

    public NotificationCenterViewModel(
        Services.INotificationService notificationService,
        Services.ILoggingService loggingService,
        Services.RemoteNotificationService remoteNotificationService,
        Services.LocalNotificationStore localStore,
        RemoteInfoCardService remoteInfoCardService,
        SecureCacheService secureCache)
    {
        _notificationService = notificationService;
        _loggingService = loggingService;
        _remoteNotificationService = remoteNotificationService;
        _localStore = localStore;
        _remoteInfoCardService = remoteInfoCardService;
        _secureCache = secureCache;

        _dispatcherQueue = DispatcherQueue.GetForCurrentThread();

        // 订阅实时通知
        _notificationService.OnNotificationReceived += OnNotificationReceived;
        _loggingService.OnLogAdded += OnLogAdded;

        // 订阅远程信息流卡片刷新
        _remoteInfoCardService.CardsRefreshed += OnCardsRefreshed;

        // 订阅用户会话结束（登出）：清空当前用户的服务通知集合，防止多用户先后登录时状态残留
        _remoteNotificationService.SessionEnded += OnSessionEnded;

        // 加载已有数据
        LoadExistingData();

        // 加载信息流卡片
        _ = ReloadCardsAsync();
    }

    /// <summary>
    /// 加载已有通知和日志
    /// </summary>
    private void LoadExistingData()
    {
        // 消息推送
        var pushItems = _notificationService.GetNotifications(NotificationCategory.Push);
        PushNotifications = new ObservableCollection<Services.AppNotification>(pushItems);

        // 服务通知
        var serviceItems = _notificationService.GetNotifications(NotificationCategory.Service);
        ServiceNotifications = new ObservableCollection<Services.AppNotification>(serviceItems);

        // 日志
        var logs = _loggingService.GetLogs();
        LogEntries = new ObservableCollection<LogEntry>(logs);
    }

    // ================================================================
    //  信息流原生控件渲染（FlipView + MediaPlayerElement + Image + WebView2）
    // ================================================================

    private void OnCardsRefreshed()
    {
        _dispatcherQueue.TryEnqueue(() => _ = ReloadCardsAsync());
    }

    /// <summary>
    /// 释放所有信息流卡片的媒体资源引用（ImageSource / HtmlContent / VideoPath 置空），
    /// 由 MainPage.OnNavigatedFrom 在切出首页时调用，让 BitmapImage 等解码内存可被 GC 回收。
    /// 原始数据仍保留在 RemoteInfoCardService 的 DTO 缓存中，
    /// 切回首页时 ReloadCardsAsync 会从本地缓存重建全部媒体资源，数据不丢失。
    /// </summary>
    public void ReleaseMediaResources()
    {
        foreach (var vm in Cards)
        {
            vm.ImageSource = null;
            vm.HtmlContent = null;
            vm.VideoPath = null;
        }
        System.Diagnostics.Debug.WriteLine(
            $"[NotificationCenterVM] 已释放 {Cards.Count} 张卡片媒体资源引用");
    }

    /// <summary>
    /// 从 RemoteInfoCardService 加载缓存数据 → 构建 InfoCardViewModel 集合 → 后台下载媒体。
    /// 首次立即显示（本地缓存命中则秒显，否则显示占位），下载完成后自动刷新绑定。
    /// </summary>
    public async Task ReloadCardsAsync()
    {
        try
        {
            var rawCards = _remoteInfoCardService.GetCachedCards();

            if (rawCards.Count == 0)
            {
                Cards.Clear();
                CardCount = 0;
                CurrentCardTitle = CurrentCardSummary = CurrentCardTime = string.Empty;
                CurrentCardIndex = 0;
                return;
            }

            // 构建 InfoCardViewModel 列表，尝试从本地缓存立即命中
            var vms = new List<InfoCardViewModel>(rawCards.Count);
            foreach (var raw in rawCards)
            {
                var isHtml = (raw.MediaType ?? "image").Equals("html", StringComparison.OrdinalIgnoreCase);
                var vm = new InfoCardViewModel
                {
                    CardId = raw.Id,
                    Title = raw.Title,
                    Summary = raw.Summary ?? string.Empty,
                    Time = raw.CreatedAt.ToLocalTime().ToString("yyyy-MM-dd HH:mm"),
                    MediaType = (raw.MediaType ?? "image").ToLowerInvariant(),
                    ExternalUrl = raw.ExternalUrl,
                };
                await TryLoadLocalCacheAsync(vm, raw.Version);
                vms.Add(vm);
            }

            // 保留当前索引（刷新时不跳回第一张）
            int savedIndex = CurrentCardIndex;
            if (savedIndex >= vms.Count) savedIndex = 0;

            // [修复] 原地更新集合而非替换实例：
            // x:Bind 默认 OneTime 时，替换 Cards 实例后 FlipView 不刷新（切回首页空白）。
            // 即使 XAML 已加 Mode=OneWay，原地 Clear+Add 也是更稳的做法：
            // FlipView 监听同一实例的 CollectionChanged，与绑定模式无关。
            Cards.Clear();
            foreach (var vm in vms)
            {
                Cards.Add(vm);
            }
            CardCount = vms.Count;

            CurrentCardIndex = savedIndex;
            UpdateCurrentCardProperties();

            System.Diagnostics.Debug.WriteLine(
                $"[NotificationCenterVM] 加载 {vms.Count} 条原生卡片, 当前 #{CurrentCardIndex}");

            // ★ 后台下载媒体（fire-and-forget，不阻塞 UI 渲染）
            //    卡片已从缓存秒显，媒体文件异步下载完成后自动刷新绑定
            _ = DownloadAndRefreshAsync(rawCards, vms);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[NotificationCenterVM] 卡片加载失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 从本地缓存加载媒体到 InfoCardViewModel（精确版本匹配）。
    /// HTML 内容使用异步文件读取，避免阻塞 UI 线程。
    /// </summary>
    private async Task TryLoadLocalCacheAsync(InfoCardViewModel vm, int version)
    {
        if (vm.IsVideo)
        {
            var mediaPath = GetCachedPath(vm.CardId, version, "media");
            if (mediaPath != null)
            {
                vm.VideoPath = mediaPath;
            }
        }
        else if (vm.IsHtml)
        {
            // HTML 卡片：异步加载缓存的 HTML 文件内容
            var htmlPath = GetCachedPath(vm.CardId, version, "media");
            if (htmlPath != null)
            {
                try { vm.HtmlContent = await File.ReadAllTextAsync(htmlPath); } catch { }
            }
        }
        else
        {
            // 图片卡片：加载 media 作为背景图
            var path = GetCachedPath(vm.CardId, version, "media");
            if (path != null)
            {
                try { vm.ImageSource = new BitmapImage(new Uri(path)); } catch { }
            }
        }
    }

    /// <summary>
    /// 后台下载所有卡片的媒体文件，完成后回写 InfoCardViewModel 属性触发 UI 刷新。
    /// </summary>
    private async Task DownloadAndRefreshAsync(
        IReadOnlyList<InfoCardResponseData> rawCards,
        List<InfoCardViewModel> vms)
    {
        if (!Directory.Exists(MediaCacheDir))
            Directory.CreateDirectory(MediaCacheDir);

        bool anyUpdated = false;

        for (int i = 0; i < rawCards.Count; i++)
        {
            var raw = rawCards[i];
            var vm = vms[i];

            if (vm.IsVideo)
            {
                if (await DownloadOneAsync(raw.Id, raw.Version, "media"))
                {
                    var path = GetCachedPath(raw.Id, raw.Version, "media");
                    if (path != null)
                    {
                        _dispatcherQueue.TryEnqueue(() => vm.VideoPath = path);
                        anyUpdated = true;
                    }
                }
            }
            else if (vm.IsHtml)
            {
                // HTML 卡片：下载 HTML 文件到缓存，然后读取内容
                if (await DownloadOneAsync(raw.Id, raw.Version, "media"))
                {
                    var path = GetCachedPath(raw.Id, raw.Version, "media");
                    if (path != null)
                    {
                        _dispatcherQueue.TryEnqueue(async () =>
                        {
                            try { vm.HtmlContent = await File.ReadAllTextAsync(path); } catch { }
                        });
                        anyUpdated = true;
                    }
                }
            }
            else
            {
                // 图片卡片
                if (await DownloadOneAsync(raw.Id, raw.Version, "media"))
                {
                    var path = GetCachedPath(raw.Id, raw.Version, "media");
                    if (path != null)
                    {
                        _dispatcherQueue.TryEnqueue(() =>
                        {
                            // ★ [修复] 仅当 ImageSource 尚未加载时才赋值：
                            //   TryLoadLocalCacheAsync 已成功加载时，此处重复创建同 Uri 的新 BitmapImage
                            //   在 WinUI3 Release 时序下可能解码失败（切出首页再切回后图片空白，Debug 正常）。
                            //   缓存已命中即复用现有实例，避免同 Uri 重复解码。
                            if (vm.ImageSource == null)
                            {
                                try { vm.ImageSource = new BitmapImage(new Uri(path)); } catch { }
                            }
                        });
                        anyUpdated = true;
                    }
                }
            }
        }

        if (anyUpdated)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[NotificationCenterVM] 媒体下载完成，已刷新 {vms.Count} 条卡片");
        }
    }

    /// <summary>
    /// 点击圆点切换到指定卡片。
    /// <summary>
    /// 点击圆点切换到指定卡片。
    /// </summary>
    [RelayCommand]
    private void SelectCard(int index)
    {
        if (index >= 0 && index < CardCount)
            CurrentCardIndex = index;
    }

    /// <summary>
    /// 切换到上一张卡片。
    /// </summary>
    [RelayCommand]
    private void PrevCard()
    {
        if (CurrentCardIndex <= 0) return;
        CurrentCardIndex--;
    }

    /// <summary>
    /// 切换到下一张卡片。
    /// </summary>
    [RelayCommand]
    private void NextCard()
    {
        if (CurrentCardIndex >= CardCount - 1) return;
        CurrentCardIndex++;
    }

    /// <summary>
    /// FlipView 自动播放：切换到下一张（循环）。供 auto-play timer 调用。
    /// </summary>
    public void AutoPlayNext()
    {
        if (CardCount <= 1) return;
        if (CurrentCardIndex >= CardCount - 1)
            CurrentCardIndex = 0;
        else
            CurrentCardIndex++;
    }

    /// <summary>
    /// 当前卡片变更时同步元数据（标题/摘要/时间）到 CurrentCardTitle 等属性。
    /// </summary>
    private void UpdateCurrentCardProperties()
    {
        if (CurrentCardIndex < 0 || CurrentCardIndex >= Cards.Count)
        {
            CurrentCardTitle = string.Empty;
            CurrentCardSummary = string.Empty;
            CurrentCardTime = string.Empty;
            return;
        }
        var card = Cards[CurrentCardIndex];
        CurrentCardTitle = card.Title;
        CurrentCardSummary = card.Summary;
        CurrentCardTime = card.Time;
    }

    // ===== 点状导航指示器 =====

    /// <summary>
    /// 根据 CardCount 重建点状指示器集合。
    /// </summary>
    private void RebuildDots()
    {
        CardDots.Clear();
        for (int i = 0; i < CardCount; i++)
        {
            CardDots.Add(new DotState { Index = i, IsActive = i == CurrentCardIndex });
        }
    }

    /// <summary>
    /// 当前卡片切换时更新点状指示器高亮状态。
    /// </summary>
    private void UpdateDots()
    {
        for (int i = 0; i < CardDots.Count; i++)
        {
            CardDots[i].IsActive = i == CurrentCardIndex;
        }
    }

    // ================================================================
    //  本地媒体缓存（通过预签名 URL API 下载，文件名含版本号）
    // ================================================================

    /// <summary>
    /// 通过预签名 URL API 下载单张卡片的单个媒体文件。
    /// 版本精确匹配：本地缓存版本与卡片 Version 一致才复用，否则重新下载。
    /// </summary>
    /// <returns>true 表示下载成功或缓存已存在（版本匹配）</returns>
    private async Task<bool> DownloadOneAsync(Guid cardId, int version, string field)
    {
        if (GetCachedPath(cardId, version, field) != null) return true;

        CleanOldMedia(cardId, field);

        try
        {
            var presignedUrl = await _remoteInfoCardService.GetMediaPresignedUrlAsync(cardId, field);
            if (string.IsNullOrEmpty(presignedUrl))
            {
                System.Diagnostics.Debug.WriteLine($"[DownloadOne] ⚠️ 无预签名 URL: {field}/{cardId:N}");
                return false;
            }

            using var client = NetworkClientFactory.Create();
            client.Timeout = TimeSpan.FromSeconds(30);
            using var response = await client.GetAsync(presignedUrl, HttpCompletionOption.ResponseContentRead);
            if (!response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine($"[DownloadOne] ❌ HTTP {(int)response.StatusCode}: {field}/{cardId:N}");
                return false;
            }

            var bytes = await response.Content.ReadAsByteArrayAsync();
            var ext = GuessExtension(response.Content.Headers.ContentType?.MediaType, presignedUrl);
            var cachePath = Path.Combine(MediaCacheDir, $"{cardId:N}_v{version}_{field}{ext}");

            CleanOldMedia(cardId, field);

            // 方案B：内容明文 + 加密 meta（SHA256 + ETag + Version），防篡改
            string? etag = null;
            if (response.Headers.ETag is { } etagHeader && etagHeader.Tag is { } tagValue)
                etag = tagValue.Trim('"');
            _secureCache.SaveWithMeta(cachePath, bytes, etag, version);

            System.Diagnostics.Debug.WriteLine($"[DownloadOne] ✅ {cachePath} ({bytes.Length} bytes)");
            return true;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[DownloadOne] ❌ {field}/{cardId:N}: {ex.Message}");
            return false;
        }
    }

    private static void CleanOldMedia(Guid cardId, string field)
    {
        try
        {
            if (!Directory.Exists(MediaCacheDir)) return;
            foreach (var f in Directory.GetFiles(MediaCacheDir, $"{cardId:N}_v*_{field}.*"))
                try { File.Delete(f); } catch { }
            foreach (var f in Directory.GetFiles(MediaCacheDir, $"{cardId:N}_{field}.*"))
                try { File.Delete(f); } catch { }
        }
        catch { }
    }

    /// <summary>
    /// 查找与指定版本精确匹配的本地媒体缓存路径。
    /// 文件名格式: {cardId:N}_v{version}_{field}.{ext}（DownloadOneAsync 写入时带版本号）。
    /// 版本不匹配（服务端已更新）→ 返回 null → 触发重新下载。
    /// 方案B：解密 meta（被篡改→失败）+ SHA256 校验内容（被篡改→失败），不通过则删除重新下载。
    /// </summary>
    private string? GetCachedPath(Guid cardId, int version, string field)
    {
        try
        {
            if (!Directory.Exists(MediaCacheDir)) return null;
            var files = Directory.GetFiles(MediaCacheDir, $"{cardId:N}_v{version}_{field}.*")
                .Where(f => !f.EndsWith(".meta", StringComparison.OrdinalIgnoreCase))
                .ToArray();
            if (files.Length == 0) return null;
            var file = files[0];
            // 方案B完整性校验：meta 解密失败 / 内容 SHA256 不匹配 → 删除并返回 null（重新下载）
            if (_secureCache.VerifyWithMeta(file))
                return file;
            _secureCache.DeleteWithMeta(file);
            System.Diagnostics.Debug.WriteLine($"[NotificationCenterVM] 媒体缓存被篡改，已删除: {file}");
            return null;
        }
        catch { return null; }
    }

    private static string GuessExtension(string? mimeType, string url)
    {
        if (!string.IsNullOrEmpty(mimeType))
        {
            var ext = mimeType.ToLowerInvariant() switch
            {
                "image/png" => ".png", "image/jpeg" or "image/jpg" => ".jpg",
                "image/webp" => ".webp", "image/gif" => ".gif", "image/bmp" => ".bmp",
                "video/mp4" => ".mp4", "video/webm" => ".webm",
                "video/x-msvideo" => ".avi", "video/x-matroska" => ".mkv",
                "video/quicktime" => ".mov",
                _ => null,
            };
            if (ext != null) return ext;
        }
        var path = url.Split('?')[0];
        var e = Path.GetExtension(path);
        return !string.IsNullOrEmpty(e) ? e : ".bin";
    }

    // ===== 实时事件处理 =====

    /// <summary>
    /// 新通知到达时，按类别加入对应集合
    /// </summary>
    private void OnNotificationReceived(Services.AppNotification notification)
    {
        var queue = DispatcherQueue.GetForCurrentThread();
        if (queue != null && queue.HasThreadAccess)
        {
            AddNotificationToCollection(notification);
        }
        else
        {
            var appQueue = DispatcherQueue.GetForCurrentThread();
            appQueue?.TryEnqueue(() => AddNotificationToCollection(notification));
        }
    }

    private void AddNotificationToCollection(Services.AppNotification notification)
    {
        switch (notification.Category)
        {
            case NotificationCategory.Push:
                PushNotifications.Insert(0, notification);
                OnPropertyChanged(nameof(PushUnreadCount));
                OnPropertyChanged(nameof(HasUnreadPushItems));
                OnPropertyChanged(nameof(IsPushEmpty));
                OnPropertyChanged(nameof(IsCurrentTabEmpty));
                OnPropertyChanged(nameof(HasCurrentTabItems));
                break;
            case NotificationCategory.Service:
                ServiceNotifications.Insert(0, notification);
                OnPropertyChanged(nameof(ServiceUnreadCount));
                OnPropertyChanged(nameof(HasUnreadServiceItems));
                OnPropertyChanged(nameof(CanMarkAllRead));
                OnPropertyChanged(nameof(IsServiceEmpty));
                OnPropertyChanged(nameof(IsCurrentTabEmpty));
                OnPropertyChanged(nameof(HasCurrentTabItems));
                break;
            case NotificationCategory.Log:
                // 日志通过 LoggingService 事件处理
                break;
        }
    }

    /// <summary>
    /// 新日志到达时加入日志集合
    /// </summary>
    private void OnLogAdded(LogEntry entry)
    {
        var queue = DispatcherQueue.GetForCurrentThread();
        if (queue != null && queue.HasThreadAccess)
        {
            LogEntries.Insert(0, entry);
            OnPropertyChanged(nameof(LogEntries));
            OnPropertyChanged(nameof(IsLogEmpty));
            OnPropertyChanged(nameof(IsCurrentTabEmpty));
            OnPropertyChanged(nameof(HasCurrentTabItems));
        }
        else
        {
            queue?.TryEnqueue(() =>
            {
                LogEntries.Insert(0, entry);
                OnPropertyChanged(nameof(LogEntries));
                OnPropertyChanged(nameof(IsLogEmpty));
                OnPropertyChanged(nameof(IsCurrentTabEmpty));
                OnPropertyChanged(nameof(HasCurrentTabItems));
            });
        }
    }

    /// <summary>
    /// 用户登出时清空服务通知集合（v2: 防止下一个登录用户看到上一个用户的通知）。
    /// 内存总线中的 Service 通知已由 RemoteNotificationService 同步清除。
    /// </summary>
    private void OnSessionEnded()
    {
        _dispatcherQueue?.TryEnqueue(() =>
        {
            ServiceNotifications.Clear();
            OnPropertyChanged(nameof(ServiceNotifications));
            OnPropertyChanged(nameof(ServiceUnreadCount));
            OnPropertyChanged(nameof(HasUnreadServiceItems));
            OnPropertyChanged(nameof(CanMarkAllRead));
            OnPropertyChanged(nameof(IsServiceEmpty));
            OnPropertyChanged(nameof(IsCurrentTabEmpty));
            OnPropertyChanged(nameof(HasCurrentTabItems));
        });
    }

    // ===== 命令 =====

    [RelayCommand]
    private void MarkPushAsRead(Guid id)
    {
        _notificationService.MarkAsRead(id);
        OnPropertyChanged(nameof(PushUnreadCount));
        OnPropertyChanged(nameof(HasUnreadPushItems));
    }

    [RelayCommand]
    private async Task MarkServiceAsRead(Guid id)
    {
        _notificationService.MarkAsRead(id);
        OnPropertyChanged(nameof(ServiceUnreadCount));
        OnPropertyChanged(nameof(HasUnreadServiceItems));
        OnPropertyChanged(nameof(CanMarkAllRead));

        // 强制刷新 UI：替换 ObservableCollection 中的项，使 DataTemplate 重新绑定 IsRead
        for (int i = 0; i < ServiceNotifications.Count; i++)
        {
            if (ServiceNotifications[i].Id == id)
            {
                var original = ServiceNotifications[i];
                var updated = new Services.AppNotification
                {
                    Id = original.Id,
                    Category = original.Category,
                    Severity = original.Severity,
                    Title = original.Title,
                    Message = original.Message,
                    HtmlContent = original.HtmlContent,
                    Timestamp = original.Timestamp,
                    IsRead = true,
                    Source = original.Source,
                    // v1.10: 互动通知定位字段（标记已读时保留，防止丢失）
                    ActionType = original.ActionType,
                    ActorUserId = original.ActorUserId,
                    ActorName = original.ActorName,
                    TargetId = original.TargetId,
                    ResourceKey = original.ResourceKey,
                    ContentTitle = original.ContentTitle,
                };
                ServiceNotifications[i] = updated;
                break;
            }
        }

        // 通知服务器同步已读状态
        await _remoteNotificationService.MarkAsReadAsync(id);
    }

    [RelayCommand]
    private async Task MarkAllServiceRead()
    {
        _notificationService.MarkAllAsRead(NotificationCategory.Service);
        OnPropertyChanged(nameof(ServiceUnreadCount));
        OnPropertyChanged(nameof(HasUnreadServiceItems));
        OnPropertyChanged(nameof(CanMarkAllRead));

        // 强制刷新 UI：替换集合中所有项为已读副本
        for (int i = 0; i < ServiceNotifications.Count; i++)
        {
            var original = ServiceNotifications[i];
            var updated = new Services.AppNotification
            {
                Id = original.Id,
                Category = original.Category,
                Severity = original.Severity,
                Title = original.Title,
                Message = original.Message,
                HtmlContent = original.HtmlContent,
                Timestamp = original.Timestamp,
                IsRead = true,
                Source = original.Source,
                // v1.10: 互动通知定位字段（标记已读时保留，防止丢失）
                ActionType = original.ActionType,
                ActorUserId = original.ActorUserId,
                ActorName = original.ActorName,
                TargetId = original.TargetId,
                ResourceKey = original.ResourceKey,
                ContentTitle = original.ContentTitle,
            };
            ServiceNotifications[i] = updated;
        }

        // 通知服务器同步全部已读
        await _remoteNotificationService.MarkAllAsReadAsync();
    }

    [RelayCommand]
    private void ClearAllPush()
    {
        _notificationService.Clear(NotificationCategory.Push);
        PushNotifications.Clear();
        OnPropertyChanged(nameof(PushUnreadCount));
        OnPropertyChanged(nameof(HasUnreadPushItems));
        OnPropertyChanged(nameof(IsPushEmpty));
        OnPropertyChanged(nameof(IsCurrentTabEmpty));
        OnPropertyChanged(nameof(HasCurrentTabItems));
    }

    [RelayCommand]
    private void ClearAllService()
    {
        _notificationService.Clear(NotificationCategory.Service);
        ServiceNotifications.Clear();
        OnPropertyChanged(nameof(ServiceUnreadCount));
        OnPropertyChanged(nameof(HasUnreadServiceItems));
        OnPropertyChanged(nameof(CanMarkAllRead));
        OnPropertyChanged(nameof(IsServiceEmpty));
        OnPropertyChanged(nameof(IsCurrentTabEmpty));
        OnPropertyChanged(nameof(HasCurrentTabItems));
    }

    [RelayCommand]
    private void ClearAllLogs()
    {
        _loggingService.ClearLogs();
        LogEntries.Clear();
        OnPropertyChanged(nameof(LogEntries));
        OnPropertyChanged(nameof(IsLogEmpty));
        OnPropertyChanged(nameof(IsCurrentTabEmpty));
        OnPropertyChanged(nameof(HasCurrentTabItems));
    }

    /// <summary>
    /// 清除当前选中标签页的所有通知/日志。
    /// 与标题栏的「清除」按钮联动，根据 SelectedTabIndex 分派到对应的清除方法。
    /// </summary>
    [RelayCommand]
    private void ClearCurrentTab()
    {
        switch (SelectedTabIndex)
        {
            case 0:
                // 信息流标签不移除清除功能
                break;
            case 1:
                _notificationService.Clear(NotificationCategory.Service);
                ServiceNotifications.Clear();
                OnPropertyChanged(nameof(HasUnreadServiceItems));
                // 清除当前用户的本地通知缓存（ID 记入已清除集合）
                // 重启后已清除的通知不会被重新拉取；服务端 IsRead 仅作状态呈现
                _localStore.Clear();
                OnPropertyChanged(nameof(ServiceUnreadCount));
                OnPropertyChanged(nameof(CanMarkAllRead));
                OnPropertyChanged(nameof(IsServiceEmpty));
                OnPropertyChanged(nameof(IsCurrentTabEmpty));
                OnPropertyChanged(nameof(HasCurrentTabItems));
                break;
            case 2:
                _loggingService.ClearLogs();
                LogEntries.Clear();
                OnPropertyChanged(nameof(LogEntries));
                OnPropertyChanged(nameof(IsLogEmpty));
                OnPropertyChanged(nameof(IsCurrentTabEmpty));
                OnPropertyChanged(nameof(HasCurrentTabItems));
                break;
        }
    }
}

/// <summary>
/// 点状导航指示器状态 — 单个点的 active/inactive 状态。
/// </summary>
public partial class DotState : ObservableObject
{
    /// <summary>圆点对应卡片索引</summary>
    public int Index { get; set; }

    [ObservableProperty]
    private bool _isActive;
}
