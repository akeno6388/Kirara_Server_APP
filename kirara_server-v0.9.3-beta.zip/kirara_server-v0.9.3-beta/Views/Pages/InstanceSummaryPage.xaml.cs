using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Navigation;
using Microsoft.UI.Dispatching;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.ViewModels.Controls;
using Kirara_Server_WinUI.Views.Controls;
using Kirara_Server_WinUI.Views.Instance;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Kirara_Server_WinUI.Views.Pages;

/// <summary>
/// 实例先导页面 — 展示实例的方案和令牌概览，后台预加载所有方案内容
/// 点击"开始工作"后进入预热的 InstanceWorkspace
/// </summary>
public sealed partial class InstanceSummaryPage : Page
{
    private IInstanceService? _instanceService;
    private ISchemeService? _schemeService;
    private ITokenService? _tokenService;
    private ISchemePageCache? _pageCache;
    private INavigationService? _navService;
    private StatusBarViewModel? _statusBarViewModel;

    private Models.Instance? _instance;
    private TaskCompletionSource _statusBarReadyTcs = new();

    /// <summary>卡片总数，达到就绪状态数后启用开始按钮</summary>
    private int _totalCardCount;

    /// <summary>是否正在部署中</summary>
    private bool _isDeploying;

    /// <summary>需要部署的绑定列表（WebView2 自动登录 + OpenVPN 令牌直连/本地凭据，TokenId 可空）</summary>
    private readonly List<(SchemeHostPage Page, SchemeBinding Binding, Guid? TokenId)> _pendingDeployments = new();

    /// <summary>终端就绪状态集合——卡片为此状态时视为"已就绪"</summary>
    private static readonly HashSet<string> _readyStatuses = new(StringComparer.Ordinal)
    {
        "令牌已链接", "令牌已链接(需确认)", "界面加载完成",
        "有通知，令牌链接已中断", "令牌链接失败", "预加载失败",
        "方案已加载",  // 非 WebView2 / 无令牌方案直接视为就绪
        "方案已加载(令牌异常)"  // 令牌已被删除，方案已加载但令牌不可用
    };

    /// <summary>方案卡片显示模型（可观察，支持状态刷新）</summary>
    private sealed class SchemeCardModel : INotifyPropertyChanged
    {
        private string _statusDisplay = "请稍候...";
        public Guid BindingId { get; set; }
        public string IconGlyph { get; set; } = "";
        public string? CoverImageUrl { get; set; }
        public string DisplayName { get; set; } = "";
        public string Description { get; set; } = "";
        public string TokenDisplay { get; set; } = "";

        /// <summary>状态主文字（如"令牌已链接"、"界面加载完成"）</summary>
        public string StatusMainText
        {
            get
            {
                var s = _statusDisplay;
                var idx = s.IndexOf('(');
                return idx > 0 ? s[..idx] : s;
            }
        }

        /// <summary>状态后缀（如"(需确认)"），无后缀时为空</summary>
        public string StatusSuffix
        {
            get
            {
                var s = _statusDisplay;
                var idx = s.IndexOf('(');
                return idx > 0 ? s[idx..] : "";
            }
        }

        public string StatusDisplay
        {
            get => _statusDisplay;
            set
            {
                if (_statusDisplay == value) return;
                _statusDisplay = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(StatusMainText));
                OnPropertyChanged(nameof(StatusSuffix));
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public InstanceSummaryPage()
    {
        InitializeComponent();
    }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        base.OnNavigatedTo(e);

        // ★ 重置状态栏就绪信号，确保每次导航独立等待
        _statusBarReadyTcs = new TaskCompletionSource();

        _instanceService = App.Services.GetRequiredService<IInstanceService>();
        _schemeService = App.Services.GetRequiredService<ISchemeService>();
        _tokenService = App.Services.GetRequiredService<ITokenService>();
        _pageCache = App.Services.GetRequiredService<ISchemePageCache>();
        _navService = App.Services.GetRequiredService<INavigationService>();

        // 启动状态栏后台预热（异步，不阻塞 UI）
        _statusBarViewModel = App.Services.GetRequiredService<StatusBarViewModel>();
        _statusBarViewModel.Initialize();
        _statusBarViewModel.PropertyChanged += OnStatusBarPropertyChanged;

        // 立即触发一次网关 ping 检测，让 VPN 状态尽早显示
        _statusBarViewModel.TriggerImmediateVpnCheck();

        if (e.Parameter is Guid instanceId)
        {
            // 异步加载，页面 UI 立即渲染
            _ = LoadAndPreloadAsync(instanceId);
        }
    }

    protected override void OnNavigatedFrom(NavigationEventArgs e)
    {
        base.OnNavigatedFrom(e);
        if (_statusBarViewModel != null)
            _statusBarViewModel.PropertyChanged -= OnStatusBarPropertyChanged;
        SchemeIconCacheService.SchemeIconsRefreshed -= OnSchemeIconsRefreshed;
    }

    /// <summary>
    /// 方案图标缓存刷新后，重新加载卡片以显示最新封面图标。
    /// </summary>
    private void OnSchemeIconsRefreshed()
    {
        if (_instance == null) return;
        DispatcherQueue.TryEnqueue(() =>
        {
            var iconCache = App.Services.GetRequiredService<SchemeIconCacheService>();

            var cards = _instance.SchemeBindings
                .OrderBy(b => b.Order)
                .Select(b =>
                {
                    var scheme = _schemeService!.GetScheme(b.SchemeId);
                    var tokenDisplay = "未绑定令牌";
                    if (b.TokenId.HasValue)
                    {
                        var token = _tokenService!.GetToken(b.TokenId.Value);
                        tokenDisplay = token != null ? token.Name : "⚠令牌已被删除";
                    }
                    return new SchemeCardModel
                    {
                        BindingId = b.Id,
                        IconGlyph = scheme?.IconGlyph ?? "\uE7C3",
                        CoverImageUrl = scheme != null ? iconCache.GetCachedIconUrl(scheme.Name) : null,
                        DisplayName = scheme?.DisplayName ?? "不存在或未知的方案",
                        Description = scheme?.Description ?? "",
                        TokenDisplay = tokenDisplay,
                        StatusDisplay = "请稍候..."
                    };
                })
                .ToList();

            SchemeListControl.ItemsSource = cards;
        });
    }

    /// <summary>同步工作状态到左侧栏圆点，通过 DI 拿到侧边栏 VM 的 Instance 副本写入</summary>
    private void SyncWorkStatus(string? status)
    {
        if (_instance == null) return;
        App.Services.GetRequiredService<ViewModels.Controls.LeftFunctionBarViewModel>()
            .UpdateInstanceWorkStatus(_instance.Id, status);
    }

    /// <summary>
    /// 全异步加载流程：
    /// 1. 立即渲染页面骨架（按钮禁用 + 进度条显示）
    /// 2. 后台读取 LiteDB 数据
    /// 3. 数据就绪后启用"开始部署"（方案加载延后到点击"开始部署"后）
    /// </summary>
    private async Task LoadAndPreloadAsync(Guid instanceId)
    {
        // —— 阶段 0：立即锁定 UI（用户进入时就看到加载状态） ——
        StartButton.IsEnabled = false;
        StartButton.Content = "开始部署";
        StatusText.Text = "工作区加载中...";
        SyncWorkStatus(null);
        // 让 XAML 先渲染加载状态，避免卡死
        await Task.Yield();

        // 重置状态
        _isDeploying = false;
        lock (_pendingDeployments) { _pendingDeployments.Clear(); }

        // —— 阶段 1：后台线程读取 LiteDB 数据 + 创建卡片 ——
        // 悬空的 TokenId 保留不自动清空，以便 UI 显示 "⚠令牌已被删除" 警告，
        // 同时为 ImportToken 复用原始 Id → 自动重链接提供依据。
        Models.Instance? instance = null;
        List<SchemeCardModel> cards = new();

        await Task.Run(() =>
        {
            var inst = _instanceService!.GetInstance(instanceId);
            if (inst == null) return;

            instance = inst;

            cards = instance.SchemeBindings
                .OrderBy(b => b.Order)
                .Select(b =>
                {
                    var scheme = _schemeService!.GetScheme(b.SchemeId);
                    var tokenDisplay = "未绑定令牌";
                    if (b.TokenId.HasValue)
                    {
                        var token = _tokenService!.GetToken(b.TokenId.Value);
                        tokenDisplay = token != null ? token.Name : "⚠令牌已被删除";
                    }
                    return new SchemeCardModel
                    {
                        BindingId = b.Id,
                        IconGlyph = scheme?.IconGlyph ?? "\uE7C3",
                        CoverImageUrl = null, // 在 UI 线程填充
                        DisplayName = scheme?.DisplayName ?? "不存在或未知的方案",
                        Description = scheme?.Description ?? "",
                        TokenDisplay = tokenDisplay,
                        StatusDisplay = "待部署"
                    };
                })
                .ToList();
        });

        if (instance == null) return;

        // —— 阶段 2：UI 线程填充封面图标 + 渲染卡片 ——
        try
        {
            var iconCache = App.Services.GetRequiredService<SchemeIconCacheService>();
            foreach (var c in cards)
            {
                var binding = instance.SchemeBindings.FirstOrDefault(b => b.Id == c.BindingId);
                if (binding != null)
                {
                    var s = _schemeService!.GetScheme(binding.SchemeId);
                    if (s != null)
                        c.CoverImageUrl = iconCache.GetCachedIconUrl(s.Name);
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[InstanceSummaryPage] 填充封面图标失败: {ex.Message}");
        }

        _instance = instance;
        InstanceNameText.Text = instance.Name;
        SchemeListControl.ItemsSource = cards;

        // —— 阶段 3：检查已缓存的方案页，若全部已加载则直接进入"开始工作" ——
        var bindings = instance.SchemeBindings
            .Where(b => b.IsEnabled)
            .OrderBy(b => b.Order)
            .ToList();

        _totalCardCount = bindings.Count;

        if (bindings.Count > 0)
        {
            // 检查是否所有方案页都已在缓存中且已加载完毕（用户之前已完成部署）
            var cachedPages = _pageCache!.GetInstancePages(instanceId);
            bool allCachedAndLoaded = bindings.All(b =>
                cachedPages.TryGetValue(b.SchemeId, out var cachedPage)
                && cachedPage.IsSchemeLoaded);

            if (allCachedAndLoaded)
            {
                // 所有方案页已缓存且已加载 → 直接进入"开始工作"状态
                // 从缓存的 SchemeHostPage 读取真实状态，恢复为切出前的显示
                foreach (var b in bindings)
                {
                    if (cachedPages.TryGetValue(b.SchemeId, out var cachedPage))
                    {
                        // 恢复状态文字
                        var status = cachedPage.LastAutoLoginStatus;

                        // OpenVPN 用户版方案无自动登录状态记录：以 VPN 服务当前连接状态作为令牌链接标志
                        if (string.IsNullOrEmpty(status) && cachedPage.CurrentCustomControl is OpenVpnControl)
                        {
                            var vpnService = App.Services.GetRequiredService<VpnConnectionService>();
                            status = vpnService.State == VpnConnectionState.Connected
                                ? "令牌已链接" : "方案已加载";
                        }

                        // OpenVPN 服务版方案：以 VPN 连接状态还原（令牌链接 = VPN 已连接）
                        if (string.IsNullOrEmpty(status) && cachedPage.CurrentOpenVpnServiceControl is OpenVpnServiceControl)
                        {
                            var vpnService = App.Services.GetRequiredService<VpnConnectionService>();
                            status = vpnService.State == VpnConnectionState.Connected
                                ? "令牌已链接" : "方案已加载";
                        }

                        UpdateCardStatus(b, !string.IsNullOrEmpty(status) ? status : "方案已加载");

                        // 重新订阅自动登录事件以保持状态同步
                        cachedPage.OnAutoLoginCompleted -= OnSchemeAutoLoginCompleted;
                        cachedPage.OnAutoLoginCompleted += OnSchemeAutoLoginCompleted;
                    }
                }
                StartButton.Content = "开始工作";
                StartButton.IsEnabled = true;
                StatusText.Text = "工作区已就绪";
                SyncWorkStatus("工作区已就绪");
            }
            else
            {
                // 方案加载延后到"开始部署"，此处直接启用按钮
                StartButton.Content = "开始部署";
                StartButton.IsEnabled = true;
                StatusText.Text = "点击\"开始部署\"加载方案并链接令牌";
            }
        }
        else
        {
            // 无绑定方案：直接进入就绪状态
            StartButton.Content = "开始工作";
            StartButton.IsEnabled = true;
            StatusText.Text = "工作区已就绪";
            SyncWorkStatus("工作区已就绪");
        }

        // —— 阶段 4：等待状态栏就绪（最多 5 秒） ——
        await Task.WhenAny(_statusBarReadyTcs.Task, Task.Delay(5000));
    }

    /// <summary>
    /// 在 UI 线程预加载单个方案（WebView2 / RDP 控件需要 UI 线程创建）
    /// 不再自动连接令牌——令牌连接由用户点击"开始部署"触发
    /// </summary>
    private async Task PreloadSingleSchemeOnUIAsync(Guid instanceId, SchemeBinding binding, CancellationToken ct)
    {
        if (ct.IsCancellationRequested) return;

        try
        {
            // 先检查方案是否存在，避免 LoadSchemeAsync 内部静默失败后状态未更新
            var scheme = _schemeService!.GetScheme(binding.SchemeId);
            if (scheme == null)
            {
                UpdateCardStatus(binding, "预加载失败");
                return;
            }

            var page = _pageCache!.GetOrCreate(instanceId, binding.SchemeId);

            // 订阅自动登录完成事件（先取消旧订阅防止重复）
            page.OnAutoLoginCompleted -= OnSchemeAutoLoginCompleted;
            page.OnAutoLoginCompleted += OnSchemeAutoLoginCompleted;

            await page.LoadSchemeAsync(binding.SchemeId, binding);

            // —— 服务版 OpenVPN（CustomControl）：自动登录凭据来自本地保存的配置，与绑定令牌无关 ——
            if (page.CurrentOpenVpnServiceControl is OpenVpnServiceControl ovpnSvc)
            {
                var store = App.Services.GetRequiredService<OpenVpnProfileStore>();
                var autoProfile = store.GetAutoLoginProfile(binding.InstanceId);
                if (autoProfile != null)
                {
                    // 有自动登录配置 → 部署阶段自动连接（TokenId 为 null，不校验绑定令牌）
                    lock (_pendingDeployments)
                    {
                        _pendingDeployments.Add((page, binding, null));
                    }
                }
                else
                {
                    // 无自动登录配置 → 仅"方案加载完成"，不自动连接
                    UpdateCardStatus(binding, "方案已加载");
                }
                return;
            }

            // 如果有令牌，先验证令牌是否仍然存在（可能已被删除）
            if (binding.TokenId.HasValue)
            {
                var token = _tokenService!.GetToken(binding.TokenId.Value);
                if (token == null)
                {
                    // 令牌已被删除：方案已加载，但令牌异常，跳过令牌链接
                    UpdateCardStatus(binding, "方案已加载(令牌异常)");
                }
                else if (scheme.UIKind == SchemeUIKind.WebView2)
                {
                    // WebView2 方案：部署阶段注入令牌账号密码执行自动登录
                    lock (_pendingDeployments)
                    {
                        _pendingDeployments.Add((page, binding, binding.TokenId.Value));
                    }
                }
                else if (scheme.UIKind == SchemeUIKind.CustomControl)
                {
                    if (page.CurrentCustomControl is OpenVpnControl)
                    {
                        // OpenVPN 方案：部署阶段拉起 openvpn.exe 并以绑定令牌直连
                        // （令牌连接成功的读取标志 = VPN 连接成功）
                        lock (_pendingDeployments)
                        {
                            _pendingDeployments.Add((page, binding, binding.TokenId.Value));
                        }
                    }
                    else if (page.HasSchemeError)
                    {
                        // CustomControl 初始化失败（如 OpenVPN 无 .ovpn 配置）→ 标记失败，不进入部署
                        UpdateCardStatus(binding, "预加载失败");
                    }
                    else
                    {
                        // 其他 CustomControl 但有令牌：直接标记为就绪
                        UpdateCardStatus(binding, "方案已加载");
                    }
                }
                else
                {
                    // 非 WebView2 / 非 CustomControl 但有令牌：直接标记为就绪
                    UpdateCardStatus(binding, "方案已加载");
                }
            }
            else
            {
                // 无令牌：直接标记为就绪
                UpdateCardStatus(binding, "方案已加载");
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[SummaryPage] 预加载失败 scheme={binding.SchemeId}: {ex.Message}");
            UpdateCardStatus(binding, "预加载失败");
        }
    }

    /// <summary>
    /// 自动登录完成回调 — 直接使用 SchemeHostPage 传递的状态文字
    /// 同时检查所有卡片是否均已就绪，提前启用"开始工作"按钮
    /// </summary>
    private void OnSchemeAutoLoginCompleted(Guid bindingId, string statusText)
    {
        _ = DispatcherQueue.TryEnqueue(() =>
        {
            var cards = (System.Collections.IList?)SchemeListControl.ItemsSource;
            if (cards == null) return;

            for (int i = 0; i < cards.Count; i++)
            {
                if (cards[i] is SchemeCardModel c && c.BindingId == bindingId)
                {
                    c.StatusDisplay = statusText;
                    break;
                }
            }

            // 检查所有卡片是否已到达"就绪"状态，提前启用开始按钮
            TryEnableStartButton();
        });
    }

    /// <summary>

    /// 当所有卡片均处于终端就绪状态时，将按钮切换为"开始工作"并启用
    /// </summary>
    private void TryEnableStartButton()
    {
        if (StartButton.IsEnabled && StartButton.Content?.ToString() == "开始工作") return;
        if (_totalCardCount == 0) return;

        var cards = (System.Collections.IList?)SchemeListControl.ItemsSource;
        if (cards == null || cards.Count == 0) return;

        int ready = 0;
        for (int i = 0; i < cards.Count; i++)
        {
            if (cards[i] is SchemeCardModel c && _readyStatuses.Contains(c.StatusDisplay))
                ready++;
        }

        if (ready >= _totalCardCount)
        {
            StartButton.Content = "开始工作";
            StartButton.IsEnabled = true;
            StatusText.Text = "工作区已就绪";
            SyncWorkStatus("工作区已就绪");
            System.Diagnostics.Debug.WriteLine(
                $"[SummaryPage] 全部 {ready}/{_totalCardCount} 卡片已就绪，启用\"开始工作\"按钮");
        }
    }

    /// <summary>
    /// 更新方案卡片的状态文字（必须在 UI 线程调用）
    /// </summary>
    private void UpdateCardStatus(SchemeBinding binding, string status)
    {
        var cards = (System.Collections.IList?)SchemeListControl.ItemsSource;
        if (cards == null) return;

        for (int i = 0; i < cards.Count; i++)
        {
            if (cards[i] is SchemeCardModel c && c.BindingId == binding.Id)
            {
                c.StatusDisplay = status;
                break;
            }
        }
    }

    /// <summary>
    /// 检查状态栏是否已就绪（CPU 和内存数据已采集到有效值）
    /// </summary>
    private void CheckStatusBarReady()
    {
        if (_statusBarViewModel != null &&
            _statusBarViewModel.CpuUsagePercent > 0 &&
            _statusBarViewModel.MemoryUsagePercent > 0)
        {
            _statusBarReadyTcs.TrySetResult();
        }
    }

    /// <summary>
    /// 监听状态栏属性变化，当 CPU/内存数据就绪时标记完成
    /// </summary>
    private void OnStatusBarPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(StatusBarViewModel.CpuUsagePercent) ||
            e.PropertyName == nameof(StatusBarViewModel.MemoryUsagePercent))
        {
            CheckStatusBarReady();
        }
    }

    /// <summary>
    /// 按钮点击处理 —— 两阶段：
    /// 阶段1（"开始部署"）：先加载方案，再部署令牌
    /// 阶段2（"开始工作"）：标记实例已启动，进入预热好的 InstanceWorkspace
    /// </summary>
    private void OnStartClick(object sender, RoutedEventArgs e)
    {
        if (_instance == null) return;

        var buttonText = StartButton.Content?.ToString();

        if (buttonText == "开始部署")
        {
            // 阶段1：加载方案 + 部署令牌
            _ = StartDeploymentAsync();
        }
        else if (buttonText == "开始工作")
        {
            // 阶段2：进入工作区，侧边栏状态圆点设为绿色
            SyncWorkStatus("工作区已就绪");
            App.Services.GetRequiredService<ViewModels.Controls.LeftFunctionBarViewModel>()
                .MarkInstanceStarted(_instance.Id);

            // [侧栏自动折叠] 统一由 InstanceWorkspace.OnNavigatedTo 处理
            // （记录进入前状态并折叠，覆盖所有进入路径；离开时恢复）
            _navService!.NavigateTo(typeof(Views.Instance.InstanceWorkspace), _instance.Id);
        }
    }

    /// <summary>
    /// 开始部署：先加载所有方案，再链接令牌（WebView2 方案）
    /// </summary>
    private async Task StartDeploymentAsync()
    {
        if (_isDeploying) return;
        if (_instance == null) return;

        _isDeploying = true;

        // 按钮变为"正在部署..."并灰化
        StartButton.Content = "正在部署...";
        StartButton.IsEnabled = false;
        StatusText.Text = "正在加载方案...";
        SyncWorkStatus("正在加载方案...");

        // —— 阶段 1：加载所有方案 ——
        var bindings = _instance.SchemeBindings
            .Where(b => b.IsEnabled)
            .OrderBy(b => b.Order)
            .ToList();

        lock (_pendingDeployments) { _pendingDeployments.Clear(); }

        using var loadCts = new CancellationTokenSource();

        // 所有卡片进入加载忙状态
        foreach (var b in bindings)
            UpdateCardStatus(b, "方案加载中...");

        var loadTasks = bindings.Select(b => PreloadSingleSchemeOnUIAsync(_instance.Id, b, loadCts.Token));
        await Task.WhenAll(loadTasks);

        StatusText.Text = "正在链接令牌...";
        SyncWorkStatus("正在链接令牌...");

        // —— 阶段 2：部署令牌 ——
        List<(SchemeHostPage Page, SchemeBinding Binding, Guid? TokenId)> deployments;
        lock (_pendingDeployments)
        {
            deployments = new List<(SchemeHostPage, SchemeBinding, Guid?)>(_pendingDeployments);
        }

        if (deployments.Count == 0)
        {
            // 没有需要部署的方案，直接标记完成
            _isDeploying = false;
            StartButton.Content = "开始工作";
            StartButton.IsEnabled = true;
            StatusText.Text = "工作区已就绪";
            SyncWorkStatus("工作区已就绪");
            return;
        }

        // 并行触发所有自动登录 / 令牌直连（部署前二次校验令牌是否存在）
        var deployTasks = deployments.Select(async d =>
        {
            try
            {
                // —— 服务版 OpenVPN：使用本地保存的自动登录凭据连接（不校验绑定令牌）——
                if (d.Page.CurrentOpenVpnServiceControl is OpenVpnServiceControl ovpnSvc)
                {
                    UpdateCardStatus(d.Binding, "正在链接令牌...");
                    var (vpnOk, vpnError) = await ovpnSvc.AutoLoginAsync();
                    UpdateCardStatus(d.Binding, vpnOk ? "令牌已链接" : "令牌链接失败");
                    if (!vpnOk)
                    {
                        System.Diagnostics.Debug.WriteLine(
                            $"[SummaryPage] 服务版 OpenVPN 自动登录失败 binding={d.Binding.Id}: {vpnError}");
                    }
                    return;
                }

                // 二次校验：令牌可能在预加载后被删除（极端情况）
                var tokenCheck = d.TokenId.HasValue ? _tokenService!.GetToken(d.TokenId.Value) : null;
                if (d.TokenId.HasValue && tokenCheck == null)
                {
                    UpdateCardStatus(d.Binding, "方案已加载(令牌异常)");
                    return;
                }

                UpdateCardStatus(d.Binding, "正在链接令牌...");

                // —— OpenVPN（CustomControl）：拉起 openvpn.exe + 令牌直连 ——
                // 令牌连接成功的读取标志 = VPN 连接成功（状态进入 Connected）
                if (d.Page.CurrentCustomControl is OpenVpnControl ovpnControl)
                {
                    var (vpnOk, vpnError) = await ovpnControl.ConnectWithTokenAsync();
                    UpdateCardStatus(d.Binding, vpnOk ? "令牌已链接" : "令牌链接失败");
                    if (!vpnOk)
                    {
                        System.Diagnostics.Debug.WriteLine(
                            $"[SummaryPage] OpenVPN 令牌直连失败 binding={d.Binding.Id}: {vpnError}");
                    }
                    return;
                }

                // —— WebView2：自动登录（完成后通过 OnSchemeAutoLoginCompleted 事件更新状态） ——
                if (d.TokenId.HasValue)
                {
                    await d.Page.AutoLoginAsync(d.TokenId.Value);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[SummaryPage] 部署失败 binding={d.Binding.Id}: {ex.Message}");
                UpdateCardStatus(d.Binding, "令牌链接失败");
            }
        });

        await Task.WhenAll(deployTasks);

        // 部署完成，检查所有卡片状态
        _isDeploying = false;
        TryEnableStartButton();
    }
}
