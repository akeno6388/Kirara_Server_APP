using System.Collections.Generic;
using System.Runtime.InteropServices;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Animation;
using Microsoft.UI.Xaml.Media.Imaging;
using Microsoft.UI.Xaml.Navigation;
using Microsoft.Web.WebView2.Core;
using Kirara_Server_WinUI.Controls;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.ViewModels.Pages;
using Kirara_Server_WinUI.ViewModels.Controls;
using Windows.Foundation;
using Windows.Media.Core;
using Windows.Media.Playback;
using Windows.System;
using Windows.UI;

namespace Kirara_Server_WinUI.Views.Pages;

public sealed partial class MainPage : Page
{
    /// <summary>首页 ViewModel</summary>
    public MainPageViewModel ViewModel { get; }

    /// <summary>通知中心 ViewModel（供 XAML x:Bind 使用）</summary>
    public NotificationCenterViewModel NotificationVM { get; }

    /// <summary>账号设置 ViewModel（供 XAML x:Bind 使用）</summary>
    public AccountSettingsViewModel SettingsVM { get; }

    /// <summary>设置面板是否已打开</summary>
    public bool IsSettingsPanelOpen => AccountSettingsPanel?.Visibility == Visibility.Visible;

    private IUserAvatarService? _avatarService;

    /// <summary>GIF 动图渲染器（主界面头像）</summary>
    private GifRenderer? _mainAvatarGif;

    /// <summary>视频/HTML 覆盖层滚轮翻页节流间隔（防止触控板惯性连翻多页）</summary>
    private static readonly TimeSpan OverlayWheelFlipThrottle = TimeSpan.FromMilliseconds(300);

    /// <summary>视频/HTML 覆盖层上次滚轮翻页时间（UTC）</summary>
    private DateTime _lastOverlayWheelFlipTime = DateTime.MinValue;

    /// <summary>GIF 动图渲染器（设置面板头像）</summary>
    private GifRenderer? _settingsAvatarGif;

    /// <summary>保存触发设置命令的按钮引用，用于 Flyout 正确定位</summary>
    private FrameworkElement? _settingsCommandSender;

    // ===== 信息流卡片自动播放 =====

    /// <summary>FlipView 自动播放计时器（3s 切换）</summary>
    private DispatcherTimer? _autoPlayTimer;

    /// <summary>共享视频播放器实例</summary>
    private MediaPlayer? _mediaPlayer;

    /// <summary>当前视频 MediaEnded 事件的处理器引用（用于 Dispose 前安全移除）</summary>
    private TypedEventHandler<MediaPlayer, object?>? _mediaEndedHandler;

    /// <summary>页面是否正在导航离开（防止异步回调访问已卸载控件）</summary>
    private bool _isNavigatedAway;

    /// <summary>HTML 卡片 WebView2 是否已初始化</summary>
    private bool _htmlViewInitialized;

    /// <summary>
    /// 光标是否悬停在 HTML 容器内。
    /// 为 true 时暂停自动播放（用户正在浏览网页内容，不应被自动翻页打断）；
    /// 移出后恢复自动播放。
    /// </summary>
    private bool _isPointerOverHtml;

    /// <summary>正在进行的退场/入场动画 Storyboard 集合，用于停止旧动画避免冲突</summary>
    private readonly List<Storyboard> _activeSectionAnimations = new();

    // ===== 信息流悬浮大图（Lightbox）=====

    /// <summary>是否正在拖拽平移大图</summary>
    private bool _isLightboxDragging;

    /// <summary>拖拽起始指针位置（图片容器坐标）</summary>
    private Point _lightboxDragStart;

    /// <summary>拖拽起始 Translate 偏移</summary>
    private double _lightboxStartTranslateX;

    /// <summary>拖拽起始 Translate 偏移</summary>
    private double _lightboxStartTranslateY;

    /// <summary>悬浮大图缩放范围</summary>
    private const double LightboxMinScale = 0.5;

    /// <summary>悬浮大图缩放范围上限</summary>
    private const double LightboxMaxScale = 6.0;

    /// <summary>Lightbox 当前播放的入场/退场动画（快速连续打开/关闭时停止旧动画）</summary>
    private Storyboard? _lightboxAnimSb;

    /// <summary>
    /// 安全地在 UI 线程上执行操作，捕获因页面卸载/窗口关闭导致的 COMException。
    /// 与 StatusBarViewModel.SafeSetOnUi 保持一致的防护策略。
    /// </summary>
    private void SafeDispatch(Action action)
    {
        if (_isNavigatedAway) return;
        _ = DispatcherQueue.TryEnqueue(() =>
        {
            if (_isNavigatedAway) return;
            try
            {
                action();
            }
            catch (COMException ex) when ((uint)ex.HResult == 0x8000FFFF)
            {
                // 窗口/页面已关闭，UI 元素已销毁，静默忽略
            }
            catch (ObjectDisposedException)
            {
                // UI 元素已被释放，静默忽略
            }
        });
    }

    public MainPage()
    {
        InitializeComponent();

        ViewModel = App.Services.GetRequiredService<MainPageViewModel>();
        NotificationVM = App.Services.GetRequiredService<NotificationCenterViewModel>();
        SettingsVM = App.Services.GetRequiredService<AccountSettingsViewModel>();

        DataContext = ViewModel;
        _avatarService = App.Services.GetRequiredService<IUserAvatarService>();

        // 初始化头像
        _avatarService.AvatarChanged += OnAvatarChanged;
        ApplyAvatar(_avatarService.CurrentAvatarPath);

        // 订阅 Pivot 选择变化事件
        if (FindName("NotificationPivot") is Pivot pivot)
        {
            pivot.SelectionChanged += OnNotificationPivotSelectionChanged;
        }

        // 订阅账号设置结果通知事件
        SettingsVM.OnResultNotification += OnSettingsResultNotification;

        // 订阅 FlipView 选中变更（视频/HTML 覆层管理 + 自动播放重置）
        Loaded += MainPage_Loaded;

        // [修复] 主题切换后信息流图片不可见：监听根元素 ActualThemeChanged，
        // 强制重建 BitmapImage（WinUI 3 RequestedTheme 切换的已知问题）
        Loaded += (_, _) =>
        {
            try
            {
                var mainWindow = MainWindow.Current;
                if (mainWindow?.Content is FrameworkElement rootElement)
                {
                    rootElement.ActualThemeChanged += OnRootActualThemeChanged;
                }
            }
            catch { /* 窗口未就绪，忽略 */ }
        };
        Unloaded += (_, _) =>
        {
            try
            {
                var mainWindow = MainWindow.Current;
                if (mainWindow?.Content is FrameworkElement rootElement)
                {
                    rootElement.ActualThemeChanged -= OnRootActualThemeChanged;
                }
            }
            catch { /* 窗口已关闭，忽略 */ }
        };
    }

    /// <summary>
    /// 根元素主题切换处理。
    /// [修复] WinUI 3 已知问题：RequestedTheme 切换触发视觉树重建时，
    /// Image 控件绑定从本地文件加载的 BitmapImage 会丢失渲染（图片不可见）。
    /// 视频（MediaPlayerElement 独立渲染层）与 HTML（WebView2 独立渲染层）不受影响，
    /// 仅需强制重建图片卡片的 ImageSource（置 null 再重新赋值触发重新解码）。
    /// </summary>
    private void OnRootActualThemeChanged(FrameworkElement sender, object args)
    {
        try
        {
            foreach (var card in NotificationVM.Cards)
            {
                if (!card.IsImage || card.ImageSource == null) continue;

                // 保存原 URI → 置 null → 重新创建 BitmapImage（强制重新解码，修复主题切换后空白）
                var uri = card.ImageSource.UriSource;
                card.ImageSource = null;
                if (uri != null)
                {
                    try { card.ImageSource = new BitmapImage(uri); } catch { }
                }
            }
            System.Diagnostics.Debug.WriteLine(
                $"[MainPage] 主题切换完成，已刷新 {NotificationVM.Cards.Count(c => c.IsImage && c.ImageSource != null)} 张图片卡片");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[MainPage] 主题切换刷新图片失败: {ex.Message}");
        }
    }

    private async void MainPage_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            // 初始化 HTML 卡片 WebView2
            if (CardHtmlView != null)
            {
                // ★ [Program Files 只读修复] 必须显式指定共享环境：
                //   默认用户数据目录 = exe 所在目录（安装到 Program Files 后只读），
                //   WebView2 会报「无法创建数据目录：...EBWebView」。
                //   共享环境固定到 %LOCALAPPDATA%\Kirara\webview2\shared。
                var sharedEnv = await Helpers.WebView2EnvironmentHelper.GetSharedEnvironmentAsync();
                await CardHtmlView.EnsureCoreWebView2Async(sharedEnv);
                CardHtmlView.CoreWebView2.Settings.AreDefaultScriptDialogsEnabled = false;
                CardHtmlView.CoreWebView2.Settings.IsScriptEnabled = true;
                // 🎯 设计决策（v2）：HTML 容器不启用滚轮翻页 — 滚轮事件完全交由网页自身处理，
                // 用户可用滚轮浏览网页内容；HTML 卡片不可通过滚轮切出（其他容器切入保留）。
                // 因此关闭 WebMessage（无需 JS 上报），保持默认安全配置。
                CardHtmlView.CoreWebView2.Settings.IsWebMessageEnabled = false;
                CardHtmlView.CoreWebView2.Settings.AreHostObjectsAllowed = false;

                // ★ HTML 导航完成后才显示 WebView2，避免切入时空白闪烁
                // （不注入任何脚本 — 滚轮/滚动行为完全交给网页自身）
                CardHtmlView.CoreWebView2.NavigationCompleted += (_, _) =>
                {
                    if (_isNavigatedAway) return;
                    CardHtmlView.Visibility = Visibility.Visible;
                };
                _htmlViewInitialized = true;

                // ★ 光标在 HTML 容器内时暂停自动播放（用户浏览网页不被自动翻页打断）
                CardHtmlView.PointerEntered += OnHtmlPointerEntered;
                CardHtmlView.PointerExited += OnHtmlPointerExited;
            }

            // 注册 FlipView 选中变更事件
            if (CardFlipView != null)
            {
                CardFlipView.SelectionChanged += OnCardFlipViewSelectionChanged;
            }

            // ★ 视频容器滚轮翻页：视频卡片覆盖时 FlipView 无法接收滚轮，
            // 在 MediaPlayerElement 上拦截滚轮（上滚 → 上一张，下滚 → 下一张），
            // 并阻止冒泡到父级页面（页面不上下滚动）
            CardVideoPlayer.AddHandler(
                PointerWheelChangedEvent,
                new PointerEventHandler(OnVideoOverlayWheel),
                handledEventsToo: true);

            // ★ 立即从内存/本地缓存加载卡片数据（秒显，不等待网络）
            //    （登录时 RemoteInfoCardService 已加载本地缓存并触发 CardsRefreshed）
            await NotificationVM.ReloadCardsAsync();

            // 首次加载后更新视频/HTML 覆层 + 启动自动播放
            UpdateOverlayForCurrentCard();
            StartAutoPlayTimer();

            // ★ 后台静默从服务端增量同步（不阻塞 UI 交互与入场动画）
            //    同步结果通过 CardsRefreshed 事件驱动 UI 刷新；
            //    此处额外 ReloadCardsAsync 兜底覆盖 ForceRefreshAsync 加载本地缓存后
            //    未触发事件的情况（如首次进入时 _cachedCards 尚为空）。
            var infoCardService = App.Services.GetRequiredService<RemoteInfoCardService>();
            _ = Task.Run(async () =>
            {
                try
                {
                    await infoCardService.ForceRefreshAsync();
                    // 同步完成后刷新 UI
                    SafeDispatch(async () =>
                        await NotificationVM.ReloadCardsAsync());
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[MainPage] 后台同步失败: {ex.Message}");
                }
            });
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[MainPage] 信息流初始化失败: {ex.Message}");
        }
    }

    // ================================================================
    //  FlipView 选中变更 → 更新视频/HTML 覆层 + 重置自动播放计时器
    // ================================================================

    private void OnCardFlipViewSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_isNavigatedAway) return;

        // ★ 修复错位：SelectionChanged 触发时 x:Bind TwoWay 写回 CurrentCardIndex 可能滞后
        // （滚轮直接驱动 FlipView.SelectedIndex 时尤为明显），导致覆层按旧索引判断卡片类型。
        // 直接从 FlipView 读取真实选中索引并同步到 VM，确保遮罩/圆点/覆层按真实卡片更新。
        // 值相同时 SetProperty 不触发任何事件（程序化翻页路径无副作用）。
        if (CardFlipView != null && CardFlipView.SelectedIndex >= 0)
        {
            NotificationVM.CurrentCardIndex = CardFlipView.SelectedIndex;
        }

        UpdateOverlayForCurrentCard();
        ResetAutoPlayTimer();
    }

    // ================================================================
    //  视频/HTML 覆盖层滚轮翻页（上滚 → 上一张，下滚 → 下一张）
    // ================================================================

    /// <summary>
    /// 视频容器（MediaPlayerElement）滚轮拦截。
    /// 视频卡片覆盖时 FlipView 无法接收滚轮，在此拦截并驱动翻页，
    /// 同时阻止事件冒泡到父级页面（页面不上下滚动）。
    /// </summary>
    private void OnVideoOverlayWheel(object sender, PointerRoutedEventArgs e)
    {
        if (_isNavigatedAway) return;

        // 标记已处理：阻止继续冒泡到父级垂直 ScrollViewer（页面不上下滚动）
        e.Handled = true;

        int delta = e.GetCurrentPoint(CardVideoPlayer).Properties.MouseWheelDelta;
        if (delta != 0)
            FlipCardByWheel(delta > 0 ? 1 : -1);
    }

    /// <summary>
    /// 覆盖层滚轮翻页统一入口（带节流，防止触控板惯性连翻多页）。
    /// </summary>
    /// <param name="direction">+1 = 上一张（滚轮向上），-1 = 下一张（滚轮向下）</param>
    private void FlipCardByWheel(int direction)
    {
        if (_isNavigatedAway) return;

        var now = DateTime.UtcNow;
        if (now - _lastOverlayWheelFlipTime < OverlayWheelFlipThrottle)
            return;
        _lastOverlayWheelFlipTime = now;

        if (direction > 0)
            NotificationVM.PrevCardCommand.Execute(null);
        else
            NotificationVM.NextCardCommand.Execute(null);
    }

    // ================================================================
    //  16:10 自适应 — MaxWidth 720 容器，宽度变化时高度 = 宽度 × 10/16
    // ================================================================

    private void OnInfoCardWrapperSizeChanged(object sender, SizeChangedEventArgs e)
    {
        if (CardMediaBorder == null) return;

        var width = e.NewSize.Width;
        if (width <= 0) return;

        var height = Math.Max(width * 9.0 / 16.0, 200);
        CardMediaBorder.Height = height;

        // 裁剪内层 Grid，防止 FlipView/视频/WebView2 内容溢出 Border 圆角
        if (CardMediaClipGrid != null)
        {
            CardMediaClipGrid.Clip = new RectangleGeometry
            {
                Rect = new Windows.Foundation.Rect(0, 0, width, height),
            };
        }

        // ★ 同步服务项和日志项容器的高度，确保三标签切换时高度一致
        if (FindName("ServiceContentPanel") is Grid svc)
            svc.Height = height;
        if (FindName("LogContentPanel") is Grid log)
            log.Height = height;
    }

    // ================================================================
    //  圆点导航悬停放大动画 + 遮罩淡入淡出
    // ================================================================

    private void OnDotPointerEntered(object sender, PointerRoutedEventArgs e)
    {
        if (sender is FrameworkElement el)
        {
            var scale = new ScaleTransform { ScaleX = 1.8, ScaleY = 1.8, CenterX = 14, CenterY = 14 };
            el.RenderTransform = scale;
        }
    }

    private void OnDotPointerExited(object sender, PointerRoutedEventArgs e)
    {
        if (sender is FrameworkElement el)
        {
            el.RenderTransform = null;
        }
    }

    /// <summary>
    /// 圆点导航遮罩 — 光标移入时淡入到 Opacity=1.0（完全显现）
    /// </summary>
    private void OnDotNavPointerEntered(object sender, PointerRoutedEventArgs e)
    {
        if (sender is not Border border) return;
        var sb = new Storyboard();
        var anim = new DoubleAnimation
        {
            From = border.Opacity,
            To = 1.0,
            Duration = TimeSpan.FromMilliseconds(200),
            EasingFunction = new CircleEase { EasingMode = EasingMode.EaseOut },
        };
        Storyboard.SetTarget(anim, border);
        Storyboard.SetTargetProperty(anim, "Opacity");
        sb.Children.Add(anim);
        sb.Begin();
    }

    /// <summary>
    /// 圆点导航遮罩 — 光标移出时淡出到 Opacity=0.9（仍保持较高可见度）
    /// </summary>
    private void OnDotNavPointerExited(object sender, PointerRoutedEventArgs e)
    {
        if (sender is not Border border) return;
        var sb = new Storyboard();
        var anim = new DoubleAnimation
        {
            From = border.Opacity,
            To = 0.9,
            Duration = TimeSpan.FromMilliseconds(300),
            EasingFunction = new CircleEase { EasingMode = EasingMode.EaseOut },
        };
        Storyboard.SetTarget(anim, border);
        Storyboard.SetTargetProperty(anim, "Opacity");
        sb.Children.Add(anim);
        sb.Begin();
    }

    /// <summary>
    /// 点击圆点切换到对应卡片。
    /// </summary>
    private void OnDotPointerPressed(object sender, PointerRoutedEventArgs e)
    {
        if (sender is FrameworkElement el && el.DataContext is DotState dot)
        {
            if (dot.Index >= 0 && dot.Index < NotificationVM.CardCount)
                NotificationVM.CurrentCardIndex = dot.Index;
        }
    }

    // ================================================================
    //  HTML 容器悬停（光标在 HTML 内时暂停自动播放，移出后恢复）
    // ================================================================

    /// <summary>
    /// 光标移入 HTML 容器 → 暂停自动播放。
    /// 用户正在浏览网页内容，不应被自动翻页打断。
    /// </summary>
    private void OnHtmlPointerEntered(object sender, PointerRoutedEventArgs e)
    {
        if (_isNavigatedAway) return;
        _isPointerOverHtml = true;
        StopAutoPlayTimer();
    }

    /// <summary>
    /// 光标移出 HTML 容器 → 恢复自动播放。
    /// </summary>
    private void OnHtmlPointerExited(object sender, PointerRoutedEventArgs e)
    {
        if (_isNavigatedAway) return;
        _isPointerOverHtml = false;
        // 仅当当前卡片仍是 HTML 时恢复（若已切换卡片，SelectionChanged 已处理计时器）
        if (NotificationVM.Cards.Count > 0 &&
            NotificationVM.Cards[NotificationVM.CurrentCardIndex].IsHtml)
        {
            StartAutoPlayTimer();
        }
    }

    // ================================================================
    //  自动播放计时器
    // ================================================================

    private void StartAutoPlayTimer()
    {
        StopAutoPlayTimer();

        // ★ 光标悬停在 HTML 容器内时不启动自动播放（用户正在浏览网页内容）
        if (_isPointerOverHtml)
            return;

        _autoPlayTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(10) };
        _autoPlayTimer.Tick += (s, args) =>
        {
            NotificationVM.AutoPlayNext();
        };
        _autoPlayTimer.Start();
    }

    private void StopAutoPlayTimer()
    {
        if (_autoPlayTimer != null)
        {
            _autoPlayTimer.Stop();
            _autoPlayTimer = null;
        }
    }

    private void ResetAutoPlayTimer()
    {
        StopAutoPlayTimer();
        StartAutoPlayTimer();
    }

    // ================================================================
    //  视频 & HTML 叠层管理
    // ================================================================

    /// <summary>
    /// 根据当前选中的卡片类型，显示/隐藏视频播放器或 HTML WebView2 覆层。
    /// </summary>
    private async void UpdateOverlayForCurrentCard()
    {
        if (_isNavigatedAway) return;
        if (NotificationVM.Cards.Count == 0) return;

        // 优先从 FlipView 读取真实选中索引（与 SelectionChanged 同步后的值一致），
        // 避免依赖可能滞后的 VM 属性导致覆层错位
        int idx = CardFlipView?.SelectedIndex ?? NotificationVM.CurrentCardIndex;
        if (idx < 0 || idx >= NotificationVM.Cards.Count) return;

        var card = NotificationVM.Cards[idx];

        // 先停止/隐藏所有覆层
        StopVideoPlayer();
        CardVideoPlayer.Visibility = Visibility.Collapsed;
        CardHtmlView.Visibility = Visibility.Collapsed;
        // ★ HTML 被隐藏时重置悬停标记（元素 Collapsed 不触发 PointerExited，
        // 必须手动复位，否则自动播放永久暂停）
        _isPointerOverHtml = false;

        if (card.IsVideo && !string.IsNullOrEmpty(card.VideoPath))
        {
            await PlayVideoAsync(card.VideoPath);
        }
        else if (card.IsHtml && _htmlViewInitialized && CardHtmlView.CoreWebView2 != null)
        {
            ShowHtmlContent(card);
        }
    }

    // ================================================================
    //  视频播放器（MediaPlayerElement）— 循环、静音、无控件
    // ================================================================

    private async Task PlayVideoAsync(string filePath)
    {
        try
        {
            if (!File.Exists(filePath))
            {
                System.Diagnostics.Debug.WriteLine($"[MainPage] 视频文件不存在: {filePath}");
                return;
            }

            var file = await Windows.Storage.StorageFile.GetFileFromPathAsync(filePath);
            // ★ 异步 I/O 期间可能已导航离开，立即中止避免访问已卸载控件
            if (_isNavigatedAway) return;
            var source = MediaSource.CreateFromStorageFile(file);
            var player = new MediaPlayer
            {
                Source = source,
                IsLoopingEnabled = false,   // 不循环，播放完自动切换
                Volume = 0,                 // 静音
                IsMuted = true,
            };
            player.CommandManager.IsEnabled = false; // 禁用播放控件

            // ★ 视频播放完毕后自动切换到下一张
            //   捕获 DispatcherQueue 防止页面卸载后属性返回 null
            var dq = this.DispatcherQueue;
            _mediaEndedHandler = (_, _) =>
            {
                if (_isNavigatedAway || dq == null) return;
                _ = dq.TryEnqueue(() => NotificationVM.AutoPlayNext());
            };
            player.MediaEnded += _mediaEndedHandler;

            _mediaPlayer = player;
            CardVideoPlayer.SetMediaPlayer(player);
            CardVideoPlayer.Visibility = Visibility.Visible;

            player.Play();
            System.Diagnostics.Debug.WriteLine($"[MainPage] 视频播放: {Path.GetFileName(filePath)}");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[MainPage] 视频播放失败: {ex.Message}");
            CardVideoPlayer.Visibility = Visibility.Collapsed;
        }
    }

    private void StopVideoPlayer()
    {
        if (_mediaPlayer != null)
        {
            // ★ 先移除 MediaEnded 回调，防止后续操作触发异常
            if (_mediaEndedHandler != null)
            {
                _mediaPlayer.MediaEnded -= _mediaEndedHandler;
                _mediaEndedHandler = null;
            }
            _mediaPlayer.Pause();
            // ★ 先将 MediaPlayer 从 MediaPlayerElement 上解绑，再清理 Source
            CardVideoPlayer?.SetMediaPlayer(null);
            _mediaPlayer.Source = null;
            // ★ 不调用 Dispose() — 挂载在 MediaPlayerElement 上时 Dispose 可能损坏
            //    COM 对象，导致 Frame.Navigate 抛出 E_ABORT
            _mediaPlayer = null;
        }
    }

    // ================================================================
    //  HTML 内容渲染（仅 HTML 类型卡片使用 WebView2）
    // ================================================================

    private void ShowHtmlContent(InfoCardViewModel card)
    {
        if (_isNavigatedAway) return;
        try
        {
            if (CardHtmlView?.CoreWebView2 == null) return;

            // ★ 始终隐藏 WebView2，等待导航完成后统一显现，避免空白闪烁
            CardHtmlView.Visibility = Visibility.Collapsed;

            if (!string.IsNullOrEmpty(card.ExternalUrl))
            {
                // 有真实网页 URL → 直接加载
                CardHtmlView.CoreWebView2.Navigate(card.ExternalUrl);
            }
            else if (!string.IsNullOrEmpty(card.HtmlContent))
            {
                // 无 ExternalUrl 但有本地缓存的 HTML 文件内容 → NavigateToString
                CardHtmlView.CoreWebView2.NavigateToString(card.HtmlContent);
            }
            else
            {
                // 没有任何 HTML 资源 → 隐藏 WebView2，空状态"暂无信息流内容"自然显示
                return;
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[MainPage] HTML 渲染失败: {ex.Message}");
            CardHtmlView.Visibility = Visibility.Collapsed;
        }
    }

    // ================================================================
    //  信息流悬浮大图（Lightbox）
    //  点击图片卡片 → 重新解码全分辨率大图悬浮显示；
    //  支持滚轮缩放（0.5x–6x）、拖拽平移、双击还原、背景/Esc/按钮关闭。
    // ================================================================

    /// <summary>
    /// FlipView DataTemplate 内图片点击 → 打开悬浮大图（仅 image 类型卡片）。
    /// </summary>
    private void OnCardImageTapped(object sender, TappedRoutedEventArgs e)
    {
        if (_isNavigatedAway) return;
        if (sender is FrameworkElement fe && fe.DataContext is InfoCardViewModel card)
        {
            // 仅图片卡片响应；视频/HTML 卡片忽略
            if (card.IsImage && card.ImageSource != null)
            {
                OpenLightbox(card);
                e.Handled = true;
            }
        }
    }

    /// <summary>
    /// 打开悬浮大图：重新解码全分辨率 BitmapImage（独立实例，不与卡片缩略图共享解码状态），
    /// 暂停自动播放，聚焦悬浮层以支持 Esc 关闭。
    /// </summary>
    private void OpenLightbox(InfoCardViewModel card)
    {
        try
        {
            // ★ 重新解码全分辨率大图（原始文件/URL），避免复用缩略图解码缓存
            //   双重空检查：调用方已检查 ImageSource 非空，但编译器无法跨方法推断
            //   （消除 CS8602 警告 + 防御性保护）
            var imageSource = card.ImageSource;
            if (imageSource == null) return;

            var uri = imageSource.UriSource;
            if (uri == null) return;   // 非文件来源（理论上不存在）→ 不打开

            var full = new BitmapImage(uri);
            full.ImageFailed += (_, _) => CloseLightbox();  // 解码失败自动关闭

            ResetLightboxTransform();
            LightboxImage.Source = full;
            ImageLightbox.Visibility = Visibility.Visible;

            // ★ 圆角窗口尺寸：占视口 90%（先布局再读取 ActualWidth）
            ImageLightbox.UpdateLayout();
            double windowW = Math.Max(200, ImageLightbox.ActualWidth * 0.9);
            double windowH = Math.Max(150, ImageLightbox.ActualHeight * 0.9);
            LightboxWindow.Width = windowW;
            LightboxWindow.Height = windowH;

            // ★ 入场动画：淡入 + 缩放上浮
            AnimateLightboxIn();

            StopAutoPlayTimer();                          // 悬浮期间暂停自动播放
            _ = ImageLightbox.Focus(FocusState.Programmatic); // 获得焦点支持 Esc
            System.Diagnostics.Debug.WriteLine($"[MainPage] 打开悬浮大图: {card.CardId:N}");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[MainPage] 悬浮大图打开失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 关闭悬浮大图并释放图片源。
    /// </summary>
    /// <param name="restoreAutoPlay">是否恢复自动播放（导航离开时传 false，避免离页后计时器运行）</param>
    private void CloseLightbox(bool restoreAutoPlay = true)
    {
        if (ImageLightbox == null) return;
        if (ImageLightbox.Visibility != Visibility.Visible) return;

        // ★ 导航离开等场景（页面不可见）→ 立即关闭，不播退场动画
        if (!restoreAutoPlay)
        {
            FinishCloseLightbox();
            return;
        }

        // ★ 正常关闭：播放退场动画，完成后释放资源
        AnimateLightboxOut();
    }

    // ================================================================
    //  Lightbox 入场/退场动画
    // ================================================================

    /// <summary>
    /// 入场动画：窗口淡入 + 0.85→1.0 缩放 + 上浮 20px（320ms CubicEase.EaseOut）。
    /// </summary>
    private void AnimateLightboxIn()
    {
        StopLightboxAnim();
        LightboxWindow.Opacity = 0;

        var group = GetOrCreateLightboxWindowTransform();
        var scale = (ScaleTransform)group.Children[0];
        var translate = (TranslateTransform)group.Children[1];
        scale.ScaleX = 0.85;
        scale.ScaleY = 0.85;
        translate.Y = 20;

        var sb = new Storyboard();
        AddDoubleAnim(sb, LightboxWindow, 320, 0, 1, new CubicEase { EasingMode = EasingMode.EaseOut }, "Opacity");
        AddDoubleAnim(sb, scale, 320, 0.85, 1.0, new CubicEase { EasingMode = EasingMode.EaseOut }, "ScaleX");
        AddDoubleAnim(sb, scale, 320, 0.85, 1.0, new CubicEase { EasingMode = EasingMode.EaseOut }, "ScaleY");
        AddDoubleAnim(sb, translate, 320, 20, 0, new CubicEase { EasingMode = EasingMode.EaseOut }, "Y");
        sb.Completed += (_, _) => { _lightboxAnimSb = null; };
        _lightboxAnimSb = sb;
        sb.Begin();
    }

    /// <summary>
    /// 退场动画：窗口淡出 + 缩小至 0.92 + 下移 10px（220ms CubicEase.EaseIn），完成后释放资源。
    /// </summary>
    private void AnimateLightboxOut()
    {
        StopLightboxAnim();

        var group = GetOrCreateLightboxWindowTransform();
        var scale = (ScaleTransform)group.Children[0];
        var translate = (TranslateTransform)group.Children[1];

        var sb = new Storyboard();
        AddDoubleAnim(sb, LightboxWindow, 220, 1, 0, new CubicEase { EasingMode = EasingMode.EaseIn }, "Opacity");
        AddDoubleAnim(sb, scale, 220, scale.ScaleX, 0.92, new CubicEase { EasingMode = EasingMode.EaseIn }, "ScaleX");
        AddDoubleAnim(sb, scale, 220, scale.ScaleY, 0.92, new CubicEase { EasingMode = EasingMode.EaseIn }, "ScaleY");
        AddDoubleAnim(sb, translate, 220, translate.Y, 10, new CubicEase { EasingMode = EasingMode.EaseIn }, "Y");
        sb.Completed += (_, _) =>
        {
            _lightboxAnimSb = null;
            // ★ 动画期间可能导航离开，此时不恢复自动播放
            FinishCloseLightbox(!_isNavigatedAway);
        };
        _lightboxAnimSb = sb;
        sb.Begin();
    }

    /// <summary>
    /// 完成关闭：隐藏、释放图片源、重置变换与窗口动画状态。
    /// </summary>
    private void FinishCloseLightbox(bool restoreAutoPlay = true)
    {
        StopLightboxAnim();
        ImageLightbox.Visibility = Visibility.Collapsed;
        LightboxImage.Source = null;
        ResetLightboxTransform();
        LightboxWindow.Opacity = 1;               // 复位，防止下次入场动画起点错误
        LightboxWindow.RenderTransform = null;    // 复位窗口变换，防止下次入场残留缩放/位移
        if (restoreAutoPlay)
            StartAutoPlayTimer();
        System.Diagnostics.Debug.WriteLine("[MainPage] 悬浮大图已关闭");
    }

    /// <summary>
    /// 获取（或创建）LightboxWindow 的 TransformGroup（Scale + Translate），供入场/退场动画使用。
    /// </summary>
    private TransformGroup GetOrCreateLightboxWindowTransform()
    {
        if (LightboxWindow.RenderTransform is TransformGroup group && group.Children.Count == 2)
            return group;
        group = new TransformGroup();
        group.Children.Add(new ScaleTransform { ScaleX = 1, ScaleY = 1 });
        group.Children.Add(new TranslateTransform());
        LightboxWindow.RenderTransform = group;
        return group;
    }

    /// <summary>停止正在播放的 Lightbox 动画（快速连续打开/关闭时防止旧动画驱动新状态）</summary>
    private void StopLightboxAnim()
    {
        if (_lightboxAnimSb != null)
        {
            _lightboxAnimSb.Stop();
            _lightboxAnimSb = null;
        }
    }

    /// <summary>
    /// 重置大图缩放/平移变换。
    /// </summary>
    private void ResetLightboxTransform()
    {
        LightboxTransform.ScaleX = 1;
        LightboxTransform.ScaleY = 1;
        LightboxTransform.TranslateX = 0;
        LightboxTransform.TranslateY = 0;
        LightboxTransform.CenterX = 0;
        LightboxTransform.CenterY = 0;
    }

    /// <summary>
    /// 点击悬浮层背景（非图片区域）→ 关闭。
    /// </summary>
    private void OnLightboxBackgroundTapped(object sender, TappedRoutedEventArgs e) => CloseLightbox();

    /// <summary>
    /// 图片区域点击不关闭（仅消费事件，阻止冒泡到背景层）。
    /// </summary>
    private void OnLightboxImageHostTapped(object sender, TappedRoutedEventArgs e) => e.Handled = true;

    /// <summary>
    /// 双击图片 → 还原 100% 缩放与居中。
    /// </summary>
    private void OnLightboxDoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
    {
        ResetLightboxTransform();
        e.Handled = true;
    }

    /// <summary>
    /// 关闭按钮 → 关闭。
    /// </summary>
    private void OnLightboxCloseClick(object sender, RoutedEventArgs e) => CloseLightbox();

    /// <summary>
    /// Esc 键 → 关闭。
    /// </summary>
    private void OnLightboxKeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == VirtualKey.Escape)
        {
            CloseLightbox();
            e.Handled = true;
        }
    }

    /// <summary>
    /// 窗口尺寸变化时同步裁剪几何（图片被裁剪在窗口矩形内，
    /// 四角露出窗口圆角背景，视觉上呈现圆角窗口内嵌图片）。
    /// </summary>
    private void OnLightboxWindowSizeChanged(object sender, SizeChangedEventArgs e)
    {
        if (LightboxClip != null)
        {
            LightboxClip.Rect = new Rect(0, 0, e.NewSize.Width, e.NewSize.Height);
        }
    }

    /// <summary>
    /// 限制平移范围：放大后图片边缘不得越出窗口（用于改变浏览区间而非拖出画面）。
    /// 缩放中心为容器中心，故最大偏移 = (图片显示尺寸 - 容器尺寸) / 2。
    /// </summary>
    private void ClampLightboxTranslation()
    {
        double scale = LightboxTransform.ScaleX;
        if (scale <= 0) return;

        // Image.ActualWidth 为 Uniform 布局尺寸（RenderTransform 不影响布局），缩放后显示尺寸 = 布局尺寸 × Scale
        double imgW = LightboxImage.ActualWidth;
        double imgH = LightboxImage.ActualHeight;
        if (double.IsNaN(imgW) || imgW <= 0 || double.IsNaN(imgH) || imgH <= 0) return;

        double hostW = LightboxImageHost.ActualWidth;
        double hostH = LightboxImageHost.ActualHeight;
        if (double.IsNaN(hostW) || hostW <= 0 || double.IsNaN(hostH) || hostH <= 0) return;

        double maxX = Math.Max(0, (imgW * scale - hostW) / 2);
        double maxY = Math.Max(0, (imgH * scale - hostH) / 2);

        double tx = Math.Clamp(LightboxTransform.TranslateX, -maxX, maxX);
        double ty = Math.Clamp(LightboxTransform.TranslateY, -maxY, maxY);
        if (!double.IsNaN(tx)) LightboxTransform.TranslateX = tx;
        if (!double.IsNaN(ty)) LightboxTransform.TranslateY = ty;
    }

    /// <summary>
    /// 滚轮缩放（以图片容器中心为缩放中心，范围 0.5x–6x）。
    /// 缩放后限制平移边界，标记 Handled 阻止滚轮穿透到页面 ScrollViewer。
    /// </summary>
    private void OnLightboxWheel(object sender, PointerRoutedEventArgs e)
    {
        if (ImageLightbox.Visibility != Visibility.Visible) return;

        int delta = e.GetCurrentPoint(this).Properties.MouseWheelDelta;
        double factor = delta > 0 ? 1.15 : 1.0 / 1.15;
        double newScale = Math.Clamp(LightboxTransform.ScaleX * factor, LightboxMinScale, LightboxMaxScale);

        // 以容器中心缩放，视觉上图片围绕画面中心缩放
        LightboxTransform.CenterX = LightboxImageHost.ActualWidth / 2;
        LightboxTransform.CenterY = LightboxImageHost.ActualHeight / 2;
        LightboxTransform.ScaleX = newScale;
        LightboxTransform.ScaleY = newScale;
        ClampLightboxTranslation();
        e.Handled = true;
    }

    /// <summary>
    /// 按下：记录拖拽起点并捕获指针（坐标无效时忽略，防止 NaN 写入变换）。
    /// </summary>
    private void OnLightboxImagePointerPressed(object sender, PointerRoutedEventArgs e)
    {
        if (ImageLightbox.Visibility != Visibility.Visible) return;
        var point = e.GetCurrentPoint(LightboxImageHost);
        if (double.IsNaN(point.Position.X) || double.IsNaN(point.Position.Y)) return;
        _isLightboxDragging = true;
        _lightboxDragStart = point.Position;
        _lightboxStartTranslateX = LightboxTransform.TranslateX;
        _lightboxStartTranslateY = LightboxTransform.TranslateY;
        LightboxImageHost.CapturePointer(e.Pointer);
        e.Handled = true;
    }

    /// <summary>
    /// 移动：更新平移偏移并限制在窗口边界内（坐标无效时跳过，防止 NaN 异常）。
    /// </summary>
    private void OnLightboxImagePointerMoved(object sender, PointerRoutedEventArgs e)
    {
        if (!_isLightboxDragging) return;
        var point = e.GetCurrentPoint(LightboxImageHost);
        double dx = point.Position.X - _lightboxDragStart.X;
        double dy = point.Position.Y - _lightboxDragStart.Y;
        // ★ 捕获指针期间 GetCurrentPoint 可能返回 NaN，写入 CompositeTransform 会抛
        //   ArgumentException (0x80070057) — 无效坐标直接跳过本次更新
        if (double.IsNaN(dx) || double.IsNaN(dy) || double.IsInfinity(dx) || double.IsInfinity(dy)) return;
        LightboxTransform.TranslateX = _lightboxStartTranslateX + dx;
        LightboxTransform.TranslateY = _lightboxStartTranslateY + dy;
        ClampLightboxTranslation();
        e.Handled = true;
    }

    /// <summary>
    /// 释放/取消/捕获丢失：结束拖拽并释放指针。
    /// </summary>
    private void OnLightboxImagePointerReleased(object sender, PointerRoutedEventArgs e)
    {
        if (!_isLightboxDragging) return;
        _isLightboxDragging = false;
        LightboxImageHost.ReleasePointerCapture(e.Pointer);
        e.Handled = true;
    }

    // ================================================================
    //  导航生命周期（GIF 暂停/恢复隔离）
    //  页面不可见时暂停 GIF 动画，避免后台纹理上传竞争 UI 线程和 GPU
    // ================================================================

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        _isNavigatedAway = false;
        base.OnNavigatedTo(e);

        // ★ [头像修复] NavigationCacheMode=Required 下页面实例被缓存复用，
        //   退出登录再登录不会执行构造函数；登出期间 AvatarChanged 事件
        //   也被 _isNavigatedAway 拦截丢弃（SafeDispatch 双检查）。
        //   因此切回首页时从服务重新读取当前头像路径并应用，
        //   保证登录后头像与设置界面一致（设置面板是打开时实时读取，无此问题）。
        ApplyAvatar(_avatarService?.CurrentAvatarPath);

        ResumeAllGifs();
        StartAutoPlayTimer();
        // ★ 切回首页：重新加载信息流媒体资源（离开时已释放），完成后恢复视频/HTML 覆层
        _ = ReloadAndRestoreOverlayAsync();
    }

    /// <summary>
    /// 重新加载信息流卡片媒体资源，完成后恢复当前卡片的视频/HTML 覆层。
    /// 期间可能再次导航离开，每个异步步骤后都检查 _isNavigatedAway。
    /// </summary>
    private async Task ReloadAndRestoreOverlayAsync()
    {
        await NotificationVM.ReloadCardsAsync();
        if (_isNavigatedAway) return;
        UpdateOverlayForCurrentCard();
    }

    protected override void OnNavigatedFrom(NavigationEventArgs e)
    {
        // ★ 必须最先置位，让所有正在执行的异步方法在 await 后立即感知并中止
        _isNavigatedAway = true;
        base.OnNavigatedFrom(e);
        // ★ 离开首页时关闭悬浮大图（不恢复自动播放，避免离页后计时器继续运行）
        CloseLightbox(restoreAutoPlay: false);
        PauseAllGifs();
        StopAutoPlayTimer();
        // ★ 复位 HTML 悬停标记（离开页面时若光标仍在 HTML 上，不会触发 PointerExited）
        _isPointerOverHtml = false;
        // ★ 离开首页时彻底清理所有信息流媒体资源
        StopVideoPlayer();
        if (CardHtmlView != null)
        {
            try { CardHtmlView.CoreWebView2?.NavigateToString(""); } catch { }
            CardHtmlView.Visibility = Visibility.Collapsed;
        }
        if (CardVideoPlayer != null)
            CardVideoPlayer.Visibility = Visibility.Collapsed;
        // ★ 释放信息流卡片的图片/HTML/视频路径引用，让位图解码内存可被 GC 回收
        //   （原始数据仍在 RemoteInfoCardService DTO 缓存中，切回时 ReloadCardsAsync 重建）
        NotificationVM.ReleaseMediaResources();
    }

    /// <summary>
    /// 设置命令按钮的统一 Click 处理：保存 sender 引用后执行命令
    /// </summary>
    private void OnSettingsCommandClick(object sender, RoutedEventArgs e)
    {
        _settingsCommandSender = sender as FrameworkElement;
    }

    // ================================================================
    //  账号设置结果通知 Flyout（仿退出登录风格）
    // ================================================================

    private void OnSettingsResultNotification(string title, string message, bool isSuccess, Action? onConfirmed = null)
    {
        SafeDispatch(() =>
        {
            var anchor = _settingsCommandSender ?? SettingsFlyoutAnchor;
            _settingsCommandSender = null;

            FlyoutHelper.ShowInfo(
                anchor,
                FlyoutPlacementMode.BottomEdgeAlignedRight,
                isSuccess ? "\uE73E" : "\uE783",
                Color.FromArgb(255,
                    isSuccess ? (byte)76 : (byte)255,
                    isSuccess ? (byte)175 : (byte)193,
                    isSuccess ? (byte)80 : (byte)7),
                title,
                message,
                onConfirmed: onConfirmed);
        });
    }

    // ================================================================
    //  头像管理
    // ================================================================

    private void OnAvatarChanged(string? path)
    {
        SafeDispatch(() =>
        {
            ApplyAvatar(path);
            // 如果设置面板可见，同步更新
            if (AccountSettingsPanel.Visibility == Visibility.Visible)
                SyncSettingsPanelAvatar();
        });
    }

    /// <summary>
    /// 统一的头像渲染方法：支持 GIF 动图和静态图。
    /// 返回新创建的 GifRenderer（GIF 时）或 null（静态图 / 路径为空）。
    /// 调用方应在调用前通过 StopGif 清理旧的 GifRenderer。
    /// </summary>
    private static async Task<GifRenderer?> ApplyAvatarTo(Image image, Border glyphBorder, Border imageBorder,
        string? path, string logPrefix = "头像")
    {
        if (string.IsNullOrEmpty(path))
        {
            glyphBorder.Visibility = Visibility.Visible;
            imageBorder.Visibility = Visibility.Collapsed;
            return null;
        }

        try
        {
            var cleanPath = path.Contains('?') ? path[..path.IndexOf('?')] : path;
            bool isGif = cleanPath.EndsWith(".gif", StringComparison.OrdinalIgnoreCase);

            if (isGif)
            {
                var gifRenderer = new GifRenderer(image);
                await gifRenderer.LoadGifAsync(cleanPath);
                glyphBorder.Visibility = Visibility.Collapsed;
                imageBorder.Visibility = Visibility.Visible;
                return gifRenderer;
            }
            else
            {
                image.Source = new BitmapImage(new Uri("file:///" + path));
                glyphBorder.Visibility = Visibility.Collapsed;
                imageBorder.Visibility = Visibility.Visible;
                return null;
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[MainPage] {logPrefix}加载失败: {ex.Message}");
            glyphBorder.Visibility = Visibility.Visible;
            imageBorder.Visibility = Visibility.Collapsed;
            return null;
        }
    }

    /// <summary>
    /// 停止并释放指定的 GifRenderer。
    /// </summary>
    private static void StopGif(ref GifRenderer? gifRenderer)
    {
        gifRenderer?.Stop();
        gifRenderer = null;
    }

    /// <summary>
    /// 暂停所有 GIF 头像动画（页面不可见 / 退场动画期间调用）。
    /// </summary>
    private void PauseAllGifs()
    {
        _mainAvatarGif?.Pause();
        _settingsAvatarGif?.Pause();
    }

    /// <summary>
    /// 恢复所有 GIF 头像动画（页面可见 / 入场动画完成后调用）。
    /// </summary>
    private void ResumeAllGifs()
    {
        _mainAvatarGif?.Resume();
        _settingsAvatarGif?.Resume();
    }

    private async void ApplyAvatar(string? path)
    {
        StopGif(ref _mainAvatarGif);
        _mainAvatarGif = await ApplyAvatarTo(MainAvatarImg, MainAvatarGlyph, MainAvatarImage, path);
    }

    // ================================================================
    //  账号设置面板开关
    // ================================================================

    /// <summary>
    /// 打开设置面板：主页内容退场 → 设置面板从右侧滑入
    /// </summary>
    private void OnOpenSettingsClick(object sender, RoutedEventArgs e)
    {
        // 同步设置面板头像
        SyncSettingsPanelAvatar();

        // ★ [账户切换同步] 打开设置面板时主动刷新名片信息（用户名/登录时长/上次登录时间），
        //   与 LoginStateChanged 订阅形成双保险，确保面板打开即显示当前登录用户的数据。
        SettingsVM.RefreshAccountInfo();

        PlayExitAnimation(() =>
        {
            AccountSettingsPanel.Visibility = Visibility.Visible;
            AnimateSettingsPanelIn();
        });
    }

    /// <summary>
    /// 清空所有输入框（PasswordBox 不支持 MVVM 绑定，需 code-behind 手动清空）
    /// </summary>
    private void ClearSettingsInputs()
    {
        SettingsVM.ResetFormFields();
        SettingsCurrentPasswordBox.Password = string.Empty;
        SettingsNewPasswordBox.Password = string.Empty;
        SettingsConfirmPasswordBox.Password = string.Empty;
    }

    /// <summary>
    /// 关闭设置面板：设置面板滑出 → 主页内容入场
    /// </summary>
    /// <summary>
    /// 如果设置面板已打开，关闭它（由 ShellPage 在导航切出前调用）
    /// </summary>
    /// <param name="onCompleted">完成回调</param>
    /// <param name="restoreSections">关闭后是否恢复首页容器的透明度（为 false 表示即将切出，无需恢复）</param>
    public void CloseSettingsPanelIfOpen(Action onCompleted, bool restoreSections = true)
    {
        if (AccountSettingsPanel.Visibility != Visibility.Visible)
        {
            onCompleted();
            return;
        }
        ClearSettingsInputs();
        AnimateSettingsPanelOut(() =>
        {
            AccountSettingsPanel.Visibility = Visibility.Collapsed;
            if (restoreSections)
            {
                PlayEnterAnimation();
            }
            onCompleted();
        });
    }

    /// <summary>
    /// 关闭设置面板：设置面板滑出 → 主页内容入场
    /// </summary>
    private void OnCloseSettingsClick(object sender, RoutedEventArgs e)
    {
        ClearSettingsInputs();
        AnimateSettingsPanelOut(() =>
        {
            AccountSettingsPanel.Visibility = Visibility.Collapsed;
            PlayEnterAnimation();
        });
    }

    private void AnimateSettingsPanelIn()
    {
        const int durationMs = 350;
        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };

        var translate = new TranslateTransform { X = 80 };
        AccountSettingsPanel.RenderTransform = translate;
        AccountSettingsPanel.Opacity = 0;

        var sb = new Storyboard();

        var fadeAnim = new DoubleAnimation
        {
            From = 0, To = 1,
            Duration = TimeSpan.FromMilliseconds(durationMs),
            EasingFunction = ease,
        };
        Storyboard.SetTarget(fadeAnim, AccountSettingsPanel);
        Storyboard.SetTargetProperty(fadeAnim, "Opacity");
        sb.Children.Add(fadeAnim);

        var slideAnim = new DoubleAnimation
        {
            From = 80, To = 0,
            Duration = TimeSpan.FromMilliseconds(durationMs),
            EasingFunction = ease,
        };
        Storyboard.SetTarget(slideAnim, translate);
        Storyboard.SetTargetProperty(slideAnim, "X");
        sb.Children.Add(slideAnim);

        sb.Begin();
    }

    private void AnimateSettingsPanelOut(Action onCompleted)
    {
        const int durationMs = 250;
        var ease = new CubicEase { EasingMode = EasingMode.EaseIn };

        var translate = new TranslateTransform();
        AccountSettingsPanel.RenderTransform = translate;

        var sb = new Storyboard();

        var fadeAnim = new DoubleAnimation
        {
            From = 1, To = 0,
            Duration = TimeSpan.FromMilliseconds(durationMs),
            EasingFunction = ease,
        };
        Storyboard.SetTarget(fadeAnim, AccountSettingsPanel);
        Storyboard.SetTargetProperty(fadeAnim, "Opacity");
        sb.Children.Add(fadeAnim);

        var slideAnim = new DoubleAnimation
        {
            From = 0, To = 80,
            Duration = TimeSpan.FromMilliseconds(durationMs),
            EasingFunction = ease,
        };
        Storyboard.SetTarget(slideAnim, translate);
        Storyboard.SetTargetProperty(slideAnim, "X");
        sb.Children.Add(slideAnim);

        sb.Completed += (_, _) =>
        {
            AccountSettingsPanel.RenderTransform = null;
            onCompleted();
        };
        sb.Begin();
    }

    // ================================================================
    //  设置页面密码框同步
    // ================================================================

    private void OnSettingsCurrentPasswordChanged(object sender, RoutedEventArgs e)
    {
        SettingsVM.CurrentPassword = SettingsCurrentPasswordBox.Password;
    }

    private void OnSettingsNewPasswordChanged(object sender, RoutedEventArgs e)
    {
        SettingsVM.NewPassword = SettingsNewPasswordBox.Password;
    }

    private void OnSettingsConfirmPasswordChanged(object sender, RoutedEventArgs e)
    {
        SettingsVM.ConfirmPassword = SettingsConfirmPasswordBox.Password;
    }

    /// <summary>
    /// 同步设置面板中的头像显示
    /// </summary>
    private async void SyncSettingsPanelAvatar()
    {
        StopGif(ref _settingsAvatarGif);
        _settingsAvatarGif = await ApplyAvatarTo(AvatarImage, AvatarGlyphContainer, AvatarImageContainer,
            _avatarService?.CurrentAvatarPath);
    }

    // ================================================================
    //  通知中心标签切换逻辑
    // ================================================================
    private void OnNotificationPivotSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (sender is not Pivot pivot) return;

        // 三个标签各自拥有独立的顶层容器
        var panels = new[] { "PushContentPanel", "ServiceContentPanel", "LogContentPanel" };
        int newIndex = pivot.SelectedIndex;
        if (newIndex < 0 || newIndex >= panels.Length) return;

        // 更新 ViewModel 中的标签索引（供清除按钮分派使用）
        NotificationVM.SelectedTabIndex = newIndex;

        // 找出当前可见（Opacity > 0）的面板索引
        int oldIndex = -1;
        for (int i = 0; i < panels.Length; i++)
        {
            if (FindName(panels[i]) is Grid p && p.Opacity > 0)
            {
                oldIndex = i;
                break;
            }
        }

        // 相同标签，不做任何操作
        if (oldIndex == newIndex)
            return;

        // ★ 在首页内切换标签不做任何资源释放，所有内容保持加载
        //    （视频继续播放、视觉树完整保留），仅做透明度动画切换

        // 计算滑动方向：右滑为正，左滑为负
        int direction = newIndex > oldIndex ? 1 : -1;

        const double animMs = 300;
        var ease = new CircleEase { EasingMode = EasingMode.EaseOut };

        // ---- 旧面板淡出（不 Collapsed，保持视觉树加载） ----
        if (oldIndex >= 0 && FindName(panels[oldIndex]) is Grid oldPanel)
        {
            // ★ 立即禁用交互，防止淡出过程中误触
            oldPanel.IsHitTestVisible = false;

            // ★ 离开信息流时：仅隐藏卡片的深色底板（CardMediaBorder #0d0d1a），
            //    避免淡出时深色底板透过半透明背景浮现，
            //    但不卸载 InfoCardContainer 保持 WebView2/图片/视频视觉树持久化
            if (oldIndex == 0 && FindName("CardMediaBorder") is Border mediaBorder)
                mediaBorder.Opacity = 0;

            var oldTranslate = new TranslateTransform();
            oldPanel.RenderTransform = oldTranslate;

            var outSb = new Storyboard();

            var fadeOut = new DoubleAnimation
            {
                From = 1.0, To = 0.0,
                Duration = TimeSpan.FromMilliseconds(animMs),
                EasingFunction = ease,
            };
            Storyboard.SetTarget(fadeOut, oldPanel);
            Storyboard.SetTargetProperty(fadeOut, "Opacity");
            outSb.Children.Add(fadeOut);

            var slideOut = new DoubleAnimation
            {
                From = 0, To = -direction * 40,
                Duration = TimeSpan.FromMilliseconds(animMs),
                EasingFunction = ease,
            };
            Storyboard.SetTarget(slideOut, oldTranslate);
            Storyboard.SetTargetProperty(slideOut, "X");
            outSb.Children.Add(slideOut);

            outSb.Completed += (_, _) =>
            {
                oldPanel.RenderTransform = null;
                // ★ 恢复 CardMediaBorder 不透明度，供下次切回时使用
                if (oldIndex == 0 && FindName("CardMediaBorder") is Border mb)
                    mb.Opacity = 1.0;
                // ★ 不设置 Visibility=Collapsed，仅保持 Opacity=0，视觉树不卸载
            };
            outSb.Begin();
        }

        // ---- 新面板从反方向滑入 + 淡入 ----
        if (FindName(panels[newIndex]) is Grid newPanel)
        {
            // ★ 确保新面板可见（首次加载时可能为 Opacity=0）
            if (newPanel.Visibility != Visibility.Visible)
                newPanel.Visibility = Visibility.Visible;
            // ★ 淡入过程中允许交互
            newPanel.IsHitTestVisible = true;

            // ★ 切回信息流时：遮罩卡片初始透明，与媒体容器同步淡入，防止闪现
            Border? overlay = null;
            if (newIndex == 0)
            {
                overlay = FindName("CardOverlayPanel") as Border;
                if (overlay != null)
                    overlay.Opacity = 0.0;
            }

            var newTranslate = new TranslateTransform { X = direction * 40 };
            newPanel.RenderTransform = newTranslate;
            newPanel.Opacity = 0.0;

            var inSb = new Storyboard();

            var fadeIn = new DoubleAnimation
            {
                From = 0.0, To = 1.0,
                Duration = TimeSpan.FromMilliseconds(animMs),
                EasingFunction = ease,
            };
            Storyboard.SetTarget(fadeIn, newPanel);
            Storyboard.SetTargetProperty(fadeIn, "Opacity");
            inSb.Children.Add(fadeIn);

            // ★ 遮罩卡片同步淡入
            if (overlay != null)
            {
                var overlayFadeIn = new DoubleAnimation
                {
                    From = 0.0, To = 1.0,
                    Duration = TimeSpan.FromMilliseconds(animMs),
                    EasingFunction = ease,
                };
                Storyboard.SetTarget(overlayFadeIn, overlay);
                Storyboard.SetTargetProperty(overlayFadeIn, "Opacity");
                inSb.Children.Add(overlayFadeIn);
            }

            var slideIn = new DoubleAnimation
            {
                From = direction * 40, To = 0,
                Duration = TimeSpan.FromMilliseconds(animMs),
                EasingFunction = ease,
            };
            Storyboard.SetTarget(slideIn, newTranslate);
            Storyboard.SetTargetProperty(slideIn, "X");
            inSb.Children.Add(slideIn);

            inSb.Completed += (_, _) =>
            {
                newPanel.RenderTransform = null;
                // ★ 在首页内切换不做任何资源释放，无需恢复覆层
            };
            inSb.Begin();
        }
    }

    // ================================================================
    //  首页切入入场动画（由 ShellPage 在背景淡入完成后调用）
    // ================================================================

    /// <summary>
    /// 切入首页：一级容器按顺序逐个淡入，营造渐进式加载感。
    /// 通知中心额外带微缩放弹出效果。
    /// </summary>
    public void PlayEnterAnimation()
    {
        // ★ 停止所有正在进行的退场/入场动画，并将各 section 重置到干净状态
        StopAndClearSectionAnimations();
        ResetSectionsVisibility();

        // 收集三个一级容器（LoginSection 可能因绑定隐藏，但动画仍需处理）
        var sections = new[]
        {
            (element: (UIElement)LoginSection, delayMs: 0),
            (element: (UIElement)QuickStartSection, delayMs: 100),
            (element: (UIElement)NotificationSection, delayMs: 200),
        };

        const double fadeInMs = 350;
        var opacityEase = new CircleEase { EasingMode = EasingMode.EaseOut };
        var translateEase = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.3 };

        for (int i = 0; i < sections.Length; i++)
        {
            var section = sections[i];
            section.element.Opacity = 0.0;

            var translate = new TranslateTransform { Y = 20 };
            section.element.RenderTransform = translate;

            var delaySb = new Storyboard();
            delaySb.BeginTime = TimeSpan.FromMilliseconds(section.delayMs);

            var fadeAnim = new DoubleAnimation
            {
                From = 0.0,
                To = 1.0,
                Duration = TimeSpan.FromMilliseconds(fadeInMs),
                EasingFunction = opacityEase,
            };
            Storyboard.SetTarget(fadeAnim, section.element);
            Storyboard.SetTargetProperty(fadeAnim, "Opacity");
            delaySb.Children.Add(fadeAnim);

            var floatAnim = new DoubleAnimation
            {
                From = 20,
                To = 0,
                Duration = TimeSpan.FromMilliseconds(fadeInMs + 100),
                EasingFunction = translateEase,
            };
            Storyboard.SetTarget(floatAnim, translate);
            Storyboard.SetTargetProperty(floatAnim, "Y");
            delaySb.Children.Add(floatAnim);

            // 通知中心额外添加微缩放弹出效果
            if (section.element == NotificationSection)
            {
                var scaleX = new ScaleTransform { ScaleX = 0.96, ScaleY = 0.96 };
                var group = new TransformGroup();
                group.Children.Add(translate);
                group.Children.Add(scaleX);
                section.element.RenderTransform = group;

                var scaleAnimX = new DoubleAnimation
                {
                    From = 0.96, To = 1.0,
                    Duration = TimeSpan.FromMilliseconds(fadeInMs + 150),
                    EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.25 },
                };
                Storyboard.SetTarget(scaleAnimX, scaleX);
                Storyboard.SetTargetProperty(scaleAnimX, "ScaleX");
                delaySb.Children.Add(scaleAnimX);

                var scaleAnimY = new DoubleAnimation
                {
                    From = 0.96, To = 1.0,
                    Duration = TimeSpan.FromMilliseconds(fadeInMs + 150),
                    EasingFunction = new BackEase { EasingMode = EasingMode.EaseOut, Amplitude = 0.25 },
                };
                Storyboard.SetTarget(scaleAnimY, scaleX);
                Storyboard.SetTargetProperty(scaleAnimY, "ScaleY");
                delaySb.Children.Add(scaleAnimY);
            }

            delaySb.Begin();

            // ★ 追踪 Storyboard，以便后续停止
            _activeSectionAnimations.Add(delaySb);

            // 最后一段动画完成后恢复 GIF 渲染
            if (i == sections.Length - 1)
            {
                delaySb.Completed += (_, _) =>
                {
                    ResumeAllGifs();

                    // ★ 通知更新服务：首页已完全加载，可弹出更新提示
                    //   （避免更新弹窗与首页入场动画抢占视觉焦点）
                    try
                    {
                        App.Services.GetRequiredService<AppUpdateService>()
                            .NotifyHomePageReady();
                    }
                    catch { /* 服务未就绪不影响入场动画 */ }
                };
            }
        }
    }

    // ================================================================
    //  退出登录确认飞入菜单（仿左栏实例删除/离开向导风格）
    // ================================================================

    /// <summary>
    /// 退出登录按钮点击 —— 弹出 Flyout 确认后执行退出
    /// </summary>
    private async void OnLogoutClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button anchor) return;

        bool confirmed = await FlyoutHelper.ShowConfirmAsync(
            anchor,
            FlyoutPlacementMode.BottomEdgeAlignedRight,
            "\uE783",
            Color.FromArgb(255, 229, 115, 115),
            "要退出当前登录的账号吗？",
            "退出后需要重新登录才能继续使用 Kirara Server",
            confirmText: "退出登录",
            confirmColor: Color.FromArgb(255, 229, 115, 115));

        if (confirmed)
            ViewModel.LogoutCommand.Execute(null);
    }

    /// <summary>
    /// 取消退出动画时调用：立即恢复所有 section 的透明度和位移，
    /// 确保 PlayEnterAnimation 能从一个干净的状态开始。
    /// </summary>
    public void ResetSectionsVisibility()
    {
        var sections = new UIElement[] { LoginSection, QuickStartSection, NotificationSection };
        foreach (var section in sections)
        {
            section.Opacity = 1.0;
            section.RenderTransform = null;
        }
    }

    /// <summary>
    /// 停止所有正在进行的 section 入场/退场动画并清理追踪列表。
    /// </summary>
    private void StopAndClearSectionAnimations()
    {
        foreach (var sb in _activeSectionAnimations)
            sb.Stop();
        _activeSectionAnimations.Clear();
    }

    private void ResetSectionExitBaseState()
    {
        var sections = new UIElement[] { LoginSection, QuickStartSection, NotificationSection };
        foreach (var section in sections)
        {
            section.Opacity = 1.0;
            section.RenderTransform = null;
        }
    }

    /// <summary>
    /// 切出首页：一级容器倒序逐个淡出下沉，完成后回调。
    /// 如果设置面板处于打开状态，一并纳入退出动画（优先淡出）。
    /// 通知中心额外带微缩退场效果。
    /// </summary>
    public void PlayExitAnimation(Action onCompleted)
    {
        // ★ 停止所有正在进行的入场/退场动画，避免 Storyboard 累积
        StopAndClearSectionAnimations();

        // ★ 立即恢复各 section 到可见状态：WinUI 的 Storyboard.Stop() 可能导致
        //    FillBehavior=HoldEnd 的动画属性回退到 XAML 基值（Opacity=0），
        //    若不主动重置，后续退场动画的 From 将读到 0，导致 0→0 无动画（闪现消失）。
        ResetSectionExitBaseState();

        // 立即暂停 GIF 动画，避免退场动画期间 GIF 纹理上传竞争 UI 线程/GPU
        PauseAllGifs();

        // 构建退出元素列表
        var sectionList = new List<(UIElement element, double delayMs)>();

        // 设置面板如果打开，优先放入列表最前（最先开始退场）
        bool settingsPanelOpen = AccountSettingsPanel.Visibility == Visibility.Visible;
        if (settingsPanelOpen)
        {
            sectionList.Add((AccountSettingsPanel, 0));
        }

        // 倒序：通知中心 → 快速开始 → 登录区
        // 设置面板打开时各区块延迟略微后移，避免与面板动画拥挤
        double delayOffset = settingsPanelOpen ? 40 : 0;
        sectionList.Add((NotificationSection, delayOffset + 0));
        sectionList.Add((QuickStartSection, delayOffset + 70));
        sectionList.Add((LoginSection, delayOffset + 140));

        var sections = sectionList.ToArray();

        const double fadeOutMs = 220;
        var opacityEase = new CircleEase { EasingMode = EasingMode.EaseIn };
        var translateEase = new CubicEase { EasingMode = EasingMode.EaseIn };

        // 计算总时长：最后一个元素结束时间
        double totalExitMs = sections[^1].delayMs + fadeOutMs;

        for (int i = 0; i < sections.Length; i++)
        {
            var section = sections[i];

            var translate = new TranslateTransform { Y = 0 };
            section.element.RenderTransform = translate;

            var delaySb = new Storyboard();
            delaySb.BeginTime = TimeSpan.FromMilliseconds(section.delayMs);

            var fadeAnim = new DoubleAnimation
            {
                From = 1.0,
                To = 0.0,
                Duration = TimeSpan.FromMilliseconds(fadeOutMs),
                EasingFunction = opacityEase,
            };
            Storyboard.SetTarget(fadeAnim, section.element);
            Storyboard.SetTargetProperty(fadeAnim, "Opacity");
            delaySb.Children.Add(fadeAnim);

            // 设置面板：向右滑出（80px → 0），而非下沉
            if (section.element == AccountSettingsPanel)
            {
                var slideOutAnim = new DoubleAnimation
                {
                    From = 0,
                    To = 80,
                    Duration = TimeSpan.FromMilliseconds(fadeOutMs),
                    EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn },
                };
                Storyboard.SetTarget(slideOutAnim, translate);
                Storyboard.SetTargetProperty(slideOutAnim, "X");
                delaySb.Children.Add(slideOutAnim);

                // 面板退出完成后隐藏
                delaySb.Completed += (_, _) =>
                {
                    AccountSettingsPanel.Visibility = Visibility.Collapsed;
                    AccountSettingsPanel.RenderTransform = null;
                    AccountSettingsPanel.Opacity = 1.0;
                };
            }
            else
            {
                // 微下沉（0 → -20px，营造退场感）
                var floatAnim = new DoubleAnimation
                {
                    From = 0,
                    To = -20,
                    Duration = TimeSpan.FromMilliseconds(fadeOutMs),
                    EasingFunction = translateEase,
                };
                Storyboard.SetTarget(floatAnim, translate);
                Storyboard.SetTargetProperty(floatAnim, "Y");
                delaySb.Children.Add(floatAnim);
            }

            // 通知中心额外添加微缩退场效果
            if (section.element == NotificationSection)
            {
                var scaleX = new ScaleTransform { ScaleX = 1.0, ScaleY = 1.0 };
                var group = new TransformGroup();
                group.Children.Add(translate);
                group.Children.Add(scaleX);
                section.element.RenderTransform = group;

                var scaleAnimX = new DoubleAnimation
                {
                    From = 1.0, To = 0.95,
                    Duration = TimeSpan.FromMilliseconds(fadeOutMs),
                    EasingFunction = new CircleEase { EasingMode = EasingMode.EaseIn },
                };
                Storyboard.SetTarget(scaleAnimX, scaleX);
                Storyboard.SetTargetProperty(scaleAnimX, "ScaleX");
                delaySb.Children.Add(scaleAnimX);

                var scaleAnimY = new DoubleAnimation
                {
                    From = 1.0, To = 0.95,
                    Duration = TimeSpan.FromMilliseconds(fadeOutMs),
                    EasingFunction = new CircleEase { EasingMode = EasingMode.EaseIn },
                };
                Storyboard.SetTarget(scaleAnimY, scaleX);
                Storyboard.SetTargetProperty(scaleAnimY, "ScaleY");
                delaySb.Children.Add(scaleAnimY);
            }

            delaySb.Begin();

            // ★ 追踪 Storyboard，以便后续停止
            _activeSectionAnimations.Add(delaySb);
        }

        // 所有动画完成后触发回调
        var completeTimer = new DispatcherTimer();
        completeTimer.Interval = TimeSpan.FromMilliseconds(totalExitMs + 50);
        completeTimer.Tick += (s, e) =>
        {
            completeTimer.Stop();
            onCompleted?.Invoke();
        };
        completeTimer.Start();
    }

    // ================================================================
    //  模板卡片封面图片加载失败回退
    // ================================================================

    /// <summary>
    /// 模板封面图片加载失败时回退到内置默认图片。
    /// 适用于网络图加载失败（如 URL 失效、网络中断等场景）。
    /// </summary>
    private void OnTemplateCardImageFailed(object sender, ExceptionRoutedEventArgs e)
    {
        if (sender is Image img)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[MainPage] 模板封面图加载失败，回退到默认图片: {e.ErrorMessage}");
            // Unpackaged 模式下 ms-appx 协议不可用，需解析为输出目录文件路径
            img.Source = new BitmapImage(new Uri(AssetPathHelper.Resolve("Assets/template_default.png")));
        }
    }

    // ================================================================
    //  模板卡片交互动画（与 InstanceEditorPage 方案卡片完全一致）
    // ================================================================

    /// <summary>
    /// 悬停进入：优雅放大 1.05× + 上浮 4px
    /// </summary>
    private void OnTemplateCardPointerEntered(object sender, PointerRoutedEventArgs e)
    {
        var card = GetTemplateCardBorder(sender);
        if (card == null) return;

        var scale = GetScaleTransform(card);
        var translate = GetTranslateTransform(card);
        if (scale == null || translate == null) return;

        var sb = new Storyboard();
        AddDoubleAnim(sb, scale, 400, 1.0, 1.05, new QuarticEase { EasingMode = EasingMode.EaseOut }, "ScaleX");
        AddDoubleAnim(sb, scale, 400, 1.0, 1.05, new QuarticEase { EasingMode = EasingMode.EaseOut }, "ScaleY");
        AddDoubleAnim(sb, translate, 400, 0.0, -4.0, new QuarticEase { EasingMode = EasingMode.EaseOut }, "Y");
        sb.Begin();
    }

    /// <summary>
    /// 悬停离开：弹性回弹 + 位移归零
    /// </summary>
    private void OnTemplateCardPointerExited(object sender, PointerRoutedEventArgs e)
    {
        var card = GetTemplateCardBorder(sender);
        if (card == null) return;

        var scale = GetScaleTransform(card);
        var translate = GetTranslateTransform(card);
        if (scale == null || translate == null) return;

        var sb = new Storyboard();
        var elastic = new ElasticEase { EasingMode = EasingMode.EaseOut, Oscillations = 1, Springiness = 6 };
        AddDoubleAnim(sb, scale, 500, 1.05, 1.0, elastic, "ScaleX");
        AddDoubleAnim(sb, scale, 500, 1.05, 1.0, elastic, "ScaleY");
        AddDoubleAnim(sb, translate, 400, -4.0, 0.0, new QuarticEase { EasingMode = EasingMode.EaseOut }, "Y");
        sb.Begin();
    }

    /// <summary>
    /// 按下反馈：快速下沉到 0.97× + 导航到快速开始向导
    /// </summary>
    private void OnTemplateCardPointerPressed(object sender, PointerRoutedEventArgs e)
    {
        // ── 动画：快速缩小到 0.97 ──
        var card = GetTemplateCardBorder(sender);
        if (card != null)
        {
            var scale = GetScaleTransform(card);
            if (scale != null)
            {
                var sb = new Storyboard();
                var pressEase = new CubicEase { EasingMode = EasingMode.EaseIn };
                AddDoubleAnim(sb, scale, 100, 1.05, 0.97, pressEase, "ScaleX");
                AddDoubleAnim(sb, scale, 100, 1.05, 0.97, pressEase, "ScaleY");
                sb.Begin();
            }
        }

        // ── 业务：导航到快速开始向导 ──
        if (sender is FrameworkElement element && element.DataContext is Services.QuickStartTemplate template)
        {
            ViewModel.SelectTemplateCommand.Execute(template);
        }
    }

    /// <summary>
    /// 释放还原：弹回 1.05×（弹性缓出）
    /// </summary>
    private void OnTemplateCardPointerReleased(object sender, PointerRoutedEventArgs e)
    {
        var card = GetTemplateCardBorder(sender);
        if (card == null) return;

        var scale = GetScaleTransform(card);
        if (scale == null) return;

        var sb = new Storyboard();
        var elastic = new ElasticEase { EasingMode = EasingMode.EaseOut, Oscillations = 1, Springiness = 8 };
        AddDoubleAnim(sb, scale, 300, 0.97, 1.05, elastic, "ScaleX");
        AddDoubleAnim(sb, scale, 300, 0.97, 1.05, elastic, "ScaleY");
        sb.Begin();
    }

    // ================================================================
    //  动画辅助方法（与 InstanceEditorPage 完全一致）
    // ================================================================

    /// <summary>从 Pointer 事件发送者获取卡片 Border（事件已绑定在 Border 上）</summary>
    private static Border? GetTemplateCardBorder(object sender)
    {
        return sender as Border;
    }

    /// <summary>从卡片 Border 获取 ScaleTransform</summary>
    private static ScaleTransform? GetScaleTransform(Border card)
    {
        return (card.RenderTransform as TransformGroup)?.Children[0] as ScaleTransform;
    }

    /// <summary>从卡片 Border 获取 TranslateTransform</summary>
    private static TranslateTransform? GetTranslateTransform(Border card)
    {
        return (card.RenderTransform as TransformGroup)?.Children[1] as TranslateTransform;
    }

    private static void AddDoubleAnim(Storyboard sb, DependencyObject target, int ms, double from, double to,
        EasingFunctionBase? ease, string property)
    {
        var anim = new DoubleAnimation
        {
            From = from,
            To = to,
            Duration = TimeSpan.FromMilliseconds(ms),
            EasingFunction = ease,
        };
        Storyboard.SetTarget(anim, target);
        Storyboard.SetTargetProperty(anim, property);
        sb.Children.Add(anim);
    }
}
