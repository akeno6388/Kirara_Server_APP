using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Navigation;
using Kirara_Server_WinUI.ViewModels.Pages;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI;
using Windows.UI;
using Microsoft.UI.Xaml;
using Kirara_Server_WinUI.Models;
using Microsoft.UI.Xaml.Media.Animation;
using System.ComponentModel;
using Windows.Foundation;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.Views.Pages;

public sealed partial class InstanceEditorPage : Page
{
    private static readonly Brush SelectedBorderBrush = new SolidColorBrush(Color.FromArgb(255, 46, 204, 113));
    private static readonly Brush HoverBorderBrush = new SolidColorBrush(Color.FromArgb(0x50, 0x00, 0x78, 0xD4));
    private static readonly Brush TransparentBorderBrush = new SolidColorBrush(Colors.Transparent);

    private InstanceEditorViewModel? _vm;

    /// <summary>进度条容器的实际宽度（在 SizeChanged 时更新）</summary>
    private double _progressTrackWidth;

    /// <summary>许可协议倒计时定时器</summary>
    private Microsoft.UI.Xaml.DispatcherTimer? _countdownTimer;



    public InstanceEditorPage()
    {
        InitializeComponent();
        try
        {
            _vm = App.Services.GetRequiredService<InstanceEditorViewModel>();
            DataContext = _vm;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[InstanceEditorPage] Failed to resolve ViewModel: {ex.Message}");
            throw;
        }

        Loaded += OnPageLoaded;
        SchemeIconCacheService.SchemeIconsRefreshed += OnSchemeIconsRefreshed;
    }

    /// <summary>
    /// 方案图标缓存刷新后，强制重绘方案卡片使其显示最新封面图标。
    /// Scheme 对象已在 SchemeIconCacheService 中被原地更新 CoverImageUrl，
    /// 但因其非可观察对象，需替换集合项触发 DataTemplate 重绘。
    /// </summary>
    private void OnSchemeIconsRefreshed()
    {
        if (_vm == null) return;
        DispatcherQueue.TryEnqueue(() =>
        {
            var iconCache = App.Services.GetRequiredService<SchemeIconCacheService>();

            // Step 2: 方案选择卡片 — 覆写 CoverImageUrl 后替换整个集合
            var schemes = _vm.AvailableSchemes.ToList();
            foreach (var s in schemes)
                s.CoverImageUrl = iconCache.GetCachedIconUrl(s.Name);
            _vm.AvailableSchemes = new System.Collections.ObjectModel.ObservableCollection<Scheme>(schemes);

            // Step 3: 令牌绑定卡片 — 覆写 Scheme.CoverImageUrl 后替换集合
            var bindings = _vm.SelectedSchemeTokenBindings.ToList();
            foreach (var b in bindings)
            {
                if (b.Scheme != null)
                    b.Scheme.CoverImageUrl = iconCache.GetCachedIconUrl(b.Scheme.Name);
            }
            _vm.SelectedSchemeTokenBindings = new System.Collections.ObjectModel.ObservableCollection<SchemeTokenBinding>(bindings);
        });
    }

    /// <summary>
    /// 页面完全加载后再启动倒计时，确保 DispatcherTimer 能正常 tick
    /// </summary>
    private void OnPageLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= OnPageLoaded;
        if (_vm != null && _vm.IsStep0Visible)
        {
            StartLicenseCountdown();
        }
    }

    /// <summary>
    /// 页面导航到此页时，提取 InstanceType 参数并初始化 ViewModel
    /// </summary>
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        base.OnNavigatedTo(e);

        // 务必先订阅 PropertyChanged，再调用 InitializeWithType，
        // 否则初始化中触发的 IsStep0Visible 等通知会丢失
        if (_vm != null)
        {
            _vm.PropertyChanged += OnViewModelPropertyChanged;
        }

        if (e.Parameter is Dictionary<string, object> parameters
            && parameters.TryGetValue("InstanceType", out var typeObj)
            && typeObj is InstanceType instanceType
            && _vm != null)
        {
            _vm.InitializeWithType(instanceType);
        }
    }

    protected override void OnNavigatedFrom(NavigationEventArgs e)
    {
        base.OnNavigatedFrom(e);

        SchemeIconCacheService.SchemeIconsRefreshed -= OnSchemeIconsRefreshed;
        StopLicenseCountdown();

        if (_vm != null)
        {
            _vm.PropertyChanged -= OnViewModelPropertyChanged;
        }
    }

    private void OnViewModelPropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (_vm == null) return;

        switch (e.PropertyName)
        {
            case nameof(_vm.CurrentStep):
                UpdateProgressBarWidth();
                AnimateActiveStepDot();
                break;
            case nameof(_vm.IsStep0Visible):
                if (_vm.IsStep0Visible)
                {
                    AnimateStepIn(Step0Container);
                }
                else
                {
                    StopLicenseCountdown();
                }
                break;
            case nameof(_vm.IsStep1Visible):
                if (_vm.IsStep1Visible) AnimateStepIn(Step1Container);
                break;
            case nameof(_vm.IsStep2Visible):
                if (_vm.IsStep2Visible) AnimateStepIn(Step2Container);
                break;
            case nameof(_vm.IsStep3Visible):
                if (_vm.IsStep3Visible) AnimateStepIn(Step3Container);
                break;
            case nameof(_vm.UseDomainAccount):
                if (_vm.UseDomainAccount)
                    AnimateToDomainMode();
                else
                    AnimateToNormalMode();
                break;
        }
    }

    // ================================================================
    //  进度条动画
    // ================================================================

    /// <summary>
    /// 进度条容器尺寸变化时记录实际宽度
    /// </summary>
    private void OnProgressTrackSizeChanged(object sender, SizeChangedEventArgs e)
    {
        _progressTrackWidth = e.NewSize.Width;
        UpdateProgressBarWidth();
    }

    /// <summary>
    /// 更新进度条宽度（使用 DoubleAnimation 实现平滑过渡）
    /// </summary>
    private void UpdateProgressBarWidth()
    {
        if (_vm == null || ProgressFill == null) return;

        if (_progressTrackWidth <= 0)
        {
            _progressTrackWidth = 620;
        }

        var targetWidth = _progressTrackWidth * _vm.ProgressBarWidthPercent;

        var storyboard = new Storyboard();
        var anim = new DoubleAnimation
        {
            To = targetWidth,
            Duration = TimeSpan.FromMilliseconds(400),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(anim, ProgressFill);
        Storyboard.SetTargetProperty(anim, "Width");
        storyboard.Children.Add(anim);
        storyboard.Begin();
    }

    /// <summary>
    /// 步骤切换时，对当前激活的步骤圆点执行缩放脉冲动画
    /// </summary>
    private void AnimateActiveStepDot()
    {
        if (_vm == null || StepsControl == null) return;

        // 从 VisualTree 中定位当前激活步骤对应的 Border（StepDotBorder）
        var activeIndex = _vm.CurrentStep;
        if (activeIndex < 0 || activeIndex >= _vm.Steps.Count) return;

        var container = StepsControl.ContainerFromIndex(activeIndex) as DependencyObject;
        if (container == null) return;

        // 在容器模板中查找名为 StepDotBorder 的元素
        var dotBorder = FindDescendant<Border>(container, "StepDotBorder");
        if (dotBorder == null) return;

        // 确保 RenderTransform 是 ScaleTransform
        if (dotBorder.RenderTransform is not ScaleTransform scale)
        {
            scale = new ScaleTransform { ScaleX = 1, ScaleY = 1 };
            dotBorder.RenderTransform = scale;
            dotBorder.RenderTransformOrigin = new Point(0.5, 0.5);
        }

        // 使用 DoubleAnimationUsingKeyFrames 在同一 Storyboard 中完成缩放脉冲
        // 思路：0→300ms 弹性放大到 1.15，300→600ms 立方缓出缩回 1.0

        var storyboard = new Storyboard();

        // ScaleX 脉冲
        var scaleXAnim = new DoubleAnimationUsingKeyFrames();
        scaleXAnim.KeyFrames.Add(new EasingDoubleKeyFrame
        {
            KeyTime = TimeSpan.FromMilliseconds(300),
            Value = 1.15,
            EasingFunction = new ElasticEase { EasingMode = EasingMode.EaseOut, Oscillations = 1 }
        });
        scaleXAnim.KeyFrames.Add(new EasingDoubleKeyFrame
        {
            KeyTime = TimeSpan.FromMilliseconds(600),
            Value = 1.0,
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        });
        Storyboard.SetTarget(scaleXAnim, dotBorder);
        Storyboard.SetTargetProperty(scaleXAnim, "(UIElement.RenderTransform).(ScaleTransform.ScaleX)");
        storyboard.Children.Add(scaleXAnim);

        // ScaleY 脉冲
        var scaleYAnim = new DoubleAnimationUsingKeyFrames();
        scaleYAnim.KeyFrames.Add(new EasingDoubleKeyFrame
        {
            KeyTime = TimeSpan.FromMilliseconds(300),
            Value = 1.15,
            EasingFunction = new ElasticEase { EasingMode = EasingMode.EaseOut, Oscillations = 1 }
        });
        scaleYAnim.KeyFrames.Add(new EasingDoubleKeyFrame
        {
            KeyTime = TimeSpan.FromMilliseconds(600),
            Value = 1.0,
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        });
        Storyboard.SetTarget(scaleYAnim, dotBorder);
        Storyboard.SetTargetProperty(scaleYAnim, "(UIElement.RenderTransform).(ScaleTransform.ScaleY)");
        storyboard.Children.Add(scaleYAnim);

        storyboard.Begin();
    }

    // ================================================================
    //  步骤内容切换动画
    // ================================================================

    /// <summary>
    /// 步骤切入动画：淡入 + 向右滑入
    /// </summary>
    private static void AnimateStepIn(UIElement element)
    {
        var transform = new CompositeTransform();
        element.RenderTransform = transform;
        element.RenderTransformOrigin = new Point(0.5, 0.5);

        transform.TranslateX = 80;
        element.Opacity = 0;

        var duration = TimeSpan.FromMilliseconds(350);
        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };

        var storyboard = new Storyboard();

        var opacityAnim = new DoubleAnimation
        {
            From = 0, To = 1,
            Duration = duration,
            EasingFunction = ease,
        };
        Storyboard.SetTarget(opacityAnim, element);
        Storyboard.SetTargetProperty(opacityAnim, "Opacity");
        storyboard.Children.Add(opacityAnim);

        var translateAnim = new DoubleAnimation
        {
            From = 80, To = 0,
            Duration = duration,
            EasingFunction = ease,
        };
        Storyboard.SetTarget(translateAnim, transform);
        Storyboard.SetTargetProperty(translateAnim, "TranslateX");
        storyboard.Children.Add(translateAnim);

        storyboard.Begin();
    }

    // ================================================================
    //  工具方法
    // ================================================================

    /// <summary>
    /// 在可视树中查找指定名称的后代元素
    /// </summary>
    private static T? FindDescendant<T>(DependencyObject parent, string name) where T : DependencyObject
    {
        int count = VisualTreeHelper.GetChildrenCount(parent);
        for (int i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is T tChild)
            {
                // 如果 T 是 FrameworkElement，检查名称
                if (tChild is FrameworkElement fe && fe.Name == name)
                    return tChild;
                // 如果匹配类型但名称不对，继续深入
                var found = FindDescendant<T>(child, name);
                if (found != null) return found;
            }
            else
            {
                var found = FindDescendant<T>(child, name);
                if (found != null) return found;
            }
        }
        return null;
    }

    // ================================================================
    //  方案卡片交互动画（悬停 / 按下 / 释放）
    // ================================================================

    /// <summary>
    /// 悬停进入：优雅放大 1.05× + 上浮 4px（无边框变色）
    /// </summary>
    private void OnSchemeCardPointerEntered(object sender, PointerRoutedEventArgs e)
    {
        var card = GetSchemeCardBorder(sender);
        if (card == null) return;

        var scale = GetScaleTransform(card);
        var translate = GetTranslateTransform(card);
        if (scale == null || translate == null) return;

        var sb = new Storyboard();

        // 缩放 1.0 → 1.05
        AddDoubleAnim(sb, scale, 400, 1.0, 1.05, new QuarticEase { EasingMode = EasingMode.EaseOut }, "ScaleX");
        AddDoubleAnim(sb, scale, 400, 1.0, 1.05, new QuarticEase { EasingMode = EasingMode.EaseOut }, "ScaleY");
        // 上浮 -4px
        AddDoubleAnim(sb, translate, 400, 0.0, -4.0, new QuarticEase { EasingMode = EasingMode.EaseOut }, "Y");

        sb.Begin();
    }

    /// <summary>
    /// 悬停离开：弹性回弹 + 位移归零（无边框变色）
    /// </summary>
    private void OnSchemeCardPointerExited(object sender, PointerRoutedEventArgs e)
    {
        var card = GetSchemeCardBorder(sender);
        if (card == null) return;

        var scale = GetScaleTransform(card);
        var translate = GetTranslateTransform(card);
        if (scale == null || translate == null) return;

        var sb = new Storyboard();

        var elastic = new ElasticEase { EasingMode = EasingMode.EaseOut, Oscillations = 1, Springiness = 6 };
        AddDoubleAnim(sb, scale, 500, 1.05, 1.0, elastic, "ScaleX");
        AddDoubleAnim(sb, scale, 500, 1.05, 1.0, elastic, "ScaleY");
        AddDoubleAnim(sb, translate, 400, -4.0, 0.0, new QuarticEase { EasingMode = EasingMode.EaseOut }, "Y");

        sb.Begin();
    }

    /// <summary>
    /// 按下反馈：快速下沉到 0.97× + 切换选中状态
    /// </summary>
    private void OnSchemeCardPointerPressed(object sender, PointerRoutedEventArgs e)
    {
        // ── 动画：快速缩小到 0.97 ──
        var card = GetSchemeCardBorder(sender);
        if (card != null)
        {
            var scale = GetScaleTransform(card);
            if (scale != null)
            {
                var sb = new Storyboard();
                var pressEase = new CubicEase { EasingMode = EasingMode.EaseIn };
                AddDoubleAnim(sb, scale, 100, 1.05, 0.97, pressEase, "ScaleX");
                AddDoubleAnim(sb, scale, 100, 1.05, 0.97, pressEase, "ScaleY");
                sb.Begin();
            }
        }

        // ── 业务：切换选中状态 ──
        if (sender is FrameworkElement element && element.DataContext is Models.Scheme scheme)
        {
            scheme.IsSelected = !scheme.IsSelected;

            var border = FindParent<Microsoft.UI.Xaml.Controls.Border>(element);
            if (border != null)
            {
                border.BorderBrush = scheme.IsSelected ? SelectedBorderBrush : TransparentBorderBrush;
            }

            if (DataContext is InstanceEditorViewModel vm)
            {
                vm.NotifySchemeSelectionChanged();
            }
        }
    }

    /// <summary>
    /// 释放还原：弹回 1.05×（弹性缓出）
    /// </summary>
    private void OnSchemeCardPointerReleased(object sender, PointerRoutedEventArgs e)
    {
        var card = GetSchemeCardBorder(sender);
        if (card == null) return;

        var scale = GetScaleTransform(card);
        if (scale == null) return;

        var sb = new Storyboard();
        var elastic = new ElasticEase { EasingMode = EasingMode.EaseOut, Oscillations = 1, Springiness = 8 };
        AddDoubleAnim(sb, scale, 300, 0.97, 1.05, elastic, "ScaleX");
        AddDoubleAnim(sb, scale, 300, 0.97, 1.05, elastic, "ScaleY");
        sb.Begin();
    }

    // ================================================================
    //  令牌绑定模式切换动画（跨面板滑入/滑出）
    // ================================================================

    /// <summary>
    /// 切换到普通模式：Domain 面板右滑淡出 → Normal 面板左滑淡入
    /// </summary>
    private void AnimateToNormalMode()
    {
        // 先关闭 Domain 面板的交互，开启 Normal 面板的交互
        DomainModePanel.IsHitTestVisible = false;
        NormalModePanel.IsHitTestVisible = true;

        // Domain 面板向右滑出 + 淡出
        var fadeOutDomain = new Storyboard();
        AddDoubleAnim(fadeOutDomain, DomainModePanel, 250, 1.0, 0.0,
            new CubicEase { EasingMode = EasingMode.EaseIn }, "Opacity");
        AddDoubleAnim(fadeOutDomain, DomainPanelTranslate, 300, 0.0, 80.0,
            new CubicEase { EasingMode = EasingMode.EaseIn }, "X");
        fadeOutDomain.Begin();

        // Normal 面板从左侧滑入 + 淡入（延迟 100ms）
        var fadeInNormal = new Storyboard { BeginTime = TimeSpan.FromMilliseconds(100) };
        AddDoubleAnim(fadeInNormal, NormalModePanel, 350, 0.0, 1.0,
            new CubicEase { EasingMode = EasingMode.EaseOut }, "Opacity");
        AddDoubleAnim(fadeInNormal, NormalPanelTranslate, 400, -40.0, 0.0,
            new QuarticEase { EasingMode = EasingMode.EaseOut }, "X");
        fadeInNormal.Begin();
    }

    /// <summary>
    /// 切换到 Domain 模式：Normal 面板左滑淡出 → Domain 面板右滑淡入
    /// </summary>
    private void AnimateToDomainMode()
    {
        // 先关闭 Normal 面板的交互，开启 Domain 面板的交互
        NormalModePanel.IsHitTestVisible = false;
        DomainModePanel.IsHitTestVisible = true;

        // Normal 面板向左滑出 + 淡出
        var fadeOutNormal = new Storyboard();
        AddDoubleAnim(fadeOutNormal, NormalModePanel, 250, 1.0, 0.0,
            new CubicEase { EasingMode = EasingMode.EaseIn }, "Opacity");
        AddDoubleAnim(fadeOutNormal, NormalPanelTranslate, 300, 0.0, -40.0,
            new CubicEase { EasingMode = EasingMode.EaseIn }, "X");
        fadeOutNormal.Begin();

        // Domain 面板从右侧滑入 + 淡入（延迟 100ms）
        var fadeInDomain = new Storyboard { BeginTime = TimeSpan.FromMilliseconds(100) };
        AddDoubleAnim(fadeInDomain, DomainModePanel, 350, 0.0, 1.0,
            new CubicEase { EasingMode = EasingMode.EaseOut }, "Opacity");
        AddDoubleAnim(fadeInDomain, DomainPanelTranslate, 400, 80.0, 0.0,
            new QuarticEase { EasingMode = EasingMode.EaseOut }, "X");
        fadeInDomain.Begin();
    }

    // ================================================================
    //  动画辅助方法
    // ================================================================

    /// <summary>从 Pointer 事件发送者获取卡片 Border</summary>
    private static Border? GetSchemeCardBorder(object sender)
    {
        return (sender as FrameworkElement)?.Parent as Border;
    }

    /// <summary>从卡片 Border 获取 ScaleTransform</summary>
    private static ScaleTransform? GetScaleTransform(Border card)
    {
        return (card.RenderTransform as TransformGroup)?.Children[0] as ScaleTransform;
    }

    /// <summary>从卡片 Border 获取 TranslateTransform</summary>
    private static TranslateTransform? GetTranslateTransform(Border card)
    {
        return (card.RenderTransform as TransformGroup)?.Children[1] as TranslateTransform;
    }

    /// <summary>确保卡片 BorderBrush 是可变 SolidColorBrush，返回 Brush 实例以供动画</summary>
    private static SolidColorBrush? EnsureBorderBrush(Border card)
    {
        if (card.BorderBrush is SolidColorBrush scb)
            return scb;
        // XAML 中 BorderBrush="Transparent" 可能生成不可变 brush，重新创建
        var brush = new SolidColorBrush(Colors.Transparent);
        card.BorderBrush = brush;
        return brush;
    }

    /// <summary>向 Storyboard 添加 DoubleAnimation</summary>
    private static void AddDoubleAnim(Storyboard sb, DependencyObject target, int ms, double from, double to,
        EasingFunctionBase? ease, string property)
    {
        var anim = new DoubleAnimation
        {
            From = from,
            To = to,
            Duration = TimeSpan.FromMilliseconds(ms),
            EasingFunction = ease,
        };
        Storyboard.SetTarget(anim, target);
        Storyboard.SetTargetProperty(anim, property);
        sb.Children.Add(anim);
    }

    /// <summary>向 Storyboard 添加 ColorAnimation</summary>
    private static void AddColorAnim(Storyboard sb, DependencyObject target, int ms, Color from, Color to,
        string property)
    {
        var anim = new ColorAnimation
        {
            From = from,
            To = to,
            Duration = TimeSpan.FromMilliseconds(ms),
        };
        Storyboard.SetTarget(anim, target);
        Storyboard.SetTargetProperty(anim, property);
        sb.Children.Add(anim);
    }

    // ================================================================
    //  实例名称实时校验（TextChanged 直接推送，每键实时校验）
    // ================================================================

    /// <summary>
    /// 实例名称输入框内容变化时直接推送到 ViewModel，触发即时校验。
    /// </summary>
    private void OnInstanceNameTextChanged(object sender, TextChangedEventArgs e)
    {
        if (_vm != null && sender is TextBox textBox)
        {
            _vm.InstanceName = textBox.Text;
        }
    }

    // ================================================================
    //  许可协议倒计时
    // ================================================================

    /// <summary>
    /// 启动 5 秒倒计时，结束后方可点击"同意"按钮
    /// </summary>
    private void StartLicenseCountdown()
    {
        StopLicenseCountdown();

        if (_vm == null) return;

        _vm.RemainingSeconds = 5;
        _countdownTimer = new Microsoft.UI.Xaml.DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(1)
        };
        _countdownTimer.Tick += OnCountdownTick;
        _countdownTimer.Start();
    }

    private void StopLicenseCountdown()
    {
        if (_countdownTimer != null)
        {
            _countdownTimer.Stop();
            _countdownTimer.Tick -= OnCountdownTick;
            _countdownTimer = null;
        }
    }

    private void OnCountdownTick(object? sender, object e)
    {
        if (_vm == null)
        {
            StopLicenseCountdown();
            return;
        }

        if (_vm.RemainingSeconds > 0)
        {
            _vm.RemainingSeconds--;
        }

        if (_vm.RemainingSeconds <= 0)
        {
            StopLicenseCountdown();
        }
    }

    private static T? FindParent<T>(DependencyObject child) where T : DependencyObject
    {
        DependencyObject parent = VisualTreeHelper.GetParent(child);
        while (parent != null)
        {
            if (parent is T typedParent)
                return typedParent;
            parent = VisualTreeHelper.GetParent(parent);
        }
        return null;
    }
}

