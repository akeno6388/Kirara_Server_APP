using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Animation;
using Microsoft.UI.Xaml.Media.Imaging;
using Microsoft.UI.Xaml.Navigation;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.Views.Pages;
using Kirara_Server_WinUI.ViewModels.Controls;
using Windows.Storage.Streams;

namespace Kirara_Server_WinUI.Views;

public sealed partial class ShellPage : Page
{
    private INavigationService? _navService;
    private IBackgroundService? _backgroundService;
    private ILoginService? _loginService;

    /// <summary>动画时长常量（毫秒）</summary>
    private const int TransitionMs = 400;

    /// <summary>记录上一次导航的页面类型，仅用于首页切入动画判断</summary>
    private Type? _previousPageType;

    /// <summary>切出动画期间暂存的导航目标类型</summary>
    private Type? _pendingNavigationType;

    /// <summary>切出动画期间暂存的导航参数</summary>
    private object? _pendingNavigationParameter;

    /// <summary>标记正在执行暂存的导航，防止 Navigating 拦截递归</summary>
    private bool _isPerformingPendingNavigation;

    /// <summary>标记正在从登录页过渡到首页（跳过背景重置）</summary>
    private bool _isFromLoginTransition;

    /// <summary>标记正在登录→首页入场动画阶段，此期间背景变更暂不播过渡</summary>
    private bool _isEnteringHome;

    /// <summary>入场动画期间收到的待处理背景路径，入场完成后执行交叉渐变</summary>
    private string? _pendingBackgroundPath;

    /// <summary>标记正在退出登录，防止自动登录重入</summary>
    private bool _isLoggingOut;

    /// <summary>标记退出动画已取消，Storyboard 回调应直接返回</summary>
    private bool _exitAnimationCancelled;

    /// <summary>上一次订阅的 LoginPageViewModel，用于取消旧订阅防止泄漏</summary>
    private System.ComponentModel.INotifyPropertyChanged? _lastLoginVM;

    /// <summary>入场动画延迟 Timer（用于在入场完成后处理待定背景）</summary>
    private DispatcherTimer? _enterHomeTimer;

    /// <summary>当前正在播放的背景淡出 Storyboard（用于停止旧动画避免冲突）</summary>
    private Storyboard? _activeBgFadeOutSb;

    /// <summary>当前正在播放的 LeftBar 动画 Storyboard（用于停止旧动画避免冲突）</summary>
    private Storyboard? _activeLeftBarSb;

    /// <summary>标记 MainPage 已导航、但入场动画应等抽屉完成后再触发</summary>
    private bool _pendingEnterAfterDrawer;

    public ShellPage()
    {
        InitializeComponent();

        Loaded += OnLoaded;
        Unloaded += OnUnloaded;
        ContentFrame.Navigating += OnContentFrameNavigating;
        ContentFrame.Navigated += OnContentNavigated;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        // 初始化导航服务
        _navService = App.Services.GetRequiredService<INavigationService>();
        if (_navService is NavigationService ns)
        {
            ns.Initialize(ContentFrame);
        }

        // [登录] 获取登录服务并订阅状态变更
        _loginService = App.Services.GetRequiredService<ILoginService>();
        _loginService.LoginStateChanged += OnLoginStateChanged;

        // [首页] 连接背景服务 — 当背景图片更新时刷新 Image 控件
        _backgroundService = App.Services.GetRequiredService<IBackgroundService>();
        ApplyBackgroundImage(_backgroundService.CurrentBackgroundPath);
        _backgroundService.BackgroundChanged += OnBackgroundChanged;

        // 设置标题栏父窗口（MainWindow 此时已完全初始化）
        var mainWindow = MainWindow.Current;
        if (mainWindow != null)
        {
            TitleBarControl.SetParentWindow(mainWindow);
        }

        // [登录] 订阅 ContentFrame 内容变化，监听 LoginPage 的 IsBusy 状态
        // ⚠️ 必须在首次导航前订阅，否则首次加载 LoginPage 时的 IsBusy 变化将无法被捕获
        ContentFrame.Navigated += OnContentFrameNavigatedForBusy;

        // [登录] 根据登录状态决定默认导航目标
        if (_loginService.IsLoggedIn)
        {
            _navService.NavigateTo(typeof(MainPage));
        }
        else
        {
            // 始终先导航到登录页，由登录页决定是否自动登录
            _navService.NavigateTo(typeof(LoginPage));
        }
    }

    /// <summary>
    /// 登录状态变更回调 — 登录后播放过渡动画再导航到首页，登出后播放反向动画。
    /// 动画不赶时间，作为一种视觉引导来呈现。
    /// </summary>
    private void OnLoginStateChanged(bool isLoggedIn)
    {
        this.DispatcherQueue.TryEnqueue(async () =>
        {
            if (isLoggedIn)
            {
                // 切换用户后重新加载当前用户的数据 + 刷新权限
                LeftBar.ViewModel.RefreshAfterLogin();

                // 如果当前在登录页面，播放登录→首页过渡动画
                if (ContentFrame.Content is LoginPage loginPage)
                {
                    await PerformLoginTransitionAsync(loginPage);
                }
                else
                {
                    LeftBar.Opacity = 1.0;
                    LeftBar.Visibility = Visibility.Visible;
                }
            }
            else
            {
                // 标记正在退出登录，防止导航到登录页后触发自动登录
                _isLoggingOut = true;

                // [账号安全] 退出登录 = 关闭当前用户打开的所有实例（等同关闭软件）：
                // 0. 重置左侧栏实例会话状态（已启动标记/WorkStatus/激活高亮），
                //    下次登录点击实例重新进入实例总结页（先导页），而非直接进工作区
                try
                {
                    LeftBar.ViewModel.ResetForLogout();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[ShellPage] 退出登录重置实例状态失败: {ex.Message}");
                }

                // 1. 关闭独立评论窗口（可能残留上一用户的评论上下文）
                // 2. 关闭所有缓存的实例页面（WebView2 进程 + OpenVPN 连接），
                //    保留磁盘数据供下次登录复用（与 ShutdownInstance 语义一致）
                // 在动画前启动（fire-and-forget），与退出动画并行执行，不阻塞 UI
                try
                {
                    var commentPanelService = App.Services.GetRequiredService<ICommentPanelService>();
                    commentPanelService.ClosePanel();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[ShellPage] 退出登录关闭评论窗口失败: {ex.Message}");
                }

                try
                {
                    var pageCache = App.Services.GetRequiredService<ISchemePageCache>();
                    _ = pageCache.ShutdownAllInstancesAsync();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[ShellPage] 退出登录关闭实例失败: {ex.Message}");
                }

                // 登出：如果当前在首页，播放退出动画
                if (ContentFrame.Content is MainPage mainPage)
                {
                    // ★ 三线并行：左侧栏淡出 + MainPage 退场 + 暗色遮罩抽屉式拉出
                    var fadeTask = AnimateLeftBarOpacity(to: 0.0, ms: 350, easingMode: EasingMode.EaseIn);

                    var exitTcs = new TaskCompletionSource();
                    mainPage.PlayExitAnimation(() => exitTcs.TrySetResult());

                    var drawerTask = AnimateHomeOverlayDrawerAsync(pullUp: false);

                    await Task.WhenAll(fadeTask, exitTcs.Task, drawerTask);

                    LeftBar.Visibility = Visibility.Collapsed;
                    HomeOverlay.Visibility = Visibility.Collapsed;
                }

                _navService?.NavigateTo(typeof(LoginPage));

                // 延迟重置登出标记，确保 LoginPage 加载完成后再允许自动登录
                _ = Task.Run(async () =>
                {
                    await Task.Delay(2000);
                    this.DispatcherQueue.TryEnqueue(() => _isLoggingOut = false);
                });
            }
        });
    }

    /// <summary>
    /// 背景图片变更回调 — 根据当前页面类型决定是否执行渐变过渡动画。
    ///
    /// ## 渐变过渡规则：
    /// - 当前页面为 MainPage（首页）或 LoginPage（登录页）→ 执行交叉淡入淡出动画
    ///   （这两个页面能展示背景图片，渐变过渡提升视觉体验）
    /// - 其他页面（实例工作区、设置页等）→ 直接静默更新 Source，不播放动画
    ///   （背景图在这些页面不可见或仅部分可见，无需动画开销）
    /// </summary>
    private void OnBackgroundChanged(string? path)
    {
        this.DispatcherQueue.TryEnqueue(async () =>
        {
            // [入场动画阶段] 暂存路径，等首页入场动画全部完成后再执行交叉渐变
            if (_isEnteringHome)
            {
                _pendingBackgroundPath = path;
                return;
            }

            // 判断当前页面是否能展示背景图片
            bool canShowBackground = ContentFrame.Content is MainPage
                                  || ContentFrame.Content is LoginPage;

            if (canShowBackground)
            {
                await TransitionBackgroundAsync(path);
            }
            else
            {
                ApplyBackgroundImageDirect(HomeBackgroundImage, path);
            }
        });
    }

    /// <summary>
    /// 🎬 背景过渡动画 — 真正的交叉渐变：旧图淡出的同时新图淡入，全程无黑屏。
    ///
    /// ## 方案说明：
    /// - 动态创建一个临时叠加层 Image（代码中创建，不碰 XAML）
    /// - 新图加载到叠加层，旧图保留在 HomeBackgroundImage
    /// - 同时播放：叠加层 Opacity 0→1 + HomeBackgroundImage Opacity 1→0
    /// - 动画完成后：交换 Source 到 HomeBackgroundImage，移除临时层
    ///
    /// 避免了双图层 XAML 的 Z-order 问题，也避免了单 Image 的中间黑屏。
    /// </summary>
    private async Task TransitionBackgroundAsync(string? newPath)
    {
        try
        {
            // Step1: 异步加载新图片（流加载，可靠）
            var newBitmap = await LoadBitmapFromFileAsync(newPath);
            if (newBitmap == null) return;

            // Step2: 创建临时叠加层 Image，插入到 HomeBackgroundImage 之后
            var overlay = new Image
            {
                Source = newBitmap,
                Stretch = Microsoft.UI.Xaml.Media.Stretch.UniformToFill,
                Opacity = 0.0,
            };
            if (this.Content is not Grid rootGrid) return;
            Grid.SetRow(overlay, 0);
            Grid.SetColumn(overlay, 0);
            Grid.SetRowSpan(overlay, 2);
            Grid.SetColumnSpan(overlay, 2);
            int bgIndex = rootGrid.Children.IndexOf(HomeBackgroundImage);
            rootGrid.Children.Insert(bgIndex + 1, overlay);

            // Step3: 同时播放交叉渐变
            //   旧图: Opacity 1→0（淡出）
            //   新图: Opacity 0→1（淡入）
            const int crossMs = 500;
            var ease = new CircleEase { EasingMode = EasingMode.EaseOut };

            var fadeOutSb = new Storyboard();
            var fadeOutAnim = new DoubleAnimation
            {
                From = HomeBackgroundImage.Opacity, To = 0.0,
                Duration = TimeSpan.FromMilliseconds(crossMs),
                EasingFunction = ease,
            };
            Storyboard.SetTarget(fadeOutAnim, HomeBackgroundImage);
            Storyboard.SetTargetProperty(fadeOutAnim, "Opacity");
            fadeOutSb.Children.Add(fadeOutAnim);

            var fadeInSb = new Storyboard();
            var fadeInAnim = new DoubleAnimation
            {
                From = 0.0, To = 1.0,
                Duration = TimeSpan.FromMilliseconds(crossMs),
                EasingFunction = ease,
            };
            Storyboard.SetTarget(fadeInAnim, overlay);
            Storyboard.SetTargetProperty(fadeInAnim, "Opacity");
            fadeInSb.Children.Add(fadeInAnim);

            var tcs = new TaskCompletionSource();
            fadeOutSb.Completed += (_, _) => tcs.TrySetResult();
            fadeOutSb.Begin();
            fadeInSb.Begin();
            await tcs.Task;

            // Step4: 动画完成 → 交换 Source 到主层，移除临时层
            HomeBackgroundImage.Source = newBitmap;
            HomeBackgroundImage.Opacity = 1.0;
            HomeBackgroundImage.Visibility = Visibility.Visible;
            rootGrid.Children.Remove(overlay);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[ShellPage] 背景过渡失败: {ex.Message}");
            ApplyBackgroundImageDirect(HomeBackgroundImage, newPath);
        }
    }

    /// <summary>
    /// 从本地文件异步加载 BitmapImage — 使用文件流 + SetSourceAsync。
    /// 完全绕过 file:/// URI 解析，避免 WinUI 3 unpackaged 模式下 URI 加载不可靠的问题。
    /// </summary>
    private static async Task<BitmapImage?> LoadBitmapFromFileAsync(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return null;

        try
        {
            // URI 路径保持原样（ms-appx / ms-appdata / http），适用于启动时的初始加载
            if (path.StartsWith("ms-appx:///", StringComparison.OrdinalIgnoreCase) ||
                path.StartsWith("ms-appdata:///", StringComparison.OrdinalIgnoreCase) ||
                path.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                path.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                return new BitmapImage(new Uri(path));
            }

            // 本地文件路径 → 文件流加载，彻底避免 URI 格式问题
            if (!File.Exists(path))
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[ShellPage] 背景文件不存在: {path}");
                return null;
            }

            using var fileStream = File.OpenRead(path);
            using var memStream = new MemoryStream();
            await fileStream.CopyToAsync(memStream);
            memStream.Position = 0;

            var bitmap = new BitmapImage();
            await bitmap.SetSourceAsync(memStream.AsRandomAccessStream());
            System.Diagnostics.Debug.WriteLine(
                $"[ShellPage] 背景图流加载完成: {Path.GetFileName(path)} ({memStream.Length} bytes)");
            return bitmap;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[ShellPage] 加载背景图失败: {ex.Message}");
            return null;
        }
    }

    /// <summary>
    /// 直接设置指定 Image 控件的 Source（无动画）。
    /// 异步加载完后应用，避免阻塞 UI。
    /// </summary>
    private static async void ApplyBackgroundImageDirect(Image imageControl, string? path)
    {
        try
        {
            imageControl.Source = await LoadBitmapFromFileAsync(path);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[ShellPage] 直接设置背景失败: {ex.Message}");
            imageControl.Source = null;
        }
    }

    /// <summary>
    /// 根据路径设置背景图片 Source（本地文件路径 / ms-appx URI / null）
    /// 此方法用于初始加载和直接替换场景（无动画）。
    /// </summary>
    private void ApplyBackgroundImage(string? path)
    {
        ApplyBackgroundImageDirect(HomeBackgroundImage, path);
    }

    private void OnUnloaded(object sender, RoutedEventArgs e)
    {
        if (_backgroundService != null)
            _backgroundService.BackgroundChanged -= OnBackgroundChanged;

        if (_loginService != null)
            _loginService.LoginStateChanged -= OnLoginStateChanged;

        // ★ 取消 LoginPage VM 订阅，防止泄漏
        if (_lastLoginVM != null)
        {
            _lastLoginVM.PropertyChanged -= OnLoginPageViewModelPropertyChanged;
            _lastLoginVM = null;
        }

        // ★ 停止入场计时器
        _enterHomeTimer?.Stop();
        _enterHomeTimer = null;

        Loaded -= OnLoaded;
        Unloaded -= OnUnloaded;
        ContentFrame.Navigating -= OnContentFrameNavigating;
        ContentFrame.Navigated -= OnContentNavigated;
        ContentFrame.Navigated -= OnContentFrameNavigatedForBusy;
    }

    // ================================================================
    //  全局忙状态遮罩管理
    // ================================================================

    /// <summary>
    /// 监听 ContentFrame 内容变化，当内容为 LoginPage 时订阅其 IsBusy 状态
    /// </summary>
    private void OnContentFrameNavigatedForBusy(object sender, NavigationEventArgs e)
    {
        // ★ 取消旧订阅，防止 PropertyChanged 处理器泄漏到旧 ViewModel 上
        if (_lastLoginVM != null)
        {
            _lastLoginVM.PropertyChanged -= OnLoginPageViewModelPropertyChanged;
            _lastLoginVM = null;
        }

        if (e.Content is Pages.LoginPage loginPage)
        {
            // 如果正在退出登录，抑制自动登录
            if (_isLoggingOut)
            {
                loginPage.ViewModel.SuppressAutoLogin = true;
            }
            _lastLoginVM = loginPage.ViewModel;
            _lastLoginVM.PropertyChanged += OnLoginPageViewModelPropertyChanged;
        }
    }

    private void OnLoginPageViewModelPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (sender is not ViewModels.Pages.LoginPageViewModel vm) return;

        if (e.PropertyName == nameof(vm.IsBusy))
        {
            if (vm.IsBusy)
            {
                ShowGlobalBusyOverlay(vm.IsRegisterMode ? "正在注册，请稍候..." : "正在登录，请稍候...");
            }
            else
            {
                HideGlobalBusyOverlay();
            }
        }
    }

    public void ShowGlobalBusyOverlay(string text)
    {
        GlobalBusyOverlayText.Text = text;
        GlobalBusyOverlay.Visibility = Visibility.Visible;
    }

    public void HideGlobalBusyOverlay()
    {
        GlobalBusyOverlay.Visibility = Visibility.Collapsed;
    }

    // ================================================================
    //  导航拦截：切出首页时先播退出动画再导航
    // ================================================================

    /// <summary>
    /// 导航前拦截：离开首页时取消导航 → 播放退场动画（容器+背景） → 执行实际导航。
    /// 容器退场与背景淡出并行播放，总耗时取最长者（~400ms）。
    /// </summary>
    private void OnContentFrameNavigating(object sender, NavigatingCancelEventArgs e)
    {
        if (_isPerformingPendingNavigation) return;
        if (ContentFrame.Content is not MainPage mainPage) return;

        // 导航目标仍是首页 → 取消进行中的退出动画并恢复首页
        if (e.SourcePageType == typeof(MainPage))
        {
            if (_pendingNavigationType != null)
            {
                CancelExitAndRestoreHome(mainPage);
                e.Cancel = true;
            }
            return;
        }

        // 导航目标为登录页面时直接放行（登出场景由 OnLoginStateChanged 处理），保留背景供登录页使用
        if (e.SourcePageType == typeof(LoginPage))
            return;

        // 拦截导航，暂存目标
        e.Cancel = true;
        _pendingNavigationType = e.SourcePageType;
        _pendingNavigationParameter = e.Parameter;

        // 启动背景淡出 Storyboard（与容器退场并行）
        const int bgMs = 500;
        var bgSb = StartBackgroundFadeOut(bgMs);

        if (mainPage.IsSettingsPanelOpen)
        {
            // 设置面板打开时：关闭面板后直接背景淡出（容器已隐藏，无需退场动画）
            mainPage.CloseSettingsPanelIfOpen(() =>
            {
                if (_exitAnimationCancelled) return;
                LeftBar?.AnimateBackingOpacity(from: 0.4, to: 1.0, ms: bgMs);
                bgSb.Begin();
            }, restoreSections: false);
        }
        else
        {
            // ★ 容器退场动画与背景淡出并行播放
            LeftBar?.AnimateBackingOpacity(from: 0.4, to: 1.0, ms: bgMs);
            mainPage.PlayExitAnimation(() => { /* 退场完成，背景淡出已在并行播放 */ });
            bgSb.Begin();
        }
    }

    /// <summary>
    /// 创建背景淡出 Storyboard，淡出完成后自动执行导航。
    /// 调用方在合适的时机调用 bgSb.Begin() 启动动画。
    /// </summary>
    private Storyboard StartBackgroundFadeOut(int fadeOutMs)
    {
        // ★ 重置取消标志，确保本次退出动画的导航不会被上一次残留的取消状态拦截
        _exitAnimationCancelled = false;

        // ★ 先重置 HomeBackgroundImage 到已知状态，防止累积动画冲突
        HomeBackgroundImage.Opacity = 1.0;

        var easing = new CubicEase { EasingMode = EasingMode.EaseIn };
        var bgSb = new Storyboard();
        var bgAnim = new DoubleAnimation
        {
            From = HomeBackgroundImage.Opacity,
            To = 0.0,
            Duration = TimeSpan.FromMilliseconds(fadeOutMs),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(bgAnim, HomeBackgroundImage);
        Storyboard.SetTargetProperty(bgAnim, "Opacity");
        bgSb.Children.Add(bgAnim);

        _activeBgFadeOutSb = bgSb;

        bgSb.Completed += (_, _) =>
        {
            _activeBgFadeOutSb = null;
            if (_exitAnimationCancelled)
            {
                _exitAnimationCancelled = false;
                return;
            }

            HomeBackgroundImage.Visibility = Visibility.Collapsed;
            HomeBackgroundImage.Opacity = 1.0;
            HomeOverlay.Visibility = Visibility.Collapsed;

            if (_pendingNavigationType != null)
            {
                _isPerformingPendingNavigation = true;
                ContentFrame.Navigate(_pendingNavigationType, _pendingNavigationParameter);
                _isPerformingPendingNavigation = false;
                _pendingNavigationType = null;
                _pendingNavigationParameter = null;
            }
        };

        return bgSb;
    }

    /// <summary>
    /// 导航完成后：刷新状态 + 控制左侧栏/背景可见性
    /// </summary>
    private void OnContentNavigated(object sender, NavigationEventArgs e)
    {
        bool isHomePage = e.SourcePageType == typeof(MainPage);
        bool isLoginPage = e.SourcePageType == typeof(LoginPage);
        bool wasHomePage = _previousPageType == typeof(MainPage);

        // [安全重置] 如果进入标记为 true 但当前不在登录过渡中，
        // 说明之前的过渡异常中断，强制复位防止后续背景更新被静默吞掉
        if (_isEnteringHome && !_isFromLoginTransition)
        {
            _isEnteringHome = false;
            _pendingBackgroundPath = null;
        }

        // [登录] 控制左侧栏可见性：登录页面隐藏，其他页面显示
        if (isLoginPage)
        {
            LeftBar.Visibility = Visibility.Collapsed;
            // 登录页：背景图可见（全亮），遮罩隐藏
            if (HomeBackgroundImage.Visibility != Visibility.Visible)
            {
                HomeBackgroundImage.Visibility = Visibility.Visible;
                HomeBackgroundImage.Opacity = 1.0;
            }
            HomeOverlay.Visibility = Visibility.Collapsed;
        }
        else if (_loginService?.IsLoggedIn == true)
        {
            // 确保非登录过渡时左侧栏以完整不透明度显示
            if (!_isFromLoginTransition)
                LeftBar.Opacity = 1.0;
            LeftBar.Visibility = Visibility.Visible;

            // 仅切入首页时播放入场动画
            bool enteringHome = isHomePage && !wasHomePage;
            if (enteringHome)
            {
                if (_isFromLoginTransition)
                {
                    _isFromLoginTransition = false;
                    // 若抽屉尚未完成，跳过自动入场（由 PerformLoginTransitionAsync 在抽屉后触发）
                    if (!_pendingEnterAfterDrawer)
                    {
                        EnterHomeFromLogin();
                    }
                    // 左侧栏从 opacity=0 淡入
                    _ = AnimateLeftBarOpacity(to: 1.0, ms: 350, easingMode: EasingMode.EaseOut);
                }
                else
                {
                    PlayHomeEnterAnimation();
                }
            }
            else if (!isHomePage)
            {
                HomeBackgroundImage.Visibility = Visibility.Collapsed;
                HomeOverlay.Visibility = Visibility.Collapsed;
            }
        }

        // 非登录页面且非首页时的处理
        if (!isHomePage && !isLoginPage)
        {
            ContentFrame.Opacity = 1.0;
        }

        _previousPageType = e.SourcePageType;

        if (LeftBar?.ViewModel != null)
        {
            var vm = LeftBar.ViewModel;
            vm.LoadInstances();

            vm.CurrentPageType = e.SourcePageType;

            var pageType = e.SourcePageType;
            bool isInstancePage = pageType == typeof(Views.Instance.InstanceWorkspace)
                               || pageType == typeof(Views.Pages.InstanceSummaryPage);
            if (!isInstancePage)
            {
                vm.IsInstanceActive = false;
                vm.ActiveInstanceId = Guid.Empty;
            }
        }
    }

    // ================================================================
    //  动画工具方法
    // ================================================================

    /// <summary>
    /// 暗色遮罩抽屉动画：拉入（从底部向上覆盖）或拉出（从上方向下退出）。
    /// 登录→首页过渡时 pullUp=true，退出登录时 pullUp=false。
    /// </summary>
    /// <returns>动画完成 Task</returns>
    private async Task AnimateHomeOverlayDrawerAsync(bool pullUp)
    {
        double windowHeight = this.ActualHeight;
        if (windowHeight < 100) windowHeight = 800;

        double from = pullUp ? windowHeight : 0;
        double to   = pullUp ? 0 : windowHeight;

        const int durationMs = 550;
        var easing = new QuinticEase { EasingMode = EasingMode.EaseIn };

        var translate = new TranslateTransform { Y = from };
        HomeOverlay.RenderTransform = translate;
        HomeOverlay.Visibility = Visibility.Visible;
        HomeOverlay.Opacity = 0.55;

        var tcs = new TaskCompletionSource();
        var sb = new Storyboard();
        var anim = new DoubleAnimation
        {
            From = from, To = to,
            Duration = TimeSpan.FromMilliseconds(durationMs),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(anim, translate);
        Storyboard.SetTargetProperty(anim, "Y");
        sb.Children.Add(anim);
        sb.Completed += (_, _) => tcs.TrySetResult();
        sb.Begin();

        await tcs.Task;
        HomeOverlay.RenderTransform = null;
    }

    /// <summary>
    /// LeftBar 整体不透明度渐变动画。to=0 淡出，to=1 淡入。
    /// </summary>
    private async Task AnimateLeftBarOpacity(double to, int ms, EasingMode easingMode)
    {
        _activeLeftBarSb?.Stop();

        double from = LeftBar.Opacity;
        LeftBar.Opacity = double.IsNaN(from) || from < 0.01 ? (to > 0.5 ? 0.0 : 1.0) : from;

        var tcs = new TaskCompletionSource();
        var sb = new Storyboard();
        var anim = new DoubleAnimation
        {
            From = LeftBar.Opacity,
            To = to,
            Duration = TimeSpan.FromMilliseconds(ms),
            EasingFunction = new CubicEase { EasingMode = easingMode },
        };
        Storyboard.SetTarget(anim, LeftBar);
        Storyboard.SetTargetProperty(anim, "Opacity");
        sb.Children.Add(anim);
        sb.Completed += (_, _) =>
        {
            _activeLeftBarSb = null;
            tcs.TrySetResult();
        };
        _activeLeftBarSb = sb;
        sb.Begin();
        await tcs.Task;
        LeftBar.Opacity = to;
    }

    // ================================================================
    //  登录过渡序列（从 OnLoginStateChanged 提取）
    // ================================================================

    /// <summary>
    /// 登录→首页完整过渡序列：等遮罩 → 卡片退场 → 遮罩从底部向上拉入覆盖 → 导航到首页（MainPage 开始渲染）。
    /// </summary>
    private async Task PerformLoginTransitionAsync(LoginPage loginPage)
    {
        _isEnteringHome = true;

        // 等待忙状态遮罩完成（ViewModel 会在 EnsureMinimumBusyTimeAsync 后设置 IsBusy = false）
        while (loginPage.ViewModel.IsBusy)
            await Task.Delay(30);

        // 确保遮罩已隐藏再继续
        await Task.Delay(50);

        // ██ Step 1: 卡片退场动画 ██
        // 自动登录时卡片从未显示，跳过退出动画
        if (!loginPage.CardAnimationSkipped)
        {
            var cardTcs = new TaskCompletionSource();
            loginPage.PlayExitAnimation(() => cardTcs.TrySetResult());
            await cardTcs.Task;
            await Task.Delay(60); // 停顿确保卡片完全消失
        }

        // ██ Step 2: 遮罩从底部向上拉入覆盖 ██
        // 先播放遮罩抽屉动画覆盖背景，再切换页面内容，
        // 视觉上形成「遮罩盖住登录页 → 首页在遮罩后渲染」的连贯过渡
        await AnimateHomeOverlayDrawerAsync(pullUp: true);

        // ██ Step 3: 导航到首页（MainPage 开始渲染）██
        _isFromLoginTransition = true;
        _pendingEnterAfterDrawer = true;
        LeftBar.Opacity = 0;
        LeftBar.Visibility = Visibility.Visible;
        _navService?.NavigateTo(typeof(MainPage));

        // ██ Step 4: 首页入场动画 ██
        EnterHomeFromLogin();
        _pendingEnterAfterDrawer = false;
    }

    /// <summary>
    /// 取消正在进行的退出动画，恢复首页的所有 UI 状态。
    /// 当用户在退出动画播放期间导航回首页时调用。
    /// </summary>
    private void CancelExitAndRestoreHome(MainPage mainPage)
    {
        _exitAnimationCancelled = true;
        _pendingNavigationType = null;
        _pendingNavigationParameter = null;

        // ★ 停止正在运行的背景淡出 Storyboard，防止动画继续驱动 Opacity→0 覆盖手动恢复的值
        _activeBgFadeOutSb?.Stop();
        _activeBgFadeOutSb = null;

        HomeBackgroundImage.Visibility = Visibility.Visible;
        HomeBackgroundImage.Opacity = 1.0;
        HomeOverlay.Visibility = Visibility.Visible;
        HomeOverlay.Opacity = 0.55;
        LeftBar?.AnimateBackingOpacity(from: 1.0, to: 0.4, ms: 400);
        mainPage.ResetSectionsVisibility();
        mainPage.PlayEnterAnimation();
    }

    /// <summary>
    /// 来自登录过渡的入场处理：播放 MainPage 入场动画，并在 ~800ms 后处理
    /// 暂存的背景路径（如果有的话）。
    /// </summary>
    private void EnterHomeFromLogin()
    {
        if (ContentFrame.Content is not MainPage mainPage) return;

        mainPage.PlayEnterAnimation();

        // 入场动画全部完成后（~800ms），执行待处理的背景交叉渐变
        _enterHomeTimer?.Stop();
        _enterHomeTimer = new DispatcherTimer
        {
            Interval = TimeSpan.FromMilliseconds(800),
        };
        _enterHomeTimer.Tick += (_, _) =>
        {
            _enterHomeTimer.Stop();
            _isEnteringHome = false;
            if (_pendingBackgroundPath != null)
            {
                var pendingPath = _pendingBackgroundPath;
                _pendingBackgroundPath = null;
                _ = TransitionBackgroundAsync(pendingPath);
            }
        };
        _enterHomeTimer.Start();
    }

    /// <summary>
    /// 切入首页：背景淡入先行 → 完成后 MainPage 容器顺序淡入
    /// </summary>
    private void PlayHomeEnterAnimation()
    {
        // ★ 停止 HomeBackgroundImage 上任何正在运行的旧动画
        _activeBgFadeOutSb?.Stop();
        _activeBgFadeOutSb = null;

        HomeBackgroundImage.Visibility = Visibility.Visible;
        HomeBackgroundImage.Opacity = 0.0;
        HomeOverlay.Visibility = Visibility.Visible;
        HomeOverlay.Opacity = 0.55;

        const int enterBgMs = 300;
        var easing = new CubicEase { EasingMode = EasingMode.EaseOut };

        var bgSb = new Storyboard();
        var bgAnim = new DoubleAnimation
        {
            From = 0.0,
            To = 1.0,
            Duration = TimeSpan.FromMilliseconds(enterBgMs),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(bgAnim, HomeBackgroundImage);
        Storyboard.SetTargetProperty(bgAnim, "Opacity");
        bgSb.Children.Add(bgAnim);

        bgSb.Completed += (_, _) =>
        {
            if (ContentFrame.Content is MainPage mainPage)
            {
                mainPage.PlayEnterAnimation();
            }
        };

        bgSb.Begin();

        // LeftBar 过渡
        LeftBar?.AnimateBackingOpacity(from: 1.0, to: 0.4, ms: enterBgMs);
    }
}
