﻿using System;
using System.Collections.Generic;
using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Animation;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.ViewModels.Controls;
using Windows.Foundation;
using Windows.UI;

namespace Kirara_Server_WinUI.Views.Controls;

public sealed partial class LeftFunctionBar : UserControl
{
    public ViewModels.Controls.LeftFunctionBarViewModel ViewModel { get; }

    // ================================================================
    //  展开/折叠过渡常量
    // ================================================================
    private const double CollapsedWidth = 48;      // 折叠态宽度
    private const int FadeMs = 180;                // 淡出/淡入时长
    private const int WidthMs = 220;               // 宽度动画时长

    private bool _isAnimating;

    /// <summary>
    /// 动画期间收到 IsLeftPaneOpen 变化时置 true：
    /// 动画进行中属性变化不能直接触发新动画（会相互干扰），
    /// 先标记待同步，当前动画完成后再次过渡到最终状态，保证 UI 与 VM 一致。
    /// </summary>
    private bool _pendingPaneSync;

    /// <summary>当前 SidebarBacking 透明度动画，用于停止旧动画避免冲突</summary>
    private Storyboard? _activeBackingOpacitySb;

    public LeftFunctionBar()
    {
        ViewModel = App.Services.GetRequiredService<ViewModels.Controls.LeftFunctionBarViewModel>();
        InitializeComponent();
        DataContext = ViewModel;

        // 初次同步（无动画）
        SyncImmediate(ViewModel.IsLeftPaneOpen);

        // 注册确认离开编辑器的 ContentDialog 委托（窗口正中央显示）
        ViewModel.ConfirmLeaveEditor = () =>
        {
            return ShowLeaveEditorDialog();
        };

        ViewModel.PropertyChanged += OnViewModelPropertyChanged;

        Loaded += OnLoaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        // 此时 ListView 已加载，但模板可能尚未完全展开，
        // 延迟到布局完成后查找 ScrollViewer
        DispatcherQueue.TryEnqueue(Microsoft.UI.Dispatching.DispatcherQueuePriority.Low, () =>
        {
            SetupScrollbarAutoHide(ExpandedListContainer, InstanceListView);
            SetupScrollbarAutoHide(CollapsedListContainer, CollapsedListView);
        });
    }

    /// <summary>
    /// 为 ListView 设置滚动条自动隐藏：鼠标悬停时淡入，离开后淡出
    /// </summary>
    private static void SetupScrollbarAutoHide(FrameworkElement container, ListView listView)
    {
        if (listView == null || container == null) return;

        var sv = FindScrollViewer(listView);
        if (sv == null) return;

        // 保持 Auto 以便滚动条自然出现，找到内部的 ScrollBar 控件
        var scrollBar = FindVerticalScrollBar(sv);
        if (scrollBar == null) return;

        // 初始隐藏
        scrollBar.Opacity = 0;

        container.PointerEntered += (_, _) =>
        {
            AnimateFade(scrollBar, 0, 1, 180, new QuarticEase { EasingMode = EasingMode.EaseOut });
        };

        container.PointerExited += (_, _) =>
        {
            AnimateFade(scrollBar, 1, 0, 200, new QuarticEase { EasingMode = EasingMode.EaseIn });
        };
    }

    /// <summary>
    /// 在 ScrollViewer 的可视化树中查找垂直 ScrollBar
    /// </summary>
    private static ScrollBar? FindVerticalScrollBar(DependencyObject parent)
    {
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is ScrollBar sb && sb.Orientation == Orientation.Vertical)
                return sb;
            var result = FindVerticalScrollBar(child);
            if (result != null)
                return result;
        }
        return null;
    }

    /// <summary>
    /// 创建单条透明度动画并启动
    /// </summary>
    private static void AnimateFade(FrameworkElement target, double from, double to,
        int ms, EasingFunctionBase easing)
    {
        var sb = new Storyboard();
        var anim = new DoubleAnimation
        {
            From = from,
            To = to,
            Duration = TimeSpan.FromMilliseconds(ms),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(anim, target);
        Storyboard.SetTargetProperty(anim, "Opacity");
        sb.Children.Add(anim);
        sb.Begin();
    }

    /// <summary>
    /// 在可视化树中递归查找 ScrollViewer
    /// </summary>
    private static ScrollViewer? FindScrollViewer(DependencyObject parent)
    {
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is ScrollViewer sv)
                return sv;
            var result = FindScrollViewer(child);
            if (result != null)
                return result;
        }
        return null;
    }

    private void OnViewModelPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName != nameof(ViewModels.Controls.LeftFunctionBarViewModel.IsLeftPaneOpen)) return;

        // 动画进行中：暂存状态变化，动画完成后统一过渡到最终状态（防吞变化）
        if (_isAnimating)
        {
            _pendingPaneSync = true;
            return;
        }
        AnimateTransition(ViewModel.IsLeftPaneOpen);
    }

    private void SyncImmediate(bool isOpen)
    {
        ExpandedContainer.Visibility = isOpen ? Visibility.Visible : Visibility.Collapsed;
        ExpandedContainer.Opacity = isOpen ? 1.0 : 0.0;
        ExpandedContainer.IsHitTestVisible = isOpen;

        CollapsedContainer.Visibility = isOpen ? Visibility.Collapsed : Visibility.Visible;
        CollapsedContainer.Opacity = isOpen ? 0.0 : 1.0;
        CollapsedContainer.IsHitTestVisible = !isOpen;

        var targetWidth = isOpen ? ViewModel.SidebarWidth : CollapsedWidth;
        RootPanel.Width = targetWidth;
        RootPanel.MinWidth = targetWidth;
    }

    /// <summary>
    /// 三段式过渡动画：
    ///   折叠：淡出展开内容 → 收缩宽度（无内容）→ 淡入折叠内容
    ///   展开：淡出折叠内容 → 扩展宽度（无内容）→ 淡入展开内容
    ///   宽度变化时所有内容完全不可见，避免视觉干扰
    /// </summary>
    private void AnimateTransition(bool toExpanded)
    {
        _isAnimating = true;
        _pendingPaneSync = false;
        var widthEasing = new QuarticEase { EasingMode = EasingMode.EaseOut };

        // 动画完成后：若动画期间又有新状态变化，再次过渡到最终状态
        void OnTransitionCompleted()
        {
            _isAnimating = false;
            if (_pendingPaneSync)
            {
                _pendingPaneSync = false;
                AnimateTransition(ViewModel.IsLeftPaneOpen);
            }
        }

        if (!toExpanded)
        {
            // ========== 折叠 ==========
            CollapsedContainer.Visibility = Visibility.Visible;
            CollapsedContainer.Opacity = 0.0;
            ExpandedContainer.IsHitTestVisible = false;
            CollapsedContainer.IsHitTestVisible = false;

            // Phase 1：淡出展开态（缩放+淡出）
            AnimateDisappear(ExpandedContainer, FadeMs,
                onCompleted: () =>
                {
                    ExpandedContainer.Visibility = Visibility.Collapsed;
                    ExpandedContainer.Opacity = 0.0;

                    // Phase 2：收缩宽度（无任何内容可见）
                    AnimateWidth(CollapsedWidth, WidthMs, widthEasing,
                        onCompleted: () =>
                        {
                            RootPanel.Width = CollapsedWidth;
                            RootPanel.MinWidth = CollapsedWidth;
                            RootPanel.InvalidateArrange();
                            RootPanel.InvalidateMeasure();

                            // Phase 3：淡入折叠态（缩放+淡入）
                            AnimateAppear(CollapsedContainer, FadeMs,
                                onCompleted: () =>
                                {
                                    CollapsedContainer.Opacity = 1.0;
                                    CollapsedContainer.IsHitTestVisible = true;
                                    OnTransitionCompleted();

                                    // 折叠态容器刚变为可见，补设滚动条自动隐藏
                                    SetupScrollbarAutoHide(CollapsedListContainer, CollapsedListView);
                                });
                        });
                });
        }
        else
        {
            // ========== 展开 ==========
            ExpandedContainer.Visibility = Visibility.Visible;
            ExpandedContainer.Opacity = 0.0;
            ExpandedContainer.IsHitTestVisible = false;
            CollapsedContainer.IsHitTestVisible = false;

            // Phase 1：淡出折叠态（缩放+淡出）
            AnimateDisappear(CollapsedContainer, FadeMs,
                onCompleted: () =>
                {
                    CollapsedContainer.Visibility = Visibility.Collapsed;
                    CollapsedContainer.Opacity = 0.0;

                    // Phase 2：扩展宽度（无任何内容可见）
                    AnimateWidth(ViewModel.SidebarWidth, WidthMs, widthEasing,
                        onCompleted: () =>
                        {
                            var targetWidth = ViewModel.SidebarWidth;
                            RootPanel.Width = targetWidth;
                            RootPanel.MinWidth = targetWidth;
                            RootPanel.InvalidateArrange();
                            RootPanel.InvalidateMeasure();

                            // Phase 3：淡入展开态（缩放+淡入）
                            AnimateAppear(ExpandedContainer, FadeMs,
                                onCompleted: () =>
                                {
                                    CollapsedContainer.Visibility = Visibility.Collapsed;
                                    CollapsedContainer.Opacity = 0.0;
                                    ExpandedContainer.Opacity = 1.0;
                                    ExpandedContainer.IsHitTestVisible = true;
                                    CollapsedContainer.IsHitTestVisible = false;
                                    OnTransitionCompleted();

                                    // 展开态容器刚变为可见，补设滚动条自动隐藏
                                    SetupScrollbarAutoHide(ExpandedListContainer, InstanceListView);
                                });
                        });
                });
        }
    }

    /// <summary>
    /// 灵动出现：透明度淡入 + 缩放弹入
    /// </summary>
    private static void AnimateAppear(FrameworkElement target, int ms,
        Action onCompleted)
    {
        var easing = new ElasticEase
        {
            EasingMode = EasingMode.EaseOut,
            Oscillations = 1,
            Springiness = 5,
        };

        EnsureScaleTransform(target, 0.93);

        var sb = new Storyboard();

        var op = new DoubleAnimation { From = 0.0, To = 1.0, Duration = TimeSpan.FromMilliseconds(ms), EasingFunction = easing };
        Storyboard.SetTarget(op, target);
        Storyboard.SetTargetProperty(op, "Opacity");
        sb.Children.Add(op);

        var sx = new DoubleAnimation { From = 0.93, To = 1.0, Duration = TimeSpan.FromMilliseconds(ms), EasingFunction = easing };
        Storyboard.SetTarget(sx, target);
        Storyboard.SetTargetProperty(sx, "(UIElement.RenderTransform).(ScaleTransform.ScaleX)");
        sb.Children.Add(sx);

        var sy = new DoubleAnimation { From = 0.93, To = 1.0, Duration = TimeSpan.FromMilliseconds(ms), EasingFunction = easing };
        Storyboard.SetTarget(sy, target);
        Storyboard.SetTargetProperty(sy, "(UIElement.RenderTransform).(ScaleTransform.ScaleY)");
        sb.Children.Add(sy);

        sb.Completed += (_, _) => onCompleted();
        sb.Begin();
    }

    /// <summary>
    /// 灵动消失：透明度淡出 + 缩放弹走
    /// </summary>
    private static void AnimateDisappear(FrameworkElement target, int ms,
        Action onCompleted)
    {
        var easing = new ElasticEase
        {
            EasingMode = EasingMode.EaseIn,
            Oscillations = 1,
            Springiness = 5,
        };

        EnsureScaleTransform(target, 1.0);

        var sb = new Storyboard();

        var op = new DoubleAnimation { From = 1.0, To = 0.0, Duration = TimeSpan.FromMilliseconds(ms), EasingFunction = easing };
        Storyboard.SetTarget(op, target);
        Storyboard.SetTargetProperty(op, "Opacity");
        sb.Children.Add(op);

        var sx = new DoubleAnimation { From = 1.0, To = 0.94, Duration = TimeSpan.FromMilliseconds(ms), EasingFunction = easing };
        Storyboard.SetTarget(sx, target);
        Storyboard.SetTargetProperty(sx, "(UIElement.RenderTransform).(ScaleTransform.ScaleX)");
        sb.Children.Add(sx);

        var sy = new DoubleAnimation { From = 1.0, To = 0.94, Duration = TimeSpan.FromMilliseconds(ms), EasingFunction = easing };
        Storyboard.SetTarget(sy, target);
        Storyboard.SetTargetProperty(sy, "(UIElement.RenderTransform).(ScaleTransform.ScaleY)");
        sb.Children.Add(sy);

        sb.Completed += (_, _) => onCompleted();
        sb.Begin();
    }

    /// <summary>
    /// 确保目标元素已设置 ScaleTransform，并重置到初始缩放值
    /// </summary>
    private static void EnsureScaleTransform(FrameworkElement target, double initialScale)
    {
        target.RenderTransformOrigin = new Point(0.5, 0.5);
        if (target.RenderTransform is ScaleTransform st)
        {
            st.ScaleX = initialScale;
            st.ScaleY = initialScale;
        }
        else
        {
            target.RenderTransform = new ScaleTransform { ScaleX = initialScale, ScaleY = initialScale };
        }
    }

    /// <summary>
    /// 创建单条宽度动画并启动，完成后回调
    /// </summary>
    private void AnimateWidth(double toWidth, int ms,
        EasingFunctionBase easing, Action onCompleted)
    {
        var sb = new Storyboard();
        var anim = new DoubleAnimation
        {
            To = toWidth,
            Duration = TimeSpan.FromMilliseconds(ms),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(anim, RootPanel);
        Storyboard.SetTargetProperty(anim, "Width");
        sb.Children.Add(anim);
        sb.Completed += (_, _) => onCompleted();
        sb.Begin();
    }

    // ================================================================
    //  ↓↓↓ 以下事件处理方法与原始代码完全一致，无需改动 ↓↓↓
    // ================================================================

    // ================================================================
    //  首页半透明过渡动画（由 ShellPage 导航时触发）
    // ================================================================

    /// <summary>
    /// 动画过渡左侧栏衬底透明度。
    /// 首页时 Opacity=0.4（半透明透出背景），切出时 Opacity=1.0（不透明）。
    /// </summary>
    /// <param name="from">起始透明度</param>
    /// <param name="to">目标透明度</param>
    /// <param name="ms">动画时长（毫秒）</param>
    public void AnimateBackingOpacity(double from, double to, int ms = 300)
    {
        // ★ 停止旧动画，防止多个 Storyboard 同时驱动 SidebarBacking.Opacity
        _activeBackingOpacitySb?.Stop();

        var easing = new CubicEase { EasingMode = EasingMode.EaseOut };

        var sb = new Storyboard();
        var anim = new DoubleAnimation
        {
            From = from,
            To = to,
            Duration = TimeSpan.FromMilliseconds(ms),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(anim, SidebarBacking);
        Storyboard.SetTargetProperty(anim, "Opacity");
        sb.Children.Add(anim);
        sb.Completed += (_, _) => _activeBackingOpacitySb = null;
        _activeBackingOpacitySb = sb;
        sb.Begin();
    }

    private void OnInstanceNameClick(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement element && element.DataContext is Models.Instance instance)
        {
            // [初始化拦截] 该实例正在初始化中：无法进入，弹出全局飞入提示
            if (ViewModel.IsInstanceInitializing(instance.Id))
            {
                FlyoutHelper.ShowInfo(
                    element,
                    Microsoft.UI.Xaml.Controls.Primitives.FlyoutPlacementMode.RightEdgeAlignedTop,
                    "\uE783",
                    Color.FromArgb(255, 255, 165, 0),
                    "正在初始化中，请稍候...",
                    "该实例正在重置所有方案，初始化完成前无法进入");
                return;
            }

            // [关闭拦截] 该实例正在关闭中：无法进入，弹出全局飞入提示
            if (ViewModel.IsInstanceClosing(instance.Id))
            {
                FlyoutHelper.ShowInfo(
                    element,
                    Microsoft.UI.Xaml.Controls.Primitives.FlyoutPlacementMode.RightEdgeAlignedTop,
                    "\uE783",
                    Color.FromArgb(255, 255, 165, 0),
                    "正在关闭中，请稍候...",
                    "该实例正在关闭所有方案，关闭完成前无法进入");
                return;
            }

            ViewModel.SelectInstanceCommand.Execute(instance);
        }
    }

    private void OnInstanceSettingsClick(object sender, RoutedEventArgs e)
    {
        if (sender is Button button && button.DataContext is Models.Instance instance)
        {
            ViewModel.SetContextInstanceCommand.Execute(instance);
            ShowInstanceSettingsFlyout(button, instance);
        }
    }

    private void ShowInstanceSettingsFlyout(Button anchor, Models.Instance instance)
    {
        var flyout = new Flyout
        {
            Placement = Microsoft.UI.Xaml.Controls.Primitives.FlyoutPlacementMode.RightEdgeAlignedTop,
        };

        var stackPanel = new StackPanel
        {
            Spacing = 4,
            Padding = new Thickness(10, 10, 10, 5),
            MinWidth = 200,
        };

        stackPanel.Children.Add(new Microsoft.UI.Xaml.Shapes.Rectangle
        {
            Height = 3,
            Margin = new Thickness(0, 0, 0, 0),
            Fill = (Brush)Application.Current.Resources["KiraraDividerBrush"],
        });

        stackPanel.Children.Add(CreateMenuButton("\uE8AC 重命名实例", () =>
        {
            flyout.Hide();
            ShowRenameFlyout(anchor, instance);
        }));

        stackPanel.Children.Add(CreateMenuButton("\uE735 切换置顶", () =>
        {
            ViewModel.ToggleFavoriteContextInstanceCommand.Execute(null);
            flyout.Hide();
        }));

        stackPanel.Children.Add(CreateMenuButton("\uE7E8 关闭实例", () =>
        {
            ViewModel.CloseInstanceCommand.Execute(null);
            flyout.Hide();
        }));

        var resetButton = CreateMenuButton("\uE777 初始化实例", () =>
        {
            flyout.Hide();
            ShowResetFlyout(anchor, instance);
        });
        resetButton.Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 165, 0));
        stackPanel.Children.Add(resetButton);

        var deleteButton = CreateMenuButton("\uE74D 删除实例", () =>
        {
            flyout.Hide();
            ShowDeleteFlyout(anchor, instance);
        });
        deleteButton.Foreground = new SolidColorBrush(Color.FromArgb(255, 229, 115, 115));
        stackPanel.Children.Add(deleteButton);

        stackPanel.Children.Add(new Microsoft.UI.Xaml.Shapes.Rectangle
        {
            Height = 3,
            Margin = new Thickness(0, 0, 0, 0),
            Fill = (Brush)Application.Current.Resources["KiraraDividerBrush"],
        });

        stackPanel.Children.Add(new TextBlock
        {
            Text = "选择颜色标签",
            FontSize = 13,
            Opacity = 0.6,
            Margin = new Thickness(0, 14, 0, 14),
        });

        var colorPanel = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 0, 0, 10),
        };
        foreach (var colorHex in ViewModel.ColorOptions)
        {
            var colorButton = CreateColorButton(colorHex, flyout);
            colorPanel.Children.Add(colorButton);
        }
        stackPanel.Children.Add(colorPanel);

        stackPanel.Children.Add(new Microsoft.UI.Xaml.Shapes.Rectangle
        {
            Height = 3,
            Margin = new Thickness(0, 4, 0, 4),
            Fill = (Brush)Application.Current.Resources["KiraraDividerBrush"],
        });

        flyout.Content = stackPanel;
        flyout.ShowAt(anchor);
    }

    // ================================================================
    //  重命名飞入菜单（参考令牌管理器风格）
    // ================================================================

    private void ShowRenameFlyout(Button anchor, Models.Instance instance)
    {
        var flyout = new Flyout
        {
            Placement = FlyoutPlacementMode.RightEdgeAlignedTop,
        };

        var root = new StackPanel { Spacing = 12, MinWidth = 280, Padding = new Thickness(4) };

        root.Children.Add(new TextBlock
        {
            Text = "重命名实例",
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 0, 0, 8),
            FontSize = 16,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
        });

        var textBox = new TextBox
        {
            Text = instance.Name,
            PlaceholderText = "输入新名称",
            Margin = new Thickness(0, 0, 0, 10),
            MaxLength = 64,
        };
        root.Children.Add(textBox);

        var errorText = new TextBlock
        {
            FontSize = 12,
            Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 107, 107)),
            TextWrapping = TextWrapping.Wrap,
            Visibility = Visibility.Collapsed,
            Margin = new Thickness(5, -10, 0, 0),
        };
        root.Children.Add(errorText);

        var buttonPanel = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Center,
            Spacing = 12,
        };

        var cancelBtn = new Button
        {
            Content = "取消",
            Style = (Style)Application.Current.Resources["GrayButtonStyle"],
            MinWidth = 100,
        };
        cancelBtn.Click += (_, _) => flyout.Hide();
        buttonPanel.Children.Add(cancelBtn);

        var saveBtn = new Button
        {
            Content = "保存",
            Style = (Style)Application.Current.Resources["PrimaryButtonStyle"],
            MinWidth = 100,
            IsEnabled = false,
        };
        buttonPanel.Children.Add(saveBtn);

        root.Children.Add(buttonPanel);
        flyout.Content = root;
        flyout.ShowAt(anchor);

        // 选中全部文字
        textBox.SelectAll();
        textBox.Focus(FocusState.Programmatic);

        // 实时校验
        textBox.TextChanged += (_, _) =>
        {
            var name = textBox.Text;
            var (isValid, errorMsg) = ViewModel.ValidateInstanceName(name, instance);
            saveBtn.IsEnabled = isValid;
            errorText.Text = errorMsg ?? string.Empty;
            errorText.Visibility = errorMsg != null ? Visibility.Visible : Visibility.Collapsed;
        };

        saveBtn.Click += (_, _) =>
        {
            var newName = textBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(newName) || newName == instance.Name)
            {
                flyout.Hide();
                return;
            }

            ViewModel.RenameContextInstanceCommand.Execute(newName);
            flyout.Hide();
        };
    }

    // ================================================================
    //  删除确认飞入（参考令牌管理器风格）
    // ================================================================

    private async void ShowDeleteFlyout(Button anchor, Models.Instance instance)
    {
        bool confirmed = await FlyoutHelper.ShowDeleteConfirmAsync(
            anchor,
            FlyoutPlacementMode.RightEdgeAlignedTop,
            "确定要永久删除此实例吗？",
            "该实例所链接方案的本地缓存也将被清除");

        if (confirmed)
            ViewModel.DeleteContextInstanceCommand.Execute(null);
    }

    // ================================================================
    //  初始化实例确认飞入（参考删除确认风格）
    // ================================================================

    private async void ShowResetFlyout(Button anchor, Models.Instance instance)
    {
        bool confirmed = await FlyoutHelper.ShowConfirmAsync(
            anchor,
            FlyoutPlacementMode.RightEdgeAlignedTop,
            "\uE783",
            Color.FromArgb(255, 255, 165, 0),
            "确定要初始化此实例吗？",
            "所有方案会被重置到初始状态，同时清除本地缓存",
            confirmText: "确定",
            confirmColor: Color.FromArgb(255, 255, 165, 0));

        if (confirmed)
            ViewModel.ResetContextInstanceCommand.Execute(null);
    }

    // ================================================================
    //  离开编辑器确认弹窗（窗口正中央显示，主题自适应）
    // ================================================================

    private async Task<bool> ShowLeaveEditorDialog()
    {
        // 构建自定义内容，参考令牌管理器 Flyout 风格
        var content = new StackPanel { Spacing = 16, MinWidth = 260 };

        content.Children.Add(new FontIcon
        {
            Glyph = "\uE783",
            FontSize = 45,
            Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 193, 7)),
            HorizontalAlignment = HorizontalAlignment.Center,
        });

        content.Children.Add(new TextBlock
        {
            Text = " 要离开实例创建向导吗？",
            FontSize = 18,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -5, 0, 0),
        });

        content.Children.Add(new TextBlock
        {
            Text = "已经完成的步骤将不会保留",
            FontSize = 15,
            Opacity = 0.7,
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -5, 0, 10),
        });

        // 跟随窗口当前主题
        var theme = MainWindow.Current?.Content is FrameworkElement root
            ? root.ActualTheme
            : ElementTheme.Default;

        var dialog = new ContentDialog
        {
            XamlRoot = this.XamlRoot,
            RequestedTheme = theme,
            Content = content,
            PrimaryButtonText = "取消",
            CloseButtonText = "离开",
            DefaultButton = ContentDialogButton.Close,
        };

        var result = await dialog.ShowAsync();
        return result == ContentDialogResult.None;
    }

    // ValidateInstanceName 已迁移到 LeftFunctionBarViewModel.ValidateInstanceName()

    private Button CreateColorButton(string colorHex, Flyout parentFlyout)
    {
        var button = new Button
        {
            Style = (Style)Resources["ColorOptionButtonStyle"],
            DataContext = colorHex,
        };

        if (string.IsNullOrEmpty(colorHex))
        {
            button.Background = new SolidColorBrush(Color.FromArgb(40, 128, 128, 128));
            button.Content = new TextBlock
            {
                Text = "\uE10A",
                FontFamily = new FontFamily("Segoe MDL2 Assets"),
                FontSize = 14,
                Foreground = new SolidColorBrush(Microsoft.UI.Colors.Gray),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
            };
        }
        else
        {
            button.SetBinding(Button.BackgroundProperty, new Microsoft.UI.Xaml.Data.Binding
            {
                Converter = (Microsoft.UI.Xaml.Data.IValueConverter)Resources["ColorTagToBrushConverter"],
            });
        }

        var capturedColor = colorHex;
        button.Click += (_, _) =>
        {
            ViewModel.SetContextInstanceColorCommand.Execute(capturedColor);
            parentFlyout.Hide();
        };
        return button;
    }

    private static Button CreateMenuButton(string text, Action action)
    {
        var grid = new Grid
        {
            ColumnDefinitions =
            {
                new ColumnDefinition { Width = GridLength.Auto },
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) },
            },
        };

        // 提取第一个 Unicode 图标字符（\uE777 等 Segoe Fluent Icons）
        string iconGlyph = text.Length > 0 && text[0] >= 0xE000 && text[0] <= 0xF000
            ? text[0].ToString()
            : "\uE7C3";

        // 提取图标后面的文本（去掉图标字符和开头的空格）
        string displayText = text.Length > 1 ? text[1..].TrimStart() : text;

        var icon = new FontIcon
        {
            Glyph = iconGlyph,
            FontSize = 16,
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(10, 0, 16, 0),
        };
        Grid.SetColumn(icon, 0);
        grid.Children.Add(icon);

        var textBlock = new TextBlock
        {
            Text = displayText,
            FontSize = 14,
            VerticalAlignment = VerticalAlignment.Center,
            TextTrimming = TextTrimming.CharacterEllipsis,
            Margin = new Thickness(5, 0, 12, 0),
        };
        Grid.SetColumn(textBlock, 1);
        grid.Children.Add(textBlock);

        var button = new Button
        {
            Content = grid,
            Style = (Style)Application.Current.Resources["NavigationButtonStyle"],
            Margin = new Thickness(0),
        };
        button.Click += (_, _) => action();
        return button;
    }

    // ================================================================
    //  实例列表项交互动画
    // ================================================================

    private void OnInstanceItemPointerEntered(object sender, Microsoft.UI.Xaml.Input.PointerRoutedEventArgs e)
    {
        if (sender is Button button)
        {
            EnsureTransformGroup(button);
            var sb = new Storyboard();
            AddScaleAnim(sb, button, 200, 1.0, 1.03, new QuarticEase { EasingMode = EasingMode.EaseOut });
            AddTranslateAnim(sb, button, 200, 0.0, -2.0, new QuarticEase { EasingMode = EasingMode.EaseOut });
            sb.Begin();
        }
    }

    private void OnInstanceItemPointerPressed(object sender, Microsoft.UI.Xaml.Input.PointerRoutedEventArgs e)
    {
        if (sender is Button button)
        {
            EnsureTransformGroup(button);
            var sb = new Storyboard();
            AddScaleAnim(sb, button, 100, 1.03, 0.97, new CubicEase { EasingMode = EasingMode.EaseIn });
            AddTranslateAnim(sb, button, 100, -2.0, 1.0, new CubicEase { EasingMode = EasingMode.EaseIn });
            sb.Begin();
        }
    }

    private void OnInstanceItemPointerReleased(object sender, Microsoft.UI.Xaml.Input.PointerRoutedEventArgs e)
    {
        if (sender is Button button)
        {
            EnsureTransformGroup(button);
            var sb = new Storyboard();
            AddScaleAnim(sb, button, 300, 0.97, 1.03, new ElasticEase { EasingMode = EasingMode.EaseOut, Oscillations = 1, Springiness = 7 });
            AddTranslateAnim(sb, button, 300, 1.0, -2.0, new ElasticEase { EasingMode = EasingMode.EaseOut, Oscillations = 1, Springiness = 7 });
            sb.Begin();
        }
    }

    private void OnInstanceItemPointerExited(object sender, Microsoft.UI.Xaml.Input.PointerRoutedEventArgs e)
    {
        if (sender is Button button)
        {
            EnsureTransformGroup(button);
            var sb = new Storyboard();
            AddScaleAnim(sb, button, 250, 1.03, 1.0, new QuarticEase { EasingMode = EasingMode.EaseOut });
            AddTranslateAnim(sb, button, 250, -2.0, 0.0, new QuarticEase { EasingMode = EasingMode.EaseOut });
            sb.Begin();
        }
    }

    // ================================================================
    //  折叠态色饼发光
    // ================================================================

    private void OnCollapsedItemPointerEntered(object sender, Microsoft.UI.Xaml.Input.PointerRoutedEventArgs e)
    {
        if (sender is Button button && button.Content is Grid grid)
        {
            foreach (var child in grid.Children)
            {
                if (child is Microsoft.UI.Xaml.Shapes.Ellipse ellipse
                    && ellipse.Visibility == Visibility.Visible
                    && ellipse.Fill is SolidColorBrush fillBrush)
                {
                    ellipse.Stroke = new SolidColorBrush(
                        Color.FromArgb(180, fillBrush.Color.R, fillBrush.Color.G, fillBrush.Color.B));
                    ellipse.StrokeThickness = 3;
                    break;
                }
            }
        }
    }

    private void OnCollapsedItemPointerExited(object sender, Microsoft.UI.Xaml.Input.PointerRoutedEventArgs e)
    {
        if (sender is Button button && button.Content is Grid grid)
        {
            foreach (var child in grid.Children)
            {
                if (child is Microsoft.UI.Xaml.Shapes.Ellipse ellipse && ellipse.Fill is SolidColorBrush)
                {
                    ellipse.ClearValue(Microsoft.UI.Xaml.Shapes.Shape.StrokeProperty);
                    ellipse.ClearValue(Microsoft.UI.Xaml.Shapes.Shape.StrokeThicknessProperty);
                }
            }
        }
    }

    // ================================================================
    //  Transform 工具方法
    // ================================================================

    private static void EnsureTransformGroup(Button button)
    {
        if (button.RenderTransform is TransformGroup) return;

        var group = new TransformGroup();
        group.Children.Add(new ScaleTransform { ScaleX = 1, ScaleY = 1 });
        group.Children.Add(new TranslateTransform());
        button.RenderTransform = group;
        button.RenderTransformOrigin = new Point(0.5, 0.5);
    }

    private static void AddScaleAnim(Storyboard sb, Button target, int ms, double from, double to, EasingFunctionBase? ease)
    {
        var animX = new DoubleAnimation { From = from, To = to, Duration = TimeSpan.FromMilliseconds(ms), EasingFunction = ease };
        Storyboard.SetTarget(animX, target);
        Storyboard.SetTargetProperty(animX, "(UIElement.RenderTransform).(TransformGroup.Children)[0].(ScaleTransform.ScaleX)");
        sb.Children.Add(animX);

        var animY = new DoubleAnimation { From = from, To = to, Duration = TimeSpan.FromMilliseconds(ms), EasingFunction = ease };
        Storyboard.SetTarget(animY, target);
        Storyboard.SetTargetProperty(animY, "(UIElement.RenderTransform).(TransformGroup.Children)[0].(ScaleTransform.ScaleY)");
        sb.Children.Add(animY);
    }

    private static void AddTranslateAnim(Storyboard sb, Button target, int ms, double from, double to, EasingFunctionBase? ease)
    {
        var animX = new DoubleAnimation { From = from, To = to, Duration = TimeSpan.FromMilliseconds(ms), EasingFunction = ease };
        Storyboard.SetTarget(animX, target);
        Storyboard.SetTargetProperty(animX, "(UIElement.RenderTransform).(TransformGroup.Children)[1].(TranslateTransform.X)");
        sb.Children.Add(animX);

        var animY = new DoubleAnimation { From = from, To = to, Duration = TimeSpan.FromMilliseconds(ms), EasingFunction = ease };
        Storyboard.SetTarget(animY, target);
        Storyboard.SetTargetProperty(animY, "(UIElement.RenderTransform).(TransformGroup.Children)[1].(TranslateTransform.Y)");
        sb.Children.Add(animY);
    }
}
