using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.ViewModels.Comment;
using Windows.Graphics;

namespace Kirara_Server_WinUI.Views.Comment;

/// <summary>
/// [评论区功能] 评论悬浮窗三态状态
/// </summary>
public enum CommentPanelState
{
    /// <summary>收缩：主窗口右下角 40×40 悬浮展开按钮（样式保持现状）</summary>
    Collapsed,

    /// <summary>气泡：悬浮于主窗口下方，左右/底部留白，高度可拖拽调整</summary>
    Expanded,

    /// <summary>全展开：悬浮面板，全宽、底对齐、顶边留空隙</summary>
    FullExpanded,
}

/// <summary>
/// 评论独立窗口 — 无边框毛玻璃子窗口，锚定在主窗口内
/// 通过 CommentPanelService 管理生命周期和定位
/// [评论区功能] 三态切换（收缩/气泡/全展开）、气泡模式顶部拖拽调整高度
/// </summary>
public sealed partial class CommentWindow : Window
{
    /// <summary>评论窗口 ViewModel</summary>
    private readonly CommentWindowViewModel _viewModel;

    /// <summary>拖拽起始 Y 坐标</summary>
    private double _dragStartY;

    /// <summary>拖拽开始时窗口高度</summary>
    private int _dragStartHeight;

    /// <summary>是否正在拖拽</summary>
    private bool _isDragging;

    /// <summary>评论窗口最小高度</summary>
    private const int MinWindowHeight = 150;

    /// <summary>[评论区功能] 气泡模式默认高度</summary>
    private const int ExpandedDefaultHeight = 320;

    /// <summary>[评论区功能] 当前状态（三态）</summary>
    public CommentPanelState State { get; private set; } = CommentPanelState.Expanded;

    /// <summary>[评论区功能] 是否处于折叠状态（兼容属性，供 CommentPanelService 使用）</summary>
    public bool IsCollapsed => State == CommentPanelState.Collapsed;

    /// <summary>[评论区功能] 气泡模式的高度（拖拽后记忆，折叠恢复/重定位时使用）</summary>
    private int _expandedHeight = ExpandedDefaultHeight;

    /// <summary>[评论区功能] Win11 (22000+) 才支持系统亚克力毛玻璃与 DWM 窗口圆角</summary>
    private static bool IsWin11OrLater => Environment.OSVersion.Version.Build >= 22000;

    public CommentWindow()
    {
        InitializeComponent();

        // 从 DI 获取 ViewModel
        var commentService = App.Services.GetRequiredService<ICommentService>();
        var homepageCommentService = App.Services.GetService<IHomepageCommentService>();
        _viewModel = new CommentWindowViewModel(commentService, homepageCommentService);

        CommentPanelControl.DataContext = _viewModel;

        // 无边框窗口设置
        AppWindow.TitleBar.ExtendsContentIntoTitleBar = true;
        AppWindow.TitleBar.PreferredHeightOption = Microsoft.UI.Windowing.TitleBarHeightOption.Collapsed;

        // [评论区功能] 评论区始终置顶，避免点击主窗口其他区域后被遮挡
        if (AppWindow.Presenter is Microsoft.UI.Windowing.OverlappedPresenter presenter)
        {
            presenter.IsAlwaysOnTop = true;
        }

        // [评论区功能] 毛玻璃背景：Win11 系统亚克力（跟随主题），Win10 降级为纯色
        ApplyAcrylicBackdrop();

        // [评论区功能] 窗口圆角（Win11 DWM 圆角裁剪；Win10 无效自动忽略）
        ApplyWindowCorner(true);

        // [评论区功能] 设置拖拽区域光标为 SizeNS（通过 Win32 API）
        ResizeDragArea.PointerEntered += (_, _) => SetCursorSizeNS();
        ResizeDragArea.PointerExited += (_, _) => SetCursorArrow();

        // [评论区功能] 订阅折叠/全展开按钮事件
        CommentPanelControl.CollapseToggleRequested += ToggleCollapse;
        CommentPanelControl.FullExpandToggleRequested += ToggleFullExpand;
    }

    /// <summary>
    /// 加载指定资源的评论（由 CommentPanelService 调用）
    /// </summary>
    public async void LoadComments(string resourceKey, Guid schemeId, string? resourceTitle)
    {
        await _viewModel.SetContextAndLoadAsync(resourceKey, schemeId, resourceTitle);
    }

    /// <summary>
    /// 将窗口带到前台
    /// </summary>
    public void BringToFront()
    {
        AppWindow.Show();
    }

    // ===== [评论区功能] 三态切换（收缩 / 气泡 / 全展开） =====

    /// <summary>
    /// [评论区功能] 切换折叠/展开状态（折叠按钮）
    /// 折叠 → 恢复气泡模式；气泡/全展开 → 收缩为右下角展开按钮
    /// </summary>
    public void ToggleCollapse()
    {
        if (IsCollapsed)
            ExpandFromCollapsed();
        else
            Collapse();
    }

    /// <summary>
    /// [评论区功能] 收缩：隐藏评论窗口，仅在主窗口右下角留 40×40 展开悬浮按钮（样式保持现状）
    /// </summary>
    public void Collapse()
    {
        if (IsCollapsed) return;
        State = CommentPanelState.Collapsed;
        ApplyStateVisual();
    }

    /// <summary>
    /// [评论区功能] 从收缩恢复为气泡模式
    /// </summary>
    public void ExpandFromCollapsed()
    {
        if (!IsCollapsed) return;
        State = CommentPanelState.Expanded;
        ApplyStateVisual();
    }

    /// <summary>
    /// [评论区功能] 切换 气泡 ↔ 全展开（全展开按钮）
    /// 全展开：悬浮面板，全宽、底对齐、顶边留空隙，高度为最大可用高度
    /// </summary>
    public void ToggleFullExpand()
    {
        if (IsCollapsed) return;
        State = State == CommentPanelState.FullExpanded
            ? CommentPanelState.Expanded
            : CommentPanelState.FullExpanded;
        ApplyStateVisual();
    }

    /// <summary>
    /// [评论区功能] 应用当前状态的窗口视觉（拖拽区/边距/圆角/面板内部视觉），并交由服务重新定位
    /// </summary>
    private void ApplyStateVisual()
    {
        switch (State)
        {
            case CommentPanelState.Collapsed:
                // 收缩：隐藏拖拽区、去除面板边距，仅留展开按钮填满 40×40 窗口；恢复方角（保持现状）
                ResizeDragArea.Visibility = Visibility.Collapsed;
                CommentPanelControl.Margin = new Thickness(0);
                ApplyWindowCorner(false);
                break;

            case CommentPanelState.Expanded:
                // 气泡：恢复拖拽区与面板边距
                ResizeDragArea.Visibility = Visibility.Visible;
                CommentPanelControl.Margin = new Thickness(0, 4, 0, 0);
                ApplyWindowCorner(true);
                break;

            case CommentPanelState.FullExpanded:
                // 全展开：悬浮面板，禁拖拽（高度固定为最大可用高度），保留面板边距
                ResizeDragArea.Visibility = Visibility.Collapsed;
                CommentPanelControl.Margin = new Thickness(0, 4, 0, 0);
                ApplyWindowCorner(true);
                break;
        }

        // 更新面板内部视觉状态（标题信息区/双按钮/图标）
        CommentPanelControl.SetPanelState(State);

        // 交由 CommentPanelService 统一定位（收缩→右下角按钮；气泡→下方留白悬浮；全展开→悬浮面板）
        App.Services.GetRequiredService<ICommentPanelService>().RepositionPanel();
    }

    /// <summary>
    /// [评论区功能] 获取气泡模式应使用的高度（收缩状态由服务单独处理），供 CommentPanelService 定位用
    /// </summary>
    public int GetCurrentHeight() => _expandedHeight;

    // ===== [评论区功能] 毛玻璃背景与窗口圆角 =====

    /// <summary>
    /// [评论区功能] 毛玻璃背景：系统级亚克力（DesktopAcrylic，跟随系统主题明暗）。
    /// Windows 10 1809+ 即支持；不支持时 WinAppSDK 自动降级为纯色背景。
    /// 注意：此前用 Win11 判断限制导致 Win10/Manifest 未声明 Win11 时毛玻璃失效
    /// </summary>
    private void ApplyAcrylicBackdrop()
    {
        SystemBackdrop = new DesktopAcrylicBackdrop();
        // 置空纯色背景，让系统亚克力毛玻璃透出
        RootGrid.Background = null;
    }

    [System.Runtime.InteropServices.DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

    private const int DWMWA_WINDOW_CORNER_PREFERENCE = 33;
    private const int DWMWCP_DONOTROUND = 1;
    private const int DWMWCP_ROUND = 2;

    /// <summary>
    /// [评论区功能] 设置窗口圆角（Win11 DWM 圆角裁剪，配合毛玻璃形成气泡/悬浮面板；
    /// Win10 无效自动忽略）。收缩状态恢复方角（保持现状）
    /// </summary>
    private void ApplyWindowCorner(bool round)
    {
        if (!IsWin11OrLater) return;

        var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
        int preference = round ? DWMWCP_ROUND : DWMWCP_DONOTROUND;
        DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, ref preference, sizeof(int));
    }

    // ===== [评论区功能] 顶部拖拽调整高度（仅气泡模式） =====

    /// <summary>
    /// 拖拽区域按下 — 记录起始位置（仅气泡模式允许拖拽调高）
    /// </summary>
    private void OnResizeDragAreaPointerPressed(object sender, PointerRoutedEventArgs e)
    {
        // [评论区功能] 仅气泡模式允许拖拽调高（全展开高度固定，收缩无内容）
        if (State != CommentPanelState.Expanded) return;

        _dragStartY = e.GetCurrentPoint(null).Position.Y;
        _dragStartHeight = AppWindow.Size.Height;
        _isDragging = true;

        // 捕获指针以确保拖拽超出窗口边界时仍能接收事件
        ResizeDragArea.CapturePointer(e.Pointer);
    }

    /// <summary>
    /// 拖拽区域移动 — 计算新高度并调整窗口
    /// </summary>
    private void OnResizeDragAreaPointerMoved(object sender, PointerRoutedEventArgs e)
    {
        if (!_isDragging) return;

        var currentY = e.GetCurrentPoint(null).Position.Y;
        var deltaY = _dragStartY - currentY; // 向上拖为正值

        var newHeight = (int)(_dragStartHeight + deltaY);

        // 计算最大高度（主窗口高度 × 0.6）
        var mainWindow = MainWindow.Current;
        var maxHeight = mainWindow != null ? (int)(mainWindow.AppWindow.Size.Height * 0.6) : 800;

        // 限制高度范围
        newHeight = Math.Clamp(newHeight, MinWindowHeight, maxHeight);

        // [评论区功能] 记录拖拽后的高度，折叠后展开时恢复
        _expandedHeight = newHeight;

        // 调整窗口大小（向上扩展）
        var pos = AppWindow.Position;
        var newRect = new RectInt32(pos.X, pos.Y + (_dragStartHeight - newHeight), AppWindow.Size.Width, newHeight);
        AppWindow.MoveAndResize(newRect);
    }

    // ===== Win32 光标设置 =====

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern IntPtr LoadCursor(IntPtr hInstance, int lpCursorName);

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern bool SetCursor(IntPtr hCursor);

    private const int IDC_SIZENS = 32645; // MAKEINTRESOURCE(32645)
    private const int IDC_ARROW = 32512;  // MAKEINTRESOURCE(32512)

    private static void SetCursorSizeNS()
    {
        var hCursor = LoadCursor(IntPtr.Zero, IDC_SIZENS);
        SetCursor(hCursor);
    }

    private static void SetCursorArrow()
    {
        var hCursor = LoadCursor(IntPtr.Zero, IDC_ARROW);
        SetCursor(hCursor);
    }
}
