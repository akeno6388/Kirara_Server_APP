; ============================================================
; Kirara Server APP - Inno Setup 安装脚本
; 分发形态: Unpackaged + 自包含 (.NET10 + WinAppSDK)
; 三方程序: OpenVPN (MSI) + WebView2 (Evergreen) → {app}\ThirdAPPs
; ============================================================

#define MyAppName "Kirara Server 应用程序"
#define MyAppVersion "0.9.3"
#define MyAppPublisher "SenVenth AC"
#define MyAppExeName "KiraraServerAPP.exe"

[Setup]
; AppId 官方格式：{{GUID}（{{ 转义为单个 {）
AppId={{732B89C8-2A4B-4C89-9FD1-CADE0CD793B7}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Kirara Server APP
DefaultGroupName={#MyAppName}
OutputBaseFilename=Kirara_Server_APP_Setup_x64
OutputDir=..\bin\installer
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
WizardResizable=yes
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExeName}
SetupIconFile=..\Assets\app.ico
; 向导图片（方案A：品牌化界面）——图片制作完成后取消注释
; WizardImageFile=..\Assets\wizard_big.bmp
; WizardSmallImageFile=..\Assets\wizard_small.bmp

[Languages]
; 简体中文语言文件放在 installer/ 目录（官方 6.5.0+ 版，避免写入 Program Files 需管理员权限）
Name: "chinesesimp"; MessagesFile: "ChineseSimplified.isl"

[Registry]
; ── 软件基础信息注册表（供安装器版本比对与外部工具查询）──
; ⚠️ 卸载时自动删除整个键（uninsdeletekey）
; 版本比对优先级：本自定义键 Version → 回退 Inno 卸载注册表 DisplayVersion
Root: HKLM; Subkey: "Software\Kirara Server APP"; ValueType: string; ValueName: "InstallPath"; ValueData: "{app}"; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Kirara Server APP"; ValueType: string; ValueName: "Version"; ValueData: "{#MyAppVersion}"
Root: HKLM; Subkey: "Software\Kirara Server APP"; ValueType: string; ValueName: "ExePath"; ValueData: "{app}\{#MyAppExeName}"
Root: HKLM; Subkey: "Software\Kirara Server APP"; ValueType: string; ValueName: "Publisher"; ValueData: "{#MyAppPublisher}"

[Tasks]
Name: "desktopicon"; Description: "创建桌面快捷方式"; GroupDescription: "附加任务:"

[Files]
; 应用本体（自包含发布文件夹，全部递归复制）
; ⚠️ Excludes: *.WebView2 排除 WebView2 用户数据目录（Cookie/登录态等运行时缓存，
;    不应打进安装包——膨胀体积 + 泄漏用户数据；安装后首次运行自动重建）
Source: "..\bin\Release\publish\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion; Excludes: "*.WebView2"
; VPN 代理服务（LocalSystem，代应用启动 openvpn.exe，免 UAC）
Source: "..\bin\Release\publish\KiraraVpnHelper\*"; DestDir: "{app}\KiraraVpnHelper"; Flags: recursesubdirs ignoreversion
; 三方安装包（解压到临时目录，不直接安装）
Source: "..\ThirdAPPs\OpenVPN-2.7.5-I001-amd64.msi"; DestDir: "{tmp}"; Flags: deleteafterinstall
Source: "..\ThirdAPPs\MicrosoftEdgeWebview2Setup.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\卸载 {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
; KiraraVpnHelper 服务注册与启动（LocalSystem，命名管道代理 openvpn）
; ⚠️ 必须先 stop + delete：sc create 在服务已存在时会失败（"服务已存在"），
;    导致旧版服务（如无管道 ACL 的旧版）继续运行，新代码不生效
Filename: "{sys}\sc.exe"; Parameters: "stop KiraraVpnHelper"; Flags: runhidden waituntilterminated skipifdoesntexist
Filename: "{sys}\sc.exe"; Parameters: "delete KiraraVpnHelper"; Flags: runhidden waituntilterminated skipifdoesntexist
Filename: "{sys}\sc.exe"; Parameters: "create KiraraVpnHelper start= auto binPath= ""{app}\KiraraVpnHelper\KiraraVpnHelper.exe"" displayname= ""Kirara VPN Helper"""; StatusMsg: "正在注册 VPN 代理服务..."; Flags: waituntilterminated runhidden
Filename: "{sys}\sc.exe"; Parameters: "description KiraraVpnHelper ""Kirara Server VPN 连接代理服务"""; StatusMsg: "正在配置 VPN 代理服务..."; Flags: waituntilterminated runhidden
Filename: "{sys}\sc.exe"; Parameters: "start KiraraVpnHelper"; StatusMsg: "正在启动 VPN 代理服务..."; Flags: waituntilterminated runhidden
; ⚠️ OpenVPN MSI 安装已从 [Run] 段移除，改由 [Code] 的 RunOpenVpnInstall() 在 ssPostInstall
;    执行（带超时保护 + 超时强制终止），防止 msiexec 挂起（MSI 全局互斥排队 / TAP 驱动安装
;    卡住等）导致整个安装进度无限卡死（waituntilterminated 无超时）
; WebView2 Evergreen（自动检测：已装则跳过）
Filename: "{tmp}\MicrosoftEdgeWebview2Setup.exe"; Parameters: "/silent /install"; StatusMsg: "正在安装 WebView2..."; Flags: waituntilterminated runhidden; Check: Not IsWebView2Installed
; 启动应用
Filename: "{app}\{#MyAppExeName}"; Description: "启动 {#MyAppName}"; Flags: nowait postinstall skipifsilent

[UninstallRun]
; 停止并删除 VPN 代理服务
Filename: "{sys}\sc.exe"; Parameters: "stop KiraraVpnHelper"; Flags: runhidden skipifdoesntexist
Filename: "{sys}\sc.exe"; Parameters: "delete KiraraVpnHelper"; Flags: runhidden skipifdoesntexist
; OpenVPN MSI 卸载：由 [Code] 的 CurUninstallStepChanged 事件处理（uninstall 阶段调用 Exec），
; 因为 [UninstallRun] 中 {code:GetOpenVpnProductCode} 在卸载上下文求值不可靠。
; 仅当本程序自动安装的 OpenVPN（{app}\ThirdAPPs\OpenVPN 目录存在）才连带卸载。

[Code]
// ============================================================
// 自动更新模式（/AUTOUPDATE 参数由客户端自动更新流程传入）
// 向导自动推进（欢迎/选项页自动跳过，安装进度页可见）+ 完成自动关闭安装器并启动应用
// ============================================================
var
  AutoUpdateMode: Boolean;

// ============================================================
// 方案B：自定义向导文字（中文友好文案）
// ============================================================

// ============================================================
// 三方程序存在性检测（已装则跳过安装）
// ============================================================

/// <summary>
/// 检测本程序自动安装的 OpenVPN 是否存在（位于 {app}\ThirdAPPs\OpenVPN）。
/// 用于卸载联动：只有本程序安装的 OpenVPN 才连带卸载，不碰用户自行安装的。
/// </summary>
function IsOwnOpenVpnInstalled(): Boolean;
begin
  // 本程序安装的 OpenVPN 固定装在 {app}\ThirdAPPs\OpenVPN
  Result := DirExists(ExpandConstant('{app}\ThirdAPPs\OpenVPN'));
end;

/// <summary>
/// 检测 OpenVPN 是否已安装。
/// 判定依据：卸载注册表存在 DisplayName 含 "OpenVPN" 的项，或 openvpn.exe 存在于常见路径。
/// </summary>
function IsOpenVpnInstalled(): Boolean;
var
  Hives: array[0..1] of Integer;
  BaseKeys: array[0..1] of String;
  h, b, i: Integer;
  Subkeys: TArrayOfString;
  DisplayName: String;
begin
  Result := False;

  // 1. 检查卸载注册表（DisplayName 含 OpenVPN）
  Hives[0] := HKLM;
  Hives[1] := HKCU;
  BaseKeys[0] := 'Software\Microsoft\Windows\CurrentVersion\Uninstall';
  BaseKeys[1] := 'Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall';
  for h := 0 to 1 do
  begin
    for b := 0 to 1 do
    begin
      if RegGetSubkeyNames(Hives[h], BaseKeys[b], Subkeys) then
      begin
        for i := 0 to GetArrayLength(Subkeys) - 1 do
        begin
          if RegQueryStringValue(Hives[h], BaseKeys[b] + '\' + Subkeys[i], 'DisplayName', DisplayName) then
          begin
            if Pos('OpenVPN', DisplayName) > 0 then
            begin
              Result := True;
              Exit;
            end;
          end;
        end;
      end;
    end;
  end;

  // 2. 检查 openvpn.exe 常见路径（兜底）
  if not Result then
    Result := FileExists(ExpandConstant('{pf}\OpenVPN\bin\openvpn.exe'))
           or FileExists(ExpandConstant('{pf}\OpenVPN Technologies\OpenVPN Client\bin\openvpn.exe'));
end;

/// <summary>
/// 检测 WebView2 Runtime（Evergreen）是否已安装。
/// 判定依据：EdgeUpdate Clients 注册表键存在（WebView2 Runtime GUID）。
/// </summary>
function IsWebView2Installed(): Boolean;
var
  Version: String;
begin
  Result := False;

  // WebView2 Runtime Evergreen GUID：{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}
  // 检查 HKLM（64位）与 WOW6432Node（32位）两个位置
  if RegQueryStringValue(HKLM,
      'SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
      'pv', Version) then
    Result := True;

  if not Result then
    if RegQueryStringValue(HKLM,
        'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
        'pv', Version) then
      Result := True;

  // HKCU（某些环境 WebView2 装在用户级）
  if not Result then
    if RegQueryStringValue(HKCU,
        'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
        'pv', Version) then
      Result := True;
end;

// ============================================================
// 应用进程检测与强制终止（安装/卸载安全）
// ⚠️ 检测对象为主应用 KiraraServerAPP.Core.exe：
//    - 启动器 KiraraServerAPP.exe 是瞬时进程（<1MB，单实例拦截后即退出）
//    - Core 才是长期运行的进程（承载窗口/服务/WebView2）
// ⚠️ [Code] 段内注释必须用 //（; 是语句分隔符，不是注释！）
// ============================================================

const
  // 长期运行的进程是主应用 Core（启动器 KiraraServerAPP.exe 是瞬时的 <1MB 进程）
  AppProcessName = 'KiraraServerAPP.Core.exe';

/// <summary>
/// 检测主应用进程是否正在运行（WMI 查询）。
/// 用于安装/卸载前检查，避免文件占用导致安装失败或卸载不彻底。
/// </summary>
function IsAppRunning(): Boolean;
var
  Locator, Service, ObjectSet: Variant;
begin
  Result := False;
  try
    Locator := CreateOleObject('WbemScripting.SWbemLocator');
    Service := Locator.ConnectServer('localhost', 'root\cimv2');
    ObjectSet := Service.ExecQuery('SELECT ProcessId FROM Win32_Process WHERE Name = ''' + AppProcessName + '''');
    Result := (ObjectSet.Count > 0);
  except
    Result := False;
  end;
end;

/// <summary>
/// 强制终止主应用进程及其子进程树（WebView2 浏览器进程等）。
/// taskkill /F 强制结束；/T 连同子进程树一起结束；/IM 按映像名称匹配。
/// 退出码 0=已终止；128=无匹配进程（应用已退出，视为正常）。
/// </summary>
procedure KillAppProcesses();
var
  ResultCode: Integer;
begin
  Exec('taskkill.exe', '/IM ' + AppProcessName + ' /T /F', '', SW_HIDE,
       ewWaitUntilTerminated, ResultCode);
end;

// ============================================================
// OpenVPN MSI ProductCode（用于卸载联动）
// ============================================================
// 查询已安装的 OpenVPN MSI ProductCode（用于卸载联动）
// 遍历卸载注册表，查找 DisplayName 含 "OpenVPN" 的项，返回其子键名（即 ProductCode）
function GetOpenVpnProductCode(Param: String): String;
var
  Hives: array[0..1] of Integer;
  BaseKeys: array[0..1] of String;
  h, b: Integer;
  Subkeys: TArrayOfString;
  i: Integer;
  DisplayName: String;
begin
  Result := '';
  Hives[0] := HKLM;
  Hives[1] := HKCU;
  BaseKeys[0] := 'Software\Microsoft\Windows\CurrentVersion\Uninstall';
  BaseKeys[1] := 'Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall';
  // 遍历两个注册表根路径（HKLM/HKCU）和两个卸载键路径（32/64 位）
  for h := 0 to 1 do
  begin
    for b := 0 to 1 do
    begin
      if RegGetSubkeyNames(Hives[h], BaseKeys[b], Subkeys) then
      begin
        for i := 0 to GetArrayLength(Subkeys) - 1 do
        begin
          // 读取该子键的 DisplayName
          if RegQueryStringValue(Hives[h], BaseKeys[b] + '\' + Subkeys[i], 'DisplayName', DisplayName) then
          begin
            // DisplayName 含 "OpenVPN" 即命中
            if Pos('OpenVPN', DisplayName) > 0 then
            begin
              Result := Subkeys[i];
              Exit;
            end;
          end;
        end;
      end;
    end;
  end;
end;

/// <summary>
/// OpenVPN MSI 安装超时（秒）。
/// TAP 驱动安装（PnP + 驱动签名验证）在慢机器/安全软件扫描时可能需 2~3 分钟，
/// 300 秒（5 分钟）未完成才视为挂起，超时强制终止不阻塞安装。
/// </summary>
const
  OpenVpnInstallTimeoutSec = 300;

// ============================================================
// msiexec 精确进程检测（按 PID 快照，不误判系统其它 MSI 事务）
// ============================================================

/// <summary>
/// 枚举当前所有 msiexec.exe 进程的 PID（WMI）。
/// 失败时返回空数组（调用方按"无进程"处理）。
/// </summary>
procedure GetMsiPids(var Pids: TArrayOfString);
var
  Locator, Service, ObjectSet, Obj: Variant;
  Count, I: Integer;
begin
  SetArrayLength(Pids, 0);
  try
    Locator := CreateOleObject('WbemScripting.SWbemLocator');
    Service := Locator.ConnectServer('localhost', 'root\cimv2');
    ObjectSet := Service.ExecQuery('SELECT ProcessId FROM Win32_Process WHERE Name = ''msiexec.exe''');
    Count := ObjectSet.Count;
    if Count > 0 then
    begin
      SetArrayLength(Pids, Count);
      for I := 0 to Count - 1 do
      begin
        Obj := ObjectSet.ItemIndex(I);
        // '' + Variant：Pascal Script 强制 Variant → String 转换
        Pids[I] := '' + Obj.ProcessId;
      end;
    end;
  except
    SetArrayLength(Pids, 0);
  end;
end;

/// <summary>
/// 当前是否存在「BasePids 快照之后新启动」的 msiexec 进程。
/// 用于判断本次启动的 MSI 事务是否仍在运行（忽略系统早已存在的其它 MSI 事务）。
/// </summary>
function HasNewMsiProcess(BasePids: TArrayOfString): Boolean;
var
  Current: TArrayOfString;
  I, J: Integer;
  IsNew: Boolean;
begin
  Result := False;
  GetMsiPids(Current);
  for I := 0 to GetArrayLength(Current) - 1 do
  begin
    IsNew := True;
    for J := 0 to GetArrayLength(BasePids) - 1 do
    begin
      if Current[I] = BasePids[J] then
      begin
        IsNew := False;
        Break;
      end;
    end;
    if IsNew then
    begin
      Result := True;
      Exit;
    end;
  end;
end;

/// <summary>
/// 强制终止「BasePids 快照之后新启动」的 msiexec 进程树。
/// 只杀本次启动的 MSI 事务，绝不误伤系统其它 msiexec（Windows Update 等）。
/// </summary>
procedure KillNewMsiProcesses(BasePids: TArrayOfString);
var
  Current: TArrayOfString;
  I, J: Integer;
  IsNew: Boolean;
  ResultCode: Integer;
begin
  GetMsiPids(Current);
  for I := 0 to GetArrayLength(Current) - 1 do
  begin
    IsNew := True;
    for J := 0 to GetArrayLength(BasePids) - 1 do
    begin
      if Current[I] = BasePids[J] then
      begin
        IsNew := False;
        Break;
      end;
    end;
    if IsNew then
    begin
      Log('[msiexec] 终止本次事务进程 PID=' + Current[I]);
      Exec('taskkill.exe', '/F /PID ' + Current[I] + ' /T', '', SW_HIDE,
           ewWaitUntilTerminated, ResultCode);
    end;
  end;
end;

/// <summary>
/// 以超时保护方式执行 msiexec 命令（异步启动 + 轮询进程退出 + 超时强制终止）。
///
/// 为什么不用 ewWaitUntilTerminated：
///   Windows Installer 是全局单事务系统（一次只能执行一个 MSI 事务），且 TAP 驱动
///   安装可能挂起 —— 直接同步等待会在「其它 MSI 事务排队 / 驱动安装卡住」时
///   无限阻塞调用方（整个安装/卸载进度卡死）。
///
/// 本实现：ewNoWait 异步启动 → 按 PID 快照精确轮询本次 msiexec 是否退出
/// （仅跟踪「启动前快照之后新出现的 msiexec」，系统其它 MSI 事务不会导致误判）→
/// 超时后仅 taskkill 本次启动的 msiexec 进程树（极端兜底）→ 返回是否正常结束。
/// </summary>
/// <param name="Params">msiexec.exe 完整参数（含 /i 或 /x 等）</param>
/// <param name="TimeoutSec">超时秒数</param>
/// <returns>true=进程正常退出（安装/卸载完成或已失败返回）；false=超时被强制终止</returns>
function RunMsiexecWithTimeout(Params: String; TimeoutSec: Integer): Boolean;
var
  ResultCode: Integer;
  I: Integer;
  BasePids: TArrayOfString;
begin
  Result := False;

  // 记录启动前的 msiexec PID 快照（排除系统其它 MSI 事务，只跟踪本次安装/卸载）
  GetMsiPids(BasePids);

  // 异步启动 msiexec（不阻塞 UI）
  if not Exec('msiexec.exe', Params, '', SW_HIDE, ewNoWait, ResultCode) then
  begin
    Log('[msiexec] 启动失败: ' + Params);
    Exit;
  end;

  // 先等待本次 msiexec 进程出现（最多 5 秒；防止进程创建延迟被误判为"已完成"）
  for I := 1 to 5 do
  begin
    if HasNewMsiProcess(BasePids) then
      Break;
    Sleep(1000);
  end;

  // 轮询：仅当「本次启动的 msiexec 进程」退出才视为结束；
  // 系统其它 MSI 事务（Windows Update 等）不会导致误判
  for I := 1 to TimeoutSec do
  begin
    if not HasNewMsiProcess(BasePids) then
    begin
      Result := True;  // 本次进程已退出（正常结束）
      Exit;
    end;
    Sleep(1000);
  end;

  // 超时兜底：只强制终止本次启动的 msiexec 进程树（不误伤系统其它 MSI 事务）
  Log('[msiexec] 超时（' + IntToStr(TimeoutSec) + 's），强制终止本次 msiexec 进程树');
  KillNewMsiProcesses(BasePids);
end;

/// <summary>
/// 终止本程序安装的 openvpn.exe 进程（仅匹配命令行含 {app}\ThirdAPPs\OpenVPN 的进程）。
/// 用于卸载前释放 TAP 网卡句柄 —— openvpn.exe 持有 TAP 适配器句柄时，
/// OpenVPN MSI 卸载 TAP 驱动会等待句柄释放 → msiexec 挂起（卸载进度条卡死）。
/// 按命令行路径精准匹配，不误杀用户自行安装的 OpenVPN。
/// </summary>
procedure KillOwnOpenVpnProcesses();
var
  Locator, Service, ObjectSet, Obj: Variant;
  Count, I: Integer;
  CmdLine, AppOvpnPath: String;
  ResultCode: Integer;
begin
  AppOvpnPath := LowerCase(ExpandConstant('{app}\ThirdAPPs\OpenVPN'));
  try
    Locator := CreateOleObject('WbemScripting.SWbemLocator');
    Service := Locator.ConnectServer('localhost', 'root\cimv2');
    ObjectSet := Service.ExecQuery('SELECT ProcessId, CommandLine FROM Win32_Process WHERE Name = ''openvpn.exe''');
    Count := ObjectSet.Count;
    for I := 0 to Count - 1 do
    begin
      Obj := ObjectSet.ItemIndex(I);
      // '' + Variant：Pascal Script 强制 Variant → String 转换（Obj.CommandLine 可能为 null）；
      // 先赋值给 String 变量再 LowerCase（Variant 运算结果仍是 Variant，不能直接作 String 参数）
      CmdLine := '' + Obj.CommandLine;
      CmdLine := LowerCase(CmdLine);
      // 命令行包含本程序安装路径才终止（用户自行安装的 OpenVPN 路径不同，不误杀）
      if Pos(AppOvpnPath, CmdLine) > 0 then
      begin
        Log('[OpenVPN] 终止本程序 openvpn 进程 PID=' + Obj.ProcessId);
        Exec('taskkill.exe', '/F /PID ' + Obj.ProcessId + ' /T', '', SW_HIDE,
             ewWaitUntilTerminated, ResultCode);
      end;
    end;
  except
    // WMI 查询失败时兜底：按映像名终止（卸载场景可接受，用户自行安装的 OpenVPN 概率极低）
    Exec('taskkill.exe', '/F /IM openvpn.exe /T', '', SW_HIDE,
         ewWaitUntilTerminated, ResultCode);
  end;
end;

/// <summary>
/// 卸载流程事件：在卸载阶段（usUninstall）：
/// ① 若应用正在运行 → 强制终止（确保卸载安全：{app} 文件不被占用，卸载彻底）；
/// ② 连带卸载本程序自动安装的 OpenVPN。
/// ⚠️ 仅当 {app}\ThirdAPPs\OpenVPN 目录存在（= 本程序安装的）才卸载，
///    不碰用户自行安装的 OpenVPN。
/// ⚠️ 卸载 OpenVPN MSI 前必须先停止 KiraraVpnHelper 服务并终止 openvpn.exe：
///    [UninstallRun] 的 sc stop 在 usUninstall 事件之后才执行，此时若用户正连着 VPN，
///    openvpn.exe（由服务以 LocalSystem 拉起）仍持有 TAP 网卡句柄，
///    MSI 卸载 TAP 驱动会等待句柄释放 → msiexec 挂起 → 卸载进度条卡死。
/// </summary>
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  ProductCode: String;
  ResultCode: Integer;
begin
  if CurUninstallStep = usUninstall then
  begin
    // [卸载安全] 若应用正在运行，强制终止（含 WebView2 子进程树），
    // 确保 {app} 目录文件可被删除、卸载彻底
    if IsAppRunning() then
      KillAppProcesses();

    // 仅当本程序自动安装的 OpenVPN 存在才连带卸载
    if DirExists(ExpandConstant('{app}\ThirdAPPs\OpenVPN')) then
    begin
      // ⚠️ 必须先停 VPN 代理服务（服务 OnStop 内部会杀 openvpn 子进程树，最多等 3 秒）
      Exec('{sys}\sc.exe', 'stop KiraraVpnHelper', '', SW_HIDE,
           ewWaitUntilTerminated, ResultCode);
      Sleep(500); // 等服务状态完全落定
      // 兜底：精准终止本程序路径下的 openvpn.exe（服务停止可能未杀干净 / 竞态场景）
      KillOwnOpenVpnProcesses();

      ProductCode := GetOpenVpnProductCode('');
      if ProductCode <> '' then
      begin
        // 静默卸载 MSI（/qn），带超时保护（5 分钟），防止 msiexec 挂起导致卸载流程卡死
        // ⚠️ 卸载失败/超时不阻塞主卸载流程（残余由注册表残留容忍，可手动清理）
        RunMsiexecWithTimeout('/x ' + ProductCode + ' /qn /NORESTART', 300);
      end;
    end;
  end;
end;

procedure InitializeWizard();
begin
  // 欢迎页标题与描述
  WizardForm.WelcomeLabel1.Caption := '欢迎安装 {#MyAppName}';
  WizardForm.WelcomeLabel2.Caption := '本向导将安装 {#MyAppName} 及其依赖组件。' + #13#10 +
    '点击"下一步"继续，或点击"取消"退出安装程序。';

  // 完成页标题与描述
  WizardForm.FinishedLabel.Caption := '已完成 {#MyAppName} 的安装。';
  WizardForm.FinishedHeadingLabel.Caption := '安装完成';
end;

/// <summary>
/// 带超时保护的 OpenVPN MSI 安装（替代原 [Run] 段 waituntilterminated 条目）。
///
/// ⚠️ 为什么必须改为带超时：
///   [Run] 段 waituntilterminated 无任何超时机制 —— 以下场景会导致整个安装进度
///   无限卡死（界面停在"正在安装 OpenVPN..."）：
///   ① MSI 全局互斥：Windows Installer 一次只能执行一个事务，若系统有其它 MSI 安装
///      （Windows 更新 / Office / 其它软件）进行中，msiexec 会无限排队等待；
///   ② TAP-Windows6 驱动安装挂起：PnP 服务异常 / 驱动签名验证（CryptSvc）卡住 /
///      安全软件拦截时，驱动安装可能长时间无响应；
///   ③ 静默模式（/qn）无进度反馈，用户无法区分"正常安装中"与"已挂起"。
///
/// 本实现：RunMsiexecWithTimeout 异步启动 → 轮询（1s 间隔）→ 超时（120s = 2 分钟）强制
/// taskkill 终止 msiexec 进程树 → 仅提示用户，不阻塞整个安装
/// （后续 WebView2 安装与应用启动照常进行）。
///
/// ⚠️ 参数说明（实测校准 v0.9.1）：
///   - 安装目录属性是 PRODUCTDIR（WiX 根目录），TARGETDIR 无效
///   - ADDLOCAL 组件名取自 MSI Feature 表：OpenVPN(核心) / OpenVPN.Service / Drivers.TAPWindows6
///   - 不装 OpenVPN.GUI：避免创建桌面/开始菜单快捷方式 + 开机自启（OpenVPN-GUI Run 项）
///   - 不装 Drivers.OvpnDco（DCO 与旧驱动冲突），与文档规划一致
///   - /NORESTART：TAP 驱动安装后可能要求重启，禁止触发（返回 3010 由轮询逻辑吞掉）
/// </summary>
procedure RunOpenVpnInstall();
var
  MsiPath, Params: String;
begin
  MsiPath := ExpandConstant('{tmp}\OpenVPN-2.7.5-I001-amd64.msi');
  if not FileExists(MsiPath) then
  begin
    Log('[OpenVPN] 安装包缺失，跳过安装');
    Exit;
  end;
  if IsOpenVpnInstalled() then
  begin
    Log('[OpenVPN] 检测到已安装（注册表/常见路径），跳过安装');
    Exit;
  end;

  Params := '/i "' + MsiPath + '" /qn /NORESTART PRODUCTDIR="' +
            ExpandConstant('{app}\ThirdAPPs\OpenVPN') +
            '" ADDLOCAL=OpenVPN,OpenVPN.Service,Drivers.TAPWindows6';

  // 更新状态文字，让用户知道正在安装 OpenVPN（而不是无响应）
  WizardForm.StatusLabel.Caption := '正在安装 OpenVPN...';

  if RunMsiexecWithTimeout(Params, OpenVpnInstallTimeoutSec) then
  begin
    Log('[OpenVPN] 安装流程正常结束');
  end
  else
  begin
    // 超时兜底：msiexec 已被强制终止。
    // 若 OpenVPN 实际已注册成功（驱动/服务已装好后才被强杀，常见场景），
    // 视为安装成功，不打扰用户；否则提示可稍后手动重装。
    if GetOpenVpnProductCode('') <> '' then
    begin
      Log('[OpenVPN] msiexec 超时被终止，但 OpenVPN 已注册成功（视为安装成功）');
    end
    else
    begin
      MsgBox('OpenVPN 组件安装超时，已跳过本次安装。' + #13#10 +
             '安装完成后可重新运行安装程序或手动安装 OpenVPN 以使用 VPN 功能。',
             mbInformation, MB_OK);
    end;
  end;
end;

/// <summary>
/// 安装完成后的收尾清理：
/// ① 带超时保护地安装 OpenVPN 组件（见 RunOpenVpnInstall 说明）；
/// ② 删除 OpenVPN-GUI 的开机自启注册表项（HKCU Run）。
/// 本程序安装的 OpenVPN 不含 GUI（ADDLOCAL 已去掉 OpenVPN.GUI），
/// 但若用户之前装过带 GUI 的 OpenVPN 会残留自启项，此处防御性清理。
/// </summary>
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
  begin
    // ① OpenVPN 安装（带超时，原 [Run] 段条目移入此处）
    RunOpenVpnInstall();

    // ② 仅当本程序安装的 OpenVPN 存在时清理（避免误删用户自行安装的 GUI 自启）
    if DirExists(ExpandConstant('{app}\ThirdAPPs\OpenVPN')) then
    begin
      // 删除 HKCU Run 中的 OpenVPN-GUI 自启项
      RegDeleteValue(HKCU, 'Software\Microsoft\Windows\CurrentVersion\Run', 'OpenVPN-GUI');
    end;
  end;
end;

// 卸载时确认提示
// ⚠️ 自动更新流程由 PrepareToInstall 调用卸载器时带 /VERYSILENT /SUPPRESSMSGBOXES：
//    Inno 内置抑制 MsgBox 并返回默认值（IDYES）→ 不弹确认框，卸载自动继续；
//    仅手动运行卸载器时才显示此确认框
function InitializeUninstall(): Boolean;
begin
  Result := MsgBox('确定要卸载 {#MyAppName} 吗？', mbConfirmation, MB_YESNO) = IDYES;
end;

/// <summary>
/// 自动更新模式（/AUTOUPDATE）：向导自动推进——欢迎页 / 目录页 / 任务页 / 程序组页 /
/// 准备安装页自动点击"下一步"，完成页自动点击"完成"（安装器自动关闭，应用已由
/// [Run] postinstall 条目启动）；安装进度页（wpInstalling）不在自动推进列表 →
/// 正常停留显示，用户可见安装过程。
/// 手动安装（无 /AUTOUPDATE）不受影响，完整向导手动操作。
/// </summary>
procedure CurPageChanged(CurPageID: Integer);
begin
  if AutoUpdateMode then
  begin
    case CurPageID of
      wpWelcome, wpSelectDir, wpSelectTasks, wpSelectProgramGroup, wpReady, wpFinished:
        WizardForm.NextButton.OnClick(WizardForm.NextButton);
    end;
  end;
end;

// ============================================================
// 安装前版本检查：相同版本跳过 / 升级前先卸载
// ============================================================

/// <summary>自定义注册表键（稳定位置，不依赖 Inno 卸载键的 _is1 后缀）</summary>
const
  AppRegKey = 'Software\Kirara Server APP';

/// <summary>
/// 读取已安装版本号。
/// 优先级：① 自定义键 Software\Kirara Server APP\Version → ② Inno 卸载注册表 DisplayVersion（兼容旧版）。
/// 返回空串表示未安装。
/// </summary>
function GetInstalledVersion(): String;
var
  Version: String;
begin
  Result := '';

  // 1. 自定义注册表键（稳定，本脚本 [Registry] 段写入）
  if RegQueryStringValue(HKLM, AppRegKey, 'Version', Version) then
  begin
    Result := Version;
    Exit;
  end;

  // 2. 回退：Inno 卸载注册表 DisplayVersion（兼容旧版安装）
  if RegQueryStringValue(HKLM,
      'Software\Microsoft\Windows\CurrentVersion\Uninstall\{732B89C8-2A4B-4C89-9FD1-CADE0CD793B7}_is1',
      'DisplayVersion', Version) then
    Result := Version;
end;

/// <summary>
/// 数字分段比较版本号（"a.b.c"）：返回 1=左边大 / 0=相等 / -1=左边小。
/// 避免字符串比较 "0.9.10" &lt; "0.9.9" 的错误。
/// </summary>
function CompareVersions(V1, V2: String): Integer;
var
  P1, P2: Integer;
  S1, S2: String;
  N1, N2: Integer;
begin
  Result := 0;
  while (V1 <> '') or (V2 <> '') do
  begin
    P1 := Pos('.', V1);
    P2 := Pos('.', V2);
    if P1 = 0 then P1 := Length(V1) + 1;
    if P2 = 0 then P2 := Length(V2) + 1;
    S1 := Copy(V1, 1, P1 - 1);
    S2 := Copy(V2, 1, P2 - 1);
    if S1 = '' then N1 := 0 else N1 := StrToIntDef(S1, 0);
    if S2 = '' then N2 := 0 else N2 := StrToIntDef(S2, 0);
    if N1 > N2 then begin Result := 1; Exit; end;
    if N1 < N2 then begin Result := -1; Exit; end;
    Delete(V1, 1, P1);
    Delete(V2, 1, P2);
  end;
end;

/// <summary>
/// 安装器启动最早点（提权前执行）——版本比对与跳过逻辑。
/// 相同版本 → 提示并中止（不重复安装）；已装版本更新 → 警告降级；旧版本 → 放行（PrepareToInstall 先卸载）。
/// ⚠️ 自动更新模式（/AUTOUPDATE）：版本判断结果直接决定继续/中止，不弹框打断自动流程
/// （客户端已预先校验版本更高，相同/降级场景理论不会发生）。
/// </summary>
function InitializeSetup(): Boolean;
var
  InstalledVersion: String;
  I: Integer;
begin
  Result := True;

  // 自动更新模式标记：客户端自动更新流程以 /AUTOUPDATE 参数拉起安装器
  // ⚠️ 用 ParamStr 遍历检测（Inno 会移除其认识的参数，保留 /AUTOUPDATE 这类自定义参数）
  AutoUpdateMode := False;
  for I := 1 to ParamCount do
  begin
    if CompareText(ParamStr(I), '/AUTOUPDATE') = 0 then
    begin
      AutoUpdateMode := True;
      Break;
    end;
  end;

  InstalledVersion := GetInstalledVersion();
  if InstalledVersion = '' then
    Exit;  // 未安装，正常继续

  // 相同版本：跳过安装，不重复安装（自动更新模式静默退出，不弹框）
  if InstalledVersion = '{#MyAppVersion}' then
  begin
    if not AutoUpdateMode then
      MsgBox('检测到 {#MyAppName} v' + InstalledVersion + ' 已安装，无需重复安装。' + #13#10 +
             '安装程序即将退出。', mbInformation, MB_OK);
    Result := False;
    Exit;
  end;

  // 已装版本比安装包更新：警告降级（用户确认才继续；自动更新模式客户端已校验版本更高，直接放行）
  if CompareVersions(InstalledVersion, '{#MyAppVersion}') > 0 then
  begin
    if not AutoUpdateMode then
    begin
      if MsgBox('检测到 {#MyAppName} v' + InstalledVersion + ' 已安装（比本安装包 v{#MyAppVersion} 更新）。' + #13#10 +
                '继续安装将降级软件，确定要继续吗？', mbConfirmation, MB_YESNO) <> IDYES then
      begin
        Result := False;
        Exit;
      end;
    end;
  end;

  // 已装旧版本 → 放行，由 PrepareToInstall 先执行卸载再安装
end;

/// <summary>
/// 安装开始前（提权后）：
/// ① [安装安全] 若应用正在运行 → 强制终止（确保 {app} 文件可覆盖，升级/安装安全）；
/// ② 升级场景先静默执行旧版卸载（含移除注册表），再继续安装。
/// 返回非空字符串将中止安装并显示该错误。
/// </summary>
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  UninstallString: String;
  UninstallExe: String;
  ResultCode: Integer;
  InstalledVersion: String;
begin
  Result := '';

  // [安装安全] 若应用正在运行，强制终止（含 WebView2 子进程树），
  // 避免 {app} 目录文件被占用导致安装/覆盖失败
  if IsAppRunning() then
    KillAppProcesses();

  InstalledVersion := GetInstalledVersion();
  if InstalledVersion = '' then
    Exit;  // 未安装，无需卸载

  // 仅旧版本升级需要先卸载（相同版本已在 InitializeSetup 拦截；降级场景直接覆盖）
  if CompareVersions(InstalledVersion, '{#MyAppVersion}') >= 0 then
    Exit;

  // 读取卸载程序路径（Inno 卸载注册表 UninstallString，形如 "C:\...\unins000.exe"）
  if not RegQueryStringValue(HKLM,
      'Software\Microsoft\Windows\CurrentVersion\Uninstall\{732B89C8-2A4B-4C89-9FD1-CADE0CD793B7}_is1',
      'UninstallString', UninstallString) then
    Exit;

  // 解析引号包裹的可执行文件路径（兼容 "exe" 带参形式，只取引号内部分）
  UninstallExe := UninstallString;
  if Copy(UninstallExe, 1, 1) = '"' then
  begin
    Delete(UninstallExe, 1, 1);
    UninstallExe := Copy(UninstallExe, 1, Pos('"', UninstallExe) - 1);
  end;

  if FileExists(UninstallExe) then
  begin
    // 静默执行旧版卸载：删除 {app} 文件 + 卸载注册表 + 自定义注册表 + VPN 服务 + OpenVPN 联动
    // /VERYSILENT 隐含 /SUPPRESSMSGBOXES → InitializeUninstall 的确认框自动跳过
    if Exec(UninstallExe, '/VERYSILENT /SUPPRESSMSGBOXES /NORESTART', '',
            SW_HIDE, ewWaitUntilTerminated, ResultCode) then
    begin
      if ResultCode <> 0 then
        Result := '旧版本卸载未正常完成（错误码 ' + IntToStr(ResultCode) + '），安装已中止。';
    end
    else
      Result := '无法启动旧版本卸载程序，安装已中止。';
  end;
end;