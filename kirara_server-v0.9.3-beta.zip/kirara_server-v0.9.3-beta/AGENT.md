---

# AGENTS.md — Kirara_Server 项目 AI 代理指令文件

---

## 一、项目概览

**Kirara_Server** 是一款基于 **WinUI 3 + .NET 10** 的 Windows 桌面应用程序。用户通过 **创建实例 → 选择方案 → 链接令牌** 的方式使用和管理内置的多种服务（媒体、直播、云存储、邮件、虚拟化、远程桌面等），实现"一次配置，多服务直达"。

- 代码完成度：约 **95%**（基础架构层完整，UI 交互层基本完成；Phase 1-3 首页功能已全部实现，含全屏背景板、通知中心、快速开始向导；**登录认证系统已完整实现**，含登录/注册/自动登录/忙状态遮罩/表单动画/全局遮罩覆盖标题栏；**账号设置系统已完整实现**，含头像上传/用户名修改/密码修改/名片信息/三方绑定桩；**远程 API 接入**：远程登录认证（JWT+RefreshToken）和远程模板获取已实现；**实例/令牌管理系统**已完整实现；**设置页面**已实现；**方案图标缓存**已实现；**方案页全局缓存**已实现；**导入导出**已实现；**第三方方案扫描器桩**已就绪；**信息流卡片**✅已在首页通知中心以WebView2单卡片+左右切换形式实现）
- 项目路径：`Kirara_Server-WinUI/`
- 主解决方案：`Kirara_Server-WinUI.slnx`
- 目标框架：`net10.0-windows10.0.19041.0`

### 服务器通信现状

> **服务端状态**：Kirara_Server-API（ASP.NET Core 10）**全部 API 已实现**（认证/评论/通知/模板/方案URL/资源/信息流卡片/管理功能），详见 `docs/服务端后端系统技术栈.md`。
> **客户端接入**：以下功能客户端当前为本地模式，通过创建 `Remote*Service` + DI 替换注册即可接入。

| 功能 | 客户端状态 | 服务端 API | 关键代码位置 |
|------|-----------|-----------|-------------|
| 首页背景图片 | ✅ HTTP 下载已实现 | ✅ `GET /api/resources/home-background` | `BackgroundService.cs` |
| 用户头像 | ✅ HTTP 下载+上传已实现 | ✅ `PUT/GET /api/resources/user-avatar` | `UserAvatarService.cs` |
| 账号认证 | ✅ **远程认证已实现**（JWT+RefreshToken） | ✅ `POST /api/auth/*` (BCrypt+JWT) | `RemoteLoginService.cs` |
| 消息推送 (Push) | 🔴 轮询未实现 | ✅ SignalR Hub + REST API | `INotificationService.cs` |
| 实例模板 | ✅ **远程模板已实现**（含封面图缓存） | ✅ `GET /api/templates` (含封面图) | `RemoteQuickStartService.cs` |
| 议题评论 | 🔴 本地 LiteDB，桩已预留 | ✅ `/* /api/comments/*` (含回复/点赞) | `CommentService.cs` |
| 方案 URL 同步 | ✅ **增量同步已实现**（POST /api/scheme-urls/sync） | ✅ `POST /api/scheme-urls/sync` (增量同步) | `ServerUrlService.SyncFromServerAsync()` |
| 方案图标缓存 | ✅ **HTTP 下载+加密缓存已实现**（方案A加密合并） | ✅ `GET /api/scheme-urls/{key}/image` | `SchemeIconCacheService.cs` |
| OpenVPN 配置 | ✅ **已接入**（版本比对+预签名URL下载+方案A加密缓存） | ✅ `GET/PUT/DELETE /api/openvpn` | `OvpnConfigCacheService.cs` / `VpnConnectionService.cs` |
| 信息流卡片 | ✅ **信息流页面已实现**（首页通知中心 FlipView 轮播，方案B媒体缓存） | ✅ `GET /api/info-cards`, `/sync` | `MainPage.xaml` / `NotificationCenterViewModel` |
| 管理功能 | 🔴 未接入 | ✅ `/api/admin/*` (用户/URL/通知/模板) | — |

> **关键文档**: 客户端 `docs/技术栈文档.md` | 服务端 `docs/服务端后端系统技术栈.md` | API 完整文档 `docs/Kirara Server API 完整文档.md`

---

## 二、技术栈

| 层级 | 技术 | 版本 |
|------|------|------|
| UI 框架 | WinUI 3 (Windows App SDK) | 2.3.1 |
| 目标框架 | .NET 10 | `net10.0-windows10.0.19041.0` |
| 语言 | C# 13 | 全项目统一 |
| MVVM 工具包 | CommunityToolkit.Mvvm | 8.4.0 |
| DI 容器 | Microsoft.Extensions.DependencyInjection + Hosting | 10.* |
| 嵌入式数据库 | LiteDB | 5.* |
| 加密 | DPAPI + AES-256-GCM | `System.Security.Cryptography` |
| XAML 样式 | Fluent 2 Design Language | 自定义 ResourceDictionary `AppStyles.xaml` |
| HTTP 客户端 | System.Net.Http.HttpClient | 内置，用于背景图片下载与头像上传（推送轮询待接入） |
| JSON 序列化 | System.Text.Json | 内置，用于推送通知解析与数据导入导出 |
| 打包分发 | MSIX (可选) / Unpackaged | — |

> **服务端现状**: 后端 **Kirara_Server-API**（ASP.NET Core 10 + PostgreSQL + Redis + MinIO + SignalR）**全部 API 已实现**，详见 `docs/服务端后端系统技术栈.md`。客户端通过实现已有接口的远程版（如 `RemoteCommentService : ICommentService`）接入，DI 替换注册即可，无需改动 ViewModel/UI 层。

---

## 三、项目结构

```
Kirara_Server-WinUI/
├── App.xaml(.cs)              # 应用入口 + DI 容器 + 全局异常捕获
├── MainWindow.xaml(.cs)       # 主窗口
├── Contracts/                 # 接口定义 (IScheme, IAutoLoginProvider 等)
├── Models/                    # 数据模型 (Instance, Scheme, Token, CommentItem 等)
├── Data/                      # 数据访问层 (LiteDB Repository)
├── Services/                  # 业务逻辑层 (20 个接口+实现，共 41 个文件)
│   ├── AuthModels.cs         # 🆕API 统一响应模型 + 认证 DTO
│   ├── SecureCacheService.cs # 🆕安全缓存服务（方案A加密合并/方案B加密meta，防篡改）
│   ├── RemoteLoginService.cs # 🆕远程登录认证（JWT+RefreshToken，已接入服务端 API）
│   ├── RemoteQuickStartService.cs # 🆕远程模板获取（HTTP + 封面图加密缓存）
│   ├── SchemeIconCacheService.cs  # 🆕方案图标缓存（HTTP + 加密缓存）
│   ├── LoggingService.cs     # 日志服务（环形缓冲区+TraceListener重定向）
│   ├── NotificationService.cs# 通知服务（全局总线，Push/Service/Log三类别）
│   ├── NotificationWiringHelper.cs # 🆕通知源连接器
│   ├── BackgroundService.cs  # 背景图片管理（缓存/下载/服务器同步/降级）
│   ├── PermissionService.cs  # 权限管理（管理员/用户组权限控制）
│   ├── UserAvatarService.cs  # 头像管理服务（缓存/下载/上传/居中裁剪70×70）
│   ├── ExportImportService.cs# 🆕导入导出服务（实例/令牌 JSON 导入导出）
│   ├── SchemePageCache.cs    # 🆕方案宿主页全局缓存管理器
│   ├── AutoLoginService.cs   # 🆕自动登录编排服务
│   ├── NavigationService.cs  # 🆕导航服务
│   ├── TokenService.cs       # 🆕令牌管理服务
│   ├── InstanceService.cs    # 🆕实例管理服务
│   ├── SchemeService.cs      # 🆕方案管理服务
│   ├── ServerUrlService.cs   # 🆕服务器 URL 管理服务
│   ├── CommentService.cs     # 🆕评论服务
│   ├── CommentPanelService.cs# 🆕评论面板服务
│   ├── InfoCardService.cs    # 🆕信息流卡片服务（包装远程拉取 + 本地缓存）
│   ├── DialogService.cs      # 🆕对话框服务
│   └── CryptoService.cs      # 🆕加密服务（DPAPI + AES-256-GCM）
├── Schemes/                   # 方案插件实现
│   ├── BaseScheme.cs          # IScheme 基类
│   ├── BuiltIn/               # 用户实例方案 (Media, OpenVPN, Alist, Note, Moment 等 11 个)
│   ├── Service/               # 服务实例方案 (AppServer, ESXi, IMM, OpenVPN, BitComet 等 14 个)
│   └── ThirdParty/            # 第三方方案扫描器桩
├── ViewModels/                # ViewModel 层 (17 个文件)
│   ├── MainWindowViewModel.cs               # 主窗口 VM（全局状态）
│   ├── Pages/
│   │   ├── MainPageViewModel.cs             # 首页 VM（登录状态/模板/通知概览/问候语定时刷新）
│   │   ├── LoginPageViewModel.cs            # 登录页 VM（登录/注册/密码强度/实时校验/自动登录）
│   │   ├── QuickStartWizardViewModel.cs     # 快速开始向导 VM
│   │   ├── AccountSettingsViewModel.cs      # 账号设置 VM（头像/用户名/密码/三方绑定桩）
│   │   ├── SettingsViewModel.cs             # 🆕设置页面 VM（主题切换/导入导出）
│   │   ├── TokenEditorViewModel.cs          # 🆕令牌编辑器 VM（三步向导）
│   │   ├── TokenManagerViewModel.cs         # 🆕令牌管理器 VM（列表/搜索/导入导出）
│   │   └── InstanceEditorViewModel.cs       # 🆕实例编辑器 VM（四步向导）
│   ├── Controls/
│   │   ├── NotificationCenterViewModel.cs   # 通知中心 VM（三标签页+实时订阅）
│   │   ├── LeftFunctionBarViewModel.cs      # 🆕左侧功能栏 VM
│   │   ├── InstanceCardViewModel.cs         # 🆕实例卡片 VM
│   │   ├── NotificationBadgeViewModel.cs    # 🆕通知徽章 VM
│   │   ├── SchemeTabBarViewModel.cs         # 🆕方案标签栏 VM
│   │   └── StatusBarViewModel.cs            # 🆕状态栏 VM
│   ├── Comment/
│   │   ├── CommentItemViewModel.cs          # 🆕评论项 VM
│   │   ├── CommentWindowViewModel.cs        # 🆕评论窗口 VM
│   │   └── ReplyItemViewModel.cs            # 🆕回复项 VM
│   └── Instance/
│       ├── InstanceWorkspaceViewModel.cs    # 🆕实例工作区 VM
│       └── SchemeHostViewModel.cs           # 🆕方案宿主 VM
├── Views/                     # XAML 视图层 (28 个文件，全部完整)
│   ├── ShellPage.xaml(.cs)                 # 主框架（标题栏/功能栏/内容区/全局遮罩）
│   ├── Pages/
│   │   ├── MainPage.xaml(.cs)              # 首页（登录面板/快速开始/通知中心三标签页动画+账号设置面板叠加）
│   │   ├── LoginPage.xaml(.cs)             # 登录页（登录/注册表单切换动画+密码强度+自动登录）
│   │   ├── QuickStartWizardPage.xaml(.cs)  # 快速开始向导页
│   │   ├── SettingsPage.xaml(.cs)          # 🆕设置页面（主题切换/导入导出）
│   │   ├── TokenEditorPage.xaml(.cs)       # 🆕令牌编辑器页（三步向导）
│   │   ├── TokenManagerPage.xaml(.cs)      # 🆕令牌管理器页（列表/搜索/导入导出）
│   │   ├── InstanceEditorPage.xaml(.cs)    # 🆕实例编辑器页（四步向导）
│   │   └── InstanceSummaryPage.xaml(.cs)   # 🆕实例概览页
│   ├── Controls/
│   │   ├── LeftFunctionBar.xaml(.cs)       # 🆕左侧功能栏
│   │   ├── TopTitleBar.xaml(.cs)           # 🆕自定义标题栏
│   │   ├── InstanceCard.xaml(.cs)          # 🆕实例卡片
│   │   ├── NotificationBadge.xaml(.cs)     # 🆕通知徽章
│   │   ├── SchemeTabBar.xaml(.cs)          # 🆕方案标签栏
│   │   └── StatusBar.xaml(.cs)             # 🆕状态栏
│   ├── Comment/
│   │   ├── CommentPanel.xaml(.cs)          # 🆕评论面板
│   │   └── CommentWindow.xaml(.cs)         # 🆕评论窗口
│   └── Instance/
│       ├── InstanceWorkspace.xaml(.cs)     # 🆕实例工作区
│       └── SchemeHostPage.xaml(.cs)        # 🆕方案宿主页（WebView2/RDP 容器）
├── Converters/                # XAML 值转换器 (22 个)
├── Helpers/                   # 工具类 (BindingProxy, ThemeHelper, HtmlContentHelper, ResourceKeyBuilder, ScreenAdaptation 等 8 个)
├── Styles/                    # Fluent2 样式资源字典 AppStyles.xaml
├── Assets/                    # MSIX 图标/启动画面资源
├── docs/                      # 📘 项目文档（开发前必读）
│   ├── 技术栈文档.md           # 客户端完整架构与技术栈
│   ├── 服务端后端系统技术栈.md   # 服务端搭建规划（API/数据库/部署）
│   ├── 需求文档.md
│   ├── 首页开发计划.md
│   └── Kirara Server API 完整文档.md
└── .github/
    └── copilot-instructions.md # 本文件
```

**⚠️ 重要目录约束：**
- **`Contracts/`、`Models/`、`Data/`、`Services/`** — 基础架构层，非必要勿改动，新增全新的功能可以增加，但是请仔细阅读docs/下的技术栈文件再开发
- **`Schemes/`** — 方案业务逻辑层，**仍可扩展**（如补充 IAutoLoginProvider 实现）
- **`Views/`** — UI 交互层，**28/28 个文件已完成**，新增视图遵循现有布局模式
- **`ViewModels/`** — 逻辑层，新增功能须先在此层添加 VM

---

## 四、构建与运行

```bash
# Debug (Unpackaged 模式 — 推荐开发调试)
dotnet build -c Debug

# Release (MSIX 打包发布)
dotnet publish -c Release -p:Platform=x64

# Visual Studio 启动配置:
# "Kirara_Server-WinUI (Package)"      — MSIX 打包运行
# "Kirara_Server-WinUI (Unpackaged)"   — 直接运行 (推荐调试)
```

**注意事项：**
- TFM 为 `net10.0-windows10.0.19041.0`，需要 .NET 10 SDK + Windows App SDK 运行时
- WebView2 的 `EnsureCoreWebView2Async()` **必须在 UI 线程调用**
- WinUI3 的 PasswordBox **不支持直接绑定 MVVM**，需通过 code-behind 中转

---

## 五、架构约束与设计原则

### 5.1 MVVM + DI 架构
- 所有依赖通过 DI 容器管理生命周期（Singleton / Transient）
- ViewModel 使用 `[ObservableProperty]` 和 `[RelayCommand]` 特性
- Repository 为 Singleton，Service 为 Singleton，ViewModel 按作用域选择
- **禁止**在 View 中直接操作业务逻辑；所有业务逻辑应委托给 Service

### 5.2 数据层规范
- 数据库路径：`%APPDATA%/Kirara/data.db`（LiteDB 单文件）
- 集合清单：`instances`、`schemes`、`tokens`、`server_urls`、`users`、`comments`
- 种子数据写入 `AppDatabase.SeedBuiltInSchemes()`，启动同步在 `SchemeService.SyncBuiltInSchemas()`
- 所有新集合须在 `AppDatabase.cs` 中注册索引

### 5.3 加密规范
- 令牌敏感字段（AccountName, AccountPassword, ApiKey, ServerUrl）**必须** AES-256-GCM 加密存储
- 加密前缀格式：`"KIRARA_ENC:" + Base64(密文)`
- AES 密钥由 DPAPI（`DataProtectionScope.CurrentUser`）保护，存于 `%APPDATA%/Kirara/.key`
- **服务器资源缓存必须经 `SecureCacheService` 加密存储（v1.7+）**：
  - 方案A（小文件）：头像/背景图/模板封面/方案图标/.ovpn/模板列表 JSON → 内容+ETag 合并加密单文件 `.enc`
  - 方案B（大媒体）：信息流图片/视频/HTML → 内容明文 + 加密 meta（SHA256 校验防篡改）
  - **禁止**再新增明文缓存 + 独立 meta 文件的方式（旧格式解密失败自动重下，无需迁移）
  - 解密后的临时明文统一放 `%APPDATA%/Kirara/tmp/`（启动时 `CleanupTempDirectory()` 清理）
  - 新增缓存服务后运行自测：`dotnet run --project tools/SecureCacheSelfTest -c Debug -p:Platform=x64`

### 5.4 方案插件系统
- 所有方案必须实现 `IScheme` 接口（位于 `Contracts/IScheme.cs`）
- 新方案建议继承 `BaseScheme`（提供虚默认实现）
- 5 种 UI 呈现方式按需选择：`CustomControl` / `WebView2` / `RDP` / `ExternalProcess` / `Overlay`
- `DefaultUrlKey` 默认返回方案 `Name`，由 `BaseScheme` 自动处理，无需在每个方案中显式重写
- 无需 URL 的方案（OpenVpn / Topic / GameServer）需显式重写 `DefaultUrlKey => null`

### 5.5 自动登录系统（IAutoLoginProvider）
- 已实现三层架构：`IAutoLoginService`（编排层）→ `SchemeHostViewModel`（状态管理层）→ `SchemeHostPage`（UI 渲染层）
- 新增 WebView2 方案的自动登录适配时，**实现 `IAutoLoginProvider`** 接口即可，共 11 个可配置项
- 使用 `DeferToWorkspace` + `PostLoginDelayMs` 处理极慢页面（如 IMM 需 20s 缓冲）

### 5.6 登录认证系统
- **ILoginService/LoginService**：基于本地数据库（SHA256+盐）的登录认证，支持登录/注册/自动登录
- **自动登录**：通过 `UserAccount.AutoLoginEnabled` 标记持久化，`TryAutoLoginAsync()` 从默认令牌读取加密凭据自动登录
- **忙状态遮罩**：全局 `GlobalBusyOverlay`（`ShellPage` 最顶层，覆盖标题栏），登录/注册操作中自动显示，最低 1s 显示时间
- **表单切换动画**：登录/注册表单通过 Grid 叠加实现交叉淡入淡出（卡片微缩 280ms → 弹性恢复 420ms），字段重置在旧表单隐藏后执行
- **PasswordBox 处理**：不支持直接 MVVM 绑定，需通过 `PasswordChanged` 事件 + code-behind 中转
- **退出登录抑制**：`_isLoggingOut` 标记防止导航回登录页时触发自动登录重入

### 5.7 通知与日志系统
- **INotificationService/NotificationService**：全局通知总线，支持 Push/Service/Log 三类别，每类别环形缓冲区 500 条
- **ILoggingService/LoggingService**：环形缓冲区日志（2000 条），通过 `ObservableTraceListener` 捕获 `Debug.WriteLine` 输出
- **通知源**（已通过 `NotificationWiringHelper` 接入）：`App.UnhandledException`（Error）、`IDialogService`（Info/Error）、`ILoggingService` Warning+ 级别
- Push 类别数据模型（`HtmlContent` 字段）和 UI 渲染已就绪，**客户端轮询拉取尚未实现**（服务端 SignalR Hub + REST API ✅ 已实现）

### 5.8 首页背景系统
- **IBackgroundService/BackgroundService**：本地加密缓存（方案A）→ 远程下载 → 降级内置默认图片
- 缓存路径：`%APPDATA%/Kirara/backgrounds/background_cache.enc`（ETag 内嵌加密信封，旧 jpg/txt 启动自动清理）
- 解密临时明文：`%APPDATA%/Kirara/tmp/background_cache.jpg`（UI 按路径加载）
- URL 注册表 Key：`home_background`（通过 `IServerUrlService` 管理）
- ShellPage 监听 `BackgroundChanged` 事件自动更新 `Image.Source`

### 5.9 ShellPage 层级结构
```
ShellPage Grid（从底到顶）:
├── [1] HomeBackgroundImage       — 首页全屏背景图片
├── [2] HomeOverlay (Rectangle)   — 抽屉动画暗色遮罩
├── [3] TopTitleBar               — 自定义标题栏
├── [4] LeftFunctionBar            — 左侧功能栏
├── [5] ContentFrame               — 页面导航（LoginPage / MainPage 等）
└── [6] GlobalBusyOverlay (Grid)  — 全局忙状态遮罩（覆盖标题栏）
```

### 5.10 账号设置系统
- **AccountSettingsViewModel**：由 MainPage 持有，管理头像/用户名/密码/三方绑定
- **头像资源链**（与 BackgroundService 一致）：本地缓存 → 服务器下载 → Glyph 降级
- **头像上传**：FileOpenPicker → 居中裁剪 70×70（BitmapTransform）→ 本地缓存 → 服务器上传
- **用户名修改**：校验规则与登录页注册一致（非法字符/长度/重复/新旧相同检测）
- **密码修改**：强度评估与登录页一致 + 当前密码验证 + 新旧密码相同检测
- **结果通知**：通过 `OnResultNotification` 事件 → MainPage 弹出 Flyout（锚定在触发按钮旁）
- **表单重置**：离开设置面板时调用 `ResetFormFields()` + PasswordBox code-behind 清空
- **设置面板动画**：打开时主页退场 → 面板从右侧滑入；关闭时面板滑出 → 主页入场
- **侧栏导航切出**：先关闭设置面板（跳过主页入场动画）→ 直接背景淡出 → 导航

---

## 六、编码规范

### 6.1 C# 代码规范
- 使用 C# 13 语法，全项目统一文件范围命名空间
- 文件名与类名一致（PascalCase）
- **禁止**使用 `var` 替代内置类型（如 `int`、`string`、`bool`）
- **禁止**引入新的第三方 NuGet 依赖；如有需要须先说明理由

### 6.2 XAML 规范
- 所有新建控件使用 `AppStyles.xaml` 中定义的样式键（`CardStyle`、`AcrylicPanelStyle`、`PrimaryButtonStyle`）
- 颜色引用使用 `ThemeResource` 实现深色/浅色自适应，**禁止**硬编码颜色值
- 自定义标题栏的 `ExtendsContentIntoTitleBar = true` 模式不要改动

### 6.3 注释与文档
- 所有公开接口方法须有 XML 文档注释
- 敏感/复杂逻辑须添加行内注释说明意图
- 方案的 `IAutoLoginProvider` 实现须标注适配的登录步骤和 DOM 选择器

---

## 七、边界约束与安全规则

### ❌ 禁止操作
1. **禁止**修改 `%APPDATA%/Kirara/` 下的数据库和密钥文件
2. **禁止**在未说明的情况下改变既定目录结构和架构分层
3. **禁止**在 `Schemes/` 之外新建功能目录（如把业务逻辑放到 `Helpers/`）
4. **禁止**在不通知的情况下删除或重命名已有 Repository 接口方法
5. **禁止**在非 UI 线程调用 WebView2 操作（`EnsureCoreWebView2Async` 等）

### ⚠️ 高敏感操作（需二次确认）
- 改动 DI 容器注册策略（Singleton ↔ Transient 变更）
- 修改 LiteDB 集合索引或数据模型字段定义
- 变更加密/解密流程（`CryptoService`）
- 删文件、改 Git 配置、改 CI/CD

### ✅ 安全第一原则
> **安全性 = 正确性 > 最小变更 > 可读性 > 一致性**[^23]

遇到阻塞点（动机不清、前置假设不成立、信息不足、方案存在冲突点）时，**立即停下报告，不要凭猜测继续推进**。

---

## 八、常见开发任务

### 8.1 新建一个 WebView2 方案
```
1. 在 Schemes/BuiltIn/ 或 Schemes/Service/ 下新建 XxxScheme.cs
2. 继承 BaseScheme，设置 Name / DisplayName / UIKind = WebView2 / IconGlyph + 指定唯一的 Guid Id
3. 如果该页面需要自动登录，实现 IAutoLoginProvider 接口
4. 确保 URL 注册表中有对应 Key（或让用户通过 ServerUrlService 注册）
5. 在 SchemeService.cs 的 BuiltInSchemeMap 中添加 Guid → Type 映射
   （SeedBuiltInSchemes() 通过反射自动扫描 BaseScheme 子类，无需手动修改）
6. 构建测试: dotnet build -c Debug
```

### 8.2 为已有方案添加自动登录
```
1. 在方案类上实现 IAutoLoginProvider 接口
2. 设置 PageReadyDomSelector（SPA 就绪选择器）
3. 实现 GetPreLoginScript / GetAutoLoginScript
4. 设置 LoginSuccessDomSelector 和 LoginPageUrlFragment
5. 如果页面加载慢，使用 DeferToWorkspace + PostLoginDelayMs
```

### 8.3 首页开发（Phase 1-3）
首页功能已全部实现，参照 `docs/` 目录下的技术栈文档和首页开发计划：
- **Phase 1**：核心骨架（LoggingService + NotificationService + ShellPage 背景层）✅已实现
- **Phase 2**：功能填充（QuickStartWizardPage + NotificationCenter + BackgroundService）✅已实现
- **Phase 3**：增强完善（登录面板 ✅ + HTML 推送 🔴客户端待接入，服务端 ✅已实现 + 方案 URL 服务器同步 ✅已实现）

**复用原则**：优先复用 `InstanceEditorViewModel.SchemeTokenBinding`、`IQuickStartService`、`IInstanceService` 等现有组件，而不是重新造轮子。

### 8.4 首页/登录页面 UI 动画
- **首页入场动画**：三个一级容器按序（登录面板 → 快速开始 → 通知中心）逐个淡入 + 微上浮（Y: 20→0 + BackEase），通知中心带缩放弹出效果（Scale: 0.85→1.0）
- **通知中心标签切换**：Pivot 标签切换带动画（旧面板淡出+滑出 → 新面板从反方向滑入+淡入，300ms CircleEase）
- **登录表单切换**：登录/注册表单通过 Grid 叠加 + 交叉淡入淡出 + 卡片弹性缩放（280ms 收缩 → 420ms 弹性恢复）
- **登录→首页过渡**：登录成功 → 忙状态遮罩消失 → 卡片退出动画 → 暗色遮罩抽屉式拉入 → 导航到首页（900ms QuinticEase）
- **退出登录过渡**：左侧栏淡出 + 首页退出动画 → 暗色遮罩抽屉式拉出 → 导航到登录页

### 8.5 登录页面开发注意事项
- 登录成功后 `IsBusy` 保持 `true`（遮罩保持显示），由 ShellPage 的 `LoginStateChanged` 回调处理后续动画
- 字段重置必须在表单切换动画的淡出完成后调用（`CompleteFormSwitch()`），防止子控件绑定提前消失
- 自动登录时跳过入场动画（`LoginCard.Opacity = 0`），防止卡片穿过遮罩层闪现
- 退出登录时通过 `_isLoggingOut` + `SuppressAutoLogin` 双重抑制，防止导航回登录页后触发自动登录重入

### 8.6 接入服务端 API（通用流程）
```
1. 阅读 docs/服务端后端系统技术栈.md 了解目标 API 端点
2. 在 Services/ 下新建 RemoteXxxService.cs，实现已有 I*Service 接口
3. 内部使用 HttpClient 调用 REST API，System.Text.Json 序列化/反序列化
4. 在 App.xaml.cs 的 ConfigureServices() 中替换 DI 注册:
   services.AddSingleton<ICommentService, RemoteCommentService>();  // 替换 CommentService
5. 构建测试: dotnet build -c Debug
```
**注意**：不需要新建接口，不需要改动 ViewModel 或 XAML 文件。

### 8.7 服务端项目（已全部实现）
> **服务端 Kirara_Server-API 已全部实现**，详见 `docs/服务端后端系统技术栈.md`。包含：
> - Auth / Comments / Notifications / Templates / SchemeUrls / Resources / InfoCards / Admin 全部 Controller
> - SignalR Hub `/hubs/notifications` 实时推送
> - MinIO 对象存储（头像/背景/封面/信息流媒体）
> - PostgreSQL + EF Core + Redis 输出缓存
> - Aspire 13 编排（Server + Redis + Frontend）
> - OpenAPI 文档生成

### 8.8 方案 URL 同步（✅ 已实现）

方案 URL 增量同步已在 `ServerUrlService.SyncFromServerAsync()` 中完整实现：

```
Step 1: 构建本地 Version 字典（从 server_urls 集合读取 SchemeName 非空的记录）
Step 2: POST /api/scheme-urls/sync → { localVersions }
Step 3: 处理 updated 列表 → UpsertBatch() 更新本地 DB（自动加密）
Step 4: 处理 deleted 列表 → 标记 SyncStatus="Removed" + Version++
Step 5: 触发 OnSchemeUrlChanged 事件（通知已打开方案的页面）
```

**调用链路**：`App.OnLaunched` → `SyncSchemeUrlsAsync()` (fire-and-forget) → `ServerUrlService.SyncFromServerAsync()`

**错误处理**：网络异常/超时（15s）→ 静默降级，仅输出 Debug 日志，不影响本地已有数据。

**事件订阅**：`OnSchemeUrlChanged` 事件已定义，`SchemeHostPage` 可订阅此事件检测当前方案 URL 变更后提示用户刷新或自动重载（当前尚未接入）。

### 8.9 信息流页面开发注意事项

**信息流卡片**直接在首页通知中心「信息流」标签中通过 **WebView2 渲染**，一次显示一张卡片，底部左右按钮切换。

```
信息流卡片数据流:
RemoteInfoCardService (HTTP 拉取 GET /api/info-cards)
  → _cachedCards (原始 API DTO)
  → CardsRefreshed 事件
    → NotificationCenterViewModel.ReloadCards()
      → BuildCardHtml() 生成单卡片 HTML
        → NotificationVM.FeedHtml 属性
          → MainPage.PushWebView.NavigateToString(html)
```

**关键文件**：
- `Services/RemoteInfoCardService.cs` — 远程拉取、CDN URL 解析、本地持久化
- `ViewModels/Controls/NotificationCenterViewModel.cs` — 卡片切换逻辑（PrevCard/NextCard）、HTML 生成、媒体缓存
- `Views/Pages/MainPage.xaml` — PushContentPanel 内嵌 WebView2 + 左右切换按钮
- `Views/Pages/MainPage.xaml.cs` — PushWebView 初始化 + FeedHtml 变更监听

**设计要点**：
- 每次只渲染一张卡片，通过 `CurrentCardIndex` 切换
- 媒体加载优先级：本地文件缓存（方案B校验通过）→ CDN 预签名 URL
- **方案B防篡改**：内容明文 + 加密 meta（AES-GCM `{sha256, etag, version}`）；读取时解密 meta + SHA256 校验，任一失败删除重新下载
- 半透明遮罩（CSS `backdrop-filter: blur(10px)` + 渐变）覆盖在媒体左上角
- 缓存路径：`%APPDATA%/Kirara/info_cards_media/{cardId:N}_v{n}_{field}.{ext}` + `{path}.meta`（加密）
- 空状态时不显示切换按钮，显示"暂无信息流内容"

---

## 九、议题（评论区）开发注意事项

- 评论数据已持久化到 LiteDB `comments` 集合，通过 `ICommentRepository` / `CommentService` 操作
- 资源键格式：`"{schemeName}://{instanceId:N}{path}"`
- 评论面板的打开/关闭由 `ICommentPanelService` 管理，在 `ShellPage.OnContentNavigated` 中触发
- 远程 API 接入只需新建 `RemoteCommentService : ICommentService`，DI 替换注册即可，**无需改动 ViewModel / UI 层**
- **服务端搭建**: 详见 `docs/服务端后端系统技术栈.md`（整体架构）

---

## 十、服务器通信架构与接入指引

### 10.1 整体通信模型

```
┌────────────────────────────────────────────────┐
│  客户端 (WinUI 3)                              │
│                                                │
│  ┌──────────────────────────────────────────┐  │
│  │ 已实现 HTTP 通信:                         │  │
│  │  ✅ BackgroundService   → GET 下载背景图  │  │
│  │  ✅ UserAvatarService   → GET/POST 头像   │  │
│  │  ✅ RemoteLoginService  → POST /api/auth/*│  │
│  │  ✅ RemoteQuickStartService→GET /api/templates││
│  │  ✅ SchemeIconCacheService→GET /api/scheme-urls/{key}/image││
│  │                                          │  │
│  │ 🔴 待接入 HTTP API（服务端 ✅ 已实现）:     │  │
│  │  🔴 NotificationService → /api/notif/*    │  │
│  │  🔴 CommentService      → /api/comments   │  │
│  │  🔴 ServerUrlService    → /api/scheme-urls│  │
│  │  🔴 InfoCards           → /api/info-cards │  │
│  │  🔴 Admin               → /api/admin/*    │  │
│  └──────────────────────────────────────────┘  │
│                                                │
│  关键设计: 接口抽象 + DI 替换注册               │
│  所有待接入功能都有 I*Service 接口，新建远程     │
│  实现类，DI 替换注册即可，不需改 ViewModel/UI   │
└────────────────────────────────────────────────┘
```

### 10.2 接入模式

客户端对接服务端 API 遵循**统一模式**，以评论系统为例：

```
Step 1: 新建 RemoteCommentService : ICommentService
        实现 HTTP 调用 (HttpClient + System.Text.Json)
Step 2: App.xaml.cs DI 容器替换注册
        services.AddSingleton<ICommentService, RemoteCommentService>();
Step 3: 可选离线降级
        在线 → RemoteCommentService；离线 → CommentService (LiteDB)
```

**已预留 TODO 桩的 Service 文件清单**：

| 文件 | 桩标记 | 目标服务端 API |
|------|--------|---------------|
| `Services/CommentService.cs` | 每个方法 `// TODO: 远程数据库` | `GET/POST /api/comments`, `/replies` |
| `Services/QuickStartService.cs` | `yield return` 硬编码 | `GET /api/templates` |
| `Services/INotificationService.cs` | `NotificationCategory.Push` 未接入 | SignalR Hub + `GET /api/notifications` |
| `Services/IUserAvatarService.cs` | 上传 fire-and-forget（无重试/确认） | `PUT /api/resources/user_avatar` |
| — | 🔴 未接入 | `/api/admin/*` (用户/URL/通知/模板) |

> **已实现远程服务**（无需再接入）：
> - ✅ `RemoteLoginService.cs` — JWT+RefreshToken 远程认证（替换 LoginService）
> - ✅ `RemoteQuickStartService.cs` — HTTP 模板获取 + 封面图 ETag 缓存（替换 QuickStartService）
> - ✅ `SchemeIconCacheService.cs` — HTTP 方案图标下载 + ETag 缓存
> - ✅ `ServerUrlService.SyncFromServerAsync()` — 方案 URL 增量同步（POST /api/scheme-urls/sync）
> - ✅ **信息流卡片** — WebView2 在首页通知中心直接渲染，单卡片+左右切换

### 10.3 关键参考文档

| 文档 | 用途 | 核心内容 |
|------|------|----------|
| `docs/服务端后端系统技术栈.md` | **服务端搭建总纲** | 技术选型、数据库 DDL、REST API 设计、部署方案、客户端改造清单 |
| `docs/技术栈文档.md` | 客户端架构参考 | 全部 Service 接口定义、DI 注册表、数据模型 |
| `docs/Kirara Server API 完整文档.md` | API 完整参考 | 全部 API 端点、请求/响应示例、状态码 |

### 10.4 方案 URL 集中管理链路

> 理解此链路对于**接入服务端 URL 推送**和**新建 WebView2 方案**至关重要。

```
方案 Name (=DefaultUrlKey)
  → BaseScheme.GetUI()
    → ServerUrlService.GetDecryptedUrl(key)
      → LiteDB server_urls 集合 (AES-256-GCM 加密)
        → 解密返回明文 URL
          → SchemeUI.WebViewUrl
            → SchemeHostPage.ShowWebViewAsync(url) → WebView2 导航

✅ 当前: `ServerUrlService.SyncFromServerAsync()` → POST /api/scheme-urls/sync → 增量同步 URL 变更
（App.OnLaunched 中 fire-and-forget 调用，15s 超时，静默降级）
```

### 10.5 新增服务器通信功能的核心原则

1. **接口不变原则**：所有待接入功能已有 `I*Service` 接口，新建 `Remote*Service` 实现即可
2. **DI 替换原则**：在 `App.xaml.cs` 的 `ConfigureServices()` 中替换注册，不改 ViewModel/UI
3. **增量同步原则**：资源/URL/模板使用 `Version` 字段，客户端上报本地版本，服务端仅返回变更
4. **降级兜底原则**：所有远程 API 调用应有本地降级路径（LiteDB / 硬编码默认值 / null）
5. **加密不变原则**：敏感字段（密码、API Key）由客户端 AES-256-GCM 加密后传输，服务端不解密（端到端加密）

---
