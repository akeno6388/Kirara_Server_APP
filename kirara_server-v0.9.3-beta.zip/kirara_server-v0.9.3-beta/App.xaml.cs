﻿using System.Runtime.InteropServices;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.UI.Xaml;
using Kirara_Server_WinUI.Data;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.Schemes;
using Kirara_Server_WinUI.ViewModels;
using Kirara_Server_WinUI.ViewModels.Pages;
using Kirara_Server_WinUI.ViewModels.Controls;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

namespace Kirara_Server_WinUI;

/// <summary>
/// Provides application-specific behavior to supplement the default Application class.
/// </summary>
public partial class App : Application
{
    private readonly IHost _host;

    /// <summary>
    /// Gets the application-wide service provider.
    /// </summary>
    public static IServiceProvider Services => ((App)Current)._host.Services;

    /// <summary>
    /// 应用入口 — 自定义 Main（替代 XAML 生成的 Main，见 csproj DISABLE_XAML_GENERATED_MAIN）。
    ///
    /// ★ [单实例] 单实例检测必须在 Application.Start（XAML 运行时初始化）之前执行：
    ///   二次双击桌面图标启动的实例在进入 XAML 运行时前直接 Environment.Exit，
    ///   进程只经历 CLR 启动便干净终止，不加载 XAML 运行时。
    ///
    /// ⚠️ 注意：发布形态下用户双击的是原生启动器 KiraraServerAPP.exe（launcher/），
    ///   本 Core 进程由启动器拉起。单实例 Mutex 仍由本进程（长期运行者）持有，
    ///   启动器与 .NET 侧检测共用同一命名 Mutex，形成双保险。
    ///
    /// 🔧 调试参数：--skip-single-instance — 跳过单实例检测（VS F5 调试用，
    ///   避免已运行主实例时调试实例被拦截退出）。
    /// </summary>
    [STAThread]
    private static void Main(string[] args)
    {
        // [调试] 跳过单实例检测（VS 调试配置默认携带该参数）
        bool skipSingleInstance = args.Any(a =>
            a.Equals("--skip-single-instance", StringComparison.OrdinalIgnoreCase));

        // ★ [单实例] 检测已有实例：二次实例已发出唤醒信号，立即终止进程。
        //   使用 Environment.Exit(0) 而非 return：跳过 CLR 托管退出路径
        //   （Finalizer/AppDomain 卸载等），进程最快速度死亡，减少可见窗口期。
        //   ⚠️ 此处位于 Application.Start 之前，XAML 运行时尚未初始化，
        //   不存在"从 XAML 回调内 Exit 被清理钩子阻塞"的问题。
        if (!skipSingleInstance && !Helpers.SingleInstanceHelper.TryAcquire())
        {
            System.Diagnostics.Debug.WriteLine("[App] 检测到已有实例，二次启动退出");
            Environment.Exit(0);
        }

        // 以下为 XAML 生成的默认引导代码：
        // WinRT COM 包装初始化 → Application.Start（初始化 XAML 运行时并创建 App 实例）
        global::WinRT.ComWrappersSupport.InitializeComWrappers();
        global::Microsoft.UI.Xaml.Application.Start(p =>
        {
            var context = new global::Microsoft.UI.Dispatching.DispatcherQueueSynchronizationContext(
                global::Microsoft.UI.Dispatching.DispatcherQueue.GetForCurrentThread());
            global::System.Threading.SynchronizationContext.SetSynchronizationContext(context);
            new App();
        });
    }

    /// <summary>
    /// Initializes the singleton application object.
    /// </summary>
    public App()
    {
        InitializeComponent();

        // 全局未处理异常捕获 — 防止 XAML Hot Reload 因未处理异常而中断
        UnhandledException += OnUnhandledException;
        TaskScheduler.UnobservedTaskException += OnUnobservedTaskException;
        AppDomain.CurrentDomain.UnhandledException += OnDomainUnhandledException;

        _host = Microsoft.Extensions.Hosting.Host
            .CreateDefaultBuilder()
            .UseContentRoot(AppContext.BaseDirectory)
            .ConfigureServices(ConfigureServices)
            .Build();
    }

    /// <summary>
    /// 全局 XAML 未处理异常 — 记录日志并标记为已处理，防止进程崩溃
    /// </summary>
    private static void OnUnhandledException(object sender, Microsoft.UI.Xaml.UnhandledExceptionEventArgs e)
    {
        var ex = e.Exception;
        System.Diagnostics.Debug.WriteLine($"[FATAL] Unhandled UI exception: {ex?.GetType().Name}: {ex?.Message}");
        System.Diagnostics.Debug.WriteLine($"[FATAL] StackTrace: {ex?.StackTrace}");
        try
        {
            var logPath = System.IO.Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Kirara", "crash.log");
            var dir = System.IO.Path.GetDirectoryName(logPath);
            if (!string.IsNullOrEmpty(dir) && !System.IO.Directory.Exists(dir))
                System.IO.Directory.CreateDirectory(dir);
            System.IO.File.AppendAllText(logPath,
                $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] UnhandledException: {ex}\r\n");
        }
        catch { /* 日志失败不影响程序 */ }

        // [首页通知] 全局异常 → 发布 Error 级别服务通知
        try
        {
            NotificationWiringHelper.NotificationService?.Publish(new Kirara_Server_WinUI.Services.AppNotification
            {
                Category = Kirara_Server_WinUI.Services.NotificationCategory.Service,
                Severity = Kirara_Server_WinUI.Services.NotificationSeverity.Error,
                Title = $"未处理异常: {ex?.GetType().Name}",
                Message = ex?.Message ?? "未知错误",
                Source = "App.UnhandledException",
            });
        }
        catch { /* 通知发布失败不影响异常处理 */ }

        e.Handled = true; // 标记为已处理，防止进程崩溃
    }

    /// <summary>
    /// 全局 Task 未观察异常
    /// </summary>
    private static void OnUnobservedTaskException(object? sender, UnobservedTaskExceptionEventArgs e)
    {
        System.Diagnostics.Debug.WriteLine($"[FATAL] Unobserved Task exception: {e.Exception?.InnerException?.Message}");
        e.SetObserved(); // 阻止进程退出
    }

    /// <summary>
    /// 全局 AppDomain 未处理异常
    /// </summary>
    private static void OnDomainUnhandledException(object sender, System.UnhandledExceptionEventArgs e)
    {
        if (e.ExceptionObject is Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[FATAL] AppDomain unhandled: {ex.GetType().Name}: {ex.Message}");
        }
    }

    /// <summary>
    /// Configures the dependency injection services.
    /// </summary>
    private static void ConfigureServices(HostBuilderContext context, IServiceCollection services)
    {
        // ===== Data Layer =====
        services.AddSingleton<AppDatabase>();
        services.AddSingleton<Data.IInstanceRepository, Data.InstanceRepository>();
        services.AddSingleton<Data.ITokenRepository, Data.TokenRepository>();
        services.AddSingleton<Data.ISchemeRepository, Data.SchemeRepository>();
        services.AddSingleton<Data.IServerUrlRepository, Data.ServerUrlRepository>();
        services.AddSingleton<Data.ICommentRepository, Data.CommentRepository>();
        services.AddSingleton<Data.IAppSettingsRepository, Data.AppSettingsRepository>(); // 🆕 应用设置（外观主题偏好）

        // ===== Services =====
        services.AddSingleton<ICryptoService, CryptoService>();
        services.AddSingleton<SecureCacheService>();   // 🆕 安全缓存服务（方案A加密合并/方案B加密meta）
        services.AddSingleton<IInstanceService, InstanceService>();
        services.AddSingleton<ITokenService, TokenService>();
        services.AddSingleton<ISchemeService, SchemeService>();
        services.AddSingleton<IExportImportService, ExportImportService>();
        services.AddSingleton<IDialogService, DialogService>();
        services.AddSingleton<IQuickStartService, RemoteQuickStartService>();
        services.AddSingleton<SchemeIconCacheService>();                      // 🆕 方案图标缓存服务
        services.AddSingleton<INavigationService, NavigationService>();
        services.AddSingleton<ISchemePageCache, SchemePageCache>();
        services.AddSingleton<IServerUrlService, ServerUrlService>();
        services.AddSingleton<IAutoLoginService, AutoLoginService>();
        // 登录认证 — 远程 API 模式（RemoteLoginService 通过 HTTP 调用服务端 API）
        services.AddSingleton<ILoginService, RemoteLoginService>();         // 🆕 远程登录认证
        services.AddSingleton<IPermissionService, PermissionService>();      // 🆕 权限管理

        // [评论区功能] DI 注册 — 远程评论服务与面板管理服务
        services.AddSingleton<ICommentService, RemoteCommentService>();
        services.AddSingleton<ICommentPanelService, CommentPanelService>();

        // [首页分享功能] DI 注册 — 首页分享服务
        services.AddSingleton<IHomepageCommentService, RemoteHomepageCommentService>();

        // [首页功能] DI 注册 — 日志服务与通知服务（Phase 1 - 基础设施层）
        services.AddSingleton<ILoggingService, LoggingService>();
        services.AddSingleton<INotificationService, NotificationService>();

        // [远程通知] DI 注册 — 本地通知持久化存储 + SignalR 实时通知服务
        services.AddSingleton<LocalNotificationStore>();
        services.AddSingleton<RemoteNotificationService>();

        // [信息流卡片] DI 注册 — 本地信息流缓存 + 远程信息流服务
        services.AddSingleton<LocalInfoCardStore>();
        services.AddSingleton<LocalTemplateStore>();                       // 🆕 模板列表本地持久化
        services.AddSingleton<RemoteInfoCardService>();

        // [首页功能] DI 注册 — 背景图片管理（Phase 2 - 功能填充）
        services.AddSingleton<IBackgroundService, Kirara_Server_WinUI.Services.BackgroundService>();

        // [首页功能] DI 注册 — 用户头像管理
        services.AddSingleton<IUserAvatarService, UserAvatarService>();
        // [评论区功能] DI 注册 — 评论作者头像缓存服务（方案A加密 + ETag 同步，按 userId 缓存）
        services.AddSingleton<CommentAvatarService>();

        // [OpenVPN 功能] DI 注册 — VPN 连接服务（openvpn.exe 子进程 + management 管理接口）
        services.AddSingleton<VpnConnectionService>();

        // [OpenVPN 功能] DI 注册 — .ovpn 配置缓存服务（服务端下载 + ETag 比对）
        services.AddSingleton<OvpnConfigCacheService>();

        // [外观主题] DI 注册 — 跟随系统/明暗/主题色管理服务
        services.AddSingleton<AppThemeService>();

        // [软件行为] DI 注册 — 关闭行为/开机自启管理服务
        services.AddSingleton<AppBehaviorService>();

        // [托盘角标] DI 注册 — 系统托盘图标服务（关闭→最小化时驻留托盘）
        services.AddSingleton<TrayIconService>();

        // [OpenVPN 服务版] DI 注册 — 多配置文件存储服务（按实例隔离 + 加密凭据）
        services.AddSingleton<OpenVpnProfileStore>();

        // [应用更新] DI 注册 — 自动更新服务（每次登录成功后检查版本 / 下载 / 静默升级）
        services.AddSingleton<AppUpdateService>();

        // ===== ViewModels =====
        services.AddTransient<MainWindowViewModel>();
        services.AddSingleton<ViewModels.Controls.LeftFunctionBarViewModel>();

        // Pages
        services.AddTransient<MainPageViewModel>();
        services.AddTransient<LoginPageViewModel>();                      // 🆕 登录页面
        services.AddTransient<QuickStartWizardViewModel>();               // 🆕 快速开始向导
        services.AddTransient<AccountSettingsViewModel>();                // 🆕 账号设置页面
        
        services.AddTransient<InstanceEditorViewModel>();
        services.AddTransient<TokenManagerViewModel>();
        services.AddTransient<TokenEditorViewModel>();
        services.AddTransient<SettingsViewModel>();

        // Controls
        services.AddTransient<InstanceCardViewModel>();
        services.AddSingleton<SchemeTabBarViewModel>();
        services.AddTransient<NotificationBadgeViewModel>();
        services.AddSingleton<NotificationCenterViewModel>();      // 🆕 通知中心
        services.AddSingleton<StatusBarViewModel>();

        // Instance
        services.AddTransient<ViewModels.InstanceSpace.InstanceWorkspaceViewModel>();
        services.AddTransient<ViewModels.InstanceSpace.SchemeHostViewModel>();

        // ===== Main Window =====
        services.AddSingleton<MainWindow>();
    }

    /// <summary>
    /// Invoked when the application is launched.
    /// </summary>
    protected override async void OnLaunched(Microsoft.UI.Xaml.LaunchActivatedEventArgs args)
    {
        // ★ [单实例] 注册唤醒回调：主实例在 UI 线程捕获 DispatcherQueue，
        //   二次双击桌面图标时（后台侦听线程收到信号）调度到此回调恢复窗口。
        //   RestoreFromTray 兼容三种窗口状态：
        //     ① 隐藏到托盘(SW_HIDE) → ShowWindow 恢复；② 最小化 → presenter.Restore；
        //     ③ 正常显示 → 前置窗口（无副作用）。
        var uiDispatcher = Microsoft.UI.Dispatching.DispatcherQueue.GetForCurrentThread();
        Helpers.SingleInstanceHelper.SetRestoreCallback(() =>
        {
            uiDispatcher.TryEnqueue(() =>
            {
                try { Helpers.WindowAnimationHelper.RestoreFromTray(); }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[App] 二次启动恢复窗口失败: {ex.Message}");
                }
            });
        });

        await _host.StartAsync();

        // [安全缓存] 启动时清理上次会话残留的临时明文文件（%APPDATA%/Kirara/tmp/）
        SecureCacheService.CleanupTempDirectory();

        // 将 ServerUrlService 注入方案基类（所有方案通过 DefaultUrlKey 从注册表解析 URL）
        BaseScheme.ServerUrlService = _host.Services.GetRequiredService<IServerUrlService>();

        var mainWindow = _host.Services.GetRequiredService<MainWindow>();

        // [OpenVPN 功能] 应用退出时断开 VPN 连接并终止 openvpn.exe 子进程（防止残留）
        var vpnService = _host.Services.GetRequiredService<VpnConnectionService>();
        // [实例关闭] 应用退出（点击关闭窗口）时，关闭所有缓存的 WebView2 页面，
        // 确保浏览器进程随应用一起退出（此前从未调用，导致关闭窗口后浏览器进程残留）
        var pageCache = _host.Services.GetRequiredService<ISchemePageCache>();
        mainWindow.Closed += async (_, _) =>
        {
            // [修复] 窗口关闭后的退出清理：
            // 1. Shutdown() 是 async void 无法 await → 用 Task.Run 隔离到后台线程执行
            // 2. 等 3s 兜底（WebView2 极端卡死时也保证窗口关闭，不无限延迟）
            // 3. 结束后显式 Exit（WinUI3 窗口关闭 ≠ 进程退出，不 Exit 会残留 28MB 进程）
            // 4. vpnService.Dispose 在 Exit 前调用（请求服务断开 openvpn，不阻塞 UI）
            // 5. [修复] _host.Dispose() 释放 Hosting 容器中所有 IDisposable Singleton：
            //    RemoteNotificationService（断开 SignalR WebSocket + 释放 HttpClient）、
            //    RemoteInfoCardService / AppUpdateService / UserAvatarService /
            //    BackgroundService / CommentAvatarService / LoggingService 等，
            //    并解除 LoginStateChanged 事件订阅 —— 消除残留进程持有的活动连接与后台任务
            // 6. [修复] 退出看门狗：Exit 后 3s 进程仍未退出 → Environment.Exit(0) 强制结束，
            //    兜底 WinUI3 Exit 不彻底导致的 ~10MB 残留进程
            try
            {
                var shutdownTask = Task.Run(() => pageCache.Shutdown());
                var completed = await Task.WhenAny(shutdownTask, Task.Delay(TimeSpan.FromSeconds(3)));
                if (completed != shutdownTask)
                {
                    System.Diagnostics.Debug.WriteLine("[App] 页面关闭超时，强制退出");
                }
            }
            catch { /* Shutdown 异常不阻塞退出 */ }

            vpnService.Dispose();

            // [托盘角标] 应用退出时销毁托盘图标并卸载 WndProc（防止残留托盘角标）
            try
            {
                TrayIconService.Current?.Dispose();
            }
            catch { /* 托盘销毁失败不影响退出 */ }

            // [单实例] 释放 Mutex / 命名事件 / 侦听线程，
            // 确保应用退出后再次双击桌面图标能正常启动新实例
            Helpers.SingleInstanceHelper.Dispose();

            // [残留进程修复] 释放 Hosting 容器：自动 Dispose 所有注册的 IDisposable Singleton
            // （SignalR 断开、HttpClient 释放、事件订阅解除）。
            // ⚠️ RemoteNotificationService.Dispose 内含 DisconnectSignalRAsync().GetAwaiter().GetResult()
            //    （SignalR StopAsync 为网络操作）→ 放 Task.Run + 3s 超时，避免阻塞 UI 线程过久。
            try
            {
                var hostDisposeTask = Task.Run(() => _host.Dispose());
                var hostCompleted = await Task.WhenAny(hostDisposeTask, Task.Delay(TimeSpan.FromSeconds(3)));
                if (hostCompleted != hostDisposeTask)
                {
                    System.Diagnostics.Debug.WriteLine("[App] Host 释放超时，强制退出");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[App] Host 释放失败: {ex.GetType().Name}: {ex.Message}");
            }

            // [修复] _host.Dispose() 释放的某个服务可能已触发应用关闭，导致
            // Application.Current 变为 null → 显式 Exit 前判空，避免 NullReferenceException。
            try
            {
                if (Application.Current != null)
                {
                    Application.Current.Exit();
                }
            }
            catch { /* Exit 失败时进程可能由系统回收 */ }

            // [残留进程修复] 退出看门狗：正常退出时进程已结束，此 Task 无意义；
            // 若 Exit 不彻底（WinUI3 已知问题，残留 ~10MB），3 秒后强制终止进程。
            _ = Task.Delay(TimeSpan.FromSeconds(3)).ContinueWith(_ =>
            {
                try { Environment.Exit(0); } catch { /* 已退出则忽略 */ }
            });
        };

        // 同步内置方案数据（Description、DisplayName 等）到数据库
        _host.Services.GetRequiredService<ISchemeService>().SyncBuiltInSchemas();

        // 迁移明文 ServerUrl 到加密存储（首次运行或升级后自动执行）
        _host.Services.GetRequiredService<IServerUrlService>().MigratePlaintextUrls();

        // [首页功能] 连接通知源（IDialogService + ILoggingService + App异常 → INotificationService）
        NotificationWiringHelper.Wire(_host.Services);

        // [首页功能] 确保背景图片 URL 注册键存在并初始化背景服务
        var backgroundService = _host.Services.GetRequiredService<IBackgroundService>();
        if (backgroundService is Kirara_Server_WinUI.Services.BackgroundService bs)
        {
            bs.EnsureBackgroundUrlRecord();
        }
        _ = backgroundService.InitializeAsync(); // 后台异步加载，不阻塞启动

        // [首页功能] 确保头像 URL 注册键存在
        // 头像初始化在登录完成后通过 LoginStateChanged 自动触发
        var avatarService = _host.Services.GetRequiredService<IUserAvatarService>();
        if (avatarService is UserAvatarService uas)
        {
            uas.EnsureAvatarUrlRecord();
        }

        // [远程接入] 确保认证 API URL 注册键存在
        var loginService = _host.Services.GetRequiredService<ILoginService>();
        if (loginService is RemoteLoginService rls)
        {
            rls.EnsureAuthApiUrlRecord();
        }

        // [远程接入] 确保模板 API URL 注册键存在并预取模板数据
        var quickStartService = _host.Services.GetRequiredService<IQuickStartService>();
        if (quickStartService is RemoteQuickStartService rqs)
        {
            rqs.EnsureTemplateApiUrlRecord();
            _ = rqs.InitializeAsync(); // 后台异步预取模板，不阻塞启动
        }

        // [方案图标] 初始化方案封面图标缓存服务
        var schemeIconCache = _host.Services.GetRequiredService<SchemeIconCacheService>();
        schemeIconCache.EnsureSchemeApiUrlRecord();
        _ = schemeIconCache.InitializeAsync(); // 后台异步加载方案图标，不阻塞启动

        // [方案 URL 同步] 确保方案 URL API 注册键存在并执行增量同步
        var serverUrlService = _host.Services.GetRequiredService<IServerUrlService>();
        if (serverUrlService is ServerUrlService sus)
        {
            sus.EnsureSchemeUrlsApiUrlRecord();
        }

        // 后台异步执行方案 URL 增量同步（不阻塞启动）
        // 与服务端比对版本号，仅更新有变更的方案 URL；
        // 版本一致的跳过，服务端不可达时静默降级保留本地值
        _ = SyncSchemeUrlsAsync(serverUrlService);

        // [远程通知] 确保通知 API URL 注册键存在并初始化 SignalR 实时通知服务
        var notificationService2 = _host.Services.GetRequiredService<RemoteNotificationService>();
        notificationService2.EnsureNotificationApiUrlRecord();
        notificationService2.CaptureUiDispatcher();  // 在 UI 线程捕获调度器，SignalR 回调发布通知前需切换到 UI 线程
        // SignalR 连接由 LoginStateChanged 事件自动控制：登录后连接，登出后断开

        // [信息流卡片] 确保信息流 API URL 注册键存在并初始化
        var infoCardService = _host.Services.GetRequiredService<RemoteInfoCardService>();
        infoCardService.EnsureInfoCardApiUrlRecord();
        infoCardService.CaptureUiDispatcher();
        // 信息流拉取由 LoginStateChanged 事件自动控制：登录后拉取

        // [OpenVPN 功能] 初始化 .ovpn 配置缓存服务
        var ovpnConfigCache = _host.Services.GetRequiredService<OvpnConfigCacheService>();
        // 确保 OpenVPN API URL 注册键存在（默认 https://api.akeno6388.online:1010）
        ovpnConfigCache.EnsureOpenVpnApiUrlRecord();
        // 登录后（LoginStateChanged）自动同步服务端最新配置；本地已有缓存时秒用
        _ = ovpnConfigCache.InitializeAsync(); // 后台异步加载，不阻塞启动

        // [应用更新] 初始化自动更新服务
        // 确保应用更新 API URL 注册键存在 + 捕获 UI 线程调度器；
        // 更新检查由 LoginStateChanged 事件自动控制：每次成功登录后检查
        var appUpdateService = _host.Services.GetRequiredService<AppUpdateService>();
        appUpdateService.EnsureAppUpdatesApiUrlRecord();
        appUpdateService.CaptureUiDispatcher();

        // 设置自定义标题栏（必须在 Activate 之前设置，避免 WinUI 3 OOM bug）
        mainWindow.ExtendsContentIntoTitleBar = true;

        // 根据主显示器工作区与 DPI 自适应计算窗口尺寸
        var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(mainWindow);
        var (initW, initH, minW, minH) = Helpers.ScreenAdaptation.CalculateWindowSizes(hwnd);
        SetWindowMinSize(mainWindow, initW, initH, minW, minH);

        // 加载壳页面（RootFrame 由 XAML x:Name 自动生成）
        mainWindow.RootFrame.Navigate(typeof(Views.ShellPage));

        // [外观主题] 应用持久化的外观设置：
        // 跟随系统开关默认开启 → 明暗主题与主题色随 Windows 自动变化；
        // 关闭时应用用户手动选择的明暗主题与自定义主题色（覆盖 SystemAccentColor 系列资源）
        try
        {
            var themeService = _host.Services.GetRequiredService<AppThemeService>();
            themeService.Load();
            themeService.Apply();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[App] 应用外观主题设置失败: {ex.GetType().Name}: {ex.Message}");
        }

        mainWindow.Activate();

        // 启用 Win11 风格缩放动画（需在窗口激活、视觉树就绪后调用）
        mainWindow.EnableAnimations();

        // [托盘角标] 初始化系统托盘服务（挂载 WndProc 接收托盘回调消息）。
        // 必须在 EnableAnimations() 之后：WindowMessageHandler 已挂载 WndProc，
        // TrayIconService 的 WndProc 插入其链中；Current 就绪后「关闭→最小化」可显示托盘角标。
        try
        {
            var trayService = TrayIconService.Initialize(hwnd);
            // 左键单击托盘角标 / 「打开」菜单 → 恢复主窗口
            trayService.RestoreRequested += () =>
            {
                try { Helpers.WindowAnimationHelper.RestoreFromTray(); }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[App] 从托盘恢复失败: {ex.Message}");
                }
            };
            // 「退出」菜单 → 真正退出应用（先隐藏托盘角标，再走正常退出清理）
            trayService.ExitRequested += () =>
            {
                try
                {
                    trayService.Hide();
                    mainWindow.Close();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[App] 托盘退出失败: {ex.Message}");
                }
            };

            // [托盘常驻] 启动即显示系统托盘角标（无需等到「关闭→最小化」才出现）
            trayService.Show();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[App] 初始化托盘服务失败: {ex.GetType().Name}: {ex.Message}");
        }

        // [软件行为] 加载持久化的关闭行为 / 开机自启设置。
        // 必须在 EnableAnimations() 之后调用：WindowAnimationHelper 已挂载 WndProc
        // SC_CLOSE 拦截，AppBehaviorService.Current 就绪后点击关闭按钮即可实时读取。
        // 开机自启通过 HKCU Run 同步（持久化标记与注册表项双向校验）。
        try
        {
            _host.Services.GetRequiredService<AppBehaviorService>().Load();

            // [侧栏启动状态] 按折叠/展开开关应用左侧功能栏初始状态
            // （自动折叠开启时启动固定展开；关闭时按开关：开=展开 / 关=折叠）
            _host.Services.GetRequiredService<ViewModels.Controls.LeftFunctionBarViewModel>()
                .ApplyStartupPaneState();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[App] 加载软件行为设置失败: {ex.GetType().Name}: {ex.Message}");
        }
    }

    /// <summary>
    /// 后台异步执行方案 URL 增量同步。
    /// 从服务端拉取方案 URL 更新并写入本地注册表。
    /// 不阻塞启动流程，同步失败时自动静默降级。
    /// </summary>
    private static async Task SyncSchemeUrlsAsync(IServerUrlService serverUrlService)
    {
        try
        {
            await serverUrlService.SyncFromServerAsync(string.Empty);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[App] 方案 URL 同步失败: {ex.GetType().Name}: {ex.Message}");
        }
    }

    /// <summary>
    /// 设置窗口初始尺寸和最小拉伸限制
    /// </summary>
    private static void SetWindowMinSize(Microsoft.UI.Xaml.Window window, int initWidth, int initHeight, int minWidth, int minHeight)
    {
        var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(window);
        var windowId = Microsoft.UI.Win32Interop.GetWindowIdFromWindow(hwnd);
        var appWindow = Microsoft.UI.Windowing.AppWindow.GetFromWindowId(windowId);

        // 设置窗口初始大小
        appWindow.Resize(new Windows.Graphics.SizeInt32 { Width = initWidth, Height = initHeight });

        // 通过 Win32 消息拦截设置最小跟踪尺寸
        WindowSizeLimiter.Attach(hwnd, minWidth, minHeight);
    }

    /// <summary>
    /// Win32 窗口尺寸限制器 — 拦截 WM_GETMINMAXINFO 消息设置窗口极限尺寸
    /// 注意：必须保持 delegate 实例引用，否则 GC 后会导致 ExecutionEngineException
    /// </summary>
    private sealed class WindowSizeLimiter
    {
        private static readonly List<WindowSizeLimiter> _instances = new();

        private readonly int _minW, _minH;
        private readonly WndProcDelegate _wndProcDelegate; // 保持引用，防止 GC
        private readonly IntPtr _oldWndProc;
        private readonly IntPtr _hwnd;

        private WindowSizeLimiter(IntPtr hwnd, int minW, int minH)
        {
            _hwnd = hwnd;
            _minW = minW;
            _minH = minH;
            _wndProcDelegate = WndProcCore;

            _oldWndProc = SetWindowLongPtr(hwnd, GWLP_WNDPROC,
                Marshal.GetFunctionPointerForDelegate(_wndProcDelegate));

            // 保持静态引用，防止 delegate 被 GC 回收
            _instances.Add(this);
        }

        /// <summary>附加到指定窗口</summary>
        public static void Attach(IntPtr hwnd, int minWidth, int minHeight)
        {
            _ = new WindowSizeLimiter(hwnd, minWidth, minHeight);
        }

        /// <summary>窗口过程核心（保留原 WndProc 链）</summary>
        private IntPtr WndProcCore(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam)
        {
            const int WM_GETMINMAXINFO = 0x0024;

            if (msg == WM_GETMINMAXINFO)
            {
                var mmi = Marshal.PtrToStructure<MINMAXINFO>(lParam);

                // 保留原来的最小值，取较大值
                if (_minW > mmi.ptMinTrackSize.x)
                    mmi.ptMinTrackSize.x = _minW;
                if (_minH > mmi.ptMinTrackSize.y)
                    mmi.ptMinTrackSize.y = _minH;

                Marshal.StructureToPtr(mmi, lParam, false);
                return IntPtr.Zero;
            }

            return CallWindowProc(_oldWndProc, hWnd, msg, wParam, lParam);
        }

        // ===== Win32 类型与 P/Invoke =====

        private const int GWLP_WNDPROC = -4;

        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        private delegate IntPtr WndProcDelegate(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT { public int x; public int y; }

        [StructLayout(LayoutKind.Sequential)]
        private struct MINMAXINFO
        {
            public POINT ptReserved;
            public POINT ptMaxSize;
            public POINT ptMaxPosition;
            public POINT ptMinTrackSize;
            public POINT ptMaxTrackSize;
        }

        [DllImport("user32.dll", SetLastError = true, EntryPoint = "SetWindowLongPtr")]
        private static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr CallWindowProc(IntPtr lpPrevWndFunc, IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
    }
}
