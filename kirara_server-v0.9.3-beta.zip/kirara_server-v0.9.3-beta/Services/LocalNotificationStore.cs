using System.Text.Json;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 本地通知持久化存储 — 将服务通知按用户缓存在 JSON 文件中，
/// 确保重启后仍能显示已接收的通知，已读状态以本地为准。
///
/// ## 设计原则（v2 — 本地已读唯一权威）
/// - 服务端 IsRead 仅作"状态呈现"上报（客户端写入，不读取、不采信）
/// - 每个用户独立存储文件（notifications/{userId}.json），用户间已读状态互不影响
/// - 已读/未读判定 100% 由本地文件决定；服务端推送/拉取的通知一律初始化为未读
/// - 本地缓存作为已接收通知的本地快照，重启后先加载缓存秒显
/// - 每次 SignalR 推送后：立即持久化
/// - "清除"操作：删除当前用户的本地存储文件；**仅已读**通知的 ID 记录到
///   notifications/{userId}.cleared.json（持久化清除，重启后不重新拉取）；
///   **未读**通知不记录，重启/下次登录后重新从服务端拉取推送，保证用户不错过未读消息
///
/// ## 存储路径
/// %APPDATA%/Kirara/notifications/{userId}.json
/// %APPDATA%/Kirara/notifications/{userId}.cleared.json（已读已清除 ID 集合）
/// </summary>
public class LocalNotificationStore
{
    /// <summary>通知存储目录（按用户分文件）</summary>
    private static readonly string StoreDirPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "notifications");

    /// <summary>旧版全局共享文件路径（v2 前）— 仅用于一次性迁移</summary>
    private static readonly string LegacyStoreFilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "service_notifications.json");

    private readonly ILoginService _loginService;
    private readonly object _lock = new();

    public LocalNotificationStore(ILoginService loginService)
    {
        _loginService = loginService;
    }

    /// <summary>当前用户 ID（未登录时为 Guid.Empty）</summary>
    private Guid CurrentUserId => _loginService.CurrentUserId;

    /// <summary>
    /// 获取当前用户的存储文件路径（按用户隔离，互不影响）。
    /// </summary>
    private string GetStoreFilePath()
    {
        return Path.Combine(StoreDirPath, $"{CurrentUserId:N}.json");
    }

    /// <summary>
    /// 已清除通知 ID 集合文件路径（{userId}.cleared.json）。
    /// 清除时写入，重启后参与拉取去重，防止已清除通知被重新拉取。
    /// </summary>
    private string GetClearedFilePath()
    {
        return Path.Combine(StoreDirPath, $"{CurrentUserId:N}.cleared.json");
    }

    /// <summary>
    /// 从本地文件加载已持久化的服务通知列表。
    /// 首次使用时若检测到旧版共享文件（v2 前），自动迁移到当前用户文件。
    /// </summary>
    public List<AppNotification> Load()
    {
        try
        {
            lock (_lock)
            {
                var filePath = GetStoreFilePath();
                if (!File.Exists(filePath))
                {
                    // 一次性迁移：旧版共享文件 → 当前用户文件
                    MigrateLegacyFileIfNeeded(filePath);
                    if (!File.Exists(filePath))
                        return new List<AppNotification>();
                }

                var json = File.ReadAllText(filePath);
                var items = JsonSerializer.Deserialize<List<AppNotification>>(json);
                return items ?? new List<AppNotification>();
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalNotificationStore] 加载失败: {ex.Message}");
            return new List<AppNotification>();
        }
    }

    /// <summary>
    /// 旧版共享文件（service_notifications.json）一次性迁移到当前用户文件。
    /// v2 起存储按用户隔离，旧数据归入首次迁移时的当前用户。
    /// </summary>
    private void MigrateLegacyFileIfNeeded(string currentUserFilePath)
    {
        try
        {
            if (!File.Exists(LegacyStoreFilePath))
                return;

            var json = File.ReadAllText(LegacyStoreFilePath);
            var items = JsonSerializer.Deserialize<List<AppNotification>>(json) ?? new List<AppNotification>();

            var dir = Path.GetDirectoryName(currentUserFilePath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            File.WriteAllText(currentUserFilePath, JsonSerializer.Serialize(items));
            File.Delete(LegacyStoreFilePath);
            System.Diagnostics.Debug.WriteLine(
                $"[LocalNotificationStore] 已迁移旧版通知缓存到当前用户文件 ({items.Count} 条)");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalNotificationStore] 旧版缓存迁移失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 全量保存通知列表到当前用户的本地文件。
    /// </summary>
    public void SaveAll(List<AppNotification> notifications)
    {
        try
        {
            lock (_lock)
            {
                var filePath = GetStoreFilePath();
                var dir = Path.GetDirectoryName(filePath);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                var json = JsonSerializer.Serialize(notifications);
                File.WriteAllText(filePath, json);
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalNotificationStore] 保存失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 追加单条通知到本地存储（含去重；已清除的通知不再存储）。
    /// </summary>
    public void Append(AppNotification notification)
    {
        try
        {
            lock (_lock)
            {
                // 已清除的通知不再存储（防止重连补拉时把已清除的通知写回）
                if (LoadClearedIdsInternal().Contains(notification.Id))
                    return;

                var items = LoadInternal();
                if (!items.Any(n => n.Id == notification.Id))
                {
                    items.Insert(0, notification);
                    SaveInternal(items);
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalNotificationStore] 追加失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 批量追加通知到本地存储（含去重；已清除的通知不再存储）。
    /// </summary>
    public void AppendRange(IEnumerable<AppNotification> notifications)
    {
        try
        {
            lock (_lock)
            {
                var clearedIds = LoadClearedIdsInternal();
                var items = LoadInternal();
                var existingIds = new HashSet<Guid>(items.Select(n => n.Id));
                foreach (var n in notifications)
                {
                    // 已清除的通知不再存储
                    if (clearedIds.Contains(n.Id))
                        continue;

                    if (!existingIds.Contains(n.Id))
                    {
                        items.Insert(0, n);
                        existingIds.Add(n.Id);
                    }
                }
                SaveInternal(items);
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalNotificationStore] 批量追加失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 标记单条通知为已读（更新本地文件状态）。
    /// </summary>
    public void MarkAsRead(Guid id)
    {
        try
        {
            lock (_lock)
            {
                var items = LoadInternal();
                var item = items.FirstOrDefault(n => n.Id == id);
                if (item != null && !item.IsRead)
                {
                    item.IsRead = true;
                    SaveInternal(items);
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalNotificationStore] 标记已读失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 标记全部为已读（更新本地文件状态）。
    /// </summary>
    public void MarkAllAsRead()
    {
        try
        {
            lock (_lock)
            {
                var items = LoadInternal();
                bool changed = false;
                foreach (var item in items)
                {
                    if (!item.IsRead)
                    {
                        item.IsRead = true;
                        changed = true;
                    }
                }
                if (changed)
                    SaveInternal(items);
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalNotificationStore] 标记全部已读失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 清除当前用户本地持久化的服务通知：
    /// 1. 仅将**已读**通知的 ID 记录到已清除集合（持久化清除，重启后不再重新拉取）
    /// 2. **未读**通知不记录 — 删除本地记录后，重启/下次登录会重新从服务端拉取推送，
    ///    保证用户不错过未读消息
    /// 3. 删除当前用户的主存储文件
    /// 仅影响当前用户的本地状态，不影响其他用户与服务端记录。
    /// </summary>
    public void Clear()
    {
        try
        {
            lock (_lock)
            {
                // 1. 仅将"已读"通知 ID 记入已清除集合（持久化清除）
                //    未读通知不记录 → 重启后重新拉取推送，用户不错过未读消息
                var items = LoadInternal();
                var readItems = items.Where(n => n.IsRead).ToList();
                if (readItems.Count > 0)
                {
                    var clearedIds = LoadClearedIdsInternal();
                    foreach (var item in readItems)
                        clearedIds.Add(item.Id);
                    SaveClearedIdsInternal(clearedIds);
                    System.Diagnostics.Debug.WriteLine(
                        $"[LocalNotificationStore] 已记录 {readItems.Count} 条已读通知 ID 为持久化清除；" +
                        $"未读通知 {items.Count - readItems.Count} 条将在下次启动重新拉取");
                }

                // 2. 删除当前用户的主文件
                var filePath = GetStoreFilePath();
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                    System.Diagnostics.Debug.WriteLine(
                        "[LocalNotificationStore] 当前用户本地通知缓存已清除");
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalNotificationStore] 清除失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 获取当前用户已清除通知的 ID 集合（重启后供拉取去重使用）。
    /// </summary>
    public HashSet<Guid> GetClearedIds()
    {
        lock (_lock)
        {
            return LoadClearedIdsInternal();
        }
    }

    /// <summary>获取已持久化的通知数量</summary>
    public int Count()
    {
        lock (_lock)
        {
            return LoadInternal().Count;
        }
    }

    // ================================================================
    //  内部方法（必须在 lock 内调用）
    // ================================================================

    /// <summary>读取当前用户的本地通知列表（无文件时返回空列表）</summary>
    private List<AppNotification> LoadInternal()
    {
        var filePath = GetStoreFilePath();
        if (!File.Exists(filePath))
            return new List<AppNotification>();

        var json = File.ReadAllText(filePath);
        return JsonSerializer.Deserialize<List<AppNotification>>(json) ?? new List<AppNotification>();
    }

    /// <summary>全量写入当前用户的本地通知列表（自动创建目录）</summary>
    private void SaveInternal(List<AppNotification> notifications)
    {
        var filePath = GetStoreFilePath();
        var dir = Path.GetDirectoryName(filePath);
        if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            Directory.CreateDirectory(dir);

        var json = JsonSerializer.Serialize(notifications);
        File.WriteAllText(filePath, json);
    }

    /// <summary>读取当前用户已清除通知 ID 集合（无文件时返回空集合）</summary>
    private HashSet<Guid> LoadClearedIdsInternal()
    {
        var filePath = GetClearedFilePath();
        if (!File.Exists(filePath))
            return new HashSet<Guid>();

        try
        {
            var json = File.ReadAllText(filePath);
            var ids = JsonSerializer.Deserialize<List<Guid>>(json) ?? new List<Guid>();
            return new HashSet<Guid>(ids);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalNotificationStore] 已清除 ID 加载失败: {ex.Message}");
            return new HashSet<Guid>();
        }
    }

    /// <summary>写入当前用户已清除通知 ID 集合（自动创建目录）</summary>
    private void SaveClearedIdsInternal(HashSet<Guid> ids)
    {
        var filePath = GetClearedFilePath();
        var dir = Path.GetDirectoryName(filePath);
        if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            Directory.CreateDirectory(dir);

        var json = JsonSerializer.Serialize(ids.ToList());
        File.WriteAllText(filePath, json);
    }
}