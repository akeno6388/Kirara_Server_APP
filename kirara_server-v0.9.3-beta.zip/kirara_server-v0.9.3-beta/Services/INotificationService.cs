namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 通知类别
/// </summary>
public enum NotificationCategory
{
    /// <summary>消息推送（来自服务器端的 HTML 通知）</summary>
    Push = 0,

    /// <summary>服务通知（应用内产生的通知、报错等）</summary>
    Service = 1,

    /// <summary>日志通知（Debug 日志输出）</summary>
    Log = 2,
}

/// <summary>
/// 通知严重程度
/// </summary>
public enum NotificationSeverity
{
    /// <summary>信息</summary>
    Info = 0,

    /// <summary>警告</summary>
    Warning = 1,

    /// <summary>错误</summary>
    Error = 2,
}

/// <summary>
/// 应用通知 — 统一的通知数据模型，支持三种类别（Push/Service/Log）
/// </summary>
public class AppNotification
{
    /// <summary>通知唯一标识</summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>通知类别</summary>
    public NotificationCategory Category { get; set; }

    /// <summary>严重程度</summary>
    public NotificationSeverity Severity { get; set; }

    /// <summary>严重程度图标（Segoe Fluent Icons 字符，用于 XAML 绑定）</summary>
    public string SeverityGlyph => Severity switch
    {
        NotificationSeverity.Error => "\uE783",    // ✕ 错误
        NotificationSeverity.Warning => "\uE7BA",  // ⚠ 警告
        _ => "\uE946",                             // ℹ 信息
    };

    /// <summary>严重程度颜色十六进制（用于 XAML StringToBrushConverter）</summary>
    public string SeverityColor => Severity switch
    {
        NotificationSeverity.Error => "#E74C3C",   // 红色
        NotificationSeverity.Warning => "#F39C12", // 橙色
        _ => "#3498DB",                            // 蓝色
    };

    /// <summary>标题</summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>消息正文</summary>
    public string Message { get; set; } = string.Empty;

    /// <summary>
    /// 显示副标题（XAML 绑定用）。
    /// 互动通知按统一格式重排：XXX赞了你在资源『 标题 』下的评论：“内容”；
    /// 广播/日志等非互动通知或信息缺失时原样返回 Message。
    /// </summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public string DisplayMessage
    {
        get
        {
            // 非互动通知（广播/日志等）原样显示
            if (ActionType is null || ActionType < 1 || ActionType > 4)
                return Message;

            var actor = string.IsNullOrWhiteSpace(ActorName) ? null : ActorName.Trim();
            var title = string.IsNullOrWhiteSpace(ContentTitle) ? null : ContentTitle.Trim();
            var quote = ExtractQuote(Message);

            // 触发者缺失 → 无法重排，原样
            if (actor is null)
                return Message;

            switch (ActionType.Value)
            {
                case 1: // 回复评论
                case 2: // 点赞评论
                case 3: // 点赞回复
                    var verb = ActionType.Value == 1 ? "回复了" : "赞了";
                    var kind = ActionType.Value == 3 ? "回复" : "评论";

                    // 标题缺失 → 回退旧式文案：XXX赞了你的评论：“内容”
                    if (title is null)
                    {
                        var fallback = $"{actor}{verb}你的{kind}";
                        return quote is null ? fallback : $"{fallback}：“{quote}”";
                    }

                    var sb = new System.Text.StringBuilder($"{actor}{verb}你在资源『 {title} 』下的{kind}");
                    if (quote is not null)
                        sb.Append($"：“{quote}”");
                    return sb.ToString();

                case 4: // 点赞首页分享
                    return title is null
                        ? $"{actor}赞了你在社区分享的资源"
                        : $"{actor}赞了你在社区分享的资源『 {title} 』";

                default:
                    return Message;
            }
        }
    }

    /// <summary>从服务端原始文案中提取内容引用（中文引号“...”之间的部分），提取不到返回 null。</summary>
    private static string? ExtractQuote(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return null;

        var open = message.IndexOf('“');
        var close = message.LastIndexOf('”');
        if (open < 0 || close <= open)
            return null;

        var quote = message.Substring(open + 1, close - open - 1).Trim();
        return string.IsNullOrWhiteSpace(quote) ? null : quote;
    }

    /// <summary>HTML 内容（消息推送专用，由 WebView2 渲染）</summary>
    public string? HtmlContent { get; set; }

    /// <summary>时间戳</summary>
    public DateTime Timestamp { get; set; } = DateTime.Now;

    /// <summary>是否已读</summary>
    public bool IsRead { get; set; }

    /// <summary>来源模块名</summary>
    public string? Source { get; set; }

    // ===== 互动通知定位字段（v1.10 起，广播通知为 null） =====

    /// <summary>互动动作类型（1=回复评论, 2=点赞评论, 3=点赞回复, 4=点赞首页分享；广播通知为 null）</summary>
    public int? ActionType { get; set; }

    /// <summary>触发者用户 ID（用于去重与"谁"；广播通知为 null）</summary>
    public Guid? ActorUserId { get; set; }

    /// <summary>触发者显示名（广播通知为 null）</summary>
    public string? ActorName { get; set; }

    /// <summary>被互动对象 ID（CommentId/ReplyId/HomepageCommentId；广播通知为 null）</summary>
    public Guid? TargetId { get; set; }

    /// <summary>视频资源键（客户端据此定位；广播通知为 null）</summary>
    public string? ResourceKey { get; set; }

    /// <summary>视频标题（广播通知为 null）</summary>
    public string? ContentTitle { get; set; }
}

/// <summary>
/// 通知服务接口 — 全局唯一通知总线，管理所有通知的发布、查询和标记
/// </summary>
public interface INotificationService
{
    /// <summary>发布一条通知</summary>
    void Publish(AppNotification notification);

    /// <summary>获取通知列表</summary>
    /// <param name="category">按类别过滤，null 表示获取全部</param>
    IReadOnlyList<AppNotification> GetNotifications(NotificationCategory? category = null);

    /// <summary>标记单条为已读</summary>
    void MarkAsRead(Guid id);

    /// <summary>标记某类别全部已读</summary>
    void MarkAllAsRead(NotificationCategory? category = null);

    /// <summary>清空某类别通知</summary>
    void Clear(NotificationCategory? category = null);

    /// <summary>按来源移除通知（用于去重，如远程刷新前清除本地缓存条目）</summary>
    void RemoveBySource(string source);

    /// <summary>未读总数</summary>
    int UnreadCount { get; }

    /// <summary>通知接收事件</summary>
    event Action<AppNotification>? OnNotificationReceived;
}
