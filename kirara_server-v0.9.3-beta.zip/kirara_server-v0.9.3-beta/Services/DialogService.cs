using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Media;
using Windows.UI;
using Windows.UI.Text;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 对话框服务实现 — 基于 WinUI 3 ContentDialog
/// </summary>
public class DialogService : IDialogService
{
    /// <summary>
    /// 获取当前可用的 XamlRoot，优先从 ShellPage 获取
    /// </summary>
    private static XamlRoot? GetXamlRoot()
    {
        return MainWindow.Current?.Content?.XamlRoot;
    }

    public async Task ShowMessageAsync(string title, string message)
    {
        var dialog = new ContentDialog
        {
            Title = string.Empty,
            Content = new StackPanel
            {
                Children =
                {
                    new TextBlock
                    {
                        Text = title,
                        TextWrapping = TextWrapping.Wrap,
                        TextAlignment = TextAlignment.Center,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        FontFamily = new FontFamily("Microsoft YaHei"),
                        FontSize = 20,
                        FontWeight = Microsoft.UI.Text.FontWeights.Normal,
                        CharacterSpacing = 180,
                        Margin = new Thickness(0, -15, 0, 20),
                    },
                    new TextBlock
                    {
                        Text = message,
                        TextWrapping = TextWrapping.Wrap,
                        TextAlignment = TextAlignment.Left,
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                    }
                }
            },
            CloseButtonText = "确定",
            XamlRoot = GetXamlRoot()
        };
        await dialog.ShowAsync();

        // [首页通知] ContentDialog 显示后发布服务通知
        NotificationWiringHelper.PublishDialogNotification(title, message, isError: false);
    }

    public async Task<bool> ShowConfirmAsync(string title, string message)
    {
        var dialog = new ContentDialog
        {
            Title = title,
            Content = message,
            PrimaryButtonText = "确认",
            CloseButtonText = "取消",
            XamlRoot = GetXamlRoot()
        };

        var result = await dialog.ShowAsync();
        return result == ContentDialogResult.Primary;
    }

    /// <summary>
    /// 显示确认对话框（支持居中显示标题和内容）
    /// </summary>
    public async Task<bool> ShowConfirmAsync(string title, string message, bool centerContent)
    {
        var dialog = new ContentDialog
        {
            PrimaryButtonText = "确认",
            CloseButtonText = "取消",
            XamlRoot = GetXamlRoot()
        };

        if (centerContent)
        {
            dialog.Title = string.Empty;
            dialog.Content = new StackPanel
            {
                Children =
                {
                    new TextBlock
                    {
                        Text = title,
                        TextWrapping = TextWrapping.Wrap,
                        TextAlignment = TextAlignment.Center,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        FontFamily = new FontFamily("Microsoft YaHei"),
                        FontSize = 20,
                        FontWeight = Microsoft.UI.Text.FontWeights.Normal,
                        CharacterSpacing = 180,
                        Margin = new Thickness(0, -15, 0, 20),
                    },
                    new TextBlock
                    {
                        Text = message,
                        TextWrapping = TextWrapping.Wrap,
                        TextAlignment = TextAlignment.Center,
                        HorizontalAlignment = HorizontalAlignment.Center,
                    }
                }
            };
        }
        else
        {
            dialog.Title = title;
            dialog.Content = message;
        }

        var result = await dialog.ShowAsync();
        return result == ContentDialogResult.Primary;
    }

    public async Task<string?> ShowInputAsync(string title, string message, string? defaultValue = null)
    {
        var textBox = new TextBox
        {
            Text = defaultValue ?? string.Empty,
            PlaceholderText = message,
            Margin = new Thickness(0, 10, 0, 0)
        };

        var dialog = new ContentDialog
        {
            Title = title,
            Content = textBox,
            PrimaryButtonText = "确定",
            CloseButtonText = "取消",
            XamlRoot = GetXamlRoot()
        };

        var result = await dialog.ShowAsync();
        return result == ContentDialogResult.Primary ? textBox.Text : null;
    }

    public async Task ShowErrorAsync(string title, string message)
    {
        var dialog = new ContentDialog
        {
            Title = string.Empty,
            Content = new StackPanel
            {
                Children =
                {
                    new TextBlock
                    {
                        Text = title,
                        TextWrapping = TextWrapping.Wrap,
                        TextAlignment = TextAlignment.Center,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        FontFamily = new FontFamily("Microsoft YaHei"),
                        FontSize = 20,
                        FontWeight = Microsoft.UI.Text.FontWeights.Normal,
                        CharacterSpacing = 180,
                        Margin = new Thickness(0, -15, 0, 20),
                    },
                    new TextBlock
                    {
                        Text = message,
                        TextWrapping = TextWrapping.Wrap,
                        TextAlignment = TextAlignment.Left,
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                    }
                }
            },
            CloseButtonText = "关闭",
            XamlRoot = GetXamlRoot()
        };
        await dialog.ShowAsync();

        // [首页通知] 错误弹窗 → 发布Error级别服务通知
        NotificationWiringHelper.PublishDialogNotification(title, message, isError: true);
    }

    public async Task<string?> ShowRenameInputAsync(
        string title,
        string currentName,
        Func<string, (bool isValid, string? error)>? validate = null)
    {
        var errorText = new TextBlock
        {
            FontSize = 12,
            Foreground = new SolidColorBrush(Color.FromArgb(255, 0xFF, 0x6B, 0x6B)),
            Margin = new Thickness(0, 4, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Visibility = Visibility.Collapsed,
        };

        var textBox = new TextBox
        {
            Text = currentName,
            PlaceholderText = "请输入新名称",
            MaxLength = 64,
        };

        var content = new StackPanel
        {
            Spacing = 0,
            Children = { textBox, errorText }
        };

        var dialog = new ContentDialog
        {
            Title = title,
            Content = content,
            PrimaryButtonText = "确定",
            CloseButtonText = "取消",
            XamlRoot = GetXamlRoot(),
            IsPrimaryButtonEnabled = false,
        };

        // 实时校验输入
        textBox.TextChanged += (_, _) =>
        {
            var name = textBox.Text;
            string? error = null;
            bool isValid = false;

            if (string.IsNullOrWhiteSpace(name) || name == currentName)
            {
                // 无变化或空值：按钮保持禁用，不显示错误
            }
            else if (validate != null)
            {
                (isValid, error) = validate(name);
            }
            else
            {
                isValid = !string.IsNullOrWhiteSpace(name) && name != currentName;
            }

            dialog.IsPrimaryButtonEnabled = isValid;

            if (error != null)
            {
                errorText.Text = error;
                errorText.Visibility = Visibility.Visible;
            }
            else
            {
                errorText.Visibility = Visibility.Collapsed;
            }
        };

        var result = await dialog.ShowAsync();
        return result == ContentDialogResult.Primary ? textBox.Text : null;
    }

    public async Task<bool> ShowRichConfirmAsync(string title, FrameworkElement content)
    {
        var header = new TextBlock
        {
            Text = title,
            FontSize = 20,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 0, 0, 12),
        };

        var stack = new StackPanel
        {
            Children = { header, content }
        };

        var dialog = new ContentDialog
        {
            Title = string.Empty,
            Content = stack,
            PrimaryButtonText = "确认",
            CloseButtonText = "取消",
            XamlRoot = GetXamlRoot()
        };

        var result = await dialog.ShowAsync();
        return result == ContentDialogResult.Primary;
    }

    /// <summary>
    /// 显示带自定义 UI 内容的确认对话框（支持强制模式）
    /// 样式参照「实例编辑器退出提示框」：主题自适应 + 模态（点击外部/超时均不会关闭）
    /// 非强制模式：确认 + 取消；强制模式：确认 + 「退出软件」（无取消）
    /// </summary>
    public async Task<bool> ShowRichConfirmAsync(string title, FrameworkElement content, string confirmText, bool isMandatory)
    {
        var stack = new StackPanel();

        // 标题非空时才添加（空标题不再产生 12px 空隙）
        if (!string.IsNullOrWhiteSpace(title))
        {
            var header = new TextBlock
            {
                Text = title,
                FontSize = 20,
                FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 12),
            };
            stack.Children.Add(header);
        }

        stack.Children.Add(content);

        // 跟随窗口当前主题（参照 LeftFunctionBar.ShowLeaveEditorDialog）
        var theme = MainWindow.Current?.Content is FrameworkElement root
            ? root.ActualTheme
            : ElementTheme.Default;

        var dialog = new ContentDialog
        {
            Title = string.Empty,
            Content = stack,
            PrimaryButtonText = confirmText,
            XamlRoot = GetXamlRoot(),
            RequestedTheme = theme,
            // 两种模式统一：回车默认触发主按钮（立即更新）
            DefaultButton = ContentDialogButton.Primary,
        };

        if (isMandatory)
        {
            // 强制模式：无取消按钮，Close 按钮改为「退出软件」（返回 None）
            dialog.CloseButtonText = "退出软件";
        }
        else
        {
            dialog.CloseButtonText = "取消";
        }

        var result = await dialog.ShowAsync();
        // 强制模式下：Primary=确认更新（true）；Close=退出软件（false，由调用方处理退出）
        return result == ContentDialogResult.Primary;
    }

    public async Task ShowNotificationFlyoutAsync(FrameworkElement target, string title, string message, bool isError = false)
    {
        var tcs = new TaskCompletionSource();

        var flyout = new Flyout
        {
            Placement = FlyoutPlacementMode.BottomEdgeAlignedRight,
        };

        var root = new StackPanel { Spacing = 12, MinWidth = 240, MaxWidth = 320, Padding = new Thickness(4) };

        // 标题
        root.Children.Add(new TextBlock
        {
            Text = title,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 0, 0, 4),
            FontSize = 16,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
        });

        // 消息正文
        root.Children.Add(new TextBlock
        {
            Text = message,
            TextWrapping = TextWrapping.Wrap,
            FontSize = 14,
            Opacity = 0.8,
        });

        // 确定按钮
        var okBtn = new Button
        {
            Content = "确定",
            Style = (Style)Application.Current.Resources["PrimaryButtonStyle"],
            MinWidth = 100,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 8, 0, 0),
        };
        okBtn.Click += (_, _) =>
        {
            flyout.Hide();
            tcs.TrySetResult();
        };
        root.Children.Add(okBtn);

        flyout.Content = root;
        flyout.ShowAt(target);

        // [首页通知] 飞入式通知 → 发布服务通知
        NotificationWiringHelper.PublishDialogNotification(title, message, isError);

        await tcs.Task;
    }
}
