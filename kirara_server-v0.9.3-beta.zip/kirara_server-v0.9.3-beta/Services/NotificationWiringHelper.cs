using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 通知源连接器 — 将现有的通知源（IDialogService、ILoggingService、App异常）
/// 与全局 INotificationService 总线连接起来。
///
/// 在 App.OnLaunched 中由 ConfigureNotificationSources() 调用一次。
/// </summary>
public static class NotificationWiringHelper
{
    /// <summary>
    /// 是否已经连接通知源（防止重复连接）
    /// </summary>
    private static bool _wired;

    /// <summary>
    /// 连接所有现有通知源到全局通知总线。
    /// 幂等操作 — 多次调用不会重复连接。
    /// </summary>
    public static void Wire(IServiceProvider services)
    {
        if (_wired) return;
        _wired = true;

        var notificationService = services.GetRequiredService<INotificationService>();
        var loggingService = services.GetRequiredService<ILoggingService>();
        var dialogService = services.GetRequiredService<IDialogService>();

        // ---- 源1: ILoggingService → Warning及以上自动转为服务通知 ----
        loggingService.OnLogAdded += entry =>
        {
            if (entry.Level >= LogLevel.Warning)
            {
                var severity = entry.Level switch
                {
                    LogLevel.Warning => NotificationSeverity.Warning,
                    LogLevel.Error or LogLevel.Fatal => NotificationSeverity.Error,
                    _ => NotificationSeverity.Info,
                };

                notificationService.Publish(new AppNotification
                {
                    Category = NotificationCategory.Service,
                    Severity = severity,
                    Title = $"[{entry.Level}] {entry.Source}",
                    Message = entry.Message,
                    Source = entry.Source,
                });
            }
        };

        // ---- 源2: IDialogService — ContentDialog显示时发布轻量通知 ----
        // （通过重构包装模式，在 DialogService 中发布通知。
        //   由于 IDialogService 是已存在的接口无法轻易拦截，
        //   这里提供静态注入方法供 DialogService 自身调用。）
        WireDialogService(notificationService);

        // ---- 源3: App.UnhandledException — 全局异常自动捕获为Error通知 ----
        // （由 App.xaml.cs 中的异常处理器在 OnUnhandledException 中发布）

        System.Diagnostics.Debug.WriteLine("[NotificationWiringHelper] 通知源连接完成");
    }

    /// <summary>
    /// 提供静态入口供 DialogService 发布通知。
    /// DI 容器中无法注入接口，通过此属性声明式注入。
    /// </summary>
    internal static INotificationService? NotificationService { get; set; }

    private static void WireDialogService(INotificationService service)
    {
        NotificationService = service;
    }

    /// <summary>
    /// 由 DialogService 调用，在 ContentDialog 显示时发布一条服务通知。
    /// </summary>
    public static void PublishDialogNotification(string title, string message, bool isError)
    {
        NotificationService?.Publish(new AppNotification
        {
            Category = NotificationCategory.Service,
            Severity = isError ? NotificationSeverity.Error : NotificationSeverity.Info,
            Title = title,
            Message = message,
            Source = "DialogService",
        });
    }
}
