using System.Text.Json;
using Kirara_Server_WinUI.Data;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

public class TokenService : ITokenService
{
    private readonly ITokenRepository _tokenRepo;
    private readonly ICryptoService _crypto;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles
    };

    public TokenService(ITokenRepository tokenRepo, ICryptoService crypto)
    {
        _tokenRepo = tokenRepo;
        _crypto = crypto;
    }

    public IEnumerable<Token> GetAllTokens() =>
        _tokenRepo.GetAll();

    public IEnumerable<Token> GetTokensByUser(Guid userId) =>
        _tokenRepo.GetAll().Where(t => t.OwnerUserId == userId);

    public bool IsTokenNameExists(Guid userId, string name) =>
        _tokenRepo.GetAll().Any(t => t.OwnerUserId == userId && t.Name == name);

    public Token? GetToken(Guid id) =>
        _tokenRepo.GetById(id);

    public Token CreateToken(string name, TokenType type, Guid ownerUserId)
    {
        var token = new Token
        {
            Name = name,
            TokenType = type,
            OwnerUserId = ownerUserId
        };
        _tokenRepo.Insert(token);
        return token;
    }

    public void InsertToken(Token token) =>
        _tokenRepo.Insert(token);

    public void UpdateToken(Token token) =>
        _tokenRepo.Update(token);

    public void DeleteToken(Guid id)
    {
        // 不自动清空 SchemeBinding 中的 TokenId：
        // 悬空的 TokenId 让 UI 可以显示 "⚠令牌已被删除" 警告，
        // 同时 ImportToken 可以复用原始 Id 实现自动重链接。
        _tokenRepo.Delete(id);
    }

    /// <summary>
    /// 安全保存令牌 — 对敏感字段加密后存入数据库
    /// </summary>
    public void SaveSecureToken(Token token)
    {
        if (!_crypto.IsEncrypted(token.AccountName))
            token.AccountName = _crypto.Encrypt(token.AccountName);
        if (!string.IsNullOrEmpty(token.AccountPassword))
            token.AccountPassword = _crypto.Encrypt(token.AccountPassword);
        if (!string.IsNullOrEmpty(token.ApiKey))
            token.ApiKey = _crypto.Encrypt(token.ApiKey);
        if (!string.IsNullOrEmpty(token.ServerUrl) && !_crypto.IsEncrypted(token.ServerUrl))
            token.ServerUrl = _crypto.Encrypt(token.ServerUrl);

        _tokenRepo.Update(token);
    }

    /// <summary>
    /// 安全加载令牌 — 解密敏感字段后返回
    /// </summary>
    public Token? LoadSecureToken(Guid id)
    {
        var token = _tokenRepo.GetById(id);
        if (token == null) return null;

        token.AccountName = _crypto.Decrypt(token.AccountName);
        if (_crypto.IsEncrypted(token.AccountPassword ?? ""))
            token.AccountPassword = _crypto.Decrypt(token.AccountPassword!);
        if (_crypto.IsEncrypted(token.ApiKey ?? ""))
            token.ApiKey = _crypto.Decrypt(token.ApiKey!);
        if (_crypto.IsEncrypted(token.ServerUrl ?? ""))
            token.ServerUrl = _crypto.Decrypt(token.ServerUrl!);
        return token;
    }

        public byte[] ExportToken(Guid id)
    {
        var token = _tokenRepo.GetById(id);
        if (token == null)
            throw new InvalidOperationException("令牌不存在");

        var json = JsonSerializer.Serialize(token, JsonOptions);
        return CryptoService.EncryptWithUid(json, token.OwnerUserId ?? Guid.Empty);
    }

    public Token? ImportToken(byte[] data, Guid currentUserId)
    {
        var json = CryptoService.DecryptWithUid(data, currentUserId);
        var token = JsonSerializer.Deserialize<Token>(json);
        if (token == null) return null;

        // 若原始 Id 未被占用则复用：导出的令牌被删除后重新导入时，
        // 保留原始 Id 可以让所有 SchemeBinding 的悬空 TokenId 自动重新匹配，
        // 无需用户手动逐个方案重新绑定令牌。
        var existing = _tokenRepo.GetById(token.Id);
        if (existing != null)
            token.Id = Guid.NewGuid();

        token.CreatedAt = DateTime.UtcNow;
        token.UpdatedAt = DateTime.UtcNow;

        _tokenRepo.Insert(token);
        return token;
    }
}
