using System;
using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media;
using Windows.UI;
using Kirara_Server_WinUI.Data;
using Kirara_Server_WinUI.Converters;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 应用外观主题服务 — 统一管理「跟随系统 / 明暗主题 / 主题色」三组外观设置。
/// 
/// 三种模式：
/// - 跟随系统（FollowSystem = true）：明暗主题跟随系统（root.RequestedTheme = Default），
///   主题色不覆盖 SystemAccentColor 系列资源，天然跟随 Windows 系统主题色。
/// - 手动明暗（FollowSystem = false）：root.RequestedTheme = Dark/Light。
/// - 手动主题色（FollowSystem = false 且 AccentColor 非空）：
///   在 Application.Resources 中覆盖 SystemAccentColor / Light1-3 / Dark1-3，
///   所有使用 ThemeResource SystemAccentColor 的控件与转换器即时生效。
///
/// 设置持久化于 LiteDB app_settings 集合（%APPDATA%/Kirara/data.db）。
/// </summary>
public class AppThemeService
{
    // ===== 设置键 =====
    private const string KeyFollowSystem = "theme.follow_system";
    private const string KeyIsDark = "theme.is_dark";
    private const string KeyAccent = "theme.accent_color";

    /// <summary>默认主题色：色板第四行第六列（#005B70 深青色）</summary>
    private const string DefaultAccentColorHex = "005B70";

    /// <summary>
    /// WinUI 主题色资源键 — 覆盖这些键即可让整个应用（含 XamlControlsResources 控件模板）使用自定义主题色
    /// </summary>
    private static readonly string[] AccentResourceKeys =
    {
        "SystemAccentColor",
        "SystemAccentColorLight1", "SystemAccentColorLight2", "SystemAccentColorLight3",
        "SystemAccentColorDark1", "SystemAccentColorDark2", "SystemAccentColorDark3",
    };

    /// <summary>
    /// ToggleSwitch 开关轨道主题色键（On 状态填充/描边及其 PointerOver/Pressed/Disabled 态）。
    /// 这些键在 XamlControlsResources 加载时已从 SystemAccentColor 解析，覆盖顶层键才能同步主题色。
    /// </summary>
    private static readonly string[] ToggleSwitchResourceKeys =
    {
        "ToggleSwitchFillOn", "ToggleSwitchFillOnPointerOver", "ToggleSwitchFillOnPressed", "ToggleSwitchFillOnDisabled",
        "ToggleSwitchStrokeOn", "ToggleSwitchStrokeOnPointerOver", "ToggleSwitchStrokeOnPressed", "ToggleSwitchStrokeOnDisabled",
    };

    /// <summary>
    /// RadioButton 选中外圈键（Stroke/Fill × 常规/PointerOver/Pressed/Disabled）：
    /// 按微软 AccentFillColor 语义显式覆盖为主题色（各状态变体），摆脱对
    /// AccentFillColorDefaultBrush → SystemAccentColorLight2/Dark1 间接链的依赖。
    /// 键序与 ApplyControlResourceKeys 约定一致：前 4 = Stroke 系列，后 4 = Fill 系列
    /// （微软默认 Stroke = Fill = 同一 AccentFillColor 系列）。
    /// </summary>
    private static readonly string[] RadioButtonOuterEllipseCheckedKeys =
    {
        "RadioButtonOuterEllipseCheckedStroke",
        "RadioButtonOuterEllipseCheckedStrokePointerOver",
        "RadioButtonOuterEllipseCheckedStrokePressed",
        "RadioButtonOuterEllipseCheckedStrokeDisabled",
        "RadioButtonOuterEllipseCheckedFill",
        "RadioButtonOuterEllipseCheckedFillPointerOver",
        "RadioButtonOuterEllipseCheckedFillPressed",
        "RadioButtonOuterEllipseCheckedFillDisabled",
    };

    /// <summary>
    /// RadioButton 内圆点描边键：保留主题色细描边设计
    /// （微软默认为近透明 CircleElevationBorderBrush）。
    /// 内圆点填充（RadioButtonCheckGlyphFill）不覆盖 ——
    /// 跟随 TextOnAccentFillColorPrimaryBrush（微软方式：浅色黑 / 深色白，自动切换）。
    /// </summary>
    private const string RadioButtonCheckGlyphStrokeKey = "RadioButtonCheckGlyphStroke";

    private readonly IAppSettingsRepository _settings;

    public AppThemeService(IAppSettingsRepository settings)
    {
        _settings = settings;
    }

    /// <summary>
    /// 是否跟随系统明暗主题与主题色（true 时 IsDark / AccentColor 设置被忽略）
    /// 默认关闭：应用使用手动明暗（暗夜）+ 手动主题色
    /// </summary>
    public bool FollowSystem { get; private set; } = false;

    /// <summary>手动模式下的明暗偏好（仅在 FollowSystem = false 时生效）；默认暗夜</summary>
    public bool IsDark { get; private set; } = true;

    /// <summary>
    /// 手动主题色；null 表示使用系统主题色（仅在 FollowSystem = false 时生效）
    /// </summary>
    public Color? AccentColor { get; private set; }

    /// <summary>
    /// 从持久化存储加载外观设置（应用启动时调用，Apply 之前）
    /// </summary>
    /// <summary>
    /// 从持久化存储加载外观设置（应用启动时调用，Apply 之前）
    /// 默认值：不跟随系统 + 暗夜主题 + 主题色 005B70（色板第四行第六列）
    /// </summary>
    public void Load()
    {
        // 跟随系统：默认关闭（首次启动/无设置时不跟随系统）
        FollowSystem = ParseBool(_settings.Get(KeyFollowSystem), false);

        // 明暗偏好：默认暗夜；仅在手动模式下有意义
        var isDarkRaw = _settings.Get(KeyIsDark);
        IsDark = ParseBool(isDarkRaw, true);

        // 主题色：默认 005B70（色板第四行第六列）；null = 跟随系统
        var accentHex = _settings.Get(KeyAccent);
        AccentColor = accentHex is null
            ? Helpers.ColorHelper.TryParseHex(DefaultAccentColorHex)
            : Helpers.ColorHelper.TryParseHex(accentHex);
    }

    /// <summary>
    /// 将当前外观设置应用到应用（主题色资源覆盖 + 根元素 RequestedTheme）。
    /// 可在窗口导航前后安全调用（根元素不存在时仅应用主题色资源）。
    /// </summary>
    public void Apply()
    {
        ApplyAccentResources();

        // 明暗主题：跟随系统时使用 Default（跟随系统），否则手动指定
        var root = MainWindow.Current?.Content as FrameworkElement;
        if (root != null)
        {
            root.RequestedTheme = FollowSystem
                ? ElementTheme.Default
                : (IsDark ? ElementTheme.Dark : ElementTheme.Light);
        }

        // 主题色变化不触发 ActualThemeChanged，需手动刷新缓存了 SystemAccentColor 的转换器
        BoolToHighlightBrushConverter.InvalidateCache();
        InstanceActiveToBrushConverter.InvalidateCache();
        StatusToBrushConverter.InvalidateCache();
    }

    /// <summary>
    /// 设置「跟随系统」开关（持久化 + 立即应用）
    /// </summary>
    public void SetFollowSystem(bool follow)
    {
        FollowSystem = follow;
        _settings.Set(KeyFollowSystem, follow ? "1" : "0");
        Apply();
    }

    /// <summary>
    /// 设置手动明暗偏好（持久化 + 立即应用；跟随系统开启时调用无效）
    /// </summary>
    public void SetIsDark(bool isDark)
    {
        IsDark = isDark;
        _settings.Set(KeyIsDark, isDark ? "1" : "0");
        if (!FollowSystem)
            Apply();
    }

    /// <summary>
    /// 设置手动主题色（持久化 + 立即应用；color 为 null 表示使用系统主题色；跟随系统开启时调用无效）
    /// </summary>
    public void SetAccentColor(Color? color)
    {
        AccentColor = color;
        _settings.Set(KeyAccent, color.HasValue ? Helpers.ColorHelper.ToHex(color.Value) : null);
        if (!FollowSystem)
            Apply();
    }

    /// <summary>
    /// 覆盖/移除 Application.Resources 中的 SystemAccentColor 系列资源，并同步更新
    /// AppStyles.xaml 的桥接画刷（KiraraAccentColorBrush 等）以及 ToggleSwitch / RadioButton
    /// 等控件的主题色资源键（开关轨道填充、选择圆点填充）。
    /// FollowSystem 或 AccentColor 为 null 时移除覆盖（恢复系统主题色）。
    /// </summary>
    private void ApplyAccentResources()
    {
        var resources = Application.Current.Resources;
        var custom = (!FollowSystem && AccentColor.HasValue) ? AccentColor.Value : (Color?)null;

        if (custom.HasValue)
        {
            resources["SystemAccentColor"] = custom.Value;
            resources["SystemAccentColorLight1"] = MixWith(custom.Value, Colors.White, 0.2f);
            resources["SystemAccentColorLight2"] = MixWith(custom.Value, Colors.White, 0.4f);
            resources["SystemAccentColorLight3"] = MixWith(custom.Value, Colors.White, 0.6f);
            resources["SystemAccentColorDark1"] = MixWith(custom.Value, Colors.Black, 0.2f);
            resources["SystemAccentColorDark2"] = MixWith(custom.Value, Colors.Black, 0.4f);
            resources["SystemAccentColorDark3"] = MixWith(custom.Value, Colors.Black, 0.6f);

            // ToggleSwitch 开关轨道：On 填充/描边及其各状态色
            ApplyControlResourceKeys(resources, ToggleSwitchResourceKeys,
                fill: custom.Value,
                hover: MixWith(custom.Value, Colors.White, 0.2f),
                pressed: MixWith(custom.Value, Colors.Black, 0.2f),
                disabled: Desaturate(custom.Value));

            // RadioButton 选中外圈：显式覆盖为主题色各状态变体（微软 AccentFillColor 语义），
            // 内圆点填充不覆盖（跟随 TextOnAccentFillColorPrimaryBrush，浅色黑/深色白自动切换），
            // 内圆点描边保留主题色细描边设计
            ApplyControlResourceKeys(resources, RadioButtonOuterEllipseCheckedKeys,
                fill: custom.Value,
                hover: MixWith(custom.Value, Colors.White, 0.2f),
                pressed: MixWith(custom.Value, Colors.Black, 0.2f),
                disabled: Desaturate(custom.Value));
            resources[RadioButtonCheckGlyphStrokeKey] = new SolidColorBrush(custom.Value);
        }
        else
        {
            // 恢复跟随系统：移除覆盖，让 XamlControlsResources 提供系统主题色
            foreach (var key in AccentResourceKeys)
            {
                if (resources.ContainsKey(key))
                    resources.Remove(key);
            }
            foreach (var key in ToggleSwitchResourceKeys)
            {
                if (resources.ContainsKey(key))
                    resources.Remove(key);
            }
            foreach (var key in RadioButtonOuterEllipseCheckedKeys)
            {
                if (resources.ContainsKey(key))
                    resources.Remove(key);
            }
            if (resources.ContainsKey(RadioButtonCheckGlyphStrokeKey))
                resources.Remove(RadioButtonCheckGlyphStrokeKey);
        }

        // ===== 同步更新 AppStyles.xaml 桥接画刷 =====
        // KiraraAccentColorBrush.Color 绑定的 {ThemeResource SystemAccentColor} 在 XAML
        // 加载时解析一次，资源键被 Set/Remove 后不会刷新（ThemeResource 不监听顶层键变化）。
        // 因此直接修改共享 SolidColorBrush 实例的 Color —— PrimaryButtonStyle 等
        // 通过 StaticResource 引用的正是同一 brush 实例，改色即时全局生效。
        var accent = ReadSystemAccent(resources);
        SetBrushColor(resources, "KiraraAccentColorBrush", accent);
        SetBrushColor(resources, "KiraraAccentLight2Brush", MixWith(accent, Colors.White, 0.4f));
        SetBrushColor(resources, "KiraraAccentDark2Brush", MixWith(accent, Colors.Black, 0.4f));
    }

    /// <summary>
    /// 按「Fill(常规) / Fill+Stroke(PointerOver) / Fill+Stroke(Pressed) / Fill+Stroke(Disabled)」
    /// 的 WinUI 命名约定写入控件主题色资源键。
    /// 模板中引用的键存在于 XamlControlsResources，顶层覆盖后 ThemeResource 解析命中顶层值。
    /// </summary>
    private static void ApplyControlResourceKeys(
        ResourceDictionary resources,
        string[] keys,
        Color fill,
        Color hover,
        Color pressed,
        Color disabled)
    {
        // 键序约定：{X}, {X}PointerOver, {X}Pressed, {X}Disabled, {X}Stroke, {X}StrokePointerOver, {X}StrokePressed, {X}StrokeDisabled
        resources[keys[0]] = new SolidColorBrush(fill);
        resources[keys[1]] = new SolidColorBrush(hover);
        resources[keys[2]] = new SolidColorBrush(pressed);
        resources[keys[3]] = new SolidColorBrush(disabled);
        resources[keys[4]] = new SolidColorBrush(fill);
        resources[keys[5]] = new SolidColorBrush(hover);
        resources[keys[6]] = new SolidColorBrush(pressed);
        resources[keys[7]] = new SolidColorBrush(disabled);
    }

    /// <summary>
    /// 颜色降饱和 — 向灰度方向混合（60% 灰度 + 40% 原色），用于禁用态
    /// </summary>
    private static Color Desaturate(Color color)
    {
        float gray = 0.299f * color.R + 0.587f * color.G + 0.114f * color.B;
        return Color.FromArgb(color.A,
            (byte)(gray * 0.6f + color.R * 0.4f),
            (byte)(gray * 0.6f + color.G * 0.4f),
            (byte)(gray * 0.6f + color.B * 0.4f));
    }

    /// <summary>
    /// 读取当前生效的系统主题色（跟随系统时来自 XamlControlsResources；覆盖时来自自定义值）
    /// </summary>
    private static Color ReadSystemAccent(ResourceDictionary resources)
    {
        try
        {
            if (resources.TryGetValue("SystemAccentColor", out var value) && value is Color color)
                return color;
        }
        catch { /* 资源不可用走兜底 */ }
        return Color.FromArgb(0xFF, 0x00, 0x78, 0xD4);
    }

    /// <summary>
    /// 修改资源字典中 SolidColorBrush 的颜色（共享实例，引用方即时生效）
    /// </summary>
    private static void SetBrushColor(ResourceDictionary resources, string key, Color color)
    {
        try
        {
            if (resources[key] is SolidColorBrush brush)
                brush.Color = color;
        }
        catch { /* 画刷不存在时忽略（资源未加载） */ }
    }

    /// <summary>
    /// 颜色混合 — 向基础色按比例混入目标色（ratio=0 返回基础色，ratio=1 返回目标色）
    /// </summary>
    private static Color MixWith(Color baseColor, Color target, float ratio)
    {
        byte MixByte(byte a, byte b) => (byte)Math.Round(a + (b - a) * ratio);
        return Color.FromArgb(
            baseColor.A,
            MixByte(baseColor.R, target.R),
            MixByte(baseColor.G, target.G),
            MixByte(baseColor.B, target.B));
    }

    /// <summary>解析 "1"/"true" → true；"0"/"false" → false；其他 → defaultValue</summary>
    private static bool ParseBool(string? raw, bool defaultValue)
    {
        if (raw is null)
            return defaultValue;
        if (raw is "1" or "true" or "True")
            return true;
        if (raw is "0" or "false" or "False")
            return false;
        return defaultValue;
    }
}
