using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

public interface ITokenService
{
    IEnumerable<Token> GetAllTokens();
    IEnumerable<Token> GetTokensByUser(Guid userId);
    bool IsTokenNameExists(Guid userId, string name);
    Token? GetToken(Guid id);
    Token CreateToken(string name, TokenType type, Guid ownerUserId);
    void InsertToken(Token token);
    void UpdateToken(Token token);
    void DeleteToken(Guid id);

    // 加密存储
    void SaveSecureToken(Token token);
    Token? LoadSecureToken(Guid id);

    // 导入导出
    byte[] ExportToken(Guid id);
    Token? ImportToken(byte[] data, Guid currentUserId);
}