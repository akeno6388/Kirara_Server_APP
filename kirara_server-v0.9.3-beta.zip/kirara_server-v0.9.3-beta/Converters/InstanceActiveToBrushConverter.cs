using Microsoft.UI;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// 实例 ID → 高亮画刷转换器
/// 当绑定的实例 ID 与当前激活实例 ID 匹配时返回主题色高亮，否则返回透明
/// </summary>
public class InstanceActiveToBrushConverter : IValueConverter
{
    /// <summary>当前左侧栏激活的实例 ID（由 LeftFunctionBarViewModel 同步设置）</summary>
    public static Guid ActiveInstanceId { get; set; }

    private static SolidColorBrush? _highlightBrush;

    /// <summary>获取主题色半透明画刷（懒加载，跟随系统主题）</summary>
    private static SolidColorBrush HighlightBrush
    {
        get
        {
            if (_highlightBrush == null)
            {
                var accent = (Color)Microsoft.UI.Xaml.Application.Current.Resources["SystemAccentColor"];
                _highlightBrush = new SolidColorBrush(Color.FromArgb(0xAA, accent.R, accent.G, accent.B));
            }
            return _highlightBrush;
        }
    }

    private static readonly SolidColorBrush TransparentBrush = new(Colors.Transparent);

    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is Guid instanceId && instanceId == ActiveInstanceId && instanceId != Guid.Empty)
            return HighlightBrush;
        return TransparentBrush;
    }

    /// <summary>
    /// 主题切换时调用，清除缓存画刷，下次 Convert 时重新读取 SystemAccentColor
    /// </summary>
    public static void InvalidateCache()
    {
        _highlightBrush = null;
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language) =>
        throw new NotSupportedException();
}
