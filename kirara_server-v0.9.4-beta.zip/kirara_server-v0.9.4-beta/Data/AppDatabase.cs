using System.Reflection;
using LiteDB;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Schemes;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.Data;

/// <summary>
/// LiteDB 数据库封装 — 管理数据库实例、集合初始化和种子数据
/// </summary>
public class AppDatabase : IDisposable
{
    private readonly LiteDatabase _db;
    private readonly ICryptoService _crypto;

    public AppDatabase(ICryptoService crypto)
    {
        _crypto = crypto;
        var dbPath = GetDatabasePath();
        var directory = Path.GetDirectoryName(dbPath);
        if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
        {
            Directory.CreateDirectory(directory);
        }

        _db = new LiteDatabase($"Filename={dbPath};Connection=direct");
        Initialize();
    }

    /// <summary>
    /// 获取数据库文件路径 (%APPDATA%/Kirara/data.db)
    /// </summary>
    private static string GetDatabasePath()
    {
        var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        return Path.Combine(appData, "Kirara", "data.db");
    }

    /// <summary>
    /// 初始化数据库集合和种子数据
    /// </summary>
    private void Initialize()
    {
        // 确保集合存在
        _db.GetCollection<Instance>("instances");
        _db.GetCollection<Scheme>("schemes");
        _db.GetCollection<Token>("tokens");
        _db.GetCollection<ServerUrlRecord>("server_urls");
        _db.GetCollection<CommentItem>("comments");
        _db.GetCollection<AppSettingsRecord>("app_settings");

        // 首次启动时写入种子数据
        SeedBuiltInSchemes();
        SeedBuiltInServerUrls();
    }

    /// <summary>
    /// 写入内置服务器 URL 注册记录 — 集中管理所有服务端地址
    /// 所有 URL 在落盘前经 AES-256-GCM 加密（与 ServerUrlService 写入路径保持一致），
    /// 明文永不落盘；MigratePlaintextUrls() 仅作为旧版本明文数据的兼容兜底。
    /// 后续可通过在线同步功能批量更新
    /// </summary>
    private void SeedBuiltInServerUrls()
    {
        var urls = _db.GetCollection<ServerUrlRecord>("server_urls");
        if (urls.Count() > 0)
            return;

        var builtInUrls = new List<ServerUrlRecord>
        {
            // ===== 基础设施 URL =====
            new() { Key = "auth_api",     DisplayName = "认证 API 服务地址",       Url = "https://api.akeno6388.online:1010",          SchemeName = null,           Category = "Infrastructure" },
            new() { Key = "home_background", DisplayName = "首页背景图片源",       Url = string.Empty,                               SchemeName = null,           Category = "Background" },
            new() { Key = "user_avatar",  DisplayName = "用户头像服务",           Url = string.Empty,                               SchemeName = null,           Category = "User" },

            // ===== UserInstance 用户实例方案 URL（Key 必须与方案类的 Name/DefaultUrlKey 一致）=====
            new() { Key = "media",      DisplayName = "Kirara Media",           Url = "https://media.akeno6388.online:1010",     SchemeName = "media",      Category = "WebView2" },
            new() { Key = "srslive",    DisplayName = "Kirara Live",            Url = "https://live.akeno6388.online:1010",      SchemeName = "srslive",    Category = "WebView2" },
            new() { Key = "drive",      DisplayName = "Kirara 团队共享云",       Url = "https://drive.akeno6388.online:1010",     SchemeName = "drive",      Category = "WebView2" },
            new() { Key = "kmail",      DisplayName = "Kmail 邮件服务",          Url = "https://kmail.akeno6388.online:1010",     SchemeName = "kmail",      Category = "WebView2" },
            new() { Key = "chat",       DisplayName = "Chat 团队协作",           Url = "https://chat.akeno6388.online:1010",      SchemeName = "chat",       Category = "WebView2" },
            new() { Key = "vmm",        DisplayName = "Vmm 虚拟化平台",          Url = "https://vmm.akeno6388.online:1010",       SchemeName = "vmm",        Category = "WebView2" },
            new() { Key = "alist",      DisplayName = "Kirara Alist",            Url = "https://alist.akeno6388.online:1010",     SchemeName = "alist",      Category = "WebView2" },
            new() { Key = "note",       DisplayName = "猫又云记",               Url = "https://note.akeno6388.online:1010",      SchemeName = "note",       Category = "WebView2" },
            new() { Key = "moment",     DisplayName = "三月相册",               Url = "https://moment.akeno6388.online:1010",    SchemeName = "moment",     Category = "WebView2" },

            // ===== ServiceInstance 服务实例方案 URL（Key 必须与方案类的 Name/DefaultUrlKey 一致）=====
            new() { Key = "appserver",    DisplayName = "APP Server 管理",        Url = "https://app.akeno6388.online:1010",       SchemeName = "appserver",    Category = "WebView2" },
            new() { Key = "backupserver", DisplayName = "Backup Server 管理",     Url = "https://bkup.akeno6388.online:1010",      SchemeName = "backupserver", Category = "WebView2" },
            new() { Key = "esxi",         DisplayName = "ESXi 管理",              Url = "https://esxi.akeno6388.online:1010",      SchemeName = "esxi",         Category = "WebView2" },
            new() { Key = "ikuai",        DisplayName = "iKuai 管理",             Url = "https://ikuai.akeno6388.online:1010",     SchemeName = "ikuai",        Category = "WebView2" },
            new() { Key = "openwrt",      DisplayName = "OpenWrt 管理",           Url = "https://opwrt.akeno6388.online:1010",     SchemeName = "openwrt",      Category = "WebView2" },
            new() { Key = "imm",          DisplayName = "IMM 管理",               Url = "https://imm.akeno6388.online:1010",       SchemeName = "imm",          Category = "WebView2" },
            new() { Key = "cert",         DisplayName = "Cert 证书签发平台",       Url = "https://cert.kiraramoe.me/certsrv/",      SchemeName = "cert",         Category = "WebView2" },
            new() { Key = "bitcomet",     DisplayName = "BitComet",                Url = "https://bitc.akeno6388.online:1010/webui/", SchemeName = "bitcomet",  Category = "WebView2" },

            // ===== RDP 方案（IP 地址，Key 必须与方案类的 Name/DefaultUrlKey 一致）=====
            new() { Key = "winserver-dc", DisplayName = "Winserver-DC 管理",      Url = "10.10.10.3",                              SchemeName = "winserver-dc", Category = "RDP" },
            new() { Key = "winserver-ac", DisplayName = "Winserver-AC 管理",      Url = "10.10.10.9",                              SchemeName = "winserver-ac", Category = "RDP" },
            new() { Key = "winserver-dl", DisplayName = "Winserver-DL 管理",      Url = "10.10.10.13",                             SchemeName = "winserver-dl", Category = "RDP" },
            new() { Key = "winserver-gn", DisplayName = "Winserver-GN 管理",      Url = "10.10.10.10",                             SchemeName = "winserver-gn", Category = "RDP" },
        };

        // 加密所有种子 URL 后再落盘（空字符串跳过，Encrypt 对空串返回空串）
        foreach (var record in builtInUrls)
        {
            if (!string.IsNullOrEmpty(record.Url) && !_crypto.IsEncrypted(record.Url))
            {
                record.Url = _crypto.Encrypt(record.Url);
            }
        }

        urls.InsertBulk(builtInUrls);
        System.Diagnostics.Debug.WriteLine($"[AppDatabase] 已写入 {builtInUrls.Count} 条内置 URL 注册记录（已加密）");
    }

    /// <summary>
    /// 写入内置方案数据 — 通过反射自动扫描所有 BaseScheme 子类
    /// 新增方案只需在 Schemes/ 下创建类，无需修改此方法
    /// </summary>
    private void SeedBuiltInSchemes()
    {
        var schemes = _db.GetCollection<Scheme>("schemes");
        if (schemes.Count() > 0)
            return;

        var builtInSchemes = typeof(BaseScheme).Assembly
            .GetTypes()
            .Where(t => t.IsClass && !t.IsAbstract && t.IsSubclassOf(typeof(BaseScheme)))
            .Select(t =>
            {
                var instance = (BaseScheme)Activator.CreateInstance(t)!;
                var ui = instance.GetUI();
                return new Scheme
                {
                    Id = instance.Id,
                    Name = instance.Name,
                    DisplayName = instance.DisplayName,
                    Description = instance.Description,
                    // 按适用实例类型区分方案来源：用户实例方案为 BuiltIn，服务实例方案为 Server
                    SchemeType = instance.InstanceType == InstanceType.ServiceInstance
                        ? SchemeType.Server
                        : SchemeType.BuiltIn,
                    InstanceType = instance.InstanceType,
                    UIKind = instance.UIKind,
                    IconGlyph = instance.IconGlyph,
                    EntryAssembly = t.Assembly.GetName().Name,
                    EntryTypeName = t.FullName,
                    WebViewUrl = ui.WebViewUrl,
                    RequiresRdp = ui.Kind == SchemeUIKind.RDP,
                    IsSystem = true,
                    SortOrder = instance.SortOrder
                };
            })
            .ToList();

        schemes.InsertBulk(builtInSchemes);
    }

    // ===== 公开集合访问器 =====

    public ILiteCollection<Instance> Instances => _db.GetCollection<Instance>("instances");
    public ILiteCollection<Scheme> Schemes => _db.GetCollection<Scheme>("schemes");
    public ILiteCollection<Token> Tokens => _db.GetCollection<Token>("tokens");
    public ILiteCollection<ServerUrlRecord> ServerUrlRecords => _db.GetCollection<ServerUrlRecord>("server_urls");
    public ILiteCollection<CommentItem> Comments => _db.GetCollection<CommentItem>("comments");
    public ILiteCollection<AppSettingsRecord> AppSettings => _db.GetCollection<AppSettingsRecord>("app_settings");

    public void Dispose()
    {
        _db?.Dispose();
    }
}
