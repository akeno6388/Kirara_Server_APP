using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 安全缓存服务 — 为所有服务器资源缓存提供加密存储与篡改检测。
///
/// ## 两种存储方案
///
/// ### 方案A（全量加密合并）— 适合小体积文件
/// 头像 / 背景图 / 模板封面 / 方案图标 / .ovpn 配置 / 模板列表 JSON
/// ```text
/// 单个文件（扩展名 .enc）= AES-256-GCM 密文
///   密文格式: [nonce:12B][tag:16B][cipher]（复用 CryptoService.EncryptToBytes）
///   明文结构: { "etag": "...", "version": N, "contentBase64": "..." }
/// ```
/// - ETag/版本号与内容绑定在同一密文中：攻击者无法只改 ETag 或只改内容
/// - 任何篡改 → GCM 认证标签校验失败 → 解密抛异常 → 视为缓存不可信，重新下载
/// - 密钥由 DPAPI 保护的 AES-256-GCM 密钥（CryptoService），攻击者无法伪造合法密文
///
/// ### 方案B（内容明文 + 加密 meta）— 适合大体积媒体
/// 信息流图片 / 视频 / HTML
/// ```text
/// 内容文件: 明文（UI / MediaPlayerElement / WebView2 按路径直接加载）
/// meta 文件: {contentPath}.meta = AES-256-GCM 加密 { "sha256": "...", "etag": "...", "version": N }
/// ```
/// - 读取时：解密 meta（被篡改 → 解密失败）→ 计算内容 SHA256 比对（被篡改 → 不匹配）
/// - meta 加密保证攻击者无法把篡改后的新哈希写进 meta（无密钥无法伪造密文）
///
/// ## 临时明文（方案A）
/// 方案A的图片/配置文件解密后写入 %APPDATA%/Kirara/tmp/ 供 UI / openvpn.exe 加载，
/// 应用启动时调用 <see cref="CleanupTempDirectory"/> 清理上次会话残留。
///
/// ## 旧格式兼容
/// 旧明文缓存（.png/.jpg/.meta/.txt/templates.json）无加密前缀，
/// TryReadEnvelope 解密必然失败 → 返回 false → 调用方删除旧文件并重新下载。
/// </summary>
public class SecureCacheService
{
    private readonly ICryptoService _crypto;

    /// <summary>加密缓存统一扩展名</summary>
    public const string EncryptedExtension = ".enc";

    /// <summary>临时明文目录（%APPDATA%/Kirara/tmp/）</summary>
    public static readonly string TempDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "tmp");

    public SecureCacheService(ICryptoService crypto)
    {
        _crypto = crypto;
    }

    // ================================================================
    //  方案A：全量加密合并
    // ================================================================

    /// <summary>方案A信封明文结构</summary>
    private class Envelope
    {
        public string Etag { get; set; } = string.Empty;
        public int Version { get; set; }
        public string ContentBase64 { get; set; } = string.Empty;
    }

    /// <summary>
    /// 方案A写入：内容 + ETag/版本 合并加密为单文件（原子写入 .tmp → Move）。
    /// </summary>
    public void SaveEnvelope(string cachePath, byte[] content, string? etag = null, int version = 0)
    {
        var payload = new Envelope
        {
            Etag = etag ?? string.Empty,
            Version = version,
            ContentBase64 = Convert.ToBase64String(content)
        };
        var json = JsonSerializer.Serialize(payload);
        var encrypted = _crypto.EncryptToBytes(json);

        var dir = Path.GetDirectoryName(cachePath);
        if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            Directory.CreateDirectory(dir);

        var tmpPath = cachePath + ".tmp";
        File.WriteAllBytes(tmpPath, encrypted);
        if (File.Exists(cachePath))
            File.Delete(cachePath);
        File.Move(tmpPath, cachePath);
    }

    /// <summary>
    /// 方案A读取：解密并校验完整性。
    /// 返回 false = 文件不存在 / 被篡改 / 损坏 / 旧明文格式 → 调用方应删除并重新下载。
    /// </summary>
    public bool TryReadEnvelope(string cachePath, out byte[] content, out string etag, out int version)
    {
        content = Array.Empty<byte>();
        etag = string.Empty;
        version = 0;

        try
        {
            if (!File.Exists(cachePath))
                return false;

            var encrypted = File.ReadAllBytes(cachePath);
            var json = _crypto.DecryptFromBytes(encrypted);   // 篡改/旧明文 → 抛异常
            var payload = JsonSerializer.Deserialize<Envelope>(json);
            if (payload == null)
                return false;

            content = Convert.FromBase64String(payload.ContentBase64);
            etag = payload.Etag;
            version = payload.Version;
            return true;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// 方案A解密到临时明文文件，返回临时文件路径（供 UI / 外部进程加载）。
    /// 解密失败（篡改/损坏/缺失）返回 null。
    /// </summary>
    public string? DecryptToTempFile(string cachePath, string tempFileName)
    {
        if (!TryReadEnvelope(cachePath, out var content, out _, out _))
            return null;
        return WriteTempFile(tempFileName, content);
    }

    // ================================================================
    //  方案B：内容明文 + 加密 meta
    // ================================================================

    /// <summary>方案B meta 明文结构</summary>
    private class Meta
    {
        public string Sha256 { get; set; } = string.Empty;
        public string Etag { get; set; } = string.Empty;
        public int Version { get; set; }
    }

    /// <summary>方案B meta 文件路径（内容文件旁，{path}.meta）</summary>
    public static string GetMetaPath(string contentPath) => contentPath + ".meta";

    /// <summary>
    /// 方案B写入：内容明文落盘 + 加密 meta（SHA256 + ETag/版本）。
    /// 先写内容（原子）再写 meta（原子）——meta 最后存在代表内容已完整落盘。
    /// </summary>
    public void SaveWithMeta(string contentPath, byte[] content, string? etag = null, int version = 0)
    {
        var dir = Path.GetDirectoryName(contentPath);
        if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            Directory.CreateDirectory(dir);

        // 1. 内容原子写入
        var tmpContent = contentPath + ".tmp";
        File.WriteAllBytes(tmpContent, content);
        if (File.Exists(contentPath))
            File.Delete(contentPath);
        File.Move(tmpContent, contentPath);

        // 2. meta 原子写入（最后写：meta 存在 = 内容完整）
        var meta = new Meta
        {
            Sha256 = ComputeSha256(content),
            Etag = etag ?? string.Empty,
            Version = version
        };
        var metaJson = JsonSerializer.Serialize(meta);
        var encryptedMeta = _crypto.EncryptToBytes(metaJson);

        var metaPath = GetMetaPath(contentPath);
        var tmpMeta = metaPath + ".tmp";
        File.WriteAllBytes(tmpMeta, encryptedMeta);
        if (File.Exists(metaPath))
            File.Delete(metaPath);
        File.Move(tmpMeta, metaPath);
    }

    /// <summary>
    /// 方案B校验：解密 meta（防伪造）+ SHA256 比对（防篡改）。
    /// true = 内容未被篡改；false = meta 被篡改 / 内容被篡改 / 文件缺失。
    /// </summary>
    public bool VerifyWithMeta(string contentPath)
    {
        try
        {
            if (!File.Exists(contentPath))
                return false;

            var metaPath = GetMetaPath(contentPath);
            if (!File.Exists(metaPath))
                return false;

            var encryptedMeta = File.ReadAllBytes(metaPath);
            var metaJson = _crypto.DecryptFromBytes(encryptedMeta);   // meta 被篡改 → 抛异常
            var meta = JsonSerializer.Deserialize<Meta>(metaJson);
            if (meta == null || string.IsNullOrEmpty(meta.Sha256))
                return false;

            // 重新计算内容 SHA256 比对
            var actualHash = ComputeSha256(File.ReadAllBytes(contentPath));
            return string.Equals(actualHash, meta.Sha256, StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            return false;
        }
    }

    // ================================================================
    //  删除
    // ================================================================

    /// <summary>删除方案A加密缓存</summary>
    public void Delete(string cachePath)
    {
        try { if (File.Exists(cachePath)) File.Delete(cachePath); } catch { }
    }

    /// <summary>删除方案B内容文件 + meta 文件</summary>
    public void DeleteWithMeta(string contentPath)
    {
        Delete(contentPath);
        try { if (File.Exists(GetMetaPath(contentPath))) File.Delete(GetMetaPath(contentPath)); } catch { }
    }

    // ================================================================
    //  临时明文目录管理
    // ================================================================

    /// <summary>确保临时目录存在</summary>
    public static void EnsureTempDirectory()
    {
        if (!Directory.Exists(TempDirectory))
            Directory.CreateDirectory(TempDirectory);
    }

    /// <summary>直接写入临时明文文件（调用方已持有明文内容），返回路径</summary>
    public string WriteTempFile(string tempFileName, byte[] content)
    {
        EnsureTempDirectory();
        var tempPath = Path.Combine(TempDirectory, tempFileName);

        // 原子写入
        var tmpPath = tempPath + ".tmp";
        File.WriteAllBytes(tmpPath, content);
        if (File.Exists(tempPath))
            File.Delete(tempPath);
        File.Move(tmpPath, tempPath);
        return tempPath;
    }

    /// <summary>清空临时目录（应用启动时调用，清理上次会话残留的明文文件）</summary>
    public static void CleanupTempDirectory()
    {
        try
        {
            if (!Directory.Exists(TempDirectory)) return;
            foreach (var file in Directory.GetFiles(TempDirectory))
            {
                try { File.Delete(file); } catch { }
            }
        }
        catch { }
    }

    // ================================================================
    //  工具
    // ================================================================

    /// <summary>计算内容 SHA256（小写十六进制）</summary>
    public static string ComputeSha256(byte[] data)
    {
        var hash = SHA256.HashData(data);
        return Convert.ToHexStringLower(hash);
    }
}
