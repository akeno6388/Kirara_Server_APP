using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Models.Api;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 评论服务接口 — 管理评论和回复的 CRUD 操作
/// 所有数据操作通过远程 API 完成
/// </summary>
public interface ICommentService
{
    /// <summary>按资源键获取评论列表（分页，跨方案查询）</summary>
    /// <param name="resourceKey">资源标识键</param>
    /// <param name="page">页码（从 1 开始）</param>
    /// <param name="pageSize">每页条数</param>
    Task<IReadOnlyList<CommentItem>> GetCommentsAsync(string resourceKey, int page = 1, int pageSize = 20);

    /// <summary>添加新评论（authorName 由服务端从 JWT 解析）</summary>
    /// <param name="resourceKey">资源标识键</param>
    /// <param name="schemeId">所属方案 ID</param>
    /// <param name="content">评论内容</param>
    /// <param name="contentTitle">视频标题（可选，用于互动通知文案，≤500 字符）</param>
    Task<CommentItem> AddCommentAsync(string resourceKey, Guid schemeId, string content, string? contentTitle = null);

    /// <summary>切换评论点赞状态，返回服务端最新结果</summary>
    Task<LikeResult> ToggleLikeCommentAsync(Guid commentId);

    /// <summary>添加回复（authorName 由服务端从 JWT 解析）</summary>
    /// <param name="commentId">父评论 ID</param>
    /// <param name="content">回复内容</param>
    /// <param name="contentTitle">视频标题（可选，用于互动通知文案；服务端优先用此值，空时回退父评论继承）</param>
    Task<ReplyItem> AddReplyAsync(Guid commentId, string content, string? contentTitle = null);

    /// <summary>切换回复点赞状态，返回服务端最新结果</summary>
    Task<LikeResult> ToggleLikeReplyAsync(Guid commentId, Guid replyId);

    /// <summary>删除评论</summary>
    Task DeleteCommentAsync(Guid commentId);

    /// <summary>删除回复</summary>
    Task DeleteReplyAsync(Guid commentId, Guid replyId);
}
