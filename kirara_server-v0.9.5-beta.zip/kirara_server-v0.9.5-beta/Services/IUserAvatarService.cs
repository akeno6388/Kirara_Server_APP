using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 用户头像管理服务接口
///
/// 资源获取链（与 BackgroundService 一致）:
/// Step1: 检查本地缓存 %APPDATA%/Kirara/avatars/{userId}.png
/// Step2: 通过 ServerUrlService.GetDecryptedUrl("user_avatar") 获取服务器URL
/// Step3: 降级为 null（UI 层使用内置 Glyph="&#xE77B;" 兜底）
/// </summary>
public interface IUserAvatarService
{
    /// <summary>当前头像的本地文件路径（null 表示无可用头像，UI 应降级为 Glyph 图标）</summary>
    string? CurrentAvatarPath { get; }

    /// <summary>是否正在加载</summary>
    bool IsLoading { get; }

    /// <summary>
    /// 初始化：从缓存加载 → 后台尝试服务器同步
    /// </summary>
    Task InitializeAsync();

    /// <summary>
    /// 上传头像图片到服务器并更新本地缓存。
    /// 图片会自动居中裁剪为 70×70 像素。
    /// </summary>
    /// <param name="imageBytes">原始图片字节数据</param>
    /// <returns>(是否成功, 错误消息)</returns>
    Task<(bool success, string? error)> UploadAvatarAsync(byte[] imageBytes);

    /// <summary>头像变更事件</summary>
    event Action<string?>? AvatarChanged;
}
