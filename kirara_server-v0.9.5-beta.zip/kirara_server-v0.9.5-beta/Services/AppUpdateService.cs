using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Kirara_Server_WinUI.Helpers;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Media;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 应用更新检查结果 — 供设置页「更新管理」显示检查反馈
/// </summary>
public enum UpdateCheckResult
{
    /// <summary>已有检查在进行中（如登录后的自动检查）</summary>
    Checking = 0,

    /// <summary>已是最新版本，无需更新</summary>
    UpToDate = 1,

    /// <summary>发现新版本（更新弹窗已弹出）</summary>
    UpdateAvailable = 2,

    /// <summary>检查失败（网络异常 / 服务器不可达 / 响应异常）</summary>
    Failed = 3,
}

/// <summary>
/// 应用自动更新服务 — 每次成功登录后检查服务器是否存在新版本（GET /api/app/updates/latest）。
///
/// ## 行为
/// - 订阅 <see cref="ILoginService.LoginStateChanged"/>：登录成功（手动 / 自动 / 注册后登录）
///   均触发 fire-and-forget 更新检查
/// - 存在新版本 → 弹窗提示（版本号 + 更新说明 + 强制更新标记）→ 用户确认 → 下载安装包
/// - 安装包下载到 %APPDATA%/Kirara/updates/ → SHA256 校验（防下载劫持）→
///   弹窗确认（是否关闭当前程序进行自动更新）→ 拉起 Inno 安装器（非静默，显示安装向导窗口，
///   /AUTOUPDATE 模式自动推进向导，完成后自动关闭并启动应用）→ 关闭应用走完整清理链
///
/// ## 错误处理（与 SyncSchemeUrlsAsync 一致）
/// 网络异常 / 超时 / 解析失败 → 静默降级（仅 Debug 日志），不影响正常使用。
///
/// ## API 规范
/// - Endpoint: GET /api/app/updates/latest?current={语义化版本}（公开端点，无需认证）
/// - 响应: ApiResponse&lt;AppUpdateResponseData&gt;（hasUpdate / latestVersion / downloadUrl /
///   sha256 / releaseNotes / isMandatory / publishedAt）
/// </summary>
public sealed class AppUpdateService : IDisposable
{
    /// <summary>应用更新 API URL 注册键名</summary>
    private const string AppUpdatesApiUrlKey = "app_updates_api";

    /// <summary>
    /// 默认 API 基础地址 — 指向生产环境 Kirara Server API。
    /// 可通过 ServerUrlService 的 "app_updates_api" key 修改。
    /// </summary>
    private const string DefaultApiBaseUrl = "https://api.akeno6388.online:1010";

    /// <summary>安装包下载超时（约 54MB，需远大于普通 API 的 15s）</summary>
    private static readonly TimeSpan DownloadTimeout = TimeSpan.FromMinutes(10);

    /// <summary>首页就绪信号超时（防止信号异常丢失导致弹窗永不出现）</summary>
    private static readonly TimeSpan HomePageReadyTimeout = TimeSpan.FromSeconds(15);

    /// <summary>
    /// 首页完全加载信号 — 由 MainPage 入场动画完成时通过 <see cref="NotifyHomePageReady"/> 触发。
    /// 更新弹窗必须等首页加载完成后再出现，避免与入场动画抢占视觉焦点。
    /// </summary>
    private readonly TaskCompletionSource _homePageReady =
        new(TaskCreationOptions.RunContinuationsAsynchronously);

    /// <summary>
    /// Inno Setup 安装器参数（自动更新模式）：
    /// /NORESTART 不自动重启 /SP- 跳过"这是否安装正确？"询问
    /// /FORCECLOSEAPPLICATIONS 强制关闭运行中的应用（双保险）
    /// /AUTOUPDATE 自定义参数 → 安装器识别为自动更新：向导自动推进（欢迎/目录/任务/准备页
    ///   自动跳过，安装进度页正常显示）、安装完成后自动关闭安装器并启动应用
    /// ⚠️ 不带 /VERYSILENT：自动更新必须显示安装向导窗口，用户可见安装进度
    /// AppId 固定（{{732B89C8-...}}）→ 安装器自动识别为同产品升级
    /// </summary>
    private const string InstallerArguments =
        "/NORESTART /SP- /FORCECLOSEAPPLICATIONS /AUTOUPDATE";

    private readonly IServerUrlService _serverUrlService;
    private readonly ILoginService _loginService;
    private readonly IDialogService _dialogService;
    private readonly INotificationService _notificationService;
    private readonly HttpClient _httpClient;
    private DispatcherQueue? _dispatcherQueue;
    private bool _isChecking;   // 防重入：登录后并发触发只检查一次
    private bool _disposed;

    /// <summary>最近一次检查发现的新版本号（无新版本 / 检查失败时为 null）</summary>
    public Version? LatestVersion { get; private set; }

    /// <summary>
    /// API 基础地址 — 优先从 ServerUrlService 的 "app_updates_api" key 读取，
    /// 未配置时使用默认值。
    /// </summary>
    private string ApiBaseUrl =>
        _serverUrlService.GetDecryptedUrl(AppUpdatesApiUrlKey) ?? DefaultApiBaseUrl;

    public AppUpdateService(
        IServerUrlService serverUrlService,
        ILoginService loginService,
        IDialogService dialogService,
        INotificationService notificationService)
    {
        _serverUrlService = serverUrlService;
        _loginService = loginService;
        _dialogService = dialogService;
        _notificationService = notificationService;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
        _httpClient.Timeout = TimeSpan.FromSeconds(15);

        // 每次成功登录后自动检查更新（手动登录 / 自动登录 / 注册后登录均触发）
        loginService.LoginStateChanged += OnLoginStateChanged;
    }

    /// <summary>
    /// 确保应用更新 API URL 注册键存在。如果尚未注册，使用生产环境地址创建一条记录。
    /// </summary>
    public void EnsureAppUpdatesApiUrlRecord()
    {
        try
        {
            var existing = _serverUrlService.GetByKey(AppUpdatesApiUrlKey);
            if (existing != null) return;

            _serverUrlService.Register(
                key: AppUpdatesApiUrlKey,
                displayName: "应用更新 API 服务地址",
                plainUrl: DefaultApiBaseUrl,
                category: "API");
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"[AppUpdateService] 注册更新 API URL 失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 由 App.OnLaunched 在 UI 线程调用，捕获 UI 线程的 DispatcherQueue。
    /// 更新检查在后台线程执行，弹窗 / 关闭窗口前需通过此调度器切换线程。
    /// </summary>
    public void CaptureUiDispatcher()
    {
        _dispatcherQueue = DispatcherQueue.GetForCurrentThread();
        Debug.WriteLine(
            $"[AppUpdateService] UI 调度器已捕获 (HasThreadAccess={_dispatcherQueue?.HasThreadAccess})");
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _loginService.LoginStateChanged -= OnLoginStateChanged;
        _httpClient.Dispose();
    }

    /// <summary>
    /// 首页完全加载通知 — 由 MainPage 入场动画完成时调用。
    /// 通知后更新检查才能继续（弹窗不会与首页入场动画抢占视觉焦点）。
    /// </summary>
    public void NotifyHomePageReady()
    {
        _homePageReady.TrySetResult();
        Debug.WriteLine("[AppUpdateService] 首页已完全加载");
    }

    // ================================================================
    //  登录状态变更 → 检查更新
    // ================================================================

    /// <summary>
    /// 登录成功 → fire-and-forget 检查更新；登出 → 忽略
    /// </summary>
    private void OnLoginStateChanged(bool isLoggedIn)
    {
        if (!isLoggedIn) return;

        Debug.WriteLine("[AppUpdateService] 用户登录成功，检查应用更新");
        _ = CheckForUpdateAsync();
    }

    /// <summary>
    /// 检查更新（fire-and-forget）：GET /api/app/updates/latest?current={版本}
    /// 存在新版本 → 弹窗提示；用户确认 → 下载安装包并拉起安装器。
    /// 任何失败均静默降级，不影响正常使用。
    ///
    /// ⚠️ 弹窗时机：等待首页完全加载（入场动画完成，由 MainPage 通知）后才执行检查，
    ///    确保更新弹窗不会与首页入场动画抢占视觉焦点；首页就绪信号未及时到达时
    ///    15 秒超时兜底（避免弹窗永远不出现）。
    /// </summary>
    public async Task<UpdateCheckResult> CheckForUpdateAsync()
    {
        if (_isChecking) return UpdateCheckResult.Checking; // 已有检查在进行（如登录自动检查）
        _isChecking = true;
        try
        {
            // 每次检查重置上一次的新版本记录（保证 LatestVersion 反映最近一次检查结果）
            LatestVersion = null;

            // ★ 等待首页完全加载（MainPage 入场动画完成 → NotifyHomePageReady），
            //   15s 超时兜底（手动检查等场景首页未加载也不阻塞）
            await Task.WhenAny(
                _homePageReady.Task,
                Task.Delay(HomePageReadyTimeout));
            if (!_homePageReady.Task.IsCompleted)
            {
                Debug.WriteLine("[AppUpdateService] 首页就绪信号超时，按已就绪继续");
            }

            var current = GetCurrentVersion();
            var response = await _httpClient.GetAsync($"{ApiBaseUrl}/api/app/updates/latest?current={current}");
            if (!response.IsSuccessStatusCode)
            {
                Debug.WriteLine($"[AppUpdateService] 版本校对请求失败: {(int)response.StatusCode}");
                return UpdateCheckResult.Failed;
            }

            var json = await response.Content.ReadAsStringAsync();
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<AppUpdateResponseData>>(json);
            var data = apiResponse?.Data;
            // hasUpdate 为 null（服务端无发布记录）或 false → 已是最新版本
            if (data == null || data.HasUpdate != true)
            {
                Debug.WriteLine($"[AppUpdateService] 已是最新版本 ({current})");
                // ★ [安装包清理] 无需更新时删除 update 目录下残留安装包（避免过期包长期占用磁盘）
                CleanupStaleInstallers();
                return UpdateCheckResult.UpToDate;
            }

            // 双保险：客户端本地也做语义化版本比对（防服务端误判）
            if (!Version.TryParse(data.LatestVersion, out var latest) || latest <= current)
            {
                // ★ [安装包清理] 本地版本不低于服务端版本 → 视为已最新，同样清理残留安装包
                CleanupStaleInstallers();
                return UpdateCheckResult.UpToDate;
            }

            LatestVersion = latest;
            Debug.WriteLine($"[AppUpdateService] 发现新版本: {data.LatestVersion} (当前 {current})");
            await PromptAndInstallAsync(data);
            return UpdateCheckResult.UpdateAvailable;
        }
        catch (Exception ex)
        {
            // 网络异常/超时/解析失败 → 静默降级（仅 Debug 日志）
            Debug.WriteLine($"[AppUpdateService] 检查更新失败: {ex.GetType().Name}: {ex.Message}");
            return UpdateCheckResult.Failed;
        }
        finally
        {
            _isChecking = false;
        }
    }

    // ================================================================
    //  提示与安装
    // ================================================================

    /// <summary>
    /// 全屏覆盖弹窗提示新版本（必须在 UI 线程），用户确认后下载并安装。
    /// 弹窗样式参照「实例编辑器退出提示框」（LeftFunctionBar.ShowLeaveEditorDialog）：
    /// 居中 ContentDialog + 图标 + 标题 + 副标题，带全屏遮罩，模态不可外部关闭、无超时；
    /// 强制更新时无取消按钮，只能确认。
    /// </summary>
    private async Task PromptAndInstallAsync(AppUpdateResponseData data)
    {
        await RunOnUiThreadAsync(async () =>
        {
            var notes = data.ReleaseNotes?.Trim() ?? string.Empty;

            var isMandatory = data.IsMandatory == true;

            // 构建自定义内容（参照 ShowLeaveEditorDialog 的居中弹窗样式）
            var content = new StackPanel { Spacing = 16, MinWidth = 280, MaxWidth = 420, Margin = new Thickness(0, -10, 0, 0) };

            // 图标：强制更新用琥珀色警示，普通更新用主题色
            content.Children.Add(new FontIcon
            {
                Glyph = "\uE7BA", // ⚠ 警告
                FontSize = 45,
                Foreground = new SolidColorBrush(
                    isMandatory
                        ? Color.FromArgb(255, 255, 193, 7)   // 强制更新：琥珀色警示
                        : (Color)Application.Current.Resources["SystemAccentColor"]),
                HorizontalAlignment = HorizontalAlignment.Center,
            });

            // 标题
            content.Children.Add(new TextBlock
            {
                Text = $"发现新版本 v{data.LatestVersion}",
                FontSize = 20,
                FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, -5, 0, 0),
            });

            // 副标题（强制更新标记）
            content.Children.Add(new TextBlock
            {
                Text = isMandatory ? "此更新为重要更新，必须安装后才能继续使用本软件" : "是否立即下载并安装？",
                FontSize = 16,
                Opacity = 0.8,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, -5, 0, 0),
            });

            // 更新说明（可滚动区域，长说明不撑爆弹窗；无更新说明时整个区域省略，保持紧凑）
            if (!string.IsNullOrWhiteSpace(notes))
            {
                content.Children.Add(new ScrollViewer
                {
                    MaxHeight = 180,
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                    Content = new TextBlock
                    {
                        Text = notes,
                        FontSize = 14,
                        Opacity = 0.8,
                        TextWrapping = TextWrapping.Wrap,
                        LineHeight = 20,
                    },
                });
            }

            var confirmed = await _dialogService.ShowRichConfirmAsync(
                string.Empty, content, "立即更新", isMandatory);

            if (confirmed)
            {
                // 用户选择立即更新 → 优先复用本地已下载安装包（哈希一致则跳过下载，
                // 直接进入安装确认界面；无包或校验失败才走下载流程）
                _ = InstallOrDownloadAsync(data);
            }
            else if (isMandatory)
            {
                // 强制更新：未点「立即更新」即用户点了「退出软件」
                // → 关闭应用（走 MainWindow.Closed 完整清理链：断开 VPN → 关闭 WebView2 → 托盘销毁 → Exit）
                Debug.WriteLine("[AppUpdateService] 用户选择退出软件（强制更新）");
                await Task.Delay(TimeSpan.FromMilliseconds(300)); // 等待弹窗关闭动画
                if (MainWindow.Current != null)
                {
                    MainWindow.Current.Close();
                }
                else
                {
                    Microsoft.UI.Xaml.Application.Current?.Exit();
                }
            }
        });
    }

    /// <summary>
    /// 更新包校验通过后的确认弹窗（样式照搬「发现新版本」更新提示弹窗）：
    /// 居中 ContentDialog + 图标 + 标题 + 副标题，询问用户是否关闭当前程序进行自动更新。
    /// 返回 true=确认更新；false=取消（普通更新保留安装包继续运行 / 强制更新由调用方退出软件）。
    /// </summary>
    private async Task<bool> PromptForInstallConfirmationAsync(string latestVersion, bool isMandatory)
    {
        // 构建自定义内容（与 PromptAndInstallAsync 的更新提示弹窗样式一致）
        var content = new StackPanel
        {
            Spacing = 16,
            MinWidth = 280,
            MaxWidth = 420,
            Margin = new Thickness(0, -10, 0, 0),
        };

        // 图标：强制更新用琥珀色警示，普通更新用主题色（与更新提示弹窗一致）
        content.Children.Add(new FontIcon
        {
            Glyph = "\uE7BA", // ⚠ 警告
            FontSize = 45,
            Foreground = new SolidColorBrush(
                isMandatory
                    ? Color.FromArgb(255, 255, 193, 7)   // 强制更新：琥珀色警示
                    : (Color)Application.Current.Resources["SystemAccentColor"]),
            HorizontalAlignment = HorizontalAlignment.Center,
        });

        // 标题
        content.Children.Add(new TextBlock
        {
            Text = $"安装包 v{latestVersion} 已就绪",
            FontSize = 20,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -5, 0, 0),
        });

        // 副标题（说明关闭程序的原因）
        content.Children.Add(new TextBlock
        {
            Text = "安装包已下载并校验通过。是否关闭当前运行的程序，立即更新？",
            FontSize = 16,
            Opacity = 0.8,
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -5, 0, 0),
        });

        // 强制模式：确认（立即更新）+ 退出软件（false，由调用方处理退出）；普通：确认 + 取消
        return await _dialogService.ShowRichConfirmAsync(
            string.Empty, content, "立即更新", isMandatory);
    }

    /// <summary>
    /// 更新目录路径（%APPDATA%/Kirara/updates）
    /// </summary>
    private static string UpdatesDirPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "updates");

    /// <summary>
    /// 安装包完整路径（按版本号命名，下载与本地复用路径共用）。
    /// </summary>
    private static string GetInstallerPath(string version) =>
        Path.Combine(UpdatesDirPath, $"Kirara_Server_Setup_{version}_x64.exe");

    /// <summary>
    /// 清理更新目录下的所有安装包（已是最新版本 / 残留过期包等场景）。
    /// 不创建目录；目录不存在时静默跳过。
    /// </summary>
    private static void CleanupStaleInstallers()
    {
        try
        {
            if (!Directory.Exists(UpdatesDirPath)) return;
            foreach (var stale in Directory.GetFiles(UpdatesDirPath, "*.exe"))
            {
                try { File.Delete(stale); } catch { /* 占用中忽略 */ }
            }
            Debug.WriteLine("[AppUpdateService] 已清理 updates 目录下残留安装包");
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"[AppUpdateService] 清理安装包失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 校验本地安装包是否有效可用（供「跳过下载直接安装」复用判定）：
    ///   1. 文件存在且大小 ≥ 1MB（安装包约 54MB，过小视为损坏/假文件）；
    ///   2. PE 可执行文件头（MZ 魔数）校验；
    ///   3. 服务端提供 SHA256 → 严格比对哈希（防劫持/损坏）；未提供 → 由 1/2 兜底。
    /// </summary>
    private static bool IsLocalInstallerValid(string installerPath, string? expectedSha256)
    {
        try
        {
            if (!File.Exists(installerPath)) return false;
            if (new FileInfo(installerPath).Length < 1 * 1024 * 1024) return false;
            if (!IsPeExecutable(installerPath)) return false;

            if (!string.IsNullOrWhiteSpace(expectedSha256))
            {
                var actualHash = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(installerPath)));
                return string.Equals(actualHash, expectedSha256.Trim(), StringComparison.OrdinalIgnoreCase);
            }
            return true;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"[AppUpdateService] 本地安装包校验异常: {ex.Message}");
            return false;
        }
    }

    /// <summary>
    /// 更新安装总流程 — 优先复用本地已下载且校验通过的安装包（跳过重复下载）：
    ///   ① 本地安装包存在且校验通过 → 直接进入安装确认界面（弹窗 → 拉起安装器 → 关闭应用）；
    ///   ② 本地无包 / 校验失败（哈希不一致或损坏）→ 删除无效包后走下载流程。
    /// </summary>
    private async Task InstallOrDownloadAsync(AppUpdateResponseData data)
    {
        try
        {
            var latestVersion = data.LatestVersion ?? string.Empty;
            var installerPath = GetInstallerPath(latestVersion);
            if (File.Exists(installerPath) && IsLocalInstallerValid(installerPath, data.Sha256))
            {
                Debug.WriteLine($"[AppUpdateService] 本地安装包校验通过，跳过下载直接进入安装确认: {installerPath}");
                await ConfirmAndLaunchInstallerAsync(data, installerPath);
                return;
            }

            if (File.Exists(installerPath))
            {
                // 本地包存在但校验失败（哈希不一致/损坏/假文件）→ 删除后重新下载
                Debug.WriteLine("[AppUpdateService] 本地安装包校验失败，删除后重新下载");
                try { File.Delete(installerPath); } catch { /* 删除失败由下载流程覆盖 */ }
            }

            await DownloadAndInstallAsync(data);
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"[AppUpdateService] 更新安装流程异常: {ex.GetType().Name}: {ex.Message}");
        }
    }

    /// <summary>
    /// 安装确认与执行（校验通过后的统一入口，下载路径与本地复用路径共用）：
    /// 弹窗确认 → 确认则拉起安装器并立即关闭应用；取消则保留安装包
    /// （普通更新继续运行 / 强制更新由用户点「退出软件」关闭应用）。
    /// </summary>
    private async Task ConfirmAndLaunchInstallerAsync(AppUpdateResponseData data, string installerPath)
    {
        var isMandatory = data.IsMandatory == true;
        var latestVersion = data.LatestVersion ?? string.Empty;

        // 弹窗确认（样式照搬「发现新版本」更新提示弹窗）——询问用户是否关闭当前程序进行自动更新
        var confirmed = await RunOnUiThreadAsync(
            () => PromptForInstallConfirmationAsync(latestVersion, isMandatory));
        if (!confirmed)
        {
            if (isMandatory)
            {
                // 强制更新：用户点「退出软件」→ 关闭应用（走 MainWindow.Closed 完整清理链），
                // 下次登录仍会提示更新
                Debug.WriteLine("[AppUpdateService] 强制更新确认弹窗：用户选择退出软件");
                await Task.Delay(TimeSpan.FromMilliseconds(300)); // 等待弹窗关闭动画
                await RunOnUiThreadAsync(() =>
                {
                    if (MainWindow.Current != null)
                    {
                        MainWindow.Current.Close();
                    }
                    else
                    {
                        Microsoft.UI.Xaml.Application.Current?.Exit();
                    }
                });
            }
            else
            {
                Debug.WriteLine("[AppUpdateService] 用户取消自动更新，安装包已保留在本地");
            }
            return;
        }

        // 拉起安装器 — 必须先关软件、再让安装器出现，避免安装与应用退出竞争：
        // ⚠️ 不能直接 Process.Start(installer, Verb="runas")：ShellExecuteEx 会同步阻塞
        //    等待 UAC 确认，确认后安装向导打开时应用仍存活（旧逻辑还延迟 2s 才关闭），
        //    用户点击「安装」时应用未退出 → 安装器复制文件被占用 → 软件与安装器一起被关。
        //    改为：通过 cmd /c start 异步拉起（start 立即返回，安装器由系统随后启动，
        //    其 manifest 自动触发 UAC），随后应用立即关闭 —— 用户处理 UAC/安装向导时
        //    应用早已完全退出（走 MainWindow.Closed 完整清理链），文件无占用冲突。
        try
        {
            // start "" "path" 参数 — 第一个 "" 是窗口标题（路径含空格时必须）
            var installCmd = $"/c start \"\" \"{installerPath}\" {InstallerArguments}";
            Process.Start(new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = installCmd,
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden,
            });
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"[AppUpdateService] 启动安装器失败: {ex.Message}");
            await PublishServiceNotificationAsync(
                NotificationSeverity.Error,
                "更新失败",
                $"安装包启动失败：{ex.Message}。可到 %APPDATA%\\Kirara\\updates 目录手动运行安装包。");
            return;
        }

        // 立即关闭应用（触发 MainWindow.Closed 完整清理链：
        // 断开 VPN → 关闭 WebView2 页面 → 托盘销毁 → Application.Current.Exit()）
        await RunOnUiThreadAsync(() =>
        {
            if (MainWindow.Current != null)
            {
                MainWindow.Current.Close();
            }
            else
            {
                Microsoft.UI.Xaml.Application.Current?.Exit();
            }
        });
    }

    /// <summary>
    /// 下载安装包 → SHA256 校验 → 弹窗确认 → 拉起安装器 → 关闭应用（走 MainWindow.Closed 完整清理链）
    /// 下载过程中显示全局飞入提示样式的进度框（图标 + 标题 + 进度条 + 状态文字）。
    /// </summary>
    private async Task DownloadAndInstallAsync(AppUpdateResponseData data)
    {
        // 下载进度提示框（全局飞入提示样式），方法级持有以便异常时也能关闭
        ProgressFlyoutController? progressController = null;
        try
        {
            if (string.IsNullOrWhiteSpace(data.DownloadUrl))
            {
                await PublishServiceNotificationAsync(
                    NotificationSeverity.Error, "下载失败", "服务器未提供安装包下载地址，请稍后重试。");
                return;
            }

            // Step 1: 准备更新目录（下载前清理旧安装包，避免残留占用）
            var updatesDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Kirara", "updates");
            Directory.CreateDirectory(updatesDir);
            foreach (var stale in Directory.GetFiles(updatesDir, "*.exe"))
            {
                try { File.Delete(stale); } catch { /* 占用中忽略 */ }
            }

            var installerPath = Path.Combine(
                updatesDir, $"Kirara_Server_Setup_{data.LatestVersion}_x64.exe");

            // Step 2: 显示下载进度提示框（全局飞入提示样式：图标 + 标题 + 进度条 + 状态文字）
            // 锚点：主窗口根元素；找不到锚点时跳过提示（不阻塞下载）
            if (MainWindow.Current?.Content is FrameworkElement anchor)
            {
                progressController = FlyoutHelper.ShowProgress(
                    anchor,
                    FlyoutPlacementMode.BottomEdgeAlignedRight,
                    "\uE896",                              // 下载图标（Segoe MDL2 Assets）
                    (Color)Application.Current.Resources["SystemAccentColor"],
                    $"正在下载 v{data.LatestVersion}",
                    description: "请稍候，安装包下载完成后将自动开始安装");
            }

            // Step 3: 流式下载安装包（专用 HttpClient，10 分钟超时）
            using (var downloadClient = NetworkClientFactory.Create(allowAutoRedirect: true))
            {
                downloadClient.Timeout = DownloadTimeout;
                // ⚠️ Alist 短链（/sd/xxx）防盗链：非浏览器 UA / 无 Referer 的请求直接返回 403。
                //    必须携带浏览器风格 User-Agent + 下载域 Referer 才能通过重定向下载。
                downloadClient.DefaultRequestHeaders.UserAgent.ParseAdd(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36");
                if (Uri.TryCreate(data.DownloadUrl, UriKind.Absolute, out var downloadUri))
                {
                    downloadClient.DefaultRequestHeaders.Referrer =
                        new Uri($"{downloadUri.Scheme}://{downloadUri.Host}");
                }

                using var response = await downloadClient.GetAsync(
                    data.DownloadUrl, HttpCompletionOption.ResponseHeadersRead);
                response.EnsureSuccessStatusCode();

                // ⚠️ 响应 Content-Type 校验：安装包应为二进制流（application/octet-stream 等）。
                //    Alist 短链 /sd/ 返回 HTML 中转页（JS/刷新跳转）或 JSON 错误页时，
                //    HttpClient 不执行 JS，拿到的就是中转页本身 → 直接拦截，避免存成假 EXE。
                var mediaType = response.Content.Headers.ContentType?.MediaType?.ToLowerInvariant();
                if (mediaType != null &&
                    (mediaType.Contains("html") || mediaType.Contains("json") ||
                     mediaType.Contains("xml") || mediaType.Contains("text/plain")))
                {
                    Debug.WriteLine($"[AppUpdateService] 下载响应不是安装包 (Content-Type: {mediaType})");
                    progressController?.Close();
                    progressController = null;
                    await PublishServiceNotificationAsync(
                        NotificationSeverity.Error,
                        "下载失败", "服务器返回的文件有误，这可能是链接解析失败导致的");
                    return;
                }

                // 流式写入 + 进度反馈：
                // 响应头 Content-Length 已知 → 确定进度（百分比 + 已下载 MB）；未知 → 不确定进度条
                var totalBytes = response.Content.Headers.ContentLength;
                await using (var source = await response.Content.ReadAsStreamAsync())
                await using (var target = File.Create(installerPath))
                {
                    if (totalBytes is > 0 && progressController != null)
                    {
                        var buffer = new byte[81920];
                        long received = 0;
                        int read;
                        while ((read = await source.ReadAsync(buffer)) > 0)
                        {
                            await target.WriteAsync(buffer.AsMemory(0, read));
                            received += read;
                            var percent = (double)received / totalBytes.Value * 100;
                            progressController.Update(percent,
                                $"正在下载... {received / 1048576.0:F1} MB / {totalBytes.Value / 1048576.0:F1} MB（{percent:F0}%）");
                        }
                    }
                    else
                    {
                        progressController?.SetIndeterminate("正在下载...");
                        await source.CopyToAsync(target);
                    }
                }
            }

            // 下载完成 → 关闭进度提示框（后续校验/安装阶段不再需要）
            progressController?.Close();
            progressController = null;

            // Step 4: 下载结果有效性校验（防 Alist 短链中转页/错误页被存成假 EXE）。
            //    即使服务端未提供 SHA256，也要校验文件大小 + PE 文件头（MZ 魔数），
            //    避免把 1KB 的 HTML/JSON 当安装包拉起（Process.Start 会报"系统找不到指定的文件"）。
            var fileInfo = new FileInfo(installerPath);
            if (fileInfo.Length < 1 * 1024 * 1024)   // 安装包约 54MB，小于 1MB 视为异常
            {
                Debug.WriteLine($"[AppUpdateService] 下载文件异常过小: {fileInfo.Length} bytes");
                LogFileHeadForDiagnosis(installerPath);
                try { File.Delete(installerPath); } catch { /* 清理失败忽略 */ }
                await PublishServiceNotificationAsync(
                    NotificationSeverity.Error,
                    "下载失败", "下载的安装包异常（文件过小），可能下载链接返回了中转页面而非安装包，已删除，请稍后重试。");
                return;
            }

            if (!IsPeExecutable(installerPath))
            {
                Debug.WriteLine($"[AppUpdateService] 下载文件不是有效 PE 可执行文件");
                LogFileHeadForDiagnosis(installerPath);
                try { File.Delete(installerPath); } catch { /* 清理失败忽略 */ }
                await PublishServiceNotificationAsync(
                    NotificationSeverity.Error,
                    "下载失败", "下载的文件不是有效的安装包（PE 校验失败），已删除，请检查服务端登记的下载地址。");
                return;
            }

            // Step 5: SHA256 校验（防下载劫持；服务端未提供哈希时跳过 — 由 4 的大小/PE 头兜底）
            if (!string.IsNullOrWhiteSpace(data.Sha256))
            {
                var actualHash = Convert.ToHexString(
                    SHA256.HashData(await File.ReadAllBytesAsync(installerPath)));
                if (!string.Equals(actualHash, data.Sha256.Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    try { File.Delete(installerPath); } catch { /* 清理失败忽略 */ }
                    await PublishServiceNotificationAsync(
                        NotificationSeverity.Error,
                        "更新失败", "安装包未通过校验，请稍后重试");
                    return;
                }
            }

            // Step 6: 弹窗确认 → 拉起安装器 → 关闭应用
            //（抽取为独立方法，供「本地缓存安装包复用」路径与下载路径共用，见 InstallOrDownloadAsync）
            await ConfirmAndLaunchInstallerAsync(data, installerPath);
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"[AppUpdateService] 下载安装失败: {ex.GetType().Name}: {ex.Message}");
            // 异常时关闭进度提示框，避免残留
            progressController?.Close();
            progressController = null;
            await PublishServiceNotificationAsync(
                NotificationSeverity.Error, "下载失败", $"下载安装包失败：{ex.Message}");
        }
    }

    // ================================================================
    //  内部方法
    // ================================================================

    /// <summary>
    /// 发布一条 Service 类别通知（自动切换 UI 线程）
    /// </summary>
    private async Task PublishServiceNotificationAsync(
        NotificationSeverity severity, string title, string message)
    {
        await RunOnUiThreadAsync(() =>
        {
            _notificationService.Publish(new AppNotification
            {
                Category = NotificationCategory.Service,
                Severity = severity,
                Title = title,
                Message = message,
                Source = "AppUpdate",
            });
        });
    }

    /// <summary>
    /// 当前应用版本（语义化版本号，供服务端比对与设置页展示）。
    /// 优先取 AssemblyInformationalVersion（对应 csproj &lt;Version&gt;，如 "0.9.1"），
    /// 失败时回退 AssemblyVersion。
    /// </summary>
    public static Version CurrentVersion => GetCurrentVersion();

    /// <summary>
    /// 标题栏版本号后缀注释文字（如 "体验版"）。
    /// 由 csproj &lt;VersionNote&gt; 属性经 AssemblyMetadataAttribute("VersionNote") 注入程序集，
    /// 修改 csproj 即可，无需改动代码；未配置时返回空字符串。
    /// </summary>
    public static string VersionNote { get; } = ReadVersionNote();

    /// <summary>从程序集元数据读取版本号注释文字（AssemblyMetadata("VersionNote")）</summary>
    private static string ReadVersionNote()
    {
        try
        {
            var assembly = Assembly.GetExecutingAssembly();
            var attr = assembly
                .GetCustomAttributes<AssemblyMetadataAttribute>()
                .FirstOrDefault(a => string.Equals(a.Key, "VersionNote", StringComparison.OrdinalIgnoreCase));
            return attr?.Value ?? string.Empty;
        }
        catch
        {
            return string.Empty;
        }
    }

    /// <summary>
    /// 校验文件是否为有效的 Windows PE 可执行文件（以 "MZ" 魔数开头）。
    /// 用于拦截 Alist 短链返回的 HTML 中转页 / JSON 错误页被误存为 .exe。
    /// </summary>
    private static bool IsPeExecutable(string path)
    {
        try
        {
            using var fs = File.OpenRead(path);
            if (fs.Length < 2) return false;
            Span<byte> header = stackalloc byte[2];
            if (fs.Read(header) != 2) return false;
            return header[0] == (byte)'M' && header[1] == (byte)'Z';
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// 记录异常文件的开头内容（前 64 字节），用于诊断下载到的到底是什么
    /// （HTML 中转页 / JSON 错误 / 纯文本等）。
    /// </summary>
    private static void LogFileHeadForDiagnosis(string path)
    {
        try
        {
            var bytes = new byte[64];
            using var fs = File.OpenRead(path);
            var read = fs.Read(bytes, 0, bytes.Length);
            var head = System.Text.Encoding.UTF8.GetString(bytes, 0, read)
                .Replace("\r", " ").Replace("\n", " ")
                .Trim();
            Debug.WriteLine($"[AppUpdateService] 文件开头: {head}");
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"[AppUpdateService] 读取文件头失败: {ex.Message}");
        }
    }

    private static Version GetCurrentVersion()
    {
        try
        {
            var assembly = Assembly.GetExecutingAssembly();
            var info = assembly
                .GetCustomAttribute<AssemblyInformationalVersionAttribute>()
                ?.InformationalVersion;
            if (!string.IsNullOrEmpty(info))
            {
                // 去除 SourceLink 可能附加的 "+commit" 后缀
                var clean = info.Split('+')[0];
                if (Version.TryParse(clean, out var v))
                    return v;
            }
            return assembly.GetName().Version ?? new Version(0, 9, 1);
        }
        catch
        {
            return new Version(0, 9, 1);
        }
    }

    /// <summary>
    /// 切换到 UI 线程执行（弹窗 / 关闭窗口 / 通知发布必须 UI 线程）
    /// </summary>
    private async Task RunOnUiThreadAsync(Func<Task> action)
    {
        if (_dispatcherQueue == null || _dispatcherQueue.HasThreadAccess)
        {
            await action();
            return;
        }

        var tcs = new TaskCompletionSource();
        _dispatcherQueue.TryEnqueue(async () =>
        {
            try { await action(); tcs.TrySetResult(); }
            catch (Exception ex) { tcs.TrySetException(ex); }
        });
        await tcs.Task;
    }

    /// <summary>
    /// 切换到 UI 线程执行（弹窗 / 关闭窗口 / 通知发布必须 UI 线程），带返回值版本。
    /// </summary>
    private async Task<T> RunOnUiThreadAsync<T>(Func<Task<T>> action)
    {
        if (_dispatcherQueue == null || _dispatcherQueue.HasThreadAccess)
        {
            return await action();
        }

        var tcs = new TaskCompletionSource<T>();
        _dispatcherQueue.TryEnqueue(async () =>
        {
            try { tcs.TrySetResult(await action()); }
            catch (Exception ex) { tcs.TrySetException(ex); }
        });
        return await tcs.Task;
    }

    private Task RunOnUiThreadAsync(Action action)
        => RunOnUiThreadAsync(() => { action(); return Task.CompletedTask; });
}
