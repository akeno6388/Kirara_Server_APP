using System.Net.Http;
using Kirara_Server_WinUI.Helpers;
using Windows.Graphics.Imaging;
using Windows.Storage;
using Windows.Storage.Streams;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 用户头像管理服务实现
///
/// 资源获取链:
/// Step1: 立即显示本地缓存（秒显）
/// Step2: 后台校验服务端版本，不一致时重新下载
/// Step3: 降级为 null（UI 使用 Glyph 兜底）
///
/// 上传流程: 裁剪 → 上传服务器 → 成功后原子替换本地缓存 → 强制刷新 UI
/// </summary>
public class UserAvatarService : IUserAvatarService, IDisposable
{
    private const string AvatarUrlKey = "user_avatar";
    private const string AuthApiUrlKey = "auth_api";
    private const string DefaultApiBaseUrl = "https://api.akeno6388.online:1010";

    private readonly IServerUrlService _serverUrlService;
    private readonly ILoginService _loginService;
    private readonly SecureCacheService _secureCache;
    private readonly HttpClient _httpClient;

    /// <summary>头像文件实际路径</summary>
    private string? _avatarFilePath;

    /// <summary>当前头像外部路径（含缓存失效标记，UI 绑定此值）</summary>
    private string? _currentAvatarPath;

    /// <summary>写入时递增，用于追加到路径后使 WinUI 刷新缓存</summary>
    private int _avatarVersion;

    private bool _disposed;
    private bool _isInitializedForUser;
    private Guid _trackedUserId;

    private static readonly string CacheDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "avatars");

    /// <summary>加密缓存文件路径（方案A：内容+ETag 合并加密单文件）</summary>
    private string CacheFilePath => Path.Combine(CacheDirectory, $"{_loginService.CurrentUserId:N}.enc");

    /// <summary>判断字节数组是否为 GIF 图片（检查 GIF magic bytes）</summary>
    private static bool IsGifImage(byte[] bytes)
    {
        return bytes.Length >= 6
            && bytes[0] == 'G' && bytes[1] == 'I' && bytes[2] == 'F'
            && bytes[3] == '8' && (bytes[4] == '7' || bytes[4] == '9') && bytes[5] == 'a';
    }

    private string ApiBaseUrl =>
        _serverUrlService.GetDecryptedUrl(AuthApiUrlKey) ?? DefaultApiBaseUrl;

    public UserAvatarService(
        IServerUrlService serverUrlService,
        ILoginService loginService,
        SecureCacheService secureCache)
    {
        _serverUrlService = serverUrlService;
        _loginService = loginService;
        _secureCache = secureCache;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
        _httpClient.Timeout = TimeSpan.FromSeconds(15);

        // 订阅登录状态变更：登录后自动加载头像，登出后清除
        loginService.LoginStateChanged += OnLoginStateChanged;
    }

    public string? CurrentAvatarPath => _currentAvatarPath;
    public bool IsLoading { get; private set; }
    public event Action<string?>? AvatarChanged;

    /// <summary>
    /// 设置头像路径并触发刷新（添加版本号使 WinUI 缓存失效）
    /// </summary>
    private void SetAvatarPath(string? filePath)
    {
        if (filePath == null)
        {
            _avatarFilePath = null;
            _currentAvatarPath = null;
        }
        else
        {
            _avatarFilePath = filePath;
            _avatarVersion++;
            // 追加版本号：WinUI BitmapImage 按 URI 缓存，同路径不同 ?v= 视为不同的 URI
            _currentAvatarPath = $"{filePath}?v={_avatarVersion}";
        }
        AvatarChanged?.Invoke(_currentAvatarPath);
    }

    /// <summary>
    /// 登录状态变更时触发 — 登录后加载头像，登出后清除
    /// </summary>
    private void OnLoginStateChanged(bool isLoggedIn)
    {
        if (isLoggedIn)
        {
            // 登录完成 → 初始化当前用户头像
            _ = InitializeForCurrentUserAsync();
        }
        else
        {
            // 登出 → 清除头像显示
            _isInitializedForUser = false;
            _trackedUserId = Guid.Empty;
            SetAvatarPath(null);
        }
    }

    // ================================================================
    //  初始化当前用户：显示本地缓存 → 后台校验版本
    // ================================================================

    /// <summary>
    /// 为当前登录用户加载头像（自动被 LoginStateChanged 触发，也可手动调用）
    /// </summary>
    public async Task InitializeForCurrentUserAsync()
    {
        var userId = _loginService.CurrentUserId;
        if (userId == Guid.Empty) return;

        // 同一用户不重复初始化，除非是切换用户
        if (_isInitializedForUser && _trackedUserId == userId)
            return;

        _trackedUserId = userId;
        _isInitializedForUser = true;

        // 立即显示本地加密缓存（秒显）：解密到临时明文文件供 UI 加载
        var tmpPath = DecryptAvatarToTemp();
        if (tmpPath != null)
        {
            SetAvatarPath(tmpPath);
        }

        // 后台检查服务端版本
        _ = CheckServerVersionAsync();
    }

    /// <summary>
    /// 兼容接口 — 旧版初始化（由 LoginStateChanged 自动触发，手动调用不再需要）
    /// </summary>
    public Task InitializeAsync()
    {
        // 如果用户已登录，立即初始化；否则等待 LoginStateChanged 触发
        if (_loginService.IsLoggedIn && !_isInitializedForUser)
            _ = InitializeForCurrentUserAsync();
        return Task.CompletedTask;
    }

    // ================================================================
    //  服务端版本检查
    // ================================================================

    private async Task CheckServerVersionAsync()
    {
        try
        {
            var userId = _loginService.CurrentUserId;
            if (userId == Guid.Empty) return;

            using var response = await _httpClient.GetAsync(
                $"{ApiBaseUrl}/api/resources/user-avatar/{userId:N}");

            if (response.IsSuccessStatusCode)
            {
                // HttpClient 默认 AllowAutoRedirect=true，自动跟随了 302 重定向
                // 到 MinIO 预签名 URL，响应体即为实际头像图片数据
                var imageBytes = await response.Content.ReadAsByteArrayAsync();
                if (imageBytes.Length == 0) return;

                // 直接从响应头获取 LastModified 用于版本比对（与 ETag 统一为字符串存储）
                DateTime? serverModified = response.Content.Headers.LastModified?.UtcDateTime;

                // 本地加密信封中的 etag 字段存储上次 LastModified（ISO 格式）
                if (serverModified.HasValue
                    && _secureCache.TryReadEnvelope(CacheFilePath, out _, out var localEtag, out _)
                    && DateTime.TryParse(localEtag, out var localModified)
                    && Math.Abs((serverModified.Value - localModified).TotalSeconds) < 1)
                {
                    System.Diagnostics.Debug.WriteLine("[UserAvatarService] 服务端版本与本地一致，跳过下载");
                    // 确保临时明文文件存在（可能已被清理）
                    var tmpPath = DecryptAvatarToTemp();
                    if (tmpPath != null)
                        SetAvatarPath(tmpPath);
                    return;
                }

                CacheImageBytes(imageBytes, serverModified);
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                if (File.Exists(CacheFilePath))
                {
                    _secureCache.Delete(CacheFilePath);
                    CleanupTempAvatarFiles();
                    SetAvatarPath(null);
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[UserAvatarService] 版本检查失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 加密缓存图片（方案A：内容 + LastModified 合并加密单文件），
    /// 并解密到临时明文文件供 UI 加载。
    /// </summary>
    private void CacheImageBytes(byte[] imageBytes, DateTime? serverModified)
    {
        try
        {
            EnsureCacheDirectory();

            // ETag 字段统一存字符串：LastModified ISO 格式（与 ETag 格式统一）
            string etag = serverModified?.ToString("O") ?? string.Empty;
            _secureCache.SaveEnvelope(CacheFilePath, imageBytes,
                string.IsNullOrEmpty(etag) ? null : etag);

            SetAvatarPath(WriteAvatarTemp(imageBytes));
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[UserAvatarService] 缓存写入失败: {ex.Message}");
        }
    }

    // ================================================================
    //  上传（先服务器 → 后缓存 → 强制刷新）
    // ================================================================

    public async Task<(bool success, string? error)> UploadAvatarAsync(byte[] imageBytes)
    {
        try
        {
            bool isGif = IsGifImage(imageBytes);
            byte[] uploadBytes;

            if (isGif)
            {
                // GIF 不做裁剪（裁剪会丢失动画帧），直接使用原始字节
                uploadBytes = imageBytes;
            }
            else
            {
                var croppedBytes = await CenterCropToSquareAsync(imageBytes, 256);
                if (croppedBytes == null) return (false, "无法处理该图片，请尝试其他图片");
                uploadBytes = croppedBytes;
            }

            // 确保 AccessToken 有效（过期时自动续期）
            await _loginService.EnsureValidAccessTokenAsync();

            var accessToken = _loginService.AccessToken;
            if (string.IsNullOrEmpty(accessToken))
                return (false, "未登录，请先登录");

            var uploadResult = await UploadToServerAsync(uploadBytes, accessToken, isGif);
            if (!uploadResult.isSuccess)
                return (false, uploadResult.error);

            // 服务器成功 → 加密写入本地缓存（方案A：内容 + ETag 合并单文件）
            EnsureCacheDirectory();
            _secureCache.SaveEnvelope(CacheFilePath, uploadBytes);

            SetAvatarPath(WriteAvatarTemp(uploadBytes));

            return (true, null);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[UserAvatarService] 上传处理失败: {ex.Message}");
            return (false, $"上传处理出错: {ex.Message}");
        }
    }

    private async Task<(bool isSuccess, string? error)> UploadToServerAsync(byte[] imageBytes, string accessToken, bool isGif = false)
    {
        try
        {
            var imageContent = new ByteArrayContent(imageBytes);
            string contentType = isGif ? "image/gif" : "image/png";
            string fileName = isGif ? "avatar.gif" : "avatar.png";
            imageContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(contentType);

            using var formContent = new MultipartFormDataContent();
            formContent.Add(imageContent, "file", fileName);

            using var request = new HttpRequestMessage(
                HttpMethod.Put, $"{ApiBaseUrl}/api/resources/user-avatar");
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);
            request.Content = formContent;

            using var response = await _httpClient.SendAsync(request);

            if (response.IsSuccessStatusCode)
                return (true, null);

            var errorBody = await response.Content.ReadAsStringAsync();
            return (false, ExtractErrorMessage(errorBody, (int)response.StatusCode));
        }
        catch (HttpRequestException ex)
        {
            return (false, $"无法连接到服务器: {ex.Message}");
        }
        catch (TaskCanceledException)
        {
            return (false, "上传超时，请检查网络后重试");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[UserAvatarService] 上传异常: {ex.Message}");
            return (false, $"上传出错: {ex.Message}");
        }
    }

    // ================================================================
    //  加密缓存辅助
    // ================================================================

    /// <summary>
    /// 解密本地加密缓存到临时明文文件（供 UI 按路径加载），返回路径；
    /// 解密失败（被篡改/损坏/旧明文格式）返回 null → 调用方走重新下载流程。
    /// </summary>
    private string? DecryptAvatarToTemp()
    {
        if (!_secureCache.TryReadEnvelope(CacheFilePath, out var content, out _, out _))
            return null;
        return WriteAvatarTemp(content);
    }

    /// <summary>按内容格式（GIF/PNG）写入临时明文头像文件，返回路径</summary>
    private string WriteAvatarTemp(byte[] content)
    {
        bool isGif = IsGifImage(content);
        var ext = isGif ? ".gif" : ".png";
        return _secureCache.WriteTempFile($"avatar_{_loginService.CurrentUserId:N}{ext}", content);
    }

    /// <summary>清理当前用户的临时明文头像文件</summary>
    private void CleanupTempAvatarFiles()
    {
        try
        {
            var userId = _loginService.CurrentUserId;
            if (!Directory.Exists(SecureCacheService.TempDirectory)) return;
            foreach (var f in Directory.GetFiles(SecureCacheService.TempDirectory, $"avatar_{userId:N}.*"))
                try { File.Delete(f); } catch { }
        }
        catch { }
    }

    // ================================================================
    //  静态工具
    // ================================================================

    private static string ExtractErrorMessage(string json, int statusCode)
    {
        try
        {
            var doc = System.Text.Json.JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("error", out var e))
            {
                if (e.TryGetProperty("message", out var m))
                {
                    var msg = m.GetString();
                    if (!string.IsNullOrEmpty(msg)) return msg;
                }
                if (e.TryGetProperty("code", out var c))
                    return $"上传失败 ({c.GetString()})";
            }
        }
        catch { }

        try
        {
            var doc = System.Text.Json.JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("errors", out var errs))
            {
                var msgs = new List<string>();
                foreach (var p in errs.EnumerateObject())
                    foreach (var v in p.Value.EnumerateArray())
                        msgs.Add(v.GetString() ?? "");
                if (msgs.Count > 0) return string.Join("；", msgs.Distinct());
            }
        }
        catch { }

        return statusCode switch
        {
            400 => "请求参数错误",
            401 => "未授权，请重新登录",
            403 => "没有权限执行此操作",
            404 => "资源不存在",
            413 => "文件大小超过限制（最大 10MB）",
            _ => $"上传失败（HTTP {statusCode}）"
        };
    }

    private static async Task<byte[]?> CenterCropToSquareAsync(byte[] imageBytes, int size)
    {
        var tempPath = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
        try
        {
            await File.WriteAllBytesAsync(tempPath, imageBytes);
            var file = await StorageFile.GetFileFromPathAsync(tempPath);
            using var stream = await file.OpenReadAsync();

            var decoder = await BitmapDecoder.CreateAsync(stream);
            uint sw = decoder.PixelWidth, sh = decoder.PixelHeight;
            if (sw == 0 || sh == 0) return null;

            uint cropSize = Math.Min(sw, sh);
            uint ox = (sw - cropSize) / 2, oy = (sh - cropSize) / 2;

            var pd = await decoder.GetPixelDataAsync(
                BitmapPixelFormat.Rgba8, BitmapAlphaMode.Premultiplied,
                new BitmapTransform(),
                ExifOrientationMode.IgnoreExifOrientation,
                ColorManagementMode.DoNotColorManage);
            var px = pd.DetachPixelData();

            uint stride = sw * 4;
            float sx = (float)cropSize / size, sy = (float)cropSize / size;
            var result = new byte[size * size * 4];

            for (int y = 0; y < size; y++)
            {
                int srcY = (int)(y * sy) + (int)oy;
                int rowStart = (int)(srcY * stride);
                for (int x = 0; x < size; x++)
                {
                    int srcX = (int)(x * sx) + (int)ox;
                    int si = rowStart + srcX * 4;
                    int di = (y * size + x) * 4;
                    result[di] = px[si];
                    result[di + 1] = px[si + 1];
                    result[di + 2] = px[si + 2];
                    result[di + 3] = px[si + 3];
                }
            }

            using var outStream = new InMemoryRandomAccessStream();
            var encoder = await BitmapEncoder.CreateAsync(BitmapEncoder.PngEncoderId, outStream);
            encoder.SetPixelData(BitmapPixelFormat.Rgba8, BitmapAlphaMode.Premultiplied,
                (uint)size, (uint)size, 96.0, 96.0, result);
            await encoder.FlushAsync();

            using var ms = new MemoryStream();
            await outStream.AsStreamForRead().CopyToAsync(ms);
            return ms.ToArray();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[UserAvatarService] 裁剪失败 ({imageBytes.Length} bytes): {ex.Message}");
            return null;
        }
        finally
        {
            if (File.Exists(tempPath)) File.Delete(tempPath);
        }
    }

    private static void EnsureCacheDirectory()
    {
        if (!Directory.Exists(CacheDirectory)) Directory.CreateDirectory(CacheDirectory);
    }

    public void EnsureAvatarUrlRecord()
    {
        try
        {
            if (_serverUrlService.GetByKey(AvatarUrlKey) != null) return;
            _serverUrlService.Register(AvatarUrlKey, "用户头像", string.Empty, category: "User");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[UserAvatarService] 注册URL记录失败: {ex.Message}");
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _httpClient.Dispose();
    }
}
