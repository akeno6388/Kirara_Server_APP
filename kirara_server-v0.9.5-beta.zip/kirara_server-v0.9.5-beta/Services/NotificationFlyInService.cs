using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 全局通知飞入弹窗服务 — 服务项（Service 类别）通知出现时在软件右下角串行展示。
///
/// ## 展示规则
/// - 仅处理 <see cref="NotificationCategory.Service"/> 类别的通知
/// - 实时推送 / 本地服务通知 → 完整内容弹窗入队（串行：一次只显示一条，
///   用户点击销毁当前弹窗后才显示下一条，与 Win11 通知一致，不点击一直显示）
/// - 离线补拉（Source == "OfflineCatchUp"）→ 聚合为一条「有新消息」提示，
///   批量补拉的多条通知只弹一条提示，避免登录时爆炸式堆叠；提示进入同一串行队列
/// - 首页就绪门控：登录过渡/首页入场动画期间通知只入队不展示，
///   首页加载完成（SetReady）后才依次飞入，避免干扰登录→首页过渡
/// - 登出时清空队列并销毁当前弹窗（防止残留上一用户的弹窗）
///
/// UI 层（ShellPage）通过 <see cref="ShowRequested"/> / <see cref="DismissRequested"/>
/// 事件渲染与销毁弹窗；用户点击弹窗时调用 <see cref="DismissCurrent"/>。
/// </summary>
public class NotificationFlyInService
{
    /// <summary>离线补拉通知的 Source 标记（RemoteNotificationService 写入）</summary>
    private const string OfflineCatchUpSource = "OfflineCatchUp";

    private readonly INotificationService _notificationService;
    private readonly ILoginService _loginService;

    /// <summary>UI 线程调度器（App 启动时由 CaptureUiDispatcher 捕获）</summary>
    private Microsoft.UI.Dispatching.DispatcherQueue? _dispatcherQueue;

    /// <summary>串行展示队列（一次仅出队一条）</summary>
    private readonly Queue<FlyInPayload> _queue = new();

    /// <summary>当前是否正在展示弹窗（true 时新通知只能排队）</summary>
    private bool _isShowing;

    /// <summary>当前正在展示的载荷（用于销毁时判断是否为离线提示）</summary>
    private FlyInPayload? _currentPayload;

    /// <summary>
    /// 离线补拉提示是否已在队列中/展示中（防止批量补拉重复入队；
    /// 提示被用户点击销毁后才允许下一条补拉提示入队）
    /// </summary>
    private bool _offlineSummaryQueued;

    /// <summary>
    /// 首页是否已加载完成（登录成功并进入主界面、入场动画结束）。
    /// 未就绪时通知只入队不展示，避免在登录过渡/首页入场动画期间弹窗干扰；
    /// 由 ShellPage 在首页入场完成后调用 <see cref="SetReady"/> 放行队列。
    /// </summary>
    private bool _isReady;

    public NotificationFlyInService(
        INotificationService notificationService,
        ILoginService loginService)
    {
        _notificationService = notificationService;
        _loginService = loginService;
        _notificationService.OnNotificationReceived += OnNotificationReceived;
        _loginService.LoginStateChanged += OnLoginStateChanged;
    }

    /// <summary>
    /// 标记首页已加载完成（登录成功并进入主界面后由 ShellPage 调用）。
    /// 放行串行队列：积压的离线提示/实时通知此时才开始依次飞入。
    /// </summary>
    public void SetReady()
    {
        if (_dispatcherQueue != null && !_dispatcherQueue.HasThreadAccess)
        {
            _dispatcherQueue.TryEnqueue(SetReady);
            return;
        }

        _isReady = true;
        TryShowNext();
    }

    /// <summary>
    /// 由 App.OnLaunched 在 UI 线程调用，捕获 UI 线程的 DispatcherQueue。
    /// 通知总线的事件可能来自后台线程（SignalR 回调 / HTTP 补拉），
    /// 队列操作与事件触发必须统一在 UI 线程执行。
    /// </summary>
    public void CaptureUiDispatcher()
    {
        _dispatcherQueue = Microsoft.UI.Dispatching.DispatcherQueue.GetForCurrentThread();
    }

    /// <summary>请求 UI 显示一条飞入弹窗（载荷内容，UI 线程触发）</summary>
    public event Action<FlyInPayload>? ShowRequested;

    /// <summary>请求 UI 销毁当前弹窗（UI 线程触发）</summary>
    public event Action? DismissRequested;

    /// <summary>
    /// UI 层调用：用户点击当前弹窗任意区域 → 销毁当前弹窗并展示下一条（串行）。
    /// </summary>
    public void DismissCurrent()
    {
        if (!_isShowing) return;

        _isShowing = false;

        // 离线提示被销毁 → 允许下一条补拉提示入队（同一批补拉期间仍会去重）
        if (_currentPayload?.IsOfflineSummary == true)
            _offlineSummaryQueued = false;
        _currentPayload = null;

        DismissRequested?.Invoke();
        TryShowNext();
    }

    /// <summary>
    /// 通知总线事件处理 — 仅关注服务项通知。
    /// 离线补拉（Source="OfflineCatchUp"）聚合为一条提示；其余完整内容入队。
    /// </summary>
    private void OnNotificationReceived(AppNotification notification)
    {
        if (notification.Category != NotificationCategory.Service) return;

        // 启动恢复的历史通知不弹窗：本地缓存恢复的通知统一走
        // 离线补拉（OfflineCatchUp）的聚合提示兜底，避免启动时逐条弹完整内容
        if (notification.IsRestored) return;

        // 非 UI 线程 → 切到 UI 线程处理（队列非线程安全，统一 UI 线程操作）
        if (_dispatcherQueue != null && !_dispatcherQueue.HasThreadAccess)
        {
            _dispatcherQueue.TryEnqueue(() => OnNotificationReceived(notification));
            return;
        }

        // 离线补拉 → 聚合提示（已排队/展示中则忽略后续批量通知）
        if (notification.Source == OfflineCatchUpSource)
        {
            if (_offlineSummaryQueued) return;
            _offlineSummaryQueued = true;
            Enqueue(new FlyInPayload
            {
                Title = "通知中心有新消息",
                Message = "离线期间服务项收到了新通知，请前往通知中心查看",
                Severity = NotificationSeverity.Info,
                Timestamp = DateTime.Now,
                IsOfflineSummary = true,
            });
            return;
        }

        // 实时推送 / 本地服务通知 → 完整内容展示
        Enqueue(new FlyInPayload
        {
            Title = notification.Title,
            Message = notification.DisplayMessage,
            Severity = notification.Severity,
            Timestamp = notification.Timestamp,
            IsOfflineSummary = false,
        });
    }

    private void Enqueue(FlyInPayload payload)
    {
        _queue.Enqueue(payload);
        // 首页未加载完成（登录过渡/入场动画中）→ 仅入队暂存，就绪后统一放行
        if (_isReady)
            TryShowNext();
    }

    /// <summary>
    /// 无弹窗展示中且队列非空 → 出队一条并请求 UI 显示。
    /// </summary>
    private void TryShowNext()
    {
        if (_isShowing || _queue.Count == 0) return;

        _currentPayload = _queue.Dequeue();
        _isShowing = true;
        ShowRequested?.Invoke(_currentPayload);
    }

    /// <summary>
    /// 登出时清空队列并销毁当前弹窗（通知总线已由 RemoteNotificationService 清空）。
    /// </summary>
    private void OnLoginStateChanged(bool isLoggedIn)
    {
        if (isLoggedIn) return;

        // 切到 UI 线程执行（LoginStateChanged 可能由后台线程触发）
        if (_dispatcherQueue != null && !_dispatcherQueue.HasThreadAccess)
        {
            _dispatcherQueue.TryEnqueue(() => OnLoginStateChanged(false));
            return;
        }

        _queue.Clear();
        _offlineSummaryQueued = false;
        // 退出登录 → 首页就绪状态失效，下次登录重新等首页加载完成
        _isReady = false;
        if (_isShowing)
        {
            _isShowing = false;
            _currentPayload = null;
            DismissRequested?.Invoke();
        }
    }
}

/// <summary>飞入弹窗展示数据（由 ShellPage 渲染）</summary>
public class FlyInPayload
{
    /// <summary>通知标题</summary>
    public string Title { get; init; } = string.Empty;

    /// <summary>消息正文（已按互动通知重排的 DisplayMessage）</summary>
    public string Message { get; init; } = string.Empty;

    /// <summary>严重程度（驱动图标与颜色）</summary>
    public NotificationSeverity Severity { get; init; }

    /// <summary>通知时间</summary>
    public DateTime Timestamp { get; init; }

    /// <summary>是否为离线补拉提示（区别于完整内容通知）</summary>
    public bool IsOfflineSummary { get; init; }
}