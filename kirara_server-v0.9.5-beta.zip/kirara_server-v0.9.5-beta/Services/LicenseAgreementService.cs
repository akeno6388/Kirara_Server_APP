using Kirara_Server_WinUI.Data;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 许可协议同意状态服务 — 按登录账户持久化「是否已同意软件许可协议」。
///
/// - 存储：LiteDB app_settings 集合，键格式 "license.agreed.{userId:N}"
/// - 语义：每个账户独立记录；未登录（CurrentUserId == Guid.Empty）时视为未同意
/// - 撤回：设置中心「数据管理」提供撤回入口，撤回后清除该账户的同意标记
/// </summary>
public class LicenseAgreementService
{
    private const string KeyPrefix = "license.agreed.";

    private readonly IAppSettingsRepository _settings;
    private readonly ILoginService _loginService;

    public LicenseAgreementService(IAppSettingsRepository settings, ILoginService loginService)
    {
        _settings = settings;
        _loginService = loginService;
    }

    /// <summary>当前登录账户是否已同意许可协议（未登录时返回 false）</summary>
    public bool IsAgreed => _loginService.CurrentUserId != Guid.Empty &&
                            ParseBool(_settings.Get(KeyForCurrentUser()), false);

    /// <summary>
    /// 标记当前登录账户已同意许可协议（持久化）。
    /// 未登录时忽略（实例编辑器本身要求已登录才能进入）。
    /// </summary>
    public void MarkAgreed()
    {
        var userId = _loginService.CurrentUserId;
        if (userId == Guid.Empty) return;
        _settings.Set(KeyFor(userId), "1");
    }

    /// <summary>
    /// 撤回当前登录账户的许可协议同意（清除持久化标记）。
    /// </summary>
    public void Revoke()
    {
        var userId = _loginService.CurrentUserId;
        if (userId == Guid.Empty) return;
        _settings.Set(KeyFor(userId), null);
    }

    private string KeyForCurrentUser() => KeyFor(_loginService.CurrentUserId);

    private static string KeyFor(Guid userId) => $"{KeyPrefix}{userId:N}";

    /// <summary>解析 "1"/"true" → true；"0"/"false" → false；其他 → defaultValue</summary>
    private static bool ParseBool(string? raw, bool defaultValue)
    {
        if (raw is null)
            return defaultValue;
        if (raw is "1" or "true" or "True")
            return true;
        if (raw is "0" or "false" or "False")
            return false;
        return defaultValue;
    }
}