using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.ViewModels.Comment;
using Kirara_Server_WinUI.ViewModels.Controls;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls.Primitives;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 通知跳转服务 — 点击互动通知的资源名时，跳转到对应的 Kirara Media 资源页面。
///
/// ## 跳转条件（已与需求确认绑死）
/// 仅支持同时满足以下条件的实例：
/// 1. 绑定了 Kirara Media 方案且绑定启用（IsEnabled=true）；
/// 2. 绑定了议题方案且绑定启用（IsEnabled=true）；
/// 3. 实例定位 ——
///    - 普通评论/点赞通知（打包键含精确 instanceId 时）：instanceId 精确匹配；
///    - 首页分享通知（ActionType=4）：按用户需求（v1.14 fix2）**忽略**打包键的
///      instanceId，与普通键一样按 media 方案可达 URL 的 authority 匹配。
///
/// ## 多实例处理
/// - 多个候选且都未启动 → 固定选择最新创建（CreatedAt）的实例；
/// - 多个候选同时运行 → 弹警告「请关闭多余的实例」（意图不明，可能点错实例）；
/// - 单个候选已启动 → 直接跳转工作区；
/// - 目标未启动 → 弹确认飞入「是否立即打开并跳转？」→ 是 → 导航先导页自动部署，
///   部署完成（所有方案就绪）后自动进入工作区并跳转到资源。
///
/// ## 跳转方式
/// 复用首页分享「查看」跳转机制：构造 SharedContentNavigationParameter
/// （InstanceId + Media 方案 Id + 目标 URL）→ NavigateTo(InstanceWorkspace)。
/// InstanceWorkspace.OnNavigatedTo 会定位到 Media 方案标签并导航到源 URL，
/// 议题方案天然包含在该实例中（无需额外处理评论窗口）。
/// </summary>
public class NotificationJumpService
{
    private readonly IInstanceService _instanceService;
    private readonly ISchemeService _schemeService;
    private readonly ITokenService _tokenService;
    private readonly IServerUrlService _serverUrlService;
    private readonly INavigationService _navigationService;
    private readonly LeftFunctionBarViewModel _leftBarViewModel;

    /// <summary>内置 Media 方案 ID（全客户端硬编码一致，跨设备有效）</summary>
    private static readonly Guid MediaSchemeGuid =
        Guid.Parse("a1000001-0000-0000-0000-000000000001");

    /// <summary>内置议题方案 ID（全客户端硬编码一致，跨设备有效）</summary>
    private static readonly Guid TopicSchemeGuid =
        Guid.Parse("a1000004-0000-0000-0000-000000000001");

    public NotificationJumpService(
        IInstanceService instanceService,
        ISchemeService schemeService,
        ITokenService tokenService,
        IServerUrlService serverUrlService,
        INavigationService navigationService,
        LeftFunctionBarViewModel leftBarViewModel)
    {
        _instanceService = instanceService;
        _schemeService = schemeService;
        _tokenService = tokenService;
        _serverUrlService = serverUrlService;
        _navigationService = navigationService;
        _leftBarViewModel = leftBarViewModel;
    }

    /// <summary>
    /// 尝试跳转到互动通知关联的 Kirara Media 资源页面。
    /// 必须在 UI 线程调用（NavigateTo 与 Flyout 均要求 UI 线程）。
    /// </summary>
    /// <param name="notification">被点击的通知条目</param>
    /// <param name="flyoutTarget">飞入确认/警告的附着元素（如通知卡片/资源名 Hyperlink）</param>
    public async Task TryJumpAsync(AppNotification notification, FrameworkElement flyoutTarget)
    {
        // 广播通知 / 无资源键 → 无跳转语义，忽略
        if (notification == null || string.IsNullOrEmpty(notification.ResourceKey))
            return;

        // 仅支持绑定 Kirara Media 的互动通知（SchemeName 缺失时从资源键提取）
        var schemeName = notification.GetEffectiveSchemeName();
        if (!string.Equals(schemeName, "media", StringComparison.OrdinalIgnoreCase))
            return;

        // 解析资源键：打包键（首页分享）→ 精确 instanceId + 原 URL；普通键 → authority 匹配
        var unpacked = ResourceKeyPacker.Unpack(notification.ResourceKey);
        var resourceKey = unpacked.ResourceKey;
        var sourceUrl = unpacked.SourceUrl;
        var exactInstanceId = unpacked.InstanceId;

        // 从资源键提取 authority 与 path（普通键：media://authority/path#frag）
        var authority = ExtractAuthority(resourceKey);
        var resourcePath = ExtractPath(resourceKey);

        // 内置方案 GUID（数据库有记录时用数据库值，保证与种子一致）
        var mediaSchemeId = ResolveSchemeId("media", MediaSchemeGuid);
        var topicSchemeId = ResolveSchemeId("topic", TopicSchemeGuid);
        if (mediaSchemeId == Guid.Empty || topicSchemeId == Guid.Empty)
        {
            ShowWarning(flyoutTarget, "未找到 Kirara Media 或议题方案，请检查内置方案数据");
            return;
        }

        // ---- 候选实例筛选 ----
        // 分享通知（ActionType=4）打包键含精确 instanceId，但按用户需求（v1.14 fix2），
        // 分享跳转也应固定选择最新创建的满足要求的实例 —— 因此分享通知**忽略**打包键的
        // instanceId 精确匹配，与普通键一样按 authority 匹配（候选含所有满足要求且
        // 服务器匹配的实例），由下方"最新创建"选择逻辑决定目标。
        // 匹配 authority 优先用资源键前缀；分享通知资源键无前缀时回退 SourceUrl 主机。
        var effectiveAuthority = authority ?? ExtractSourceUrlAuthority(sourceUrl);
        var isShareNotification = notification.ActionType == 4;

        var candidates = new List<Instance>();
        foreach (var instance in _instanceService.GetAllInstances())
        {
            // 硬性条件：同时绑定 Media 与议题，且两者绑定均启用
            var mediaBinding = instance.SchemeBindings
                .FirstOrDefault(b => b.SchemeId == mediaSchemeId);
            var topicBinding = instance.SchemeBindings
                .FirstOrDefault(b => b.SchemeId == topicSchemeId);
            if (mediaBinding == null || topicBinding == null)
                continue;
            if (!mediaBinding.IsEnabled || !topicBinding.IsEnabled)
                continue;

            // 定位条件：非分享通知打包键精确匹配 instanceId；
            // 其余（普通键 / 分享通知）匹配可达 URL 的 authority
            bool matches;
            if (!isShareNotification && exactInstanceId != Guid.Empty)
            {
                matches = instance.Id == exactInstanceId;
            }
            else if (string.IsNullOrEmpty(effectiveAuthority))
            {
                matches = false;
            }
            else
            {
                var reachableUrl = ResolveInstanceSchemeUrl(instance, mediaSchemeId);
                matches = reachableUrl != null &&
                    IsAuthorityMatch(reachableUrl, effectiveAuthority);
            }

            if (matches)
                candidates.Add(instance);
        }

        // ---- 无候选 → 警告 ----
        // ⚠️ 文案与评论区通知跳转保持一致（以评论区文本为准）：
        // 分享通知（ActionType=4）按 v1.14 fix2 忽略打包键 instanceId、按 authority 匹配，
        // 无候选的实际原因与普通评论/点赞通知相同（无 authority 匹配的实例），
        // 不再按 exactInstanceId 区分文案，避免同一场景出现两种提示。
        if (candidates.Count == 0)
        {
            ShowWarning(flyoutTarget,
                "未找到同时绑定并开启 Kirara Media 与议题方案的实例");
            return;
        }

        // ---- 多实例运行检测 ----
        // 仅统计候选实例（与通知资源 authority/instanceId 匹配）中已启动的数量：
        // 与通知资源无关的实例（不同服务器）即使已启动也不应干扰本次跳转判定。
        // 多个候选同时运行 → 无法确定用户意图，要求用户先关闭多余的实例。
        var running = candidates
            .Where(c => _leftBarViewModel.IsInstanceStarted(c.Id))
            .ToList();

        if (running.Count >= 2)
        {
            ShowWarning(flyoutTarget,
                "检测到多个实例正在运行，请关闭多余的实例后重试");
            return;
        }

        // 目标：候选中的运行实例（唯一）优先；全部未运行时固定取最新创建（CreatedAt）的实例
        var targetInstance = running.Count == 1
            ? running[0]
            : candidates.OrderByDescending(c => c.CreatedAt).First();

        System.Diagnostics.Debug.WriteLine(
            $"[NotificationJump] 候选 {candidates.Count} 个，运行中 {running.Count} 个，" +
            $"目标实例 {targetInstance.Name} ({targetInstance.Id})");

        var jumpUrl = BuildJumpUrl(resourceKey, sourceUrl, resourcePath,
            ResolveInstanceSchemeUrl(targetInstance, mediaSchemeId));
        var jumpTarget = new SharedContentNavigationParameter(
            targetInstance.Id, mediaSchemeId, jumpUrl);

        // ---- 已启动 → 直接跳转工作区 ----
        if (running.Count == 1)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[NotificationJump] 实例已运行，直接跳转工作区 → {jumpUrl}");
            await JumpToWorkspaceAsync(targetInstance, jumpTarget);
            return;
        }

        // ---- 未启动 → 确认后自动部署并跳转 ----
        // 橙色警告确认框（警告设计语言：⚠ 图标 + 橙色确认按钮）
        var confirmed = await FlyoutHelper.ShowWarningConfirmAsync(
            flyoutTarget,
            FlyoutPlacementMode.Bottom,
            "实例未打开",
            $"当前实例「{targetInstance.Name}」未打开，是否立即打开并跳转？",
            confirmText: "立即打开并跳转");

        if (!confirmed) return;

        System.Diagnostics.Debug.WriteLine(
            $"[NotificationJump] 用户确认，导航先导页自动部署实例 {targetInstance.Name} → {jumpUrl}");
        await JumpToDeployAsync(targetInstance, jumpTarget);
    }

    /// <summary>
    /// 目标实例已启动：完全复用左侧栏实例标签点击路径（拦截/权限/高亮/状态灯）后直接进入工作区并跳转。
    /// </summary>
    private Task JumpToWorkspaceAsync(Instance targetInstance, SharedContentNavigationParameter jumpTarget)
    {
        return _leftBarViewModel.SelectInstanceForNotification(targetInstance, jumpTarget);
    }

    /// <summary>
    /// 目标实例未启动：完全复用左侧栏实例标签点击路径（拦截/权限/高亮/状态灯）后进入实例总结页
    /// 自动部署模式。InstanceSummaryPage 检测到 AutoDeployNavigationParameter 后自动触发部署，
    /// 部署完成自动进入工作区并跳转到 jumpTarget。
    /// </summary>
    private Task JumpToDeployAsync(Instance targetInstance, SharedContentNavigationParameter jumpTarget)
    {
        return _leftBarViewModel.SelectInstanceForNotification(targetInstance, jumpTarget);
    }

    // ================================================================
    //  内部方法
    // ================================================================

    /// <summary>从资源键提取 authority（media://host:port/path → host:port），失败返回 null。</summary>
    private static string? ExtractAuthority(string resourceKey)
    {
        if (string.IsNullOrEmpty(resourceKey)) return null;
        var schemeEnd = resourceKey.IndexOf("://", StringComparison.Ordinal);
        if (schemeEnd < 0) return null;

        var rest = resourceKey[(schemeEnd + 3)..];
        // 打包键截断（|| 分隔符之后是 instanceId 等）
        var packSep = rest.IndexOf("||", StringComparison.Ordinal);
        if (packSep >= 0) rest = rest[..packSep];

        var pathStart = rest.IndexOf('/');
        var authority = pathStart >= 0 ? rest[..pathStart] : rest;
        return string.IsNullOrWhiteSpace(authority) ? null : authority;
    }

    /// <summary>从分享 SourceUrl 提取 authority（分享通知资源键无前缀时的匹配回退源），失败返回 null。</summary>
    private static string? ExtractSourceUrlAuthority(string? sourceUrl)
    {
        if (string.IsNullOrWhiteSpace(sourceUrl)) return null;
        try
        {
            return new Uri(sourceUrl).Authority;
        }
        catch (UriFormatException)
        {
            return null;
        }
    }

    /// <summary>从资源键提取 path+fragment（media://host:port/web#/home.html → /web#/home.html），无则返回空串。</summary>
    private static string ExtractPath(string resourceKey)
    {
        if (string.IsNullOrEmpty(resourceKey)) return string.Empty;
        var schemeEnd = resourceKey.IndexOf("://", StringComparison.Ordinal);
        if (schemeEnd < 0) return string.Empty;

        var rest = resourceKey[(schemeEnd + 3)..];
        var packSep = rest.IndexOf("||", StringComparison.Ordinal);
        if (packSep >= 0) rest = rest[..packSep];

        var pathStart = rest.IndexOf('/');
        return pathStart >= 0 ? rest[pathStart..] : string.Empty;
    }

    /// <summary>比较候选 URL 与资源键 authority 是否一致（忽略大小写）。</summary>
    private static bool IsAuthorityMatch(string candidateUrl, string authority)
    {
        try
        {
            var uri = new Uri(candidateUrl);
            return string.Equals(uri.Authority, authority, StringComparison.OrdinalIgnoreCase);
        }
        catch (UriFormatException)
        {
            return false;
        }
    }

    /// <summary>
    /// 解析实例中某方案的可达服务器 URL。
    /// 优先级：绑定令牌 ServerUrl（ResolveTokenUrl：令牌自身 → 注册表键）→ URL 注册表（方案名键）。
    /// </summary>
    private string? ResolveInstanceSchemeUrl(Instance instance, Guid schemeId)
    {
        var binding = instance.SchemeBindings
            .FirstOrDefault(b => b.SchemeId == schemeId && b.IsEnabled);

        if (binding?.TokenId.HasValue == true)
        {
            var token = _tokenService.LoadSecureToken(binding.TokenId.Value);
            if (token != null)
            {
                var url = _serverUrlService.ResolveTokenUrl(token);
                if (!string.IsNullOrWhiteSpace(url))
                    return url;
            }
        }

        var scheme = _schemeService.GetScheme(schemeId);
        if (scheme != null)
        {
            var url = _serverUrlService.GetDecryptedUrl(scheme.Name);
            if (!string.IsNullOrWhiteSpace(url))
                return url;
        }

        return null;
    }

    /// <summary>
    /// 构建跳转 URL：
    /// - 首页分享（打包键）：优先使用打包携带的 SourceUrl（含完整协议）；
    /// - 普通评论/点赞：由资源键 authority+path 拼装，scheme 优先取实例方案 URL 的协议（主机一致时），
    ///   否则默认 https。
    /// </summary>
    private static string BuildJumpUrl(
        string resourceKey, string sourceUrl, string resourcePath, string? instanceSchemeUrl)
    {
        // 打包键 → 原分享 URL 最准确
        if (!string.IsNullOrWhiteSpace(sourceUrl))
            return sourceUrl;

        // 普通键：media://authority/path → scheme://authority/path
        var authority = ExtractAuthority(resourceKey);
        if (string.IsNullOrEmpty(authority))
            return resourceKey;

        var scheme = "https";
        if (!string.IsNullOrWhiteSpace(instanceSchemeUrl))
        {
            try
            {
                var baseUri = new Uri(instanceSchemeUrl);
                if (string.Equals(baseUri.Authority, authority, StringComparison.OrdinalIgnoreCase))
                    scheme = baseUri.Scheme;
            }
            catch (UriFormatException) { }
        }

        return $"{scheme}://{authority}{resourcePath}";
    }

    /// <summary>按名称解析方案 ID（数据库优先，回退内置 GUID 常量）。</summary>
    private Guid ResolveSchemeId(string schemeName, Guid fallbackGuid)
    {
        try
        {
            var scheme = _schemeService.GetAllSchemes()
                .FirstOrDefault(s => s.Name.Equals(schemeName, StringComparison.OrdinalIgnoreCase));
            return scheme?.Id ?? fallbackGuid;
        }
        catch
        {
            return fallbackGuid;
        }
    }

    /// <summary>弹出全局橙色警告飞入提示（警告设计语言：⚠ 图标 + 橙色确定按钮）。</summary>
    private void ShowWarning(FrameworkElement target, string message)
    {
        System.Diagnostics.Debug.WriteLine($"[NotificationJump] 无法跳转: {message}");
        FlyoutHelper.ShowWarningNoticeAsync(
            target, FlyoutPlacementMode.Bottom, "无法跳转", message);
    }
}
