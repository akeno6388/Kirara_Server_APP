using System.Collections.Concurrent;
using System.Diagnostics;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 日志服务实现 — 环形缓冲区 + TraceListener 重定向
///
/// ## 设计要点
/// - 环形缓冲区：保留最近 2000 条日志，防止内存溢出
/// - TraceListener：捕获全项目 Debug.WriteLine 输出，零侵入
/// - 线程安全：使用 ConcurrentQueue 保证多线程写入无竞争
/// - 打包降级：打包后 Debug.WriteLine 不输出时，仅收集显式 Log() 写入
/// </summary>
public class LoggingService : ILoggingService, IDisposable
{
    /// <summary>环形缓冲区最大容量</summary>
    private const int MaxEntries = 2000;

    private readonly ConcurrentQueue<LogEntry> _entries = new();
    private ObservableTraceListener? _traceListener;
    private bool _disposed;

    public LoggingService()
    {
        AttachTraceListener();
        Log(LogLevel.Info, nameof(LoggingService), "日志服务已初始化");
    }

    /// <inheritdoc />
    public void Log(LogLevel level, string source, string message, Exception? exception = null)
    {
        var entry = new LogEntry
        {
            Timestamp = DateTime.Now,
            Level = level,
            Source = source,
            Message = message,
            Exception = exception?.ToString(),
        };

        _entries.Enqueue(entry);

        // 环形缓冲区：超出上限时丢弃最旧条目
        while (_entries.Count > MaxEntries)
        {
            _entries.TryDequeue(out _);
        }

        OnLogAdded?.Invoke(entry);
    }

    /// <inheritdoc />
    public IReadOnlyList<LogEntry> GetLogs(LogLevel? minLevel = null)
    {
        var entries = _entries.ToArray();
        if (minLevel.HasValue)
        {
            entries = entries.Where(e => e.Level >= minLevel.Value).ToArray();
        }
        return Array.AsReadOnly(entries);
    }

    /// <inheritdoc />
    public void ClearLogs()
    {
        while (_entries.TryDequeue(out _)) { }
        Log(LogLevel.Info, nameof(LoggingService), "日志已清空");
    }

    /// <inheritdoc />
    public event Action<LogEntry>? OnLogAdded;

    // ================================================================
    //  TraceListener 重定向
    // ================================================================

    /// <summary>
    /// 注册自定义 TraceListener，将 Debug.WriteLine 输出重定向到 LoggingService
    /// </summary>
    private void AttachTraceListener()
    {
        try
        {
            _traceListener = new ObservableTraceListener(this);
            Trace.Listeners.Add(_traceListener);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[LoggingService] 无法附加 TraceListener: {ex.Message}");
        }
    }

    /// <summary>
    /// 自定义 TraceListener — 将 Debug.Write/WriteLine 转为 LogEntry
    /// </summary>
    private sealed class ObservableTraceListener : TraceListener
    {
        private readonly LoggingService _owner;
        private string _pendingMessage = string.Empty;

        public ObservableTraceListener(LoggingService owner)
        {
            _owner = owner;
        }

        public override void Write(string? message)
        {
            if (message != null)
                _pendingMessage += message;
        }

        public override void WriteLine(string? message)
        {
            var fullMessage = _pendingMessage + (message ?? string.Empty);
            _pendingMessage = string.Empty;

            if (!string.IsNullOrWhiteSpace(fullMessage))
            {
                // 解析 Debug 输出中的 [Tag] 前缀作为 Source
                var source = "Debug";
                var msg = fullMessage;

                if (fullMessage.StartsWith('['))
                {
                    var closeBracket = fullMessage.IndexOf(']');
                    if (closeBracket > 1)
                    {
                        source = fullMessage[1..closeBracket];
                        msg = fullMessage[(closeBracket + 1)..].TrimStart();
                    }
                }

                _owner.Log(LogLevel.Debug, source, msg);
            }
        }
    }

    // ================================================================
    //  IDisposable
    // ================================================================

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        if (_traceListener != null)
        {
            Trace.Listeners.Remove(_traceListener);
            _traceListener.Dispose();
            _traceListener = null;
        }
    }
}
