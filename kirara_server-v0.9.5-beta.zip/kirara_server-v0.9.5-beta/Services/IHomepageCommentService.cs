using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Models.Api;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 首页分享服务接口 — 管理首页评论（分享资源）的查询、创建与点赞
/// 所有数据操作通过远程 API 完成
/// </summary>
public interface IHomepageCommentService
{
    /// <summary>获取首页分享列表（分页）</summary>
    /// <param name="page">页码（从 1 开始）</param>
    /// <param name="pageSize">每页条数</param>
    Task<IReadOnlyList<HomepageCommentItem>> GetHomepageCommentsAsync(int page = 1, int pageSize = 20);

    /// <summary>创建首页分享（将评论分享到首页展示）</summary>
    /// <param name="resourceKey">资源标识键</param>
    /// <param name="schemeId">所属方案 ID</param>
    /// <param name="instanceId">所属实例 ID</param>
    /// <param name="contentTitle">资源内容标题（分享时从评论区标题获取）</param>
    /// <param name="sourceUrl">分享时的页面 URL（用于“查看”时跳转）</param>
    /// <param name="content">分享评语</param>
    Task<HomepageCommentItem> CreateHomepageCommentAsync(string resourceKey, Guid schemeId, Guid instanceId, string contentTitle, string sourceUrl, string content);

    /// <summary>切换分享点赞状态，返回服务端最新结果</summary>
    Task<LikeResult> ToggleLikeAsync(Guid commentId);
}
