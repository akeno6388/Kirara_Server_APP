namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 通知类别
/// </summary>
public enum NotificationCategory
{
    /// <summary>消息推送（来自服务器端的 HTML 通知）</summary>
    Push = 0,

    /// <summary>服务通知（应用内产生的通知、报错等）</summary>
    Service = 1,

    /// <summary>日志通知（Debug 日志输出）</summary>
    Log = 2,
}

/// <summary>
/// 通知严重程度
/// </summary>
public enum NotificationSeverity
{
    /// <summary>信息</summary>
    Info = 0,

    /// <summary>警告</summary>
    Warning = 1,

    /// <summary>错误</summary>
    Error = 2,
}

/// <summary>
/// 应用通知 — 统一的通知数据模型，支持三种类别（Push/Service/Log）
/// </summary>
public class AppNotification : System.ComponentModel.INotifyPropertyChanged
{
    /// <summary>属性变更事件（SchemeIconUri 更新时触发，UI 自动切换图标）</summary>
    public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;

    /// <summary>触发属性变更通知</summary>
    private void OnPropertyChanged(string propertyName) =>
        PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
    /// <summary>通知唯一标识</summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>通知类别</summary>
    public NotificationCategory Category { get; set; }

    /// <summary>严重程度</summary>
    public NotificationSeverity Severity { get; set; }

    /// <summary>严重程度图标（Segoe Fluent Icons 字符，用于 XAML 绑定）</summary>
    public string SeverityGlyph => Severity switch
    {
        NotificationSeverity.Error => "\uE783",    // ✕ 错误
        NotificationSeverity.Warning => "\uE7BA",  // ⚠ 警告
        _ => "\uE946",                             // ℹ 信息
    };

    /// <summary>
    /// 严重程度颜色（用于 XAML StringToBrushConverter 转换）。
    /// Info（默认）→ "KiraraAccentColorBrush"：AppStyles.xaml 共享主题色画刷实例，
    /// 转换器返回该共享实例，AppThemeService 更新其 Color 时已渲染图标即时跟随主题色
    /// （与全局 XAML StaticResource KiraraAccentColorBrush 引用同一实例）。
    /// Error/Warning 为固定语义色（红色/橙色），不跟随主题色。
    /// </summary>
    public string SeverityColor => Severity switch
    {
        NotificationSeverity.Error => "#E74C3C",   // 红色
        NotificationSeverity.Warning => "#F39C12", // 橙色
        _ => "KiraraAccentColorBrush",             // 信息 → 主题色（共享画刷，实时跟随）
    };

    /// <summary>标题</summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>消息正文</summary>
    public string Message { get; set; } = string.Empty;

    /// <summary>
    /// 显示副标题（XAML 绑定用）。
    /// 互动通知按统一格式重排：XXX赞了你在资源『 标题 』下的评论：“内容”；
    /// 广播/日志等非互动通知或信息缺失时原样返回 Message。
    /// 由 DisplayPrefix + DisplayHighlight + DisplaySuffix 三段拼接（拆分逻辑见 EnsureDisplayParts）。
    /// </summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public string DisplayMessage
    {
        get
        {
            EnsureDisplayParts();
            return string.Concat(_displayPrefix, _displayHighlight, _displaySuffix);
        }
    }

    /// <summary>
    /// 显示副标题前缀段（高亮『 资源名 』之前的部分；非互动通知为完整 Message）。
    /// </summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public string DisplayPrefix
    {
        get { EnsureDisplayParts(); return _displayPrefix; }
    }

    /// <summary>
    /// 显示副标题高亮段（『 资源名 』含方头括号，XAML 以主题色渲染；无资源名时为空）。
    /// </summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public string DisplayHighlight
    {
        get { EnsureDisplayParts(); return _displayHighlight; }
    }

    /// <summary>
    /// 显示副标题后缀段（『 资源名 』之后的部分；无资源名时为空）。
    /// </summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public string DisplaySuffix
    {
        get { EnsureDisplayParts(); return _displaySuffix; }
    }

    private string _displayPrefix = string.Empty;
    private string _displayHighlight = string.Empty;
    private string _displaySuffix = string.Empty;
    private bool _displayPartsComputed;
    private readonly object _displayPartsLock = new();

    /// <summary>
    /// 一次性拆分显示文案三段（线程安全，幂等）。
    /// 互动通知（ActionType 1-4）高亮『 资源名 』；其余情况高亮段为空、前缀为完整 Message。
    /// </summary>
    private void EnsureDisplayParts()
    {
        if (_displayPartsComputed) return;

        lock (_displayPartsLock)
        {
            if (_displayPartsComputed) return;

            // 非互动通知（广播/日志等）原样显示
            if (ActionType is null || ActionType < 1 || ActionType > 4)
            {
                _displayPrefix = Message;
                _displayPartsComputed = true;
                return;
            }

            var actor = string.IsNullOrWhiteSpace(ActorName) ? null : ActorName.Trim();
            var title = string.IsNullOrWhiteSpace(ContentTitle) ? null : ContentTitle.Trim();
            var quote = ExtractQuote(Message);

            // 触发者缺失 → 无法重排，原样
            if (actor is null)
            {
                _displayPrefix = Message;
                _displayPartsComputed = true;
                return;
            }

            switch (ActionType.Value)
            {
                case 1: // 回复评论
                case 2: // 点赞评论
                case 3: // 点赞回复
                    var verb = ActionType.Value == 1 ? "回复了" : "赞了";
                    var kind = ActionType.Value == 3 ? "回复" : "评论";

                    // 标题缺失 → 回退旧式文案：XXX赞了你的评论：“内容”
                    if (title is null)
                    {
                        var fallback = $"{actor}{verb}你的{kind}";
                        _displayPrefix = quote is null ? fallback : $"{fallback}：“{quote}”";
                        _displayPartsComputed = true;
                        return;
                    }

                    _displayPrefix = $"{actor}{verb}你在资源";
                    _displayHighlight = $"『 {title} 』";
                    _displaySuffix = quote is null ? $"下的{kind}" : $"下的{kind}：“{quote}”";
                    _displayPartsComputed = true;
                    return;

                case 4: // 点赞首页分享
                    if (title is null)
                    {
                        _displayPrefix = $"{actor}赞了你在社区分享的资源";
                    }
                    else
                    {
                        _displayPrefix = $"{actor}赞了你在社区分享的资源";
                        _displayHighlight = $"『 {title} 』";
                    }
                    _displayPartsComputed = true;
                    return;

                default:
                    _displayPrefix = Message;
                    _displayPartsComputed = true;
                    return;
            }
        }
    }

    /// <summary>从服务端原始文案中提取内容引用（中文引号“...”之间的部分），提取不到返回 null。</summary>
    private static string? ExtractQuote(string message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return null;

        var open = message.IndexOf('“');
        var close = message.LastIndexOf('”');
        if (open < 0 || close <= open)
            return null;

        var quote = message.Substring(open + 1, close - open - 1).Trim();
        return string.IsNullOrWhiteSpace(quote) ? null : quote;
    }

    /// <summary>HTML 内容（消息推送专用，由 WebView2 渲染）</summary>
    public string? HtmlContent { get; set; }

    /// <summary>时间戳</summary>
    public DateTime Timestamp { get; set; } = DateTime.Now;

    /// <summary>是否已读</summary>
    public bool IsRead { get; set; }

    /// <summary>来源模块名</summary>
    public string? Source { get; set; }

    /// <summary>
    /// [瞬态] 是否为启动恢复的历史通知（仅内存标记，不持久化）。
    /// 通知飞入弹窗服务据此跳过恢复路径的通知——历史通知由离线补拉的
    /// 聚合提示兜底，不逐条弹完整内容弹窗。
    /// </summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public bool IsRestored { get; set; }

    // ===== 互动通知定位字段（v1.10 起，广播通知为 null） =====

    /// <summary>互动动作类型（1=回复评论, 2=点赞评论, 3=点赞回复, 4=点赞首页分享；广播通知为 null）</summary>
    public int? ActionType { get; set; }

    /// <summary>触发者用户 ID（用于去重与"谁"；广播通知为 null）</summary>
    public Guid? ActorUserId { get; set; }

    /// <summary>触发者显示名（广播通知为 null）</summary>
    public string? ActorName { get; set; }

    /// <summary>被互动对象 ID（CommentId/ReplyId/HomepageCommentId；广播通知为 null）</summary>
    public Guid? TargetId { get; set; }

    /// <summary>视频资源键（客户端据此定位；广播通知为 null）</summary>
    public string? ResourceKey { get; set; }

    /// <summary>视频标题（广播通知为 null）</summary>
    public string? ContentTitle { get; set; }

    // ===== 方案级通知图标关联（v1.11 起，广播通知为 null） =====

    /// <summary>关联方案名（方案级通知填写，如 "openvpn"；广播通知为 null，显示默认图标）</summary>
    public string? SchemeName { get; set; }

    /// <summary>
    /// 方案在线图标（本地缓存临时明文 URI，运行时填充；null 时 UI 显示默认 SeverityGlyph 图标）。
    /// [JsonIgnore]：临时路径 + 版本号每次启动不同，不持久化，重启后由通知中心重新解析。
    /// </summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public string? SchemeIconUri
    {
        get => _schemeIconUri;
        set
        {
            if (_schemeIconUri != value)
            {
                _schemeIconUri = value;
                OnPropertyChanged(nameof(SchemeIconUri));
            }
        }
    }

    private string? _schemeIconUri;

    /// <summary>
    /// 获取实际生效的方案名（用于方案图标关联）。
    /// 优先返回 SchemeName；缺失时从 ResourceKey 提取兜底
    /// （资源键格式 "{schemeName}://{authority}{path}"，含首页分享打包键
    ///   "{schemeName}://...||{instanceId}||..."，前缀不受 || 分隔符影响）。
    /// 兼容 v1.11 之前持久化的旧数据（无 SchemeName 字段但 ResourceKey 含方案名前缀）。
    /// </summary>
    public string? GetEffectiveSchemeName()
    {
        if (!string.IsNullOrEmpty(SchemeName))
            return SchemeName;

        if (!string.IsNullOrEmpty(ResourceKey))
        {
            var separatorIndex = ResourceKey.IndexOf("://", StringComparison.Ordinal);
            if (separatorIndex > 0)
                return ResourceKey[..separatorIndex];
        }

        return null;
    }
}

/// <summary>
/// 通知服务接口 — 全局唯一通知总线，管理所有通知的发布、查询和标记
/// </summary>
public interface INotificationService
{
    /// <summary>发布一条通知</summary>
    void Publish(AppNotification notification);

    /// <summary>获取通知列表</summary>
    /// <param name="category">按类别过滤，null 表示获取全部</param>
    IReadOnlyList<AppNotification> GetNotifications(NotificationCategory? category = null);

    /// <summary>标记单条为已读</summary>
    void MarkAsRead(Guid id);

    /// <summary>标记某类别全部已读</summary>
    void MarkAllAsRead(NotificationCategory? category = null);

    /// <summary>清空某类别通知</summary>
    void Clear(NotificationCategory? category = null);

    /// <summary>按来源移除通知（用于去重，如远程刷新前清除本地缓存条目）</summary>
    void RemoveBySource(string source);

    /// <summary>按 ID 移除单条通知（用于通知中心单条删除）</summary>
    void RemoveById(Guid id);

    /// <summary>未读总数</summary>
    int UnreadCount { get; }

    /// <summary>通知接收事件</summary>
    event Action<AppNotification>? OnNotificationReceived;
}
