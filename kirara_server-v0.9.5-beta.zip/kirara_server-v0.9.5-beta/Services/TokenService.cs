using System.Text.Json;
using Kirara_Server_WinUI.Data;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

public class TokenService : ITokenService
{
    /// <summary>
    /// 默认令牌固定 Id — 必须是非空 Guid！
    /// LiteDB 5 会将 Guid.Empty 主键视为"未赋值"并自动生成新 Guid（auto-id 行为），
    /// 导致 GetToken(Guid.Empty) 永远查不到、每次登录都重复创建默认令牌、
    /// 导出后再导入产生"默认令牌（1）"副本。非空固定 Guid 才能被原样保留。
    /// </summary>
    public static readonly Guid DefaultTokenId = new("00000000-0000-0000-0000-000000000001");

    private readonly ITokenRepository _tokenRepo;
    private readonly ICryptoService _crypto;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles
    };

    public TokenService(ITokenRepository tokenRepo, ICryptoService crypto)
    {
        _tokenRepo = tokenRepo;
        _crypto = crypto;
    }

    public IEnumerable<Token> GetAllTokens() =>
        _tokenRepo.GetAll();

    public IEnumerable<Token> GetTokensByUser(Guid userId) =>
        _tokenRepo.GetAll().Where(t => t.OwnerUserId == userId);

    public bool IsTokenNameExists(Guid userId, string name) =>
        _tokenRepo.GetAll().Any(t => t.OwnerUserId == userId && t.Name == name);

    public Token? GetToken(Guid id) =>
        _tokenRepo.GetById(id);

    public void UpdateToken(Token token) =>
        _tokenRepo.Update(token);

    public void DeleteToken(Guid id)
    {
        // 不自动清空 SchemeBinding 中的 TokenId：
        // 悬空的 TokenId 让 UI 可以显示 "⚠令牌已被删除" 警告，
        // 同时 ImportToken 可以复用原始 Id 实现自动重链接。
        _tokenRepo.Delete(id);
    }

    /// <summary>
    /// 安全保存令牌 — 对敏感字段加密后存入数据库
    /// </summary>
    public void SaveSecureToken(Token token)
    {
        EncryptSensitiveFields(token);
        _tokenRepo.Update(token);
    }

    /// <summary>
    /// 加密敏感字段后插入新令牌（单次写库，避免明文落库窗口）
    /// </summary>
    public void InsertSecureToken(Token token)
    {
        EncryptSensitiveFields(token);
        _tokenRepo.Insert(token);
    }

    /// <summary>对敏感字段做幂等加密（已加密的跳过），就地修改令牌对象</summary>
    private void EncryptSensitiveFields(Token token)
    {
        if (!_crypto.IsEncrypted(token.AccountName))
            token.AccountName = _crypto.Encrypt(token.AccountName);
        if (!string.IsNullOrEmpty(token.AccountPassword) && !_crypto.IsEncrypted(token.AccountPassword))
            token.AccountPassword = _crypto.Encrypt(token.AccountPassword);
        if (!string.IsNullOrEmpty(token.ApiKey) && !_crypto.IsEncrypted(token.ApiKey))
            token.ApiKey = _crypto.Encrypt(token.ApiKey);
        if (!string.IsNullOrEmpty(token.ServerUrl) && !_crypto.IsEncrypted(token.ServerUrl))
            token.ServerUrl = _crypto.Encrypt(token.ServerUrl);
    }

    /// <summary>已加密则解密，否则原样返回（兼容明文旧数据与 null）</summary>
    private string? DecryptIfEncrypted(string? value) =>
        _crypto.IsEncrypted(value ?? "") ? _crypto.Decrypt(value!) : value;

    /// <summary>
    /// 安全加载令牌 — 解密敏感字段后返回
    /// </summary>
    public Token? LoadSecureToken(Guid id)
    {
        var token = _tokenRepo.GetById(id);
        if (token == null) return null;

        token.AccountName = _crypto.Decrypt(token.AccountName);
        token.AccountPassword = DecryptIfEncrypted(token.AccountPassword);
        token.ApiKey = DecryptIfEncrypted(token.ApiKey);
        token.ServerUrl = DecryptIfEncrypted(token.ServerUrl);
        return token;
    }

    /// <summary>
    /// 解密令牌的敏感字段并返回副本（用于导出等场景，不修改数据库原对象）
    /// 未加密的字段原样保留，兼容旧数据
    /// </summary>
    public Token DecryptForExport(Token token)
    {
        return new Token
        {
            Id = token.Id,
            Name = token.Name,
            TokenType = token.TokenType,
            AccountName = _crypto.Decrypt(token.AccountName),
            AccountPassword = DecryptIfEncrypted(token.AccountPassword),
            ApiKey = DecryptIfEncrypted(token.ApiKey),
            ServerUrl = DecryptIfEncrypted(token.ServerUrl),
            CertificatePath = token.CertificatePath,
            Notes = token.Notes,
            ColorTag = token.ColorTag,
            IsSystem = token.IsSystem,
            CreatedAt = token.CreatedAt,
            UpdatedAt = token.UpdatedAt,
            Metadata = token.Metadata is null ? null : new Dictionary<string, string>(token.Metadata),
            OwnerUserId = token.OwnerUserId
        };
    }

    public byte[] ExportToken(Guid id)
    {
        var token = _tokenRepo.GetById(id);
        if (token == null)
            throw new InvalidOperationException("令牌不存在");

        // 导出前先解密敏感字段，导出明文（由 EncryptWithUid 做跨设备加密）
        var export = DecryptForExport(token);
        var json = JsonSerializer.Serialize(export, JsonOptions);
        return CryptoService.EncryptWithUid(json, export.OwnerUserId ?? Guid.Empty);
    }

    public Token? ImportToken(byte[] data, Guid currentUserId)
    {
        var json = CryptoService.DecryptWithUid(data, currentUserId);
        var token = JsonSerializer.Deserialize<Token>(json);
        if (token == null) return null;

        // Id 冲突 → 直接跳过（返回 null，不覆盖已有令牌）
        if (_tokenRepo.GetById(token.Id) != null)
            return null;

        token.CreatedAt = DateTime.UtcNow;
        token.UpdatedAt = DateTime.UtcNow;

        // 导入的是明文 → 加密后单次落库（避免明文落库窗口）
        InsertSecureToken(token);
        return token;
    }
}
