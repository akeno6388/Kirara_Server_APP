using Microsoft.UI.Xaml.Controls;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 导航服务实现 — 基于 Frame 的页面导航
/// </summary>
public class NavigationService : INavigationService
{
    private Frame? _frame;

    public void Initialize(Frame frame)
    {
        _frame = frame;
    }

    public void NavigateTo<T>() where T : Page =>
        NavigateTo(typeof(T));

    public void NavigateTo(Type pageType, object? parameter = null)
    {
        _frame?.Navigate(pageType, parameter);
    }

    public void GoBack()
    {
        if (_frame?.CanGoBack == true)
            _frame.GoBack();
    }

    public bool CanGoBack => _frame?.CanGoBack ?? false;
}
