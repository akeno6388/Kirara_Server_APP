using System.Security.Cryptography;
using System.Text;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 加密服务实现 — DPAPI + AES-256-GCM 双重加密
/// 使用 Windows DPAPI 保护 AES 密钥，AES-256-GCM 加密实际数据
/// </summary>
public class CryptoService : ICryptoService
{
    private const string KeyPrefix = "KIRARA_ENC:";
    private readonly byte[] _aesKey;

    public CryptoService()
    {
        _aesKey = GetOrCreateAesKey();
    }

    private static byte[] GetOrCreateAesKey()
    {
        var keyFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "Kirara", ".key");

        var directory = Path.GetDirectoryName(keyFile);
        if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            Directory.CreateDirectory(directory);

        if (File.Exists(keyFile))
        {
            var encryptedKey = File.ReadAllBytes(keyFile);
            return ProtectedData.Unprotect(encryptedKey, null, DataProtectionScope.CurrentUser);
        }

        var key = new byte[32]; // AES-256
        RandomNumberGenerator.Fill(key);
        var protectedKey = ProtectedData.Protect(key, null, DataProtectionScope.CurrentUser);
        File.WriteAllBytes(keyFile, protectedKey);
        return key;
    }

    public string Encrypt(string plainText)
    {
        if (string.IsNullOrEmpty(plainText))
            return string.Empty;

        if (IsEncrypted(plainText))
            return plainText;

        var plainBytes = Encoding.UTF8.GetBytes(plainText);
        var nonce = new byte[12]; // 96-bit nonce for GCM
        RandomNumberGenerator.Fill(nonce);

        var cipherBytes = new byte[plainBytes.Length];
        var tag = new byte[16]; // 128-bit authentication tag

        using var aes = new AesGcm(_aesKey, 16);
        aes.Encrypt(nonce, plainBytes, cipherBytes, tag);

        // 组合: nonce + tag + cipher
        var result = new byte[nonce.Length + tag.Length + cipherBytes.Length];
        Buffer.BlockCopy(nonce, 0, result, 0, nonce.Length);
        Buffer.BlockCopy(tag, 0, result, nonce.Length, tag.Length);
        Buffer.BlockCopy(cipherBytes, 0, result, nonce.Length + tag.Length, cipherBytes.Length);

        return KeyPrefix + Convert.ToBase64String(result);
    }

    public string Decrypt(string cipherTextBase64)
    {
        if (string.IsNullOrEmpty(cipherTextBase64))
            return string.Empty;

        if (!IsEncrypted(cipherTextBase64))
            return cipherTextBase64;

        var stripped = cipherTextBase64[KeyPrefix.Length..];
        var data = Convert.FromBase64String(stripped);

        var nonce = data.AsSpan(0, 12);
        var tag = data.AsSpan(12, 16);
        var cipherBytes = data.AsSpan(28);

        var plainBytes = new byte[cipherBytes.Length];

        using var aes = new AesGcm(_aesKey, 16);
        aes.Decrypt(nonce, cipherBytes, tag, plainBytes);

        return Encoding.UTF8.GetString(plainBytes);
    }

    public bool IsEncrypted(string text) =>
        text?.StartsWith(KeyPrefix) ?? false;
    
        public byte[] EncryptToBytes(string plainText)
    {
        if (string.IsNullOrEmpty(plainText))
            return Array.Empty<byte>();

        var plainBytes = Encoding.UTF8.GetBytes(plainText);
        var nonce = new byte[12];
        RandomNumberGenerator.Fill(nonce);

        var cipherBytes = new byte[plainBytes.Length];
        var tag = new byte[16];

        using var aes = new AesGcm(_aesKey, 16);
        aes.Encrypt(nonce, plainBytes, cipherBytes, tag);

        var result = new byte[nonce.Length + tag.Length + cipherBytes.Length];
        Buffer.BlockCopy(nonce, 0, result, 0, nonce.Length);
        Buffer.BlockCopy(tag, 0, result, nonce.Length, tag.Length);
        Buffer.BlockCopy(cipherBytes, 0, result, nonce.Length + tag.Length, cipherBytes.Length);

        return result;
    }

    public string DecryptFromBytes(byte[] cipherBytes)
    {
        if (cipherBytes == null || cipherBytes.Length < 28)
            throw new ArgumentException("密文数据无效");

        var nonce = cipherBytes.AsSpan(0, 12);
        var tag = cipherBytes.AsSpan(12, 16);
        var cipherSpan = cipherBytes.AsSpan(28);

        var plainBytes = new byte[cipherSpan.Length];

        using var aes = new AesGcm(_aesKey, 16);
        aes.Decrypt(nonce, cipherSpan, tag, plainBytes);

        return Encoding.UTF8.GetString(plainBytes);
    }

    // ===== 跨设备导入导出：UID 自包含加密 =====

    private const int ExportUidSize = 16;
    private const int ExportSaltSize = 32;
    private const int ExportNonceSize = 12;
    private const int ExportTagSize = 16;
    private const int ExportHeaderSize = ExportUidSize + ExportSaltSize + ExportNonceSize + ExportTagSize;

    /// <summary>
    /// 使用用户 UID 加密数据（跨设备兼容）
    /// 格式: [uid:16B][salt:32B][nonce:12B][tag:16B][cipher:N]
    /// </summary>
    public static byte[] EncryptWithUid(string plainText, Guid userId)
    {
        var plainBytes = Encoding.UTF8.GetBytes(plainText);
        var uidBytes = userId.ToByteArray();
        var salt = new byte[ExportSaltSize];
        var nonce = new byte[ExportNonceSize];
        RandomNumberGenerator.Fill(salt);
        RandomNumberGenerator.Fill(nonce);

        var key = Rfc2898DeriveBytes.Pbkdf2(
            uidBytes, salt, 600_000, HashAlgorithmName.SHA256, ExportSaltSize);

        var cipher = new byte[plainBytes.Length];
        var tag = new byte[ExportTagSize];
        using var aes = new AesGcm(key, ExportTagSize);
        aes.Encrypt(nonce, plainBytes, cipher, tag);

        var result = new byte[ExportHeaderSize + cipher.Length];
        var offset = 0;
        Buffer.BlockCopy(uidBytes, 0, result, offset, ExportUidSize); offset += ExportUidSize;
        Buffer.BlockCopy(salt, 0, result, offset, ExportSaltSize); offset += ExportSaltSize;
        Buffer.BlockCopy(nonce, 0, result, offset, ExportNonceSize); offset += ExportNonceSize;
        Buffer.BlockCopy(tag, 0, result, offset, ExportTagSize); offset += ExportTagSize;
        Buffer.BlockCopy(cipher, 0, result, offset, cipher.Length);
        return result;
    }

    /// <summary>
    /// 使用用户 UID 解密数据（自动校验文件所属账户）
    /// 文件 UID 与 currentUserId 不匹配时抛出 UnauthorizedAccessException
    /// </summary>
    public static string DecryptWithUid(byte[] data, Guid currentUserId)
    {
        if (data == null || data.Length < ExportHeaderSize)
            throw new InvalidOperationException("文件格式无效或已损坏");

        var fileUid = new Guid(data.AsSpan(0, ExportUidSize));
        if (fileUid != currentUserId)
            throw new UnauthorizedAccessException($"此文件不属于该账户");

        var salt = data.AsSpan(ExportUidSize, ExportSaltSize);
        var nonce = data.AsSpan(ExportUidSize + ExportSaltSize, ExportNonceSize);
        var tag = data.AsSpan(ExportUidSize + ExportSaltSize + ExportNonceSize, ExportTagSize);
        var cipher = data.AsSpan(ExportHeaderSize);

        var key = Rfc2898DeriveBytes.Pbkdf2(
            currentUserId.ToByteArray(), salt, 600_000, HashAlgorithmName.SHA256, ExportSaltSize);

        var plain = new byte[cipher.Length];
        using var aes = new AesGcm(key, ExportTagSize);
        aes.Decrypt(nonce, cipher, tag, plain);
        return Encoding.UTF8.GetString(plain);
    }
    
}
