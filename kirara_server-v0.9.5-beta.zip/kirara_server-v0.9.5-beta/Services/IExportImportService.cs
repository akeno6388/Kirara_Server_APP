namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 导入导出服务 — 处理实例和令牌的 JSON 导入导出
/// </summary>
public interface IExportImportService
{
    string ExportAllInstances();
    byte[] ExportAllTokens();
    /// <returns>(已导入数量, 已跳过数量)</returns>
    (int Imported, int Skipped) ImportInstances(string json);
    /// <returns>(已导入数量, 已跳过数量)</returns>
    (int Imported, int Skipped) ImportTokens(byte[] data);

    /// <summary>一键导出所有数据（实例 + 令牌），UID 加密</summary>
    byte[] ExportAllData();

    /// <summary>一键导入所有数据（实例 + 令牌）</summary>
    /// <returns>(已导入实例, 已跳过实例, 已导入令牌, 已跳过令牌)</returns>
    (int InstancesImported, int InstancesSkipped, int TokensImported, int TokensSkipped) ImportAllData(byte[] data);

    /// <summary>
    /// 一键导入（自动识别文件类型）：
    /// - UID 加密的全量数据文件（实例 + 令牌，校验当前账户）
    /// - 明文实例分享文件（仅实例，任何用户可导入）
    /// </summary>
    /// <returns>(已导入实例, 已跳过实例, 已导入令牌, 已跳过令牌, 是否仅实例分享文件)</returns>
    (int InstancesImported, int InstancesSkipped, int TokensImported, int TokensSkipped, bool IsInstanceOnly) ImportData(byte[] data);
}
