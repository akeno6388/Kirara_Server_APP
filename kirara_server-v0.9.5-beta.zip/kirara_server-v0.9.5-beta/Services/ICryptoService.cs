namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 加密服务接口 — 用于令牌等敏感数据的加密/解密
/// </summary>
public interface ICryptoService
{
    /// <summary>加密明文，返回 Base64 编码的密文</summary>
    string Encrypt(string plainText);

    /// <summary>解密密文（Base64），返回明文</summary>
    string Decrypt(string cipherTextBase64);

    /// <summary>判断字符串是否已加密</summary>
    bool IsEncrypted(string text);
     /// <summary>加密明文，返回原始加密字节（用于导出二进制文件）</summary>
    byte[] EncryptToBytes(string plainText);

    /// <summary>从原始加密字节解密，返回明文</summary>
    string DecryptFromBytes(byte[] cipherBytes);
}