namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 快速开始服务 — 管理预置模板和外部客户端快捷入口
/// </summary>
public interface IQuickStartService
{
    IEnumerable<QuickStartTemplate> GetTemplates();
    IEnumerable<ExternalClient> GetExternalClients();
}

/// <summary>
/// 快速开始模板
/// </summary>
public class QuickStartTemplate
{
    /// <summary>模板 ID（服务端返回）</summary>
    public Guid Id { get; set; }

    /// <summary>模板名称</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>描述</summary>
    public string Description { get; set; } = string.Empty;

    /// <summary>关联的方案 ID 列表</summary>
    public Guid[] SchemeIds { get; set; } = Array.Empty<Guid>();

    /// <summary>封面图片 URL（MinIO 对象键或完整 URL）</summary>
    public string? CoverImageUrl { get; set; }

    /// <summary>分类（如 "media" / "office"）</summary>
    public string? Category { get; set; }

    /// <summary>标签，逗号分隔</summary>
    public string? Tags { get; set; }

    /// <summary>版本号，用于客户端缓存比对</summary>
    public int Version { get; set; } = 1;
}

/// <summary>
/// 外部客户端快捷入口
/// </summary>
public class ExternalClient
{
    public string Name { get; set; } = string.Empty;
    public string ExecutablePath { get; set; } = string.Empty;
    public string? Arguments { get; set; }
    public string IconGlyph { get; set; } = "\uE7C3";
}
