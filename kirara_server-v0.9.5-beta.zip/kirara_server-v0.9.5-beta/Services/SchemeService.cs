using System.Reflection;
using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Data;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Schemes.BuiltIn;
using Kirara_Server_WinUI.Schemes.Service;
using Kirara_Server_WinUI.Schemes;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 方案服务 — 管理方案的 CRUD 和 IScheme 插件实例化
/// </summary>
public class SchemeService : ISchemeService
{
    /// <summary>
    /// 内置方案 ID → 类型映射表（无需反射，编译期安全）
    /// </summary>
    private static readonly Dictionary<Guid, Type> BuiltInSchemeMap = new()
    {
        // ===== 用户实例方案 =====
        [Guid.Parse("a1000001-0000-0000-0000-000000000001")] = typeof(MediaScheme),
        [Guid.Parse("a1000002-0000-0000-0000-000000000001")] = typeof(OpenVpnScheme),
        [Guid.Parse("a1000003-0000-0000-0000-000000000001")] = typeof(SRSLiveScheme),
        [Guid.Parse("a1000004-0000-0000-0000-000000000001")] = typeof(TopicScheme),
        [Guid.Parse("a1000005-0000-0000-0000-000000000001")] = typeof(DriveScheme),
        [Guid.Parse("a1000006-0000-0000-0000-000000000001")] = typeof(KmailScheme),
        [Guid.Parse("a1000007-0000-0000-0000-000000000001")] = typeof(ChatScheme),
        [Guid.Parse("a1000009-0000-0000-0000-000000000001")] = typeof(GameServerScheme),
        [Guid.Parse("a1000010-0000-0000-0000-000000000001")] = typeof(AlistScheme),
        [Guid.Parse("a1000011-0000-0000-0000-000000000001")] = typeof(NoteScheme),
        [Guid.Parse("a1000012-0000-0000-0000-000000000001")] = typeof(MomentScheme),

        // ===== 服务实例方案 =====
        [Guid.Parse("b2000001-0000-0000-0000-000000000001")] = typeof(AppServerScheme),
        [Guid.Parse("b2000002-0000-0000-0000-000000000001")] = typeof(BackupServerScheme),
        [Guid.Parse("b2000003-0000-0000-0000-000000000001")] = typeof(ESXiScheme),
        [Guid.Parse("b2000004-0000-0000-0000-000000000001")] = typeof(IkuaiScheme),
        [Guid.Parse("b2000005-0000-0000-0000-000000000001")] = typeof(OpenWrtScheme),
        [Guid.Parse("b2000006-0000-0000-0000-000000000001")] = typeof(ImmScheme),
        [Guid.Parse("b2000007-0000-0000-0000-000000000001")] = typeof(WinserverDCScheme),
        [Guid.Parse("b2000008-0000-0000-0000-000000000001")] = typeof(WinserverACScheme),
        [Guid.Parse("b2000009-0000-0000-0000-000000000001")] = typeof(CertScheme),
        [Guid.Parse("b2000010-0000-0000-0000-000000000001")] = typeof(WinserverDLScheme),
        [Guid.Parse("b2000011-0000-0000-0000-000000000001")] = typeof(WinserverGNScheme),
        [Guid.Parse("b2000012-0000-0000-0000-000000000001")] = typeof(VmmScheme),
        [Guid.Parse("b2000013-0000-0000-0000-000000000001")] = typeof(OpenVpnServiceScheme),
        [Guid.Parse("b2000014-0000-0000-0000-000000000001")] = typeof(BitCometScheme),
    };

    private static readonly Assembly CurrentAssembly = Assembly.GetExecutingAssembly();

    private readonly ISchemeRepository _schemeRepo;

    public SchemeService(ISchemeRepository schemeRepo)
    {
        _schemeRepo = schemeRepo;
    }

    public IEnumerable<Scheme> GetAllSchemes() =>
        _schemeRepo.GetAll();

    public IEnumerable<Scheme> GetSchemesByInstanceType(InstanceType type) =>
        _schemeRepo.GetByInstanceType(type);

    public Scheme? GetScheme(Guid id) =>
        _schemeRepo.GetById(id);

    /// <summary>
    /// 加载方案实例 — 优先使用内置类型映射表，再回退到反射（兼容第三方扩展）
    /// </summary>
    public IScheme? LoadSchemeInstance(Scheme scheme)
    {
        if (scheme.SchemeType == SchemeType.ThirdParty)
            return null; // 第三方方案不通过代码加载

        // 1. 优先查找内置类型映射表
        if (BuiltInSchemeMap.TryGetValue(scheme.Id, out var schemeType))
        {
            return Activator.CreateInstance(schemeType) as IScheme;
        }

        // 2. 回退：通过 EntryAssembly/EntryTypeName 反射加载（兼容旧数据）
        if (!string.IsNullOrEmpty(scheme.EntryAssembly) &&
            !string.IsNullOrEmpty(scheme.EntryTypeName))
        {
            try
            {
                var type = CurrentAssembly.GetType(scheme.EntryTypeName);
                if (type != null)
                    return Activator.CreateInstance(type) as IScheme;
            }
            catch
            {
                // 反射失败，静默处理
            }
        }

        return null;
    }

    public void RegisterThirdPartyScheme(string executablePath, string? arguments = null)
    {
        var name = Path.GetFileNameWithoutExtension(executablePath);
        var scheme = new Scheme
        {
            Name = $"thirdparty_{name.ToLowerInvariant()}",
            DisplayName = name,
            Description = "第三方导入方案",
            SchemeType = SchemeType.ThirdParty,
            InstanceType = InstanceType.UserInstance,
            UIKind = SchemeUIKind.ExternalProcess,
            IconGlyph = "\uE7C3",
            ExecutablePath = executablePath,
            Arguments = arguments,
            IsSystem = false
        };

        _schemeRepo.Insert(scheme);
    }

    /// <summary>
    /// 将内置方案代码中的最新属性（Description、DisplayName 等）同步到数据库。
    /// 每次应用启动时调用，确保代码修改后数据库中的记录保持最新。
    /// </summary>
    public void SyncBuiltInSchemas()
    {
        foreach (var (id, type) in BuiltInSchemeMap)
        {
            var instance = Activator.CreateInstance(type) as BaseScheme;
            if (instance == null) continue;

            // 按适用实例类型计算期望的方案来源类型（与 AppDatabase.SeedBuiltInSchemes 保持一致）
            var expectedSchemeType = instance.InstanceType == InstanceType.ServiceInstance
                ? SchemeType.Server
                : SchemeType.BuiltIn;

            var dbScheme = _schemeRepo.GetById(id);
            if (dbScheme == null)
            {
                // [修复] 数据库中缺失该内置方案时自动补插。
                // 种子数据仅在数据库为空时写入（见 AppDatabase.SeedBuiltInSchemes），
                // 早于该方案引入的旧数据库不会自动获得新内置方案（如议题方案），
                // 导致依赖方案记录的功能（评论区绑定等）对旧数据创建的实例失效。
                var ui = instance.GetUI();
                _schemeRepo.Insert(new Scheme
                {
                    Id = instance.Id,
                    Name = instance.Name,
                    DisplayName = instance.DisplayName,
                    Description = instance.Description,
                    SchemeType = expectedSchemeType,
                    InstanceType = instance.InstanceType,
                    UIKind = instance.UIKind,
                    IconGlyph = instance.IconGlyph,
                    EntryAssembly = type.Assembly.GetName().Name,
                    EntryTypeName = type.FullName,
                    WebViewUrl = ui.WebViewUrl,
                    RequiresRdp = ui.Kind == SchemeUIKind.RDP,
                    IsSystem = true,
                    SortOrder = instance.SortOrder
                });
                continue;
            }

            bool changed = false;

            // [修复] 同步 Name 字段，确保数据库中的 Name 与代码定义一致
            // （评论区绑定等逻辑依赖 Name 识别议题方案，旧数据可能写入了过期值）
            if (dbScheme.Name != instance.Name)
            {
                dbScheme.Name = instance.Name;
                changed = true;
            }
            if (dbScheme.DisplayName != instance.DisplayName)
            {
                dbScheme.DisplayName = instance.DisplayName;
                changed = true;
            }
            if (dbScheme.Description != instance.Description)
            {
                dbScheme.Description = instance.Description;
                changed = true;
            }
            if (dbScheme.IconGlyph != instance.IconGlyph)
            {
                dbScheme.IconGlyph = instance.IconGlyph;
                changed = true;
            }
            // [OpenVPN 功能] 同步 UIKind 字段，确保数据库中的 UIKind 与代码定义一致
            // （InstanceSummaryPage 等读取 DB 中 UIKind 判断渲染路径，旧数据可能为过期值）
            if (dbScheme.UIKind != instance.UIKind)
            {
                dbScheme.UIKind = instance.UIKind;
                changed = true;
            }
            // [修复] 同步 SchemeType 字段（旧数据库全部为 BuiltIn，需按 InstanceType 修正为 Server）
            if (dbScheme.SchemeType != expectedSchemeType)
            {
                dbScheme.SchemeType = expectedSchemeType;
                changed = true;
            }

            if (changed)
            {
                _schemeRepo.Update(dbScheme);
            }
        }
    }
}
