using System.Text.Json;
using Kirara_Server_WinUI.Helpers;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 远程信息流卡片服务 — 通过 Kirara Server API 获取信息流卡片，
/// 本地持久化缓存 DTO，支持增量版本同步。
///
/// ## 数据流
/// 启动/登录时:
///   1. 从 LocalInfoCardStore 加载缓存的 DTO（秒显）
///   2. 后台用 POST /api/info-cards/sync 增量同步（上报本地版本）
///   3. 服务端返回 updated/new/deactivated → 合并本地缓存
///   4. 保存到 LocalInfoCardStore → 触发 CardsRefreshed
///
/// ## 版本同步
/// - 每张卡片有 Version 字段
/// - 客户端构建 { cardId: version } 字典上报
/// - 服务端仅返回有变更的卡片
/// - 无变更时网络传输极小（仅版本字典）
///
/// ## API 规范
/// - GET /api/info-cards（需要 [Authorize]）全量拉取（fallback）
/// - POST /api/info-cards/sync（需要 [Authorize]）增量同步
/// </summary>
public class RemoteInfoCardService : IDisposable
{
    private readonly HttpClient _httpClient;
    private readonly IServerUrlService _serverUrlService;
    private readonly ILoginService _loginService;
    private readonly INotificationService _notificationService;
    private readonly LocalInfoCardStore _localStore;

    /// <summary>信息流 API URL 注册键名</summary>
    private const string InfoCardsApiUrlKey = "info_cards_api";

    /// <summary>默认 API 基础地址</summary>
    private const string DefaultApiBaseUrl = "https://api.akeno6388.online:1010";

    /// <summary>API 基础地址</summary>
    private string ApiBaseUrl =>
        _serverUrlService.GetDecryptedUrl(InfoCardsApiUrlKey) ?? DefaultApiBaseUrl;

    /// <summary>UI 线程调度器</summary>
    private Microsoft.UI.Dispatching.DispatcherQueue? _dispatcherQueue;

    /// <summary>当前缓存的卡片原始 DTO（线程安全）</summary>
    private List<InfoCardResponseData> _cachedCards = new();
    private readonly object _cardsLock = new();

    /// <summary>是否已释放</summary>
    private bool _disposed;

    /// <summary>
    /// 当信息流卡片数据更新时触发（本地缓存加载或远程同步完成后）。
    /// </summary>
    public event Action? CardsRefreshed;

    public RemoteInfoCardService(
        IServerUrlService serverUrlService,
        ILoginService loginService,
        INotificationService notificationService,
        LocalInfoCardStore localStore)
    {
        _serverUrlService = serverUrlService;
        _loginService = loginService;
        _notificationService = notificationService;
        _localStore = localStore;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
        _httpClient.Timeout = TimeSpan.FromSeconds(15);

        // 订阅登录状态变更：登录后加载本地缓存 + 远程同步
        loginService.LoginStateChanged += OnLoginStateChanged;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _httpClient.Dispose();
        _loginService.LoginStateChanged -= OnLoginStateChanged;
    }

    /// <summary>
    /// 由 App.OnLaunched 在 UI 线程调用，捕获 UI 线程的 DispatcherQueue。
    /// </summary>
    public void CaptureUiDispatcher()
    {
        _dispatcherQueue = Microsoft.UI.Dispatching.DispatcherQueue.GetForCurrentThread();
        System.Diagnostics.Debug.WriteLine(
            $"[RemoteInfoCardService] UI 调度器已捕获 (HasThreadAccess={_dispatcherQueue?.HasThreadAccess})");
    }

    /// <summary>
    /// 获取缓存的卡片原始 DTO 列表（线程安全），
    /// 已按 SortOrder 升序排序（同级按 CreatedAt 降序）。
    /// </summary>
    internal IReadOnlyList<InfoCardResponseData> GetCachedCards()
    {
        lock (_cardsLock)
        {
            var snapshot = _cachedCards.ToList();
            SortByOrder(snapshot);
            return snapshot.AsReadOnly();
        }
    }

    /// <summary>
    /// 按 API 返回的 SortOrder 升序排序卡片（数字越小越靠前）。
    /// SortOrder 相同时按 CreatedAt 降序（较新的在前），保证顺序稳定可预期。
    /// </summary>
    private static void SortByOrder(List<InfoCardResponseData> cards)
    {
        cards.Sort((a, b) =>
        {
            int orderCompare = a.SortOrder.CompareTo(b.SortOrder);
            if (orderCompare != 0) return orderCompare;
            return b.CreatedAt.CompareTo(a.CreatedAt);
        });
    }

    // ================================================================
    //  信息流卡片媒体预签名 URL 获取
    //  对应 API: GET /api/info-cards/{id}/media
    //           GET /api/info-cards/{id}/thumbnail
    //  响应: { "success": true, "data": { "presignedUrl": "..." } }
    // ================================================================

    /// <summary>
    /// 通过专用 API 获取信息流卡片媒体的预签名 URL。
    /// </summary>
    /// <param name="cardId">卡片 ID</param>
    /// <param name="field">"media" 或 "thumbnail"</param>
    /// <returns>预签名 URL，失败时返回 null</returns>
    public async Task<string?> GetMediaPresignedUrlAsync(Guid cardId, string field)
    {
        var accessToken = await GetValidAccessTokenAsync();
        if (string.IsNullOrEmpty(accessToken)) return null;

        try
        {
            var endpoint = field == "thumbnail" ? "thumbnail" : "media";
            var url = $"{ApiBaseUrl}/api/info-cards/{cardId:D}/{endpoint}";

            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

            using var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[RemoteInfoCardService] 预签名 URL API 返回 {(int)response.StatusCode}: {url}");
                return null;
            }

            var json = await response.Content.ReadAsStringAsync();
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<PresignedUrlResponse>>(json);
            if (apiResponse?.Success != true || apiResponse.Data?.PresignedUrl == null)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[RemoteInfoCardService] 预签名 URL API 响应异常: {url}");
                return null;
            }

            System.Diagnostics.Debug.WriteLine(
                $"[RemoteInfoCardService] 获取预签名 URL 成功: {field}/{cardId:N}");
            return apiResponse.Data.PresignedUrl;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteInfoCardService] 预签名 URL 获取失败: {field}/{cardId:N}: {ex.Message}");
            return null;
        }
    }

    // ================================================================
    //  登录状态变更
    // ================================================================

    private void OnLoginStateChanged(bool isLoggedIn)
    {
        if (isLoggedIn)
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteInfoCardService] 用户登录成功，加载并同步信息流卡片");
            _ = LoadLocalThenSyncAsync();
        }
    }

    // ================================================================
    //  公开 API
    // ================================================================

    /// <summary>
    /// 强制刷新：重新从本地缓存加载 + 远程增量同步。
    /// 供 UI 在页面加载时调用，确保数据是最新的。
    /// </summary>
    public async Task ForceRefreshAsync()
    {
        var localCards = await Task.Run(() => _localStore.Load());
        lock (_cardsLock)
        {
            _cachedCards = localCards.Count > 0 ? localCards : _cachedCards;
            SortByOrder(_cachedCards);
        }
        await IncrementalSyncAsync(localCards);
    }

    // ================================================================
    //  加载本地缓存 → 远程增量同步
    // ================================================================

    /// <summary>
    /// Step 1: 从本地缓存加载 DTO（立即显示）
    /// Step 2: 远程增量同步（后台）
    /// </summary>
    private async Task LoadLocalThenSyncAsync()
    {
        try
        {
            // Step 1: 从本地缓存加载原始 DTO（秒显）
            var localCards = await Task.Run(() => _localStore.Load());
            if (localCards.Count > 0)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[RemoteInfoCardService] 从本地缓存加载 {localCards.Count} 条信息流卡片 DTO");

                lock (_cardsLock)
                {
                    _cachedCards = localCards;
                    SortByOrder(_cachedCards);
                }

                // 通知 UI 可以使用本地缓存数据了
                FireCardsRefreshed();

                System.Diagnostics.Debug.WriteLine(
                    "[RemoteInfoCardService] ✅ 版本匹配：直接使用本地缓存，无需网络");
            }

            // Step 2: 远程增量同步（版本比对）
            await IncrementalSyncAsync(localCards);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteInfoCardService] 加载失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 增量同步：上报本地版本字典，服务端仅返回有变更的卡片。
    /// </summary>
    private async Task IncrementalSyncAsync(List<InfoCardResponseData> localCards)
    {
        var accessToken = await GetValidAccessTokenAsync();
        if (string.IsNullOrEmpty(accessToken))
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteInfoCardService] 无有效 AccessToken，跳过同步");
            return;
        }

        try
        {
            // 构建本地版本字典: { "cardId": version }
            var localVersions = new Dictionary<string, int>();
            foreach (var card in localCards)
            {
                localVersions[card.Id.ToString("D")] = card.Version;
            }

            System.Diagnostics.Debug.WriteLine(
                $"[RemoteInfoCardService] 增量同步: 上报 {localVersions.Count} 个本地版本");

            // 序列化请求体
            var syncRequest = new InfoCardSyncRequest
            {
                LocalVersions = localVersions
            };
            var requestJson = JsonSerializer.Serialize(syncRequest);
            var content = new StringContent(requestJson, System.Text.Encoding.UTF8, "application/json");

            using var request = new HttpRequestMessage(HttpMethod.Post,
                $"{ApiBaseUrl}/api/info-cards/sync")
            {
                Content = content
            };
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[RemoteInfoCardService] 增量同步 API 返回 {(int)response.StatusCode}");
                response.Dispose();
                return;
            }

            var json = await response.Content.ReadAsStringAsync();
            response.Dispose();

            var apiResponse = JsonSerializer.Deserialize<ApiResponse<InfoCardSyncResponseData>>(json);
            if (apiResponse?.Success != true || apiResponse.Data == null)
            {
                System.Diagnostics.Debug.WriteLine(
                    "[RemoteInfoCardService] 增量同步响应异常");
                return;
            }

            var syncData = apiResponse.Data;
            int updatedCount = syncData.Updated?.Count ?? 0;
            int newCount = syncData.New?.Count ?? 0;
            int deactivatedCount = syncData.Deactivated?.Count ?? 0;

            System.Diagnostics.Debug.WriteLine(
                $"[RemoteInfoCardService] 增量同步结果: 更新={updatedCount}, 新增={newCount}, 停用={deactivatedCount}");

            // 无变更时直接返回
            if (updatedCount == 0 && newCount == 0 && deactivatedCount == 0)
            {
                System.Diagnostics.Debug.WriteLine(
                    "[RemoteInfoCardService] ✅ 版本一致，无需更新");
                return;
            }

            // 合并到本地缓存
            MergeSyncResult(syncData);

            // 保存到本地持久化文件
            List<InfoCardResponseData> merged;
            lock (_cardsLock)
            {
                merged = new List<InfoCardResponseData>(_cachedCards);
            }
            await Task.Run(() => _localStore.SaveAll(merged));

            // 通知 UI
            FireCardsRefreshed();
        }
        catch (HttpRequestException ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteInfoCardService] 网络错误: {ex.Message}");
        }
        catch (TaskCanceledException)
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteInfoCardService] 同步超时");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteInfoCardService] 同步异常: {ex.Message}");
        }
    }

    /// <summary>
    /// 将增量同步结果合并到 _cachedCards。
    /// </summary>
    private void MergeSyncResult(InfoCardSyncResponseData syncData)
    {
        lock (_cardsLock)
        {
            // 1. 移除已停用的卡片（支持 dashed 和 dashless GUID 字符串）
            if (syncData.Deactivated != null && syncData.Deactivated.Count > 0)
            {
                var deactivatedSet = new HashSet<string>(syncData.Deactivated);
                _cachedCards.RemoveAll(c =>
                    deactivatedSet.Contains(c.Id.ToString("D")) ||
                    deactivatedSet.Contains(c.Id.ToString("N")));

                System.Diagnostics.Debug.WriteLine(
                    $"[RemoteInfoCardService] 移除 {syncData.Deactivated.Count} 条停用卡片: {string.Join(", ", syncData.Deactivated)}");

                // 同时清理对应的本地媒体缓存
                CleanMediaForRemovedCards(deactivatedSet);
            }

            // 2. 移除被更新的卡片旧版本
            if (syncData.Updated != null && syncData.Updated.Count > 0)
            {
                var updatedIds = new HashSet<Guid>(syncData.Updated.Select(c => c.Id));
                _cachedCards.RemoveAll(c => updatedIds.Contains(c.Id));
                _cachedCards.AddRange(syncData.Updated);

                // 清理旧版媒体缓存（版本变更了，旧媒体可能已过时）
                CleanMediaForRemovedCards(updatedIds);
            }

            // 3. 添加新卡片（避免重复：如果已存在同ID的卡片则不添加）
            if (syncData.New != null && syncData.New.Count > 0)
            {
                var existingIds = new HashSet<Guid>(_cachedCards.Select(c => c.Id));
                var trulyNew = syncData.New.Where(c => !existingIds.Contains(c.Id)).ToList();
                if (trulyNew.Count > 0)
                {
                    _cachedCards.AddRange(trulyNew);
                    System.Diagnostics.Debug.WriteLine(
                        $"[RemoteInfoCardService] 添加 {trulyNew.Count} 条新卡片 (接收{syncData.New.Count}条, 去重后{trulyNew.Count}条)");
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[RemoteInfoCardService] 服务端返回 {syncData.New.Count} 条\"新\"卡片但本地已全部存在，跳过");
                }
            }

            // 4. 按 SortOrder 重新排序，保证展示顺序与服务端一致
            SortByOrder(_cachedCards);

            System.Diagnostics.Debug.WriteLine(
                $"[RemoteInfoCardService] 合并后缓存: {_cachedCards.Count} 条卡片");
        }
    }

    /// <summary>
    /// 清理已移除/更新的卡片对应的本地媒体缓存文件。
    /// 支持 Guid 和 string 两类输入。
    /// </summary>
    private static void CleanMediaForRemovedCards(HashSet<Guid> cardIds)
    {
        CleanMediaForRemovedCards(cardIds.Select(g => g.ToString("N")).ToHashSet());
    }

    private static void CleanMediaForRemovedCards(HashSet<string> cardIdStrings)
    {
        try
        {
            var mediaDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Kirara", "info_cards_media");

            if (!Directory.Exists(mediaDir)) return;

            foreach (var idStr in cardIdStrings)
            {
                // 尝试解析为 Guid 并格式化为 dashless（文件前缀）
                string prefix;
                if (Guid.TryParse(idStr, out var guid))
                    prefix = $"{guid:N}_";
                else
                    prefix = $"{idStr}_";

                foreach (var file in Directory.GetFiles(mediaDir, $"{prefix}*"))
                {
                    try { File.Delete(file); }
                    catch { /* 静默 */ }
                }
            }
        }
        catch { /* 静默 */ }
    }

    /// <summary>
    /// 在 UI 线程触发 CardsRefreshed 事件。
    /// </summary>
    private void FireCardsRefreshed()
    {
        if (_dispatcherQueue?.HasThreadAccess == true)
        {
            CardsRefreshed?.Invoke();
        }
        else
        {
            _dispatcherQueue?.TryEnqueue(() => CardsRefreshed?.Invoke());
        }
    }

    // ================================================================
    //  全量拉取（fallback，当增量同步不可用时）
    // ================================================================

    /// <summary>
    /// 全量拉取所有活跃卡片（API fallback）。
    /// </summary>
    private async Task FetchAllAsync()
    {
        var accessToken = await GetValidAccessTokenAsync();
        if (string.IsNullOrEmpty(accessToken)) return;

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get,
                $"{ApiBaseUrl}/api/info-cards");
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode) { response.Dispose(); return; }

            var json = await response.Content.ReadAsStringAsync();
            response.Dispose();

            var apiResponse = JsonSerializer.Deserialize<ApiResponse<List<InfoCardResponseData>>>(json);
            if (apiResponse?.Success != true || apiResponse.Data == null) return;

            var cards = apiResponse.Data;
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteInfoCardService] 全量拉取: {cards.Count} 条");

            lock (_cardsLock)
            {
                _cachedCards = cards;
                SortByOrder(_cachedCards);
            }
            await Task.Run(() => _localStore.SaveAll(cards));
            FireCardsRefreshed();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteInfoCardService] 全量拉取失败: {ex.Message}");
        }
    }

    // ================================================================
    //  工具方法
    // ================================================================

    private async Task<string?> GetValidAccessTokenAsync()
    {
        if (!_loginService.IsLoggedIn) return null;
        bool isValid = await _loginService.EnsureValidAccessTokenAsync();
        return isValid ? _loginService.AccessToken : null;
    }

    // ================================================================
    //  启动初始化
    // ================================================================

    public void EnsureInfoCardApiUrlRecord()
    {
        try
        {
            var existing = _serverUrlService.GetByKey(InfoCardsApiUrlKey);
            if (existing == null)
            {
                _serverUrlService.Register(
                    key: InfoCardsApiUrlKey,
                    displayName: "信息流卡片 API 服务地址",
                    plainUrl: DefaultApiBaseUrl,
                    category: "Infrastructure");
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteInfoCardService] 注册信息流 API URL 失败: {ex.Message}");
        }
    }
}
