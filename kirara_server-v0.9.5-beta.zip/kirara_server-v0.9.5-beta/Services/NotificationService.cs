using System.Collections.Concurrent;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 通知服务实现 — 全局唯一通知总线
///
/// ## 设计要点
/// - Singleton：全局唯一实例，所有模块通过 DI 获取
/// - 订阅现有通知源：IDialogService、App.UnhandledException、ILoggingService、StatusBarViewModel
/// - 环形缓冲区：每类别保留最近 500 条，防止内存溢出
/// - 线程安全：使用 ConcurrentDictionary + lock 保护分类列表
/// </summary>
public class NotificationService : INotificationService
{
    /// <summary>每类别最大保留条数</summary>
    private const int MaxPerCategory = 500;

    private readonly LocalNotificationStore _localStore;
    private readonly ConcurrentDictionary<NotificationCategory, List<AppNotification>> _categories = new();
    private readonly object _lock = new();
    private int _unreadCount;

    public NotificationService(LocalNotificationStore localStore)
    {
        _localStore = localStore;
        foreach (NotificationCategory cat in Enum.GetValues<NotificationCategory>())
        {
            _categories[cat] = new List<AppNotification>();
        }
    }

    /// <inheritdoc />
    public void Publish(AppNotification notification)
    {
        // [持久化] 服务项通知统一写入本地存储（按用户分文件），重启后秒显恢复。
        // OpenVPN 连接失败、AppUpdate 等本地服务通知不经过 RemoteNotificationService，
        // 此前仅存内存、重启即消失；在此统一持久化（Append 内部按 Id 去重，
        // SignalR 推送/离线补拉已持久化的通知不会重复写入）。
        if (notification.Category == NotificationCategory.Service)
        {
            _localStore.Append(notification);
        }

        if (!_categories.TryGetValue(notification.Category, out var list))
            return;

        lock (_lock)
        {
            list.Add(notification);

            // 环形缓冲区
            while (list.Count > MaxPerCategory)
            {
                var removed = list[0];
                list.RemoveAt(0);
                if (!removed.IsRead)
                    _unreadCount--;
            }

            if (!notification.IsRead)
                _unreadCount++;
        }

        OnNotificationReceived?.Invoke(notification);
    }

    /// <inheritdoc />
    public IReadOnlyList<AppNotification> GetNotifications(NotificationCategory? category = null)
    {
        lock (_lock)
        {
            if (category.HasValue)
            {
                return _categories.TryGetValue(category.Value, out var list)
                    ? list.OrderByDescending(n => n.Timestamp).ToList().AsReadOnly()
                    : Array.Empty<AppNotification>();
            }

            // 全类别合并，按时间倒序
            return _categories.Values
                .SelectMany(l => l)
                .OrderByDescending(n => n.Timestamp)
                .ToList()
                .AsReadOnly();
        }
    }

    /// <inheritdoc />
    public void RemoveBySource(string source)
    {
        lock (_lock)
        {
            foreach (var kvp in _categories)
            {
                var list = kvp.Value;
                var toRemove = list.Where(n => n.Source == source).ToList();
                foreach (var n in toRemove)
                {
                    list.Remove(n);
                    if (!n.IsRead)
                        _unreadCount--;
                }
            }
        }
    }

    /// <inheritdoc />
    public void RemoveById(Guid id)
    {
        lock (_lock)
        {
            foreach (var kvp in _categories)
            {
                var list = kvp.Value;
                var item = list.FirstOrDefault(n => n.Id == id);
                if (item != null)
                {
                    list.Remove(item);
                    if (!item.IsRead)
                        _unreadCount--;
                    break;
                }
            }
        }
    }

    /// <inheritdoc />
    public void MarkAsRead(Guid id)
    {
        lock (_lock)
        {
            foreach (var list in _categories.Values)
            {
                var item = list.FirstOrDefault(n => n.Id == id);
                if (item != null && !item.IsRead)
                {
                    item.IsRead = true;
                    _unreadCount--;
                    break;
                }
            }
        }
    }

    /// <inheritdoc />
    public void MarkAllAsRead(NotificationCategory? category = null)
    {
        lock (_lock)
        {
            var targetLists = category.HasValue
                ? new[] { _categories[category.Value] }
                : _categories.Values;

            foreach (var list in targetLists)
            {
                foreach (var item in list.Where(n => !n.IsRead))
                {
                    item.IsRead = true;
                    _unreadCount--;
                }
            }
        }
    }

    /// <inheritdoc />
    public void Clear(NotificationCategory? category = null)
    {
        lock (_lock)
        {
            if (category.HasValue)
            {
                var list = _categories[category.Value];
                _unreadCount -= list.Count(n => !n.IsRead);
                list.Clear();
            }
            else
            {
                foreach (var kvp in _categories)
                {
                    kvp.Value.Clear();
                }
                _unreadCount = 0;
            }
        }
    }

    /// <inheritdoc />
    public int UnreadCount
    {
        get { lock (_lock) { return _unreadCount; } }
    }

    /// <inheritdoc />
    public event Action<AppNotification>? OnNotificationReceived;

    // ================================================================
    //  便捷发布方法（供其他模块调用）
    // ================================================================

    /// <summary>
    /// 发布服务通知（Info 级别）
    /// </summary>
    public AppNotification PublishServiceInfo(string title, string message, string? source = null)
    {
        var notification = new AppNotification
        {
            Category = NotificationCategory.Service,
            Severity = NotificationSeverity.Info,
            Title = title,
            Message = message,
            Source = source,
        };
        Publish(notification);
        return notification;
    }

    /// <summary>
    /// 发布服务通知（Warning 级别）
    /// </summary>
    public AppNotification PublishServiceWarning(string title, string message, string? source = null)
    {
        var notification = new AppNotification
        {
            Category = NotificationCategory.Service,
            Severity = NotificationSeverity.Warning,
            Title = title,
            Message = message,
            Source = source,
        };
        Publish(notification);
        return notification;
    }

    /// <summary>
    /// 发布服务通知（Error 级别）
    /// </summary>
    public AppNotification PublishServiceError(string title, string message, string? source = null)
    {
        var notification = new AppNotification
        {
            Category = NotificationCategory.Service,
            Severity = NotificationSeverity.Error,
            Title = title,
            Message = message,
            Source = source,
        };
        Publish(notification);
        return notification;
    }

    /// <summary>
    /// 发布消息推送通知（来自服务器端）
    /// </summary>
    public AppNotification PublishPush(string title, string htmlContent, string? plainText = null)
    {
        var notification = new AppNotification
        {
            Category = NotificationCategory.Push,
            Severity = NotificationSeverity.Info,
            Title = title,
            Message = plainText ?? title,
            HtmlContent = htmlContent,
        };
        Publish(notification);
        return notification;
    }

    /// <summary>
    /// 发布日志通知
    /// </summary>
    public AppNotification PublishLog(string title, string message, NotificationSeverity severity = NotificationSeverity.Info)
    {
        var notification = new AppNotification
        {
            Category = NotificationCategory.Log,
            Severity = severity,
            Title = title,
            Message = message,
        };
        Publish(notification);
        return notification;
    }
}
