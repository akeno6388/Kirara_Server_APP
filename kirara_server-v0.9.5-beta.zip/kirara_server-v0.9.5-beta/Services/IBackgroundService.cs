namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 首页背景图片管理服务接口
///
/// ## 生产环境资源获取链（本地版本校验 → 同步服务端 → 缓存急速加载）
/// ```
/// Step1: 检查本地缓存目录 (%APPDATA%/Kirara/backgrounds/)
///   ├── 有缓存文件 + 版本文件 → 立即返回本地路径（极速加载）
///   └── 无缓存 → Step2（显示内置默认背景）
///
/// Step2: 后台异步同步服务器资源（不阻塞UI）
///   ├── GET /api/resources/home-background → 302重定向到MinIO预签名URL
///   ├── HttpClient自动跟随重定向，下载图片字节流
///   ├── 提取响应ETag与本地版本比对：
///   │   ├── ETag相同 → 无变更，跳过更新（记录同步时间）
///   │   └── ETag不同 → 写入缓存 + 更新版本文件 + 触发渐变过渡事件
///   └── 失败（网络/404）→ 保持当前背景不变，下次启动重试
///
/// Step3（兜底）: 降级使用内置默认图片 Assets/background_default.jpg
/// ```
///
/// ## 缓存策略（生产环境增强）
/// - 缓存文件名: background_cache.jpg（单一文件，最新覆盖）
/// - 版本文件: background_version.txt（存储服务端ETag，持久化跨会话）
/// - 同步冷却: 30分钟内不重复同步（避免频繁请求大资源）
/// - 渐变过渡: 服务端资源就绪后通过交叉淡入淡出替换，提升视觉体验
/// </summary>
public interface IBackgroundService
{
    /// <summary>
    /// 当前背景图片的本地文件路径（可直接用于 Image.Source 绑定）
    /// 可能为 null（无可用背景）
    /// </summary>
    string? CurrentBackgroundPath { get; }

    /// <summary>
    /// 是否正在加载背景（用于 UI 显示加载指示器）
    /// </summary>
    bool IsLoading { get; }

    /// <summary>
    /// 当前是否正在使用内置默认背景（而非服务器下载的缓存）
    /// true=显示默认背景；false=显示缓存或服务器背景
    /// </summary>
    bool IsDefaultBackground { get; }

    /// <summary>
    /// 本地缓存的背景版本标识（ETag）
    /// null=无缓存版本信息（首次运行或版本文件丢失）
    /// </summary>
    string? LocalVersion { get; }

    /// <summary>
    /// 服务端最新背景版本标识（ETag）
    /// null=尚未成功同步过服务器版本信息
    /// </summary>
    string? ServerVersion { get; }

    /// <summary>
    /// 上次成功同步服务器背景的时间（UTC）
    /// null=从未成功同步过；用于冷却期判断（30分钟内不重复同步）
    /// </summary>
    DateTime? LastSyncedAt { get; }

    /// <summary>
    /// 初始化背景：加载本地缓存+版本 → 立即显示 → 后台异步同步服务器资源。
    /// 应在 App 启动时调用一次。
    /// </summary>
    Task InitializeAsync();

    /// <summary>
    /// 手动刷新背景（强制从服务器重新下载，忽略冷却期）
    /// </summary>
    Task RefreshAsync();

    /// <summary>
    /// 背景变更事件。订阅者（如 ShellPage）可在收到事件后执行渐变过渡动画。
    /// </summary>
    event Action<string?>? BackgroundChanged;
}
