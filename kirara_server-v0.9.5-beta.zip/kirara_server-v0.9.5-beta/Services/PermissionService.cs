using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 权限服务实现 — 管理员拥有全部权限，普通用户无法创建/访问服务实例
/// </summary>
public class PermissionService : IPermissionService
{
    private readonly ILoginService _loginService;

    public PermissionService(ILoginService loginService)
    {
        _loginService = loginService;
    }

    /// <summary>
    /// 管理员可以创建服务实例，普通用户不可以
    /// </summary>
    public bool CanCreateServiceInstance => _loginService.IsAdmin;

    /// <summary>
    /// 检查当前用户是否可以访问指定实例。
    /// 管理员可以访问所有实例；普通用户只能访问用户实例。
    /// </summary>
    public bool CanAccessInstance(Instance instance)
    {
        if (_loginService.IsAdmin) return true;

        // 普通用户：仅允许访问 UserInstance
        return instance.InstanceType == InstanceType.UserInstance;
    }

    /// <summary>
    /// 检查当前用户是否可以访问指定类型的实例
    /// </summary>
    public bool CanAccessInstanceType(InstanceType instanceType)
    {
        if (_loginService.IsAdmin) return true;

        return instanceType == InstanceType.UserInstance;
    }

    /// <summary>
    /// 过滤出当前用户有权访问的实例列表。
    /// 管理员看到全部；普通用户只看到 UserInstance。
    /// </summary>
    public IEnumerable<Instance> FilterAccessibleInstances(IEnumerable<Instance> instances)
    {
        if (_loginService.IsAdmin) return instances;

        return instances.Where(i => i.InstanceType == InstanceType.UserInstance);
    }
}
