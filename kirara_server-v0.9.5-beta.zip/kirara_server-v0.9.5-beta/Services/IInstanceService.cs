using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

public interface IInstanceService
{
    IEnumerable<Instance> GetAllInstances();
    IEnumerable<Instance> GetInstancesByUser(Guid userId);
    IEnumerable<Instance> GetInstancesByType(InstanceType type);
    Instance? GetInstance(Guid id);
    Instance CreateInstance(string name, InstanceType type, Guid ownerUserId);
    void UpdateInstance(Instance instance);
    void DeleteInstance(Guid id);
    void RenameInstance(Guid id, string newName);
    void ToggleFavorite(Guid id);
    void SetColorTag(Guid id, string? colorTag);
    Instance? ActivateInstance(Guid id);
    void DeactivateInstance();

    // 导入导出
    string ExportInstance(Guid id);
    Instance? ImportInstance(string json);
    void InsertInstanceAsIs(Instance instance);

    // 方案绑定管理
    void AddSchemeToInstance(Guid instanceId, Guid schemeId, Guid? tokenId = null);
    void RemoveSchemeFromInstance(Guid instanceId, Guid schemeId);
    void UpdateSchemeBinding(Guid instanceId, Guid schemeId, Guid? tokenId, bool isEnabled);
}

