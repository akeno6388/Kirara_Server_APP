using System.Text.Json;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// OpenVPN 服务版配置文件存储服务 — 按实例隔离管理多个导入的 .ovpn 配置及其账密。
///
/// ## 目录结构（按实例隔离）
///   %APPDATA%/Kirara/openvpn-server/{instanceId:N}/
///     profiles.json           — 配置元数据（账密字段 AES-256-GCM 加密）
///     {profileId:N}.ovpn      — 导入的配置文件（每配置一个文件）
///
/// ## 设计要点
/// - 每个配置文件对应一套独立账密，彼此互不干扰；
/// - 账密字段由 ICryptoService（AES-256-GCM）加密后存入 profiles.json；
/// - AutoLogin 标记同一实例内全局唯一：勾选时自动清除其他配置的标记；
/// - 硬重载 / 初始化实例通过 ClearAllAsync 完全清除本方案的全部信息。
/// </summary>
public class OpenVpnProfileStore
{
    private const string ProfilesFileName = "profiles.json";

    private readonly ICryptoService _cryptoService;

    public OpenVpnProfileStore(ICryptoService cryptoService)
    {
        _cryptoService = cryptoService;
    }

    /// <summary>实例隔离目录根（%APPDATA%/Kirara/openvpn-server/）</summary>
    private static string RootDirectory
    {
        get
        {
            var dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Kirara", "openvpn-server");
            Directory.CreateDirectory(dir);
            return dir;
        }
    }

    /// <summary>实例目录（不存在时创建）</summary>
    private static string GetInstanceDirectory(Guid instanceId)
    {
        var dir = Path.Combine(RootDirectory, instanceId.ToString("N"));
        Directory.CreateDirectory(dir);
        return dir;
    }

    private static string GetProfilesFilePath(Guid instanceId) =>
        Path.Combine(GetInstanceDirectory(instanceId), ProfilesFileName);

    // ================================================================
    //  公开方法
    // ================================================================

    /// <summary>读取实例的全部配置文件（无则返回空列表）</summary>
    public List<OpenVpnProfile> GetProfiles(Guid instanceId)
    {
        var filePath = GetProfilesFilePath(instanceId);
        if (!File.Exists(filePath)) return new List<OpenVpnProfile>();
        try
        {
            return JsonSerializer.Deserialize<List<OpenVpnProfile>>(File.ReadAllText(filePath))
                ?? new List<OpenVpnProfile>();
        }
        catch
        {
            return new List<OpenVpnProfile>();
        }
    }

    /// <summary>获取指定配置文件（不存在返回 null）</summary>
    public OpenVpnProfile? GetProfile(Guid instanceId, Guid profileId) =>
        GetProfiles(instanceId).FirstOrDefault(p => p.Id == profileId);

    /// <summary>
    /// 获取勾选了自动登录的配置（同一实例内全局唯一，作为下次启动的令牌自动链接凭据）。
    /// 无自动登录配置时返回 null。
    /// </summary>
    public OpenVpnProfile? GetAutoLoginProfile(Guid instanceId) =>
        GetProfiles(instanceId).FirstOrDefault(p => p.AutoLogin);

    /// <summary>返回配置 .ovpn 文件的完整路径（文件不存在时返回 null）</summary>
    public string? GetConfigPath(Guid instanceId, Guid profileId)
    {
        var profile = GetProfile(instanceId, profileId);
        if (profile == null) return null;
        var path = Path.Combine(GetInstanceDirectory(instanceId), profile.OvpnFileName);
        return File.Exists(path) ? path : null;
    }

    /// <summary>
    /// 导入 .ovpn 配置文件：复制到实例目录 + 解析 remote 服务器地址 + 创建元数据。
    /// 返回新创建的配置（账密为空，需用户输入）。
    /// </summary>
    public Task<OpenVpnProfile> ImportProfileAsync(Guid instanceId, string sourceFilePath)
    {
        var profile = new OpenVpnProfile
        {
            Name = Path.GetFileNameWithoutExtension(sourceFilePath),
            OvpnFileName = $"{Guid.NewGuid():N}.ovpn",
        };

        var targetPath = Path.Combine(GetInstanceDirectory(instanceId), profile.OvpnFileName);
        File.Copy(sourceFilePath, targetPath, overwrite: true);

        // 解析 remote 指令（仅用于界面展示服务器地址；连接实际使用 .ovpn 内容）
        var remote = TryParseRemoteFromConfig(targetPath);
        profile.ServerHost = remote?.host;
        profile.ServerPort = remote?.port ?? VpnConnectionService.DefaultVpnPort;

        // 追加到元数据并保存
        var profiles = GetProfiles(instanceId);
        profiles.Add(profile);
        SaveProfiles(instanceId, profiles);
        return Task.FromResult(profile);
    }

    /// <summary>
    /// 删除配置文件：删除 .ovpn 文件 + 移除元数据条目。
    /// 若删除的是自动登录配置，自动登录标记随之消失。
    /// </summary>
    public Task DeleteProfileAsync(Guid instanceId, Guid profileId)
    {
        var profile = GetProfile(instanceId, profileId);
        if (profile != null)
        {
            try
            {
                var filePath = Path.Combine(GetInstanceDirectory(instanceId), profile.OvpnFileName);
                if (File.Exists(filePath)) File.Delete(filePath);
            }
            catch { /* 文件删除失败不影响元数据移除 */ }

            var profiles = GetProfiles(instanceId);
            profiles.RemoveAll(p => p.Id == profileId);
            SaveProfiles(instanceId, profiles);
        }
        return Task.CompletedTask;
    }

    /// <summary>
    /// 保存指定配置的账密与自动登录标记（账密 AES-256-GCM 加密存储）。
    /// 勾选自动登录时，清除同实例内其他配置的 AutoLogin 标记（全局唯一）。
    /// </summary>
    public Task SaveCredentialsAsync(
        Guid instanceId, Guid profileId, string account, string password, bool autoLogin)
    {
        var profiles = GetProfiles(instanceId);
        var profile = profiles.FirstOrDefault(p => p.Id == profileId);
        if (profile == null) return Task.CompletedTask;

        profile.AccountNameEncrypted = _cryptoService.Encrypt(account);
        profile.AccountPasswordEncrypted = _cryptoService.Encrypt(password);
        profile.AutoLogin = autoLogin;

        if (autoLogin)
        {
            // 同一实例内自动登录标记全局唯一
            foreach (var p in profiles)
            {
                if (p.Id != profileId) p.AutoLogin = false;
            }
        }

        SaveProfiles(instanceId, profiles);
        return Task.CompletedTask;
    }

    /// <summary>
    /// 完全清除实例的配置库（.ovpn 文件 + 元数据 + 账密 + 自动登录标记）。
    /// 硬重载 / 初始化实例调用，清除后需用户手动重新导入。
    /// </summary>
    public Task ClearAllAsync(Guid instanceId)
    {
        try
        {
            var dir = GetInstanceDirectory(instanceId);
            if (Directory.Exists(dir))
            {
                Directory.Delete(dir, recursive: true);
            }
        }
        catch { /* 删除失败不影响（下次导入会重建目录） */ }
        return Task.CompletedTask;
    }

    // ================================================================
    //  内部实现
    // ================================================================

    /// <summary>持久化元数据（按 Id 排序保证稳定顺序）</summary>
    private static void SaveProfiles(Guid instanceId, List<OpenVpnProfile> profiles)
    {
        var filePath = GetProfilesFilePath(instanceId);
        var sorted = profiles.OrderBy(p => p.ImportedAt).ToList();
        File.WriteAllText(filePath, JsonSerializer.Serialize(sorted));
    }

    /// <summary>
    /// 从 .ovpn 配置文件中解析 remote 指令（<c>remote &lt;host&gt; &lt;port&gt; [proto]</c>）。
    /// 用于界面展示服务器地址；解析失败返回 null（连接仍以 .ovpn 内容为准）。
    /// </summary>
    private static (string host, int port)? TryParseRemoteFromConfig(string configPath)
    {
        try
        {
            foreach (var line in File.ReadLines(configPath))
            {
                var trimmed = line.Trim();
                if (!trimmed.StartsWith("remote", StringComparison.OrdinalIgnoreCase))
                    continue;

                var parts = trimmed.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                if (parts.Length >= 2)
                {
                    string host = parts[1].Trim();
                    if (string.IsNullOrEmpty(host)) continue;

                    int port = VpnConnectionService.DefaultVpnPort;
                    if (parts.Length >= 3 && int.TryParse(parts[2], out int parsedPort) &&
                        parsedPort > 0 && parsedPort < 65536)
                    {
                        port = parsedPort;
                    }
                    return (host, port);
                }
            }
        }
        catch { /* 配置读取失败忽略 */ }
        return null;
    }
}
