using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using Microsoft.Win32;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// VPN 连接状态
/// </summary>
public enum VpnConnectionState
{
    /// <summary>未连接</summary>
    Disconnected,

    /// <summary>连接中（含重连）</summary>
    Connecting,

    /// <summary>已连接</summary>
    Connected,

    /// <summary>断开中</summary>
    Disconnecting,

    /// <summary>连接失败</summary>
    Failed,
}

/// <summary>
/// OpenVPN 连接服务 — 通过 KiraraVpnHelper 服务（LocalSystem）启动 openvpn.exe，
/// 并与其 management 管理接口通信。
/// 
/// 设计要点（v0.9.1 架构升级）：
/// - 应用以普通权限运行（asInvoker，修复 requireAdministrator 下 WinUI 界面不加载问题）。
/// - openvpn.exe 由 KiraraVpnHelper Windows 服务代启动（LocalSystem 权限），
///   通过命名管道 CONNECT/DISCONNECT 命令控制，VPN 连接全程无需 UAC。
/// - 使用 <c>--management-client</c> 反向连接模式：本服务先创建 TcpListener（自动分配端口），
///   openvpn 子进程作为客户端主动连接，避免多实例并发时的固定端口冲突。
/// - 日志链路：openvpn 通过 --log 写日志文件；management 订阅 "log on" 推送
///   >LOG: 事件（stdout 重定向不再可用——子进程由服务托管）。
/// - 凭据通过 auth.txt 文件注入（auth-user-pass），无需交互式 password 命令。
/// - 事件驱动：StateChanged / ByteCountChanged / LogLineAdded，与 INotificationService 风格一致。
/// - 单例服务，同时只支持一个活动连接；新连接发起前自动断开旧连接。
/// </summary>
public class VpnConnectionService : IDisposable
{
    /// <summary>默认 VPN 服务器端口（UDP）</summary>
    public const int DefaultVpnPort = 1195;

    /// <summary>openvpn.exe 常见固定安装路径（社区版）</summary>
    private static readonly string[] WellKnownPaths =
    {
        @"C:\Program Files\OpenVPN\bin\openvpn.exe",
        @"C:\Program Files (x86)\OpenVPN\bin\openvpn.exe",
    };

    /// <summary>管理接口连接超时（秒）</summary>
    private const int ManagementConnectTimeoutSeconds = 15;

    // ===== 状态 =====

    /// <summary>当前连接状态</summary>
    public VpnConnectionState State { get; private set; } = VpnConnectionState.Disconnected;

    /// <summary>服务器地址（host:port）</summary>
    public string? ServerAddress { get; private set; }

    /// <summary>本地分配的虚拟 IP（连接成功后可用）</summary>
    public string? LocalIp { get; private set; }

    /// <summary>累计接收字节数（本次连接）</summary>
    public long BytesIn { get; private set; }

    /// <summary>累计发送字节数（本次连接）</summary>
    public long BytesOut { get; private set; }

    /// <summary>最近一次失败原因</summary>
    public string? LastError { get; private set; }

    // ===== 事件 =====

    /// <summary>连接状态变化事件</summary>
    public event Action<VpnConnectionState>? StateChanged;

    /// <summary>流量统计事件（参数为累计接收/发送字节数）</summary>
    public event Action<long, long>? ByteCountChanged;

    /// <summary>连接日志行事件（参数为日志文本）</summary>
    public event Action<string>? LogLineAdded;

    // ===== 内部字段 =====

    private readonly object _lock = new();
    private readonly ILoggingService _loggingService;
    private readonly INotificationService _notificationService;

    private TcpListener? _managementListener;
    private TcpClient? _managementClient;
    private StreamReader? _reader;
    private StreamWriter? _writer;
    private CancellationTokenSource? _cts;
    private Task? _readLoopTask;
    private string? _configPath;
    private string? _authFilePath;
    private string? _openVpnLogPath;
    private bool _disposed;

    /// <summary>
    /// 当前使用的方案名（通知中心据此关联方案在线图标）。
    /// 默认 "openvpn"（内置版）；服务版面板（OpenVpnServiceControl）构造时改为 "openvpn-server"。
    /// </summary>
    public string SchemeName { get; set; } = "openvpn";

    /// <summary>
    /// 初始化 OpenVPN 连接服务
    /// </summary>
    public VpnConnectionService(ILoggingService loggingService, INotificationService notificationService)
    {
        _loggingService = loggingService;
        _notificationService = notificationService;
    }

    /// <summary>
    /// 配置工作目录：%APPDATA%/Kirara/openvpn/
    /// </summary>
    private string ConfigDirectory
    {
        get
        {
            var dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Kirara", "openvpn");
            Directory.CreateDirectory(dir);
            return dir;
        }
    }

    /// <summary>
    /// 探测 openvpn.exe 可执行文件路径。
    /// 查找顺序：应用目录相对路径（软件目录\ThirdAPPs\OpenVPN）→ 固定安装路径 → PATH 环境变量
    ///          → 注册表（HKLM/HKCU\Software\OpenVPN\exe_path，NSIS 安装器提权安装时写入 HKLM）。
    /// </summary>
    public string? DetectOpenVpnExecutable()
    {
        // 1. 应用目录相对路径（安装包将 OpenVPN 装入软件目录下的 ThirdAPPs\OpenVPN 文件夹）
        //    a. {AppDir}\ThirdAPPs\OpenVPN\bin\openvpn.exe（软件目录内 ThirdAPPs 子目录，主分发路径）
        //    b. {AppDir}\..\OpenVPN\bin\openvpn.exe（与软件目录同级）
        string[] appRelativePaths =
        {
            Path.Combine(AppContext.BaseDirectory, "ThirdAPPs", "OpenVPN", "bin", "openvpn.exe"),
            Path.Combine(AppContext.BaseDirectory, "..", "OpenVPN", "bin", "openvpn.exe"),
        };
        foreach (var path in appRelativePaths)
        {
            try
            {
                var full = Path.GetFullPath(path);
                if (File.Exists(full))
                    return full;
            }
            catch { /* 无效路径跳过 */ }
        }

        // 2. 固定安装路径
        foreach (var path in WellKnownPaths)
        {
            if (File.Exists(path))
                return path;
        }

        // 3. PATH 环境变量
        try
        {
            var pathEnv = Environment.GetEnvironmentVariable("PATH");
            if (!string.IsNullOrEmpty(pathEnv))
            {
                foreach (var dir in pathEnv.Split(';', StringSplitOptions.RemoveEmptyEntries))
                {
                    try
                    {
                        var candidate = Path.Combine(dir.Trim('"'), "openvpn.exe");
                        if (File.Exists(candidate))
                            return candidate;
                    }
                    catch { /* 无效目录跳过 */ }
                }
            }
        }
        catch { /* PATH 读取失败忽略 */ }

        // 4. 注册表（NSIS 安装器写入 exe_path；提权安装时位于 HKLM，旧版本/低权限时可能写 HKCU）
        foreach (var hive in new[] { Registry.LocalMachine, Registry.CurrentUser })
        {
            try
            {
                using var key = hive.OpenSubKey(@"Software\OpenVPN");
                var exePath = key?.GetValue("exe_path") as string;
                if (!string.IsNullOrEmpty(exePath) && File.Exists(exePath))
                    return exePath;
            }
            catch { /* 注册表读取失败忽略 */ }
        }

        return null;
    }

    /// <summary>
    /// 建立 VPN 连接：准备认证文件 → 启动子进程 → 接入管理接口。
    /// 若已有活动连接，先自动断开。
    /// </summary>
    /// <param name="accountName">认证用户名</param>
    /// <param name="accountPassword">认证密码（可能为空）</param>
    /// <param name="serverHost">服务器主机名/IP（界面展示用）</param>
    /// <param name="serverPort">服务器端口（界面展示用）</param>
    /// <param name="displayName">方案显示名（用于认证文件名与日志）</param>
    /// <param name="ovpnConfigPath">.ovpn 配置文件路径（服务端下载缓存，必选；为空或不存在时直接中断连接）</param>
    public async Task<(bool success, string? error)> ConnectAsync(
        string accountName, string? accountPassword,
        string serverHost, int serverPort, string displayName,
        string? ovpnConfigPath = null)
    {
        if (_disposed) return (false, "服务已释放");

        // ===== 0. 校验 .ovpn 配置（无降级链路：本地无缓存且无法从服务器获取时直接中断） =====
        if (string.IsNullOrEmpty(ovpnConfigPath) || !File.Exists(ovpnConfigPath))
        {
            var configError = "无法获取 .ovpn 配置文件，连接已中断";
            SetState(VpnConnectionState.Failed, configError);
            return (false, configError);
        }

        lock (_lock)
        {
            if (State is VpnConnectionState.Connecting or VpnConnectionState.Connected or VpnConnectionState.Disconnecting)
            {
                // 已有活动连接：先断开再建立新连接
                _ = Task.Run(async () => await DisconnectInternalAsync());
            }
        }

        // 等待旧连接完全断开
        for (int i = 0; i < 50 && GetState() != VpnConnectionState.Disconnected; i++)
        {
            await Task.Delay(100);
        }

        var exePath = DetectOpenVpnExecutable();
        if (exePath == null)
        {
            var error = "未找到 openvpn.exe，请先安装 OpenVPN（默认安装到 C:\\Program Files\\OpenVPN）";
            SetState(VpnConnectionState.Failed, error);
            return (false, error);
        }

        // ===== 1. 准备认证文件 =====
        // 配置文件直接使用缓存文件（本地唯一 .ovpn，服务端更新时覆盖），不复制副本
        _configPath = ovpnConfigPath;
        _authFilePath = Path.Combine(ConfigDirectory, $"{displayName}_{DateTime.Now:yyyyMMddHHmmss}.auth");

        int managementPort = 0;
        try
        {
            // auth.txt：第一行用户名，第二行密码
            await File.WriteAllTextAsync(_authFilePath, $"{accountName}\n{accountPassword ?? string.Empty}");

            // 创建管理接口监听器（自动分配空闲端口，避免多实例冲突）
            _managementListener = new TcpListener(IPAddress.Loopback, 0);
            _managementListener.Start();
            managementPort = ((IPEndPoint)_managementListener.LocalEndpoint).Port;

            // 防御性检查：缓存配置中不应包含 management 指令（服务端下发的配置不含客户端私有指令）
            try
            {
                var lines = await File.ReadAllLinesAsync(_configPath);
                if (lines.Any(l => l.TrimStart().StartsWith("management", StringComparison.OrdinalIgnoreCase)))
                {
                    _loggingService.Log(LogLevel.Warning, "VpnConnection",
                        ".ovpn 配置中包含 management 指令，命令行参数将覆盖它");
                }
            }
            catch { /* 配置读取失败不影响连接（openvpn 会自行报错） */ }
        }
        catch (Exception ex)
        {
            var error = $"生成认证文件失败: {ex.Message}";
            CleanupArtifacts();
            SetState(VpnConnectionState.Failed, error);
            return (false, error);
        }

        // ===== 2. 通过 KiraraVpnHelper 服务启动 openvpn 子进程 =====
        // （LocalSystem 权限，应用侧无需提权；进程退出检测由服务负责）
        string openVpnLogPath;
        try
        {
            // openvpn 日志文件：%APPDATA%/Kirara/openvpn/openvpn.log（--log 参数）
            openVpnLogPath = Path.Combine(ConfigDirectory, "openvpn.log");
            var helperError = await VpnHelperClient.RequestConnectAsync(
                exePath, _configPath, _authFilePath, managementPort, openVpnLogPath);
            if (helperError != null)
            {
                var error = $"VPN Helper 启动 openvpn 失败: {helperError}";
                CleanupArtifacts();
                SetState(VpnConnectionState.Failed, error);
                return (false, error);
            }
            _openVpnLogPath = openVpnLogPath;
        }
        catch (Exception ex)
        {
            var error = $"请求 VPN Helper 服务失败: {ex.Message}";
            CleanupArtifacts();
            SetState(VpnConnectionState.Failed, error);
            return (false, error);
        }

        ServerAddress = $"{serverHost}:{serverPort}";
        _cts = new CancellationTokenSource();
        _loggingService.Log(LogLevel.Info, "VpnConnection", $"OpenVPN 进程已通过 VPN Helper 服务启动，服务器 {ServerAddress}");

        // ===== 3. 等待管理接口接入（反向连接），并行监听进程退出 =====
        try
        {
            using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(_cts.Token);
            timeoutCts.CancelAfter(TimeSpan.FromSeconds(ManagementConnectTimeoutSeconds));

            // 并行等待：管理接口接入 或 openvpn 进程退出（任一先发生）
            var acceptTask = _managementListener.AcceptTcpClientAsync(timeoutCts.Token).AsTask();
            // 应用不持有 openvpn 进程句柄（由服务托管）→ 通过管道 STATUS 轮询检测进程退出
            var exitTask = PollProcessExitAsync(timeoutCts.Token);

            // 观察 exitTask 异常（超时取消时防止 UnobservedTaskException）
            _ = exitTask.ContinueWith(static _ => { }, CancellationToken.None,
                TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);

            var completed = await Task.WhenAny(acceptTask, exitTask);

            // openvpn 提前退出（配置错误/权限不足/驱动缺失等）→ 立即报错，不再等待
            if (completed == exitTask && exitTask.IsCompletedSuccessfully)
            {
                var error = "openvpn.exe 异常退出，请查看上方连接日志中的 openvpn 输出以定位原因";
                await DisconnectInternalAsync();
                SetState(VpnConnectionState.Failed, error);
                return (false, error);
            }

            // 管理接口未接入（15s 超时）→ 报错并提示查看日志
            if (!acceptTask.IsCompletedSuccessfully)
            {
                var error = "管理接口连接超时（15s）：openvpn 未连接管理端口，请查看上方连接日志中的 openvpn 输出（常见原因：TAP/Wintun 驱动缺失、.ovpn 配置错误、管理员权限）";
                await DisconnectInternalAsync();
                SetState(VpnConnectionState.Failed, error);
                return (false, error);
            }

            _managementClient = acceptTask.Result;
            _managementClient.NoDelay = true;

            var stream = _managementClient.GetStream();
            _reader = new StreamReader(stream, Encoding.UTF8);
            // 使用无 BOM 的 UTF-8 编码：StreamWriter 默认的 Encoding.UTF8 会在首次写入时输出 BOM（EF BB BF），
            // 导致发给 openvpn management 的第一条命令带 BOM 前缀（日志中表现为 "MANAGEMENT: CMD '锘縮tate on'"）
            // 而无法识别——state on 不生效，management 不推送 >STATE: 事件，状态检测依赖兜底逻辑
            var utf8NoBom = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false);
            _writer = new StreamWriter(stream, utf8NoBom) { AutoFlush = true };

            // 发送初始化命令：实时状态 / 每秒流量 / 日志订阅。
            // ⚠️ 必须发送 log on：openvpn 由 VPN Helper 服务托管，stdout 重定向不可用，
            //    日志只能通过 management >LOG: 推送获取（配合 --log 文件双写）
            _writer.WriteLine("state on");
            _writer.WriteLine("bytecount 1");
            _writer.WriteLine("log on");

            SetState(VpnConnectionState.Connecting);
            _readLoopTask = Task.Run(ReadLoopAsync, _cts.Token);
        }
        catch (Exception ex) when (ex is OperationCanceledException or SocketException)
        {
            var error = "管理接口连接超时（15s）：openvpn 未连接管理端口，请查看上方连接日志中的 openvpn 输出（常见原因：TAP/Wintun 驱动缺失、.ovpn 配置错误、管理员权限）";
            await DisconnectInternalAsync();
            SetState(VpnConnectionState.Failed, error);
            return (false, error);
        }

        return (true, null);
    }

    // ===== 进程退出轮询（VPN Helper 服务托管 openvpn，应用无进程句柄） =====

    /// <summary>
    /// 通过管道 STATUS 轮询检测 openvpn 进程是否退出。
    /// 服务返回 STOPPED 且未取消 → 进程已退出（连接失败路径由调用方处理）。
    /// </summary>
    private async Task PollProcessExitAsync(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            await Task.Delay(1000, token);
            var status = await VpnHelperClient.RequestStatusAsync();
            if (status != null && status.StartsWith("STATUS|STOPPED", StringComparison.Ordinal))
            {
                return;
            }
            if (status != null && status.StartsWith("ERROR|", StringComparison.Ordinal))
            {
                // 服务不可达（异常）→ 视为进程已退出，让上层报错
                return;
            }
        }
    }

    /// <summary>
    /// 管理接口读循环：解析 >STATE / >BYTECOUNT / >LOG 事件。
    /// 运行在后台线程，UI 订阅方需自行切换到 UI 线程。
    /// </summary>
    private async Task ReadLoopAsync()
    {
        try
        {
            string? line;
            while (_reader != null && (line = await _reader.ReadLineAsync()) != null)
            {
                if (line.StartsWith(">STATE:", StringComparison.Ordinal))
                {
                    // 格式: >STATE:{unix},{state},{detail},{ip},{port},{remote_ip},{remote_port}
                    System.Diagnostics.Debug.WriteLine($"[VpnConnection] management STATE: {line}");
                    var parts = line.Split(',');
                    if (parts.Length >= 3)
                    {
                        var rawState = parts[1];
                        var detail = parts.Length > 2 ? parts[2] : string.Empty;

                        switch (rawState)
                        {
                            case "CONNECTED":
                                SetState(VpnConnectionState.Connected);
                                _loggingService.Log(LogLevel.Info, "VpnConnection", $"VPN 已连接（服务器 {ServerAddress}）");
                                break;
                            case "RECONNECTING":
                                // 重连中：即使之前已连接也要降级为连接中（连接确实断开了）
                                SetState(VpnConnectionState.Connecting);
                                break;
                            case "EXITING":
                            case "SIGTERM":
                            case "SIGINT":
                                SetState(VpnConnectionState.Disconnected);
                                break;
                            case "AUTH_FAILED":
                                SetState(VpnConnectionState.Failed, "认证失败，请检查令牌中的用户名/密码");
                                break;
                            default:
                                // CONNECTING / WAIT / GET_CONFIG / ASSIGN_IP 等 → 连接中
                                if (rawState == "ASSIGN_IP" && !string.IsNullOrEmpty(detail))
                                {
                                    LocalIp = detail;
                                }
                                // 防回退：openvpn 可能在 CONNECTED 后乱序/重复推送连接推进状态
                                // （ASSIGN_IP / ADD_ROUTES 等），已连接状态下不再降级为"连接中"
                                if (State != VpnConnectionState.Connected)
                                {
                                    SetState(VpnConnectionState.Connecting);
                                }
                                break;
                        }
                    }
                }
                else if (line.StartsWith(">BYTECOUNT:", StringComparison.Ordinal))
                {
                    // 格式: >BYTECOUNT:{bytes_in},{bytes_out}
                    var parts = line.Substring(">BYTECOUNT:".Length).Split(',');
                    if (parts.Length == 2 &&
                        long.TryParse(parts[0], out var bytesIn) &&
                        long.TryParse(parts[1], out var bytesOut))
                    {
                        BytesIn = bytesIn;
                        BytesOut = bytesOut;
                        ByteCountChanged?.Invoke(bytesIn, bytesOut);
                    }
                }
                else if (line.StartsWith(">LOG:", StringComparison.Ordinal))
                {
                    // 格式: >LOG:{time},{flags},{text}
                    var idx = line.IndexOf(',');
                    if (idx >= 0)
                    {
                        var flagsEnd = line.IndexOf(',', idx + 1);
                        var text = flagsEnd >= 0 ? line.Substring(flagsEnd + 1) : line.Substring(idx + 1);
                        LogLineAdded?.Invoke(text);

                        // 兜底检测：management 事件可能因对接异常/时序问题丢失，
                        // "Initialization Sequence Completed" 是连接建立的铁证，强制标记已连接
                        // （原 stdout 检测迁移至此——stdout 由服务托管不可用，日志走 >LOG: 推送）
                        if (text.Contains("Initialization Sequence Completed", StringComparison.OrdinalIgnoreCase)
                            && State != VpnConnectionState.Connected)
                        {
                            System.Diagnostics.Debug.WriteLine(
                                "[VpnConnection] >LOG: 检测到 Initialization Sequence Completed，强制标记已连接");
                            SetState(VpnConnectionState.Connected);
                            _loggingService.Log(LogLevel.Info, "VpnConnection", "VPN 已连接（>LOG: 兜底检测）");
                        }
                    }
                }
                else if (line.StartsWith(">FATAL:", StringComparison.Ordinal) ||
                         line.StartsWith(">ERROR:", StringComparison.Ordinal))
                {
                    var text = line.Substring(line.IndexOf(':') + 1);
                    LogLineAdded?.Invoke(text);
                    if (line.StartsWith(">FATAL:", StringComparison.Ordinal))
                    {
                        SetState(VpnConnectionState.Failed, text.Trim());
                    }
                }
            }

            // 读循环结束（管理接口断开）→ 若进程仍存活说明异常退出
            if (State is VpnConnectionState.Connected or VpnConnectionState.Connecting)
            {
                SetState(VpnConnectionState.Failed, "管理连接意外中断");
            }
        }
        catch (Exception ex) when (ex is IOException or ObjectDisposedException or OperationCanceledException)
        {
            // 正常断开或取消时忽略
        }
        catch (Exception ex)
        {
            _loggingService.Log(LogLevel.Error, "VpnConnection", $"管理接口读取异常: {ex.Message}");
        }
    }

    /// <summary>
    /// 断开 VPN 连接：发送 SIGTERM → 等待进程退出 → 清理资源。
    /// </summary>
    public async Task DisconnectAsync()
    {
        await DisconnectInternalAsync();
    }

    /// <summary>
    /// 断开内部实现（幂等）
    /// </summary>
    private async Task DisconnectInternalAsync()
    {
        if (_disposed) return;

        SetState(VpnConnectionState.Disconnecting);

        try
        {
            // 1. 通过管理接口发送 SIGTERM
            if (_writer != null)
            {
                try
                {
                    _writer.WriteLine("signal SIGTERM");
                }
                catch { /* 连接可能已断开 */ }
            }

            // 2. 请求 VPN Helper 服务终止 openvpn 进程（服务 Kill 兜底）
            try
            {
                await VpnHelperClient.RequestDisconnectAsync();
            }
            catch { /* 服务不可达时忽略（进程可能已退出） */ }
        }
        finally
        {
            CleanupArtifacts();
            SetState(VpnConnectionState.Disconnected);
            _loggingService.Log(LogLevel.Info, "VpnConnection", "VPN 连接已断开");
        }
    }

    /// <summary>
    /// 清理管理接口与临时配置文件
    /// </summary>
    private void CleanupArtifacts()
    {
        try { _cts?.Cancel(); } catch { }
        try { _reader?.Dispose(); } catch { }
        try { _writer?.Dispose(); } catch { }
        try { _managementClient?.Dispose(); } catch { }
        try { _managementListener?.Stop(); } catch { }

        _reader = null;
        _writer = null;
        _managementClient = null;
        _managementListener = null;
        _cts = null;
        _readLoopTask = null;
        _openVpnLogPath = null;

        // 清理临时认证文件（.ovpn 配置文件为服务端下载的缓存文件，保留供下次连接复用）
        try
        {
            if (!string.IsNullOrEmpty(_authFilePath) && File.Exists(_authFilePath)) File.Delete(_authFilePath);
        }
        catch { /* 文件清理失败不影响断开 */ }

        _configPath = null;
        _authFilePath = null;
        BytesIn = 0;
        BytesOut = 0;
        LocalIp = null;
    }

    /// <summary>
    /// 更新状态并触发事件（线程安全）
    /// </summary>
    private void SetState(VpnConnectionState state, string? error = null)
    {
        lock (_lock)
        {
            if (_disposed) return;
            State = state;
            if (error != null)
            {
                LastError = error;
                _loggingService.Log(LogLevel.Error, "VpnConnection", error);

                // 失败通知 → 通知中心（Error 级别，服务项仅接收方案级通知）
                _notificationService.Publish(new AppNotification
                {
                    Category = NotificationCategory.Service,
                    Severity = NotificationSeverity.Error,
                    Title = "VPN 连接失败",
                    Message = error,
                    Source = "VpnConnection",
                    SchemeName = SchemeName, // 通知中心据此显示方案在线图标
                });
            }
        }
        StateChanged?.Invoke(state);
    }

    /// <summary>
    /// 线程安全读取当前状态
    /// </summary>
    private VpnConnectionState GetState()
    {
        lock (_lock) { return State; }
    }

    /// <summary>
    /// 释放服务（应用退出时调用，请求服务终止 openvpn 子进程）
    /// </summary>
    public void Dispose()
    {
        lock (_lock)
        {
            if (_disposed) return;
            _disposed = true;
        }

        try { _cts?.Cancel(); } catch { }
        try { _writer?.WriteLine("signal SIGTERM"); } catch { }

        // [修复] 异步请求断开（不阻塞 UI 线程）：
        // 原同步 .Wait(3s) 在管道通信慢时会阻塞 UI 线程 → 窗口延迟关闭。
        // 改为 fire-and-forget，主进程随后 Exit 时由服务侧自动终止 openvpn。
        _ = VpnHelperClient.RequestDisconnectAsync();

        CleanupArtifacts();
    }
}
