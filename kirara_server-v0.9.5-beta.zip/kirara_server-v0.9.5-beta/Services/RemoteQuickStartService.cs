using System.Globalization;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using Kirara_Server_WinUI.Helpers;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 远程快速开始服务实现 — 通过 Kirara Server API 获取实例模板
///
/// ## 设计说明
/// - GetTemplates() 通过 HTTP 调用 GET /api/templates 获取模板列表
/// - 首次调用时异步预取缓存，UI 绑定同步返回缓存数据
/// - 缓存为空时（初始化未完成）同步回退请求，5 秒超时
/// - GetExternalClients() 保持本地检测已安装的官方客户端
///
/// ## 模板封面图缓存策略（v2 — 与 BackgroundService/UserAvatarService 一致的范式）
/// ``` 
/// FetchTemplatesAsync():
///   ├── GET /api/templates → JSON → MapToTemplate()
///   ├── Step 1: 加载本地缓存封面（秒显）
///   │     ├── ✅有缓存 → CoverImageUrl = 本地文件路径（极速加载）
///   │     └── ❌无缓存 → CoverImageUrl = null（后续由转换器回退默认图）
///   └── Step 2: 并行同步服务端封面
///         ├── GET /api/templates/{id}/cover → 302 → MinIO 预签名 URL
///         ├── GET 预签名 URL → 下载图片字节流 + 提取 ETag
///         ├── ETag == 本地版本? → 跳过更新（服务端无变更）
///         ├── ETag != 本地版本? → 保存到缓存 + 更新版本文件
///         └── 404 → 删除本地缓存（服务端已移除封面）
/// ```
///
/// ## API 规范
/// - Endpoint: GET /api/templates（无需认证）
/// - GET /api/templates/{id}/cover → 302 → MinIO 预签名 URL（v1.4 新增）
/// - 响应: ApiResponse&lt;List&lt;TemplateResponseData&gt;&gt;
/// </summary>
public class RemoteQuickStartService : IQuickStartService, IDisposable
{
    private readonly HttpClient _httpClient;
    private readonly IServerUrlService _serverUrlService;
    private readonly LocalTemplateStore _localTemplateStore;
    private readonly SecureCacheService _secureCache;
    private bool _disposed;

    /// <summary>模板 API URL 注册键名</summary>
    private const string TemplatesApiUrlKey = "templates_api";

    /// <summary>
    /// 默认 API 基础地址 — 指向生产环境 Kirara Server API。
    /// 可通过 ServerUrlService 的 "templates_api" key 修改。
    /// </summary>
    private const string DefaultApiBaseUrl = "https://api.akeno6388.online:1010";

    /// <summary>
    /// API 基础地址 — 优先从 ServerUrlService 的 "templates_api" key 读取，
    /// 未配置时使用默认值。
    /// </summary>
    private string ApiBaseUrl =>
        _serverUrlService.GetDecryptedUrl(TemplatesApiUrlKey) ?? DefaultApiBaseUrl;

    // ================================================================
    //  封面图缓存
    // ================================================================

    /// <summary>模板封面图缓存根目录</summary>
    private static readonly string CoverCacheDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "template_covers");

    /// <summary>封面图片版本号（递增，用于 WinUI BitmapImage 缓存失效）</summary>
    private int _coverVersion;

    private string GetCoverCachePath(Guid templateId) =>
        Path.Combine(CoverCacheDirectory, $"{templateId:N}{SecureCacheService.EncryptedExtension}");

    /// <summary>
    /// 获取带版本号的封面图临时明文 URI（WinUI BitmapImage 按 URI 缓存，追加 ?v= 强制刷新）
    /// </summary>
    private string GetCoverCacheUrl(Guid templateId)
    {
        var tempPath = Path.Combine(SecureCacheService.TempDirectory, $"cover_{templateId:N}.png");
        return $"{tempPath}?v={_coverVersion}";
    }

    // ================================================================
    //  元数据模型
    // ================================================================

    // 封面 ETag/版本元数据已内嵌于加密信封（方案A），不再使用独立 meta 文件

    // ================================================================
    //  缓存
    // ================================================================

    /// <summary>缓存模板列表（线程安全）</summary>
    private List<QuickStartTemplate>? _cachedTemplates;
    private readonly object _cacheLock = new();

    public RemoteQuickStartService(
        IServerUrlService serverUrlService,
        LocalTemplateStore localTemplateStore,
        SecureCacheService secureCache)
    {
        _serverUrlService = serverUrlService;
        _localTemplateStore = localTemplateStore;
        _secureCache = secureCache;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
        _httpClient.Timeout = TimeSpan.FromSeconds(15);
    }

    // ================================================================
    //  IQuickStartService
    // ================================================================

    /// <inheritdoc />
    public IEnumerable<QuickStartTemplate> GetTemplates()
    {
        // 缓存已就绪 → 直接返回
        lock (_cacheLock)
        {
            if (_cachedTemplates != null)
                return _cachedTemplates;
        }

        // 首次调用：同步回退请求（5 秒超时），避免 UI 绑定长时间阻塞
        System.Diagnostics.Debug.WriteLine(
            "[RemoteQuickStartService] 模板缓存为空，执行同步回退请求");

        try
        {
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));
            var task = FetchTemplatesAsync(cts.Token);
            if (task.Wait(TimeSpan.FromSeconds(5), cts.Token))
            {
                var templates = task.Result;
                lock (_cacheLock)
                {
                    _cachedTemplates = templates;
                }
                System.Diagnostics.Debug.WriteLine(
                    $"[RemoteQuickStartService] 同步回退请求成功，获取 {templates.Count} 个模板");
                return templates;
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 同步回退请求失败: {ex.Message}");
        }

        return Enumerable.Empty<QuickStartTemplate>();
    }

    /// <inheritdoc />
    public IEnumerable<ExternalClient> GetExternalClients()
    {
        var clients = new List<ExternalClient>();

        var synologyDrive = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            "Synology", "Synology Drive", "Synology Drive.exe");
        if (File.Exists(synologyDrive))
        {
            clients.Add(new ExternalClient
            {
                Name = "Synology Drive",
                ExecutablePath = synologyDrive,
                IconGlyph = "\uEC50"
            });
        }

        var potPlayer = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            "DAUM", "PotPlayer", "PotPlayerMini64.exe");
        if (File.Exists(potPlayer))
        {
            clients.Add(new ExternalClient
            {
                Name = "PotPlayer",
                ExecutablePath = potPlayer,
                IconGlyph = "\uE8B9"
            });
        }

        var obs = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            "OBS Studio", "bin", "64bit", "obs64.exe");
        if (File.Exists(obs))
        {
            clients.Add(new ExternalClient
            {
                Name = "OBS Studio",
                ExecutablePath = obs,
                IconGlyph = "\uEB9C"
            });
        }

        return clients;
    }

    // ================================================================
    //  异步预取（启动时由 OnLaunched 触发）
    // ================================================================

    /// <summary>
    /// 异步预取模板数据并填充缓存。
    /// 由 App.OnLaunched 以 fire-and-forget 方式调用，不阻塞启动流程。
    ///
    /// ## 本地持久化 + 秒显（v3）
    /// Step 0: 从 LocalTemplateStore 加载本地缓存的模板 DTO → 立即映射为客户端模型填入缓存（秒显）
    /// Step 1: 从服务端拉取最新模板列表 → Version 合并比对（新增/更新/移除）
    /// Step 2: 有变更 → 持久化到本地；无变更 → 不写盘
    /// Step 3: 封面图缓存同步（ETag 比对）
    /// </summary>
    public async Task InitializeAsync()
    {
        System.Diagnostics.Debug.WriteLine(
            "[RemoteQuickStartService] === InitializeAsync ===");

        // Step 0: 优先从本地持久化缓存加载模板（秒显，不等网络）
        var localDtos = await Task.Run(() => _localTemplateStore.Load());
        if (localDtos.Count > 0)
        {
            var cachedFromLocal = localDtos.Select(MapToTemplate).ToList();
            LoadLocalCovers(cachedFromLocal);
            lock (_cacheLock)
            {
                _cachedTemplates = cachedFromLocal;
            }
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 本地缓存模板已加载: {cachedFromLocal.Count} 个（秒显）");
        }

        try
        {
            var templates = await FetchTemplatesAsync();
            lock (_cacheLock)
            {
                _cachedTemplates = templates;
            }
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 预取成功，获取 {templates.Count} 个模板");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 预取失败: {ex.Message}");
            // 网络失败时保留 Step 0 加载的本地缓存，不覆盖
        }
    }

    // ================================================================
    //  内部方法
    // ================================================================

    /// <summary>
    /// 从服务端获取模板列表，并执行封面图缓存同步。
    ///
    /// ## 执行流程
    /// ```
    /// Step 1: GET /api/templates → 解析 JSON → 映射为 QuickStartTemplate 列表
    /// Step 2: 优先加载本地缓存封面（秒显，不阻塞 UI 线程）
    ///         有缓存 → CoverImageUrl = 本地文件路径
    ///         无缓存 → CoverImageUrl = null（转换器回退默认图）
    /// Step 3: 并行同步服务端封面图
    ///         ↓
    ///         对每个模板:
    ///           ① GET /api/templates/{id}/cover → 302 Location（预签名 URL）
    ///           ② GET 预签名 URL → 提取 ETag + 下载图片字节流
    ///           ③ ETag == 本地版本? → 跳过（服务端无变更）
    ///           ④ ETag != 本地版本? → 原子写入缓存文件 + 保存版本元数据
    ///           ⑤ 404 → 删除本地缓存（服务端已移除封面）
    /// ```
    /// </summary>
    private async Task<List<QuickStartTemplate>> FetchTemplatesAsync(
        CancellationToken ct = default)
    {
        var response = await _httpClient.GetAsync(
            $"{ApiBaseUrl}/api/templates", ct);

        if (!response.IsSuccessStatusCode)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] HTTP {(int)response.StatusCode}: 获取模板失败");
            return new List<QuickStartTemplate>();
        }

        var json = await response.Content.ReadAsStringAsync(ct);
        var apiResponse = JsonSerializer.Deserialize<ApiResponse<List<TemplateResponseData>>>(json);

        if (apiResponse?.Success != true || apiResponse.Data == null)
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteQuickStartService] 服务端返回异常: success=false 或 data=null");
            return new List<QuickStartTemplate>();
        }

        // Step 1: 与本地持久化缓存做 Version 合并比对（新增/更新/移除），有变更才写盘
        var localDtos = _localTemplateStore.Load();
        bool hasChanges = MergeAndPersistTemplates(apiResponse.Data, localDtos);

        // Step 2: 映射为客户端模型
        var templates = apiResponse.Data
            .Select(MapToTemplate)
            .ToList();

        // Step 3: 加载本地缓存封面（秒显）
        LoadLocalCovers(templates);

        // Step 4: 并行同步服务端封面图（下载最新 + ETag 版本比对）
        await SyncCoverImagesAsync(templates, ct);

        // Step 5: 按模板名称排序
        // 使用 ICU 拼音排序（zh-CN-u-co-pinyin），实现中文按拼音首字母、英文按字母序混排
        // .NET 10 / Windows 10+ 原生支持 ICU 区域标记，低版本自动回退到码点排序
        try
        {
            var pinyinComparer = StringComparer.Create(
                new CultureInfo("zh-CN-u-co-pinyin"), ignoreCase: true);
            templates.Sort((a, b) => pinyinComparer.Compare(a.Name, b.Name));
        }
        catch (CultureNotFoundException)
        {
            // ICU 不可用（旧系统），回退到 Unicode 码点排序（Latin 字母自然排在 CJK 前）
            templates.Sort((a, b) => string.Compare(
                a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
        }

        if (hasChanges)
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteQuickStartService] 模板列表有变更，已持久化到本地");
        }

        return templates;
    }

    /// <summary>
    /// 将服务端模板列表与本地缓存做 Version 合并比对：
    /// - 服务端有、本地无 → 新增（变更）
    /// - 双方都有且服务端 Version 更高 → 更新（变更）
    /// - 双方都有且 Version 相同 → 无变更（不写盘）
    /// - 服务端无、本地有 → 本地移除（变更，服务端已删除模板）
    ///
    /// 有任意变更时以服务端列表为准全量写盘；无变更时不写盘（避免无谓磁盘 IO）。
    /// </summary>
    /// <param name="serverDtos">服务端返回的模板 DTO 列表（权威）</param>
    /// <param name="localDtos">本地持久化的模板 DTO 列表</param>
    /// <returns>true = 存在变更且已持久化</returns>
    private bool MergeAndPersistTemplates(
        List<TemplateResponseData> serverDtos,
        List<TemplateResponseData> localDtos)
    {
        if (localDtos.Count == 0 && serverDtos.Count > 0)
        {
            // 首次同步：本地为空 → 全量写入
            _localTemplateStore.SaveAll(serverDtos);
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 首次同步，持久化 {serverDtos.Count} 个模板");
            return true;
        }

        if (serverDtos.Count == 0 && localDtos.Count > 0)
        {
            // 服务端已清空 → 清除本地
            _localTemplateStore.Clear();
            System.Diagnostics.Debug.WriteLine(
                "[RemoteQuickStartService] 服务端模板已清空，清除本地缓存");
            return true;
        }

        // 比对 Version 是否一致
        var localVersionMap = localDtos.ToDictionary(d => d.Id, d => d.Version);
        bool changed = false;

        foreach (var server in serverDtos)
        {
            if (!localVersionMap.TryGetValue(server.Id, out int localVersion))
            {
                changed = true; // 新增
                break;
            }
            if (server.Version != localVersion)
            {
                changed = true; // 版本变化（更高或更低均视为变更）
                break;
            }
        }

        // 本地存在但服务端已移除
        if (!changed)
        {
            var serverIds = new HashSet<Guid>(serverDtos.Select(d => d.Id));
            changed = localDtos.Any(d => !serverIds.Contains(d.Id));
        }

        if (changed)
        {
            _localTemplateStore.SaveAll(serverDtos);
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 模板列表版本变更，已持久化 {serverDtos.Count} 个模板");
            return true;
        }

        System.Diagnostics.Debug.WriteLine(
            "[RemoteQuickStartService] 模板列表无变更，跳过写盘");
        return false;
    }

    /// <summary>
    /// 将 API 响应数据映射为客户端 QuickStartTemplate。
    /// CoverImageUrl 初始设为 null（不直接使用对象键），
    /// 后续由缓存加载和服务器同步流程填充本地文件路径。
    /// </summary>
    private static QuickStartTemplate MapToTemplate(TemplateResponseData dto)
    {
        return new QuickStartTemplate
        {
            Id = dto.Id,
            Name = dto.Name,
            Description = dto.Description ?? string.Empty,
            SchemeIds = dto.SchemeIds?.ToArray() ?? Array.Empty<Guid>(),
            CoverImageUrl = null, // 不使用对象键，后续通过缓存/API 填充
            Category = dto.Category,
            Tags = dto.Tags,
            Version = dto.Version,
        };
    }

    // ================================================================
    //  本地缓存加载（Step 2）
    // ================================================================

    /// <summary>
    /// 从本地缓存目录加载已有的封面图。
    /// 有缓存时直接设置 CoverImageUrl 为本地文件路径（带版本号），
    /// 实现"秒显"效果，不等网络请求完成。
    /// </summary>
    private void LoadLocalCovers(List<QuickStartTemplate> templates)
    {
        var loadedCount = 0;
        foreach (var template in templates)
        {
            var cachePath = GetCoverCachePath(template.Id);
            // 解密加密信封到临时明文文件（失败=被篡改/旧明文格式 → 走重新下载）
            if (_secureCache.TryReadEnvelope(cachePath, out var content, out _, out _))
            {
                _secureCache.WriteTempFile($"cover_{template.Id:N}.png", content);
                template.CoverImageUrl = GetCoverCacheUrl(template.Id);
                loadedCount++;
            }
        }

        if (loadedCount > 0)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 本地缓存封面已加载: {loadedCount}/{templates.Count}");
        }
    }

    // ================================================================
    //  服务端封面图同步（Step 3）
    // ================================================================

    /// <summary>
    /// 并行同步所有模板的封面图：
    /// ① GET /api/templates/{id}/cover → 302 → 预签名 URL
    /// ② GET 预签名 URL → 提取 ETag + 下载图片字节流
    /// ③ ETag 比对 → 有变更才写入缓存
    /// ④ 404 → 清理本地缓存
    /// </summary>
    private async Task SyncCoverImagesAsync(List<QuickStartTemplate> templates,
        CancellationToken ct = default)
    {
        if (templates.Count == 0) return;

        System.Diagnostics.Debug.WriteLine(
            $"[RemoteQuickStartService] 开始并行同步 {templates.Count} 个模板封面图");

        var tasks = templates.Select(async template =>
        {
            try
            {
                await SyncSingleCoverAsync(template, ct);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[RemoteQuickStartService] 模板 {template.Name} 同步失败: {ex.Message}");
            }
        });

        await Task.WhenAll(tasks);

        var cachedCount = templates.Count(t =>
            t.CoverImageUrl != null &&
            t.CoverImageUrl.StartsWith("file:", StringComparison.OrdinalIgnoreCase));

        System.Diagnostics.Debug.WriteLine(
            $"[RemoteQuickStartService] 封面图同步完成: {cachedCount}/{templates.Count} 个模板已缓存");
    }

    /// <summary>
    /// 同步单个模板的封面图：获取预签名 URL → 下载 → ETag 比对 → 写入缓存
    /// </summary>
    private async Task SyncSingleCoverAsync(QuickStartTemplate template,
        CancellationToken ct = default)
    {
        // Step ①: 获取预签名 URL
        var presignedUrl = await FetchCoverPresignedUrlAsync(template.Id, ct);

        if (presignedUrl == null)
        {
            // 服务端返回 404 → 封面上次存在但已被管理员移除
            DeleteLocalCover(template.Id);
            template.CoverImageUrl = null;
            return;
        }

        // Step ②: 下载图片 + 加密缓存（方案A：内容+ETag 合并加密单文件）
        var cachePath = GetCoverCachePath(template.Id);
        var changed = await DownloadAndCacheCoverAsync(presignedUrl, template, cachePath, ct);

        if (changed)
        {
            // 有新图片 → 递增版本号使 WinUI 缓存失效
            _coverVersion++;
            template.CoverImageUrl = GetCoverCacheUrl(template.Id);
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 模板 {template.Name} 封面已更新");
        }
        else if (!_secureCache.TryReadEnvelope(cachePath, out _, out _, out _))
        {
            // 下载失败且无本地加密缓存
            template.CoverImageUrl = null;
        }
        // else: 已有缓存（可能是 Step 2 加载的）且服务端无变更，保持 CoverImageUrl 不变
    }

    // ================================================================
    //  预签名 URL 获取
    // ================================================================

    /// <summary>
    /// 调用 GET /api/templates/{id}/cover 端点获取预签名 URL。
    /// 该端点返回 302 Found + Location 头指向 MinIO 预签名 URL。
    /// 客户端设置 AllowAutoRedirect=false 手动读取 Location 头。
    /// </summary>
    private async Task<string?> FetchCoverPresignedUrlAsync(Guid templateId,
        CancellationToken ct = default)
    {
        using var client = NetworkClientFactory.Create(allowAutoRedirect: false);
        client.Timeout = TimeSpan.FromSeconds(5);
        client.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");

        using var response = await client.GetAsync(
            $"{ApiBaseUrl}/api/templates/{templateId}/cover", ct);

        if (response.StatusCode == System.Net.HttpStatusCode.Redirect)
        {
            var location = response.Headers.Location?.ToString();
            if (!string.IsNullOrEmpty(location))
                return location;

            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 模板 {templateId} 302 无 Location 头");
            return null;
        }

        if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 模板 {templateId} 无封面图片 (404)");
        }
        else
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 模板 {templateId} 封面图获取异常: HTTP {(int)response.StatusCode}");
        }

        return null;
    }

    // ================================================================
    //  下载 + ETag 比对 + 缓存写入
    // ================================================================

    /// <summary>
    /// 下载封面图片，加密缓存（方案A：内容+ETag 合并加密单文件）后决定是否更新本地缓存。
    ///
    /// ## 流程（与 BackgroundService / UserAvatarService 一致的范式）
    /// ① GET 预签名 URL → 提取 ETag（MinIO 原生支持 MD5 哈希作为 ETag）
    /// ② 读取本地加密信封中的 ETag
    /// ③ ETag 一致 → 跳过更新（服务端无变更），返回 false
    /// ④ ETag 不一致 → 内容+ETag 合并加密写入 .enc，解密到临时明文供 UI 加载，返回 true
    ///
    /// ## 异常安全
    /// - 网络错误/超时 → 保持本地缓存不变，返回 false
    /// - 原子写入（.tmp → rename）防止断电/崩溃导致缓存文件损坏
    /// </summary>
    /// <param name="presignedUrl">MinIO 预签名 URL</param>
    /// <param name="template">目标模板（更新 CoverImageUrl）</param>
    /// <param name="cachePath">本地加密缓存文件路径</param>
    /// <param name="ct">取消令牌</param>
    /// <returns>true = 有新图片已缓存；false = 无需更新或下载失败</returns>
    private async Task<bool> DownloadAndCacheCoverAsync(string presignedUrl,
        QuickStartTemplate template, string cachePath, CancellationToken ct = default)
    {
        try
        {
            using var response = await _httpClient.GetAsync(presignedUrl,
                HttpCompletionOption.ResponseContentRead, ct);

            if (!response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[RemoteQuickStartService] 封面下载 HTTP {(int)response.StatusCode}");
                return false;
            }

            // 提取服务端 ETag
            string? serverEtag = null;
            if (response.Headers.ETag is { } etagHeader && etagHeader.Tag is { } tagValue)
            {
                serverEtag = tagValue.Trim('"');
            }

            // ETag 比对（仅当本地有加密缓存且 ETag 一致时跳过）
            if (serverEtag != null &&
                _secureCache.TryReadEnvelope(cachePath, out _, out var localEtag, out _) &&
                localEtag == serverEtag)
            {
                System.Diagnostics.Debug.WriteLine(
                    "[RemoteQuickStartService] ETag 一致，服务端无变更，跳过下载");
                return false;
            }

            // 下载图片字节流
            var imageBytes = await response.Content.ReadAsByteArrayAsync(ct);

            // 加密写入缓存（方案A：内容 + ETag 合并加密单文件，原子写入）
            _secureCache.SaveEnvelope(cachePath, imageBytes, serverEtag);

            // 解密到临时明文文件供 UI 加载
            if (_secureCache.TryReadEnvelope(cachePath, out var content, out _, out _))
            {
                _secureCache.WriteTempFile($"cover_{template.Id:N}.png", content);
            }

            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 封面已加密缓存 ({imageBytes.Length:N0} bytes)");
            return true;
        }
        catch (TaskCanceledException)
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteQuickStartService] 封面下载超时");
            return false;
        }
        catch (HttpRequestException ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 封面下载网络错误: {ex.Message}");
            return false;
        }
    }

    // ================================================================
    //  缓存管理辅助方法
    // ================================================================

    /// <summary>解密封面加密缓存到临时明文文件，返回路径（失败返回 null）</summary>
    private string? DecryptCoverToTemp(Guid templateId) =>
        _secureCache.DecryptToTempFile(GetCoverCachePath(templateId), $"cover_{templateId:N}.png");

    /// <summary>删除模板封面的加密缓存和临时明文文件</summary>
    private void DeleteLocalCover(Guid templateId)
    {
        var cachePath = GetCoverCachePath(templateId);
        if (File.Exists(cachePath))
        {
            File.Delete(cachePath);
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 已删除模板 {templateId} 的本地封面缓存");
        }
        try
        {
            var tempPath = Path.Combine(SecureCacheService.TempDirectory, $"cover_{templateId:N}.png");
            if (File.Exists(tempPath)) File.Delete(tempPath);
        }
        catch { }
    }

    // ================================================================
    //  启动初始化
    // ================================================================

    /// <summary>
    /// 确保模板 API URL 注册键存在。如果尚未注册，使用生产环境地址创建一条记录。
    /// </summary>
    public void EnsureTemplateApiUrlRecord()
    {
        try
        {
            var existing = _serverUrlService.GetByKey(TemplatesApiUrlKey);
            if (existing != null) return;

            _serverUrlService.Register(
                key: TemplatesApiUrlKey,
                displayName: "实例模板 API 服务地址",
                plainUrl: DefaultApiBaseUrl,
                category: "Infrastructure");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteQuickStartService] 注册模板 API URL 失败: {ex.Message}");
        }
    }

    // ================================================================
    //  IDisposable
    // ================================================================

    /// <summary>
    /// 释放服务（应用退出时由 Hosting 容器调用）。
    /// 释放 HttpClient 连接池，确保进程可完全退出。
    /// </summary>
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _httpClient.Dispose();
        GC.SuppressFinalize(this);
    }
}

// ================================================================
//  模板 API DTO
// ================================================================

/// <summary>
/// GET /api/templates 响应 data 项
/// </summary>
public class TemplateResponseData
{
    [JsonPropertyName("id")]
    public Guid Id { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;

    [JsonPropertyName("description")]
    public string? Description { get; set; }

    [JsonPropertyName("category")]
    public string? Category { get; set; }

    [JsonPropertyName("tags")]
    public string? Tags { get; set; }

    [JsonPropertyName("screenshotUrl")]
    public string? ScreenshotUrl { get; set; }

    [JsonPropertyName("coverImageUrl")]
    public string? CoverImageUrl { get; set; }

    [JsonPropertyName("schemeIds")]
    public List<Guid>? SchemeIds { get; set; }

    [JsonPropertyName("version")]
    public int Version { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }
}
