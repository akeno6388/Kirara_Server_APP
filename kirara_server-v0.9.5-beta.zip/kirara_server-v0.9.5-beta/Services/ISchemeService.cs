using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

public interface ISchemeService
{
    IEnumerable<Scheme> GetAllSchemes();
    IEnumerable<Scheme> GetSchemesByInstanceType(InstanceType type);
    Scheme? GetScheme(Guid id);
    IScheme? LoadSchemeInstance(Scheme scheme);
    void RegisterThirdPartyScheme(string executablePath, string? arguments = null);
    void SyncBuiltInSchemas();
}
