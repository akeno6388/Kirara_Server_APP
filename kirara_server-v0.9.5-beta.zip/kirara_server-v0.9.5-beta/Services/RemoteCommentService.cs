using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Models.Api;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 远程评论服务实现 — 通过 HTTP API 与远程服务器通信
/// 所有数据库操作均在服务端完成，客户端仅负责收发协议
/// </summary>
public class RemoteCommentService : ICommentService, IDisposable
{
    private readonly HttpClient _httpClient;
    private readonly ILoginService _loginService;
    private bool _disposed;

    /// <summary>API 基地址（生产环境）</summary>
    private const string ApiBaseUrl = "https://api.akeno6388.online:1010";

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public RemoteCommentService(ILoginService loginService)
    {
        _loginService = loginService;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.BaseAddress = new Uri(ApiBaseUrl);
        _httpClient.Timeout = TimeSpan.FromSeconds(30);
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
    }

    // ================================================================
    //  ICommentService 实现
    // ================================================================

    /// <inheritdoc />
    public async Task<IReadOnlyList<CommentItem>> GetCommentsAsync(
        string resourceKey, int page = 1, int pageSize = 20)
    {
        try
        {
            var url = $"/api/comments/by-resource?resourceKey={Uri.EscapeDataString(resourceKey)}&page={page}&pageSize={pageSize}";
            await AttachAuthHeaderAsync();

            var response = await _httpClient.GetAsync(url);
            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine($"[CommentAPI] GET comments 失败: {response.StatusCode} - {body}");
                return Array.Empty<CommentItem>();
            }

            var apiResponse = JsonSerializer.Deserialize<ApiResponse<PagedResult<CommentResponse>>>(body, JsonOptions);
            if (apiResponse?.Success != true || apiResponse.Data?.Items == null)
                return Array.Empty<CommentItem>();

            return apiResponse.Data.Items.Select(MapToCommentItem).ToList().AsReadOnly();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[CommentAPI] GET comments 异常: {ex.Message}");
            return Array.Empty<CommentItem>();
        }
    }

    /// <inheritdoc />
    public async Task<CommentItem> AddCommentAsync(
        string resourceKey, Guid schemeId, string content, string? contentTitle = null)
    {
        var payload = JsonSerializer.Serialize(new
        {
            resourceKey,
            schemeId,
            content,
            contentTitle
        });

        await AttachAuthHeaderAsync();
        var response = await _httpClient.PostAsync(
            "/api/comments",
            new StringContent(payload, Encoding.UTF8, "application/json"));

        var body = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            var error = TryParseError(body);
            throw new InvalidOperationException(error ?? $"创建评论失败: {response.StatusCode}");
        }

        var apiResponse = JsonSerializer.Deserialize<ApiResponse<CommentResponse>>(body, JsonOptions);
        if (apiResponse?.Success != true || apiResponse.Data == null)
            throw new InvalidOperationException("创建评论失败: 服务端返回异常");

        return MapToCommentItem(apiResponse.Data);
    }

    /// <inheritdoc />
    public async Task<LikeResult> ToggleLikeCommentAsync(Guid commentId)
    {
        await AttachAuthHeaderAsync();
        var response = await _httpClient.PostAsync(
            $"/api/comments/{commentId}/toggle-like", null);

        var body = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            var error = TryParseError(body);
            throw new InvalidOperationException(error ?? $"点赞操作失败: {response.StatusCode}");
        }

        var apiResponse = JsonSerializer.Deserialize<ApiResponse<LikeResult>>(body, JsonOptions);
        if (apiResponse?.Success != true || apiResponse.Data == null)
            throw new InvalidOperationException("点赞操作失败: 服务端返回异常");

        return apiResponse.Data;
    }

    /// <inheritdoc />
    public async Task<ReplyItem> AddReplyAsync(Guid commentId, string content, string? contentTitle = null)
    {
        var payload = JsonSerializer.Serialize(new
        {
            content,
            contentTitle
        });

        await AttachAuthHeaderAsync();
        var response = await _httpClient.PostAsync(
            $"/api/comments/{commentId}/replies",
            new StringContent(payload, Encoding.UTF8, "application/json"));

        var body = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            var error = TryParseError(body);
            throw new InvalidOperationException(error ?? $"创建回复失败: {response.StatusCode}");
        }

        var apiResponse = JsonSerializer.Deserialize<ApiResponse<ReplyResponse>>(body, JsonOptions);
        if (apiResponse?.Success != true || apiResponse.Data == null)
            throw new InvalidOperationException("创建回复失败: 服务端返回异常");

        return MapToReplyItem(apiResponse.Data);
    }

    /// <inheritdoc />
    public async Task<LikeResult> ToggleLikeReplyAsync(Guid commentId, Guid replyId)
    {
        await AttachAuthHeaderAsync();
        var response = await _httpClient.PostAsync(
            $"/api/comments/{commentId}/replies/{replyId}/toggle-like", null);

        var body = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            var error = TryParseError(body);
            throw new InvalidOperationException(error ?? $"回复点赞操作失败: {response.StatusCode}");
        }

        var apiResponse = JsonSerializer.Deserialize<ApiResponse<LikeResult>>(body, JsonOptions);
        if (apiResponse?.Success != true || apiResponse.Data == null)
            throw new InvalidOperationException("回复点赞操作失败: 服务端返回异常");

        return apiResponse.Data;
    }

    /// <inheritdoc />
    public async Task DeleteCommentAsync(Guid commentId)
    {
        await AttachAuthHeaderAsync();
        var response = await _httpClient.DeleteAsync($"/api/comments/{commentId}");
        var body = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            var error = TryParseError(body);
            throw new InvalidOperationException(error ?? $"删除评论失败: {response.StatusCode}");
        }
    }

    /// <inheritdoc />
    public async Task DeleteReplyAsync(Guid commentId, Guid replyId)
    {
        await AttachAuthHeaderAsync();
        var response = await _httpClient.DeleteAsync($"/api/comments/{commentId}/replies/{replyId}");
        var body = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            var error = TryParseError(body);
            throw new InvalidOperationException(error ?? $"删除回复失败: {response.StatusCode}");
        }
    }

    // ================================================================
    //  私有辅助方法
    // ================================================================

    /// <summary>
    /// 附加认证头 — 需要登录的端点携带 Bearer Token。
    /// 自动检测 Token 过期并续期；未登录时不附加（服务端将返回 401）。
    /// </summary>
    private async Task AttachAuthHeaderAsync()
    {
        // 确保 Token 有效（过期时自动用 RefreshToken 续期）
        await _loginService.EnsureValidAccessTokenAsync();

        var token = _loginService.AccessToken;
        if (!string.IsNullOrEmpty(token))
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);
        }
    }

    /// <summary>解析 API 错误响应中的 message 字段</summary>
    private static string? TryParseError(string body)
    {
        try
        {
            var errorResponse = JsonSerializer.Deserialize<ApiResponse<object>>(body, JsonOptions);
            return errorResponse?.Error?.Message;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>将 API 评论 DTO 映射为客户端模型</summary>
    private static CommentItem MapToCommentItem(CommentResponse dto)
    {
        return new CommentItem
        {
            Id = dto.Id,
            ResourceKey = dto.ResourceKey,
            SchemeId = dto.SchemeId,
            AuthorName = dto.AuthorName,
            AuthorUserId = dto.UserId,
            AuthorAvatarUrl = dto.AuthorAvatarUrl,
            Content = dto.Content,
            ContentTitle = dto.ContentTitle,
            LikeCount = dto.LikeCount,
            IsLikedByUser = dto.IsLikedByUser,
            ReplyCount = dto.ReplyCount,
            CreatedAt = dto.CreatedAt,
            Replies = dto.Replies?.Select(MapToReplyItem).ToList() ?? new()
        };
    }

    /// <summary>将 API 回复 DTO 映射为客户端模型</summary>
    private static ReplyItem MapToReplyItem(ReplyResponse dto)
    {
        return new ReplyItem
        {
            Id = dto.Id,
            CommentId = dto.CommentId,
            AuthorName = dto.AuthorName,
            AuthorUserId = dto.UserId,
            AuthorAvatarUrl = dto.AuthorAvatarUrl,
            Content = dto.Content,
            ContentTitle = dto.ContentTitle,
            LikeCount = dto.LikeCount,
            IsLikedByUser = dto.IsLikedByUser,
            CreatedAt = dto.CreatedAt
        };
    }

    // ================================================================
    //  IDisposable
    // ================================================================

    /// <summary>
    /// 释放服务（应用退出时由 Hosting 容器调用）。
    /// 释放 HttpClient 连接池，确保进程可完全退出。
    /// </summary>
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _httpClient.Dispose();
        GC.SuppressFinalize(this);
    }
}
