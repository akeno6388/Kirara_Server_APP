using System;
using Microsoft.Win32;
using Kirara_Server_WinUI.Data;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 应用软件行为服务 — 统一管理「关闭行为 / 开机自启」两组运行期偏好。
///
/// - CloseToMinimize：点击标题栏关闭按钮时是「最小化到任务栏」还是「直接退出」。
///   WinUI3 unpackaged + asInvoker（无提权）下通过 WndProc SC_CLOSE 拦截实现，
///   WindowMessageHandler（WindowAnimationHelper）读取本服务的静态 Current。
/// - AutoStart：开机自启 — unpackaged + asInvoker + self-contained，
///   通过 HKCU\Software\Microsoft\Windows\CurrentVersion\Run 注册表项实现，
///   exe_path = Environment.ProcessPath（当前进程可执行文件完整路径）。
///
/// 设置持久化于 LiteDB app_settings 集合（%APPDATA%/Kirara/data.db）。
/// </summary>
public class AppBehaviorService
{
    // ===== 设置键 =====
    private const string KeyCloseToMinimize = "behavior.close_to_minimize";
    private const string KeyAutoStart = "behavior.auto_start";
    private const string KeyAutoCollapseSidebar = "behavior.auto_collapse_sidebar";
    private const string KeySidebarStartupState = "behavior.sidebar_startup_state";

    // ===== HKCU Run 注册表项名（与进程名一致）=====
    private const string RunValueName = "KiraraServerAPP";
    private const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";

    /// <summary>
    /// HKCU Run 注册表键路径 — Windows unpackaged + asInvoker（无提权）下写入当前用户即可生效。
    /// </summary>
    private static readonly string[] AutoStartKeyPaths =
    {
        RunKeyPath,
    };

    private readonly IAppSettingsRepository _settings;

    /// <summary>
    /// DI Singleton — WindowMessageHandler（静态 WndProc）通过此静态引用读取关闭行为，
    /// 避免在 Win32 WndProc（非托管回调线程）中解析 DI。
    /// </summary>
    public static AppBehaviorService? Current { get; private set; }

    /// <summary>点击标题栏「关闭」按钮时是否最小化到任务栏而非退出（默认开启）</summary>
    public bool CloseToMinimize { get; private set; } = true;

    /// <summary>是否开机自启（默认关闭）</summary>
    public bool AutoStart { get; private set; }

    /// <summary>
    /// 左侧功能栏自动折叠：开启后，进入实例主界面时左侧功能栏自动折叠
    /// （默认开启）
    /// </summary>
    public bool AutoCollapseSidebar { get; private set; } = true;

    /// <summary>
    /// 侧栏启动状态：true = 启动时保持展开；false = 启动时保持折叠
    /// （仅 AutoCollapseSidebar 关闭时生效；默认展开）
    /// </summary>
    public bool SidebarStartupExpanded { get; private set; } = true;

    public AppBehaviorService(IAppSettingsRepository settings)
    {
        _settings = settings;
        Current = this;
    }

    /// <summary>
    /// 从持久化存储加载软件行为设置（应用启动时调用）。
    /// 默认值：关闭行为 = 最小化到任务栏；开机自启 = 关闭；左侧栏自动折叠 = 开启。
    /// 用户在设置页的修改经 Set* 方法写入 LiteDB app_settings，下次启动读取覆盖默认值。
    /// </summary>
    public void Load()
    {
        CloseToMinimize = ParseBool(_settings.Get(KeyCloseToMinimize), true);
        AutoStart = ParseBool(_settings.Get(KeyAutoStart), false);
        AutoCollapseSidebar = ParseBool(_settings.Get(KeyAutoCollapseSidebar), true);
        SidebarStartupExpanded = ParseBool(_settings.Get(KeySidebarStartupState), true);
        // AutoStart=true（持久化标记）但注册表项缺失时（如被清理/重装）自动补写，
        // AutoStart=false（持久化标记）但注册表项残留时自动清理。
        SyncAutoStartRegistry(AutoStart);
    }

    /// <summary>
    /// 设置「关闭行为」（持久化；立即生效 — WndProc SC_CLOSE 拦截实时读取 Current.CloseToMinimize）
    /// </summary>
    public void SetCloseToMinimize(bool minimize)
    {
        CloseToMinimize = minimize;
        _settings.Set(KeyCloseToMinimize, minimize ? "1" : "0");
    }

    /// <summary>
    /// 设置「开机自启」（持久化 + 立即写入/清理 HKCU Run）
    /// </summary>
    public void SetAutoStart(bool enable)
    {
        AutoStart = enable;
        _settings.Set(KeyAutoStart, enable ? "1" : "0");
        SyncAutoStartRegistry(enable);
    }

    /// <summary>
    /// 设置「左侧功能栏自动折叠」（持久化）
    /// 开启后点击「开始工作」进入实例主界面时左侧功能栏自动折叠。
    /// </summary>
    public void SetAutoCollapseSidebar(bool enable)
    {
        AutoCollapseSidebar = enable;
        _settings.Set(KeyAutoCollapseSidebar, enable ? "1" : "0");
    }

    /// <summary>
    /// 设置「侧栏启动状态」（持久化）
    /// true = 启动时保持展开；false = 启动时保持折叠。
    /// 仅 AutoCollapseSidebar 关闭时生效（开启时启动状态固定为展开）。
    /// </summary>
    public void SetSidebarStartupState(bool expanded)
    {
        SidebarStartupExpanded = expanded;
        _settings.Set(KeySidebarStartupState, expanded ? "1" : "0");
    }

    /// <summary>
    /// HKCU Run — unpackaged + asInvoker + self-contained：
    /// 开机自启必须指向「原生启动器」KiraraServerAPP.exe（与桌面图标同一入口）：
    ///   - 已有实例运行（含最小化/托盘隐藏）→ 启动器唤醒主窗口，不会重复启动
    ///   - 无实例 → 启动器拉起 KiraraServerAPP.Core.exe
    /// ⚠️ 不能使用 Environment.ProcessPath（那是 Core 进程路径，绕过启动器会破坏单实例）
    /// </summary>
    private static void SyncAutoStartRegistry(bool enable)
    {
        try
        {
            using var key = Registry.CurrentUser.CreateSubKey(RunKeyPath);
            if (key == null) return;

            if (enable)
            {
                // 启动器与 Core 同目录：{AppContext.BaseDirectory}\KiraraServerAPP.exe
                string launcherPath = System.IO.Path.Combine(
                    AppContext.BaseDirectory, "KiraraServerAPP.exe");
                if (System.IO.File.Exists(launcherPath))
                    key.SetValue(RunValueName, $"\"{launcherPath}\"");
                else
                {
                    // 启动器缺失（开发环境未编译）→ 回退到 Core 自身路径
                    var exePath = Environment.ProcessPath;
                    if (!string.IsNullOrEmpty(exePath))
                        key.SetValue(RunValueName, $"\"{exePath}\"");
                }
            }
            else
            {
                key.DeleteValue(RunValueName, throwOnMissingValue: false);
            }
        }
        catch (Exception ex)
        {
            // [日志] HKCU Run 写入失败不影响主流程（仅 Debug.WriteLine）
            System.Diagnostics.Debug.WriteLine(
                $"[AppBehavior] {(enable ? "启用" : "禁用")}开机自启失败: {ex.GetType().Name}: {ex.Message}");
        }
    }

    /// <summary>解析 "1"/"true" → true；"0"/"false" → false；其他 → defaultValue</summary>
    private static bool ParseBool(string? raw, bool defaultValue)
    {
        if (raw is null)
            return defaultValue;
        if (raw is "1" or "true" or "True")
            return true;
        if (raw is "0" or "false" or "False")
            return false;
        return defaultValue;
    }
}