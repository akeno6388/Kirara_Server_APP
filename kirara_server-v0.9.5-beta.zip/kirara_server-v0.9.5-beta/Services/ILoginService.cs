using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 登录服务接口 — 管理用户认证与会话状态
/// Phase 3 Part 1 使用本地数据库，Part 2 替换为服务器端认证
/// </summary>
public interface ILoginService
{
    /// <summary>当前已登录的用户（未登录时为 null）</summary>
    UserAccount? CurrentUser { get; }

    /// <summary>当前已登录用户的 ID（未登录时返回 Guid.Empty）</summary>
    Guid CurrentUserId { get; }

    /// <summary>是否已登录</summary>
    bool IsLoggedIn { get; }

    /// <summary>当前用户是否为管理员</summary>
    bool IsAdmin { get; }

    /// <summary>
    /// 用户登录 — 验证用户名和密码
    /// </summary>
    /// <returns>(是否成功, 错误消息)</returns>
    Task<(bool success, string? error)> LoginAsync(string username, string password);

    /// <summary>
    /// 用户注册 — 仅可注册用户组账户
    /// </summary>
    /// <returns>(是否成功, 错误消息)</returns>
    Task<(bool success, string? error)> RegisterAsync(string username, string password);

    /// <summary>是否启用自动登录</summary>
    bool AutoLoginEnabled { get; }

    /// <summary>尝试自动登录（读取已保存的凭据）</summary>
    /// <returns>是否自动登录成功</returns>
    Task<bool> TryAutoLoginAsync();

    /// <summary>设置自动登录状态</summary>
    void SetAutoLoginEnabled(bool enabled);

    /// <summary>上次登录的用户名（退出登录后保留，用于登录页预填）</summary>
    string? LastLoginUsername { get; }

    /// <summary>退出登录，清除当前会话</summary>
    void Logout();

    /// <summary>
    /// 修改当前用户密码 — 成功后服务端吊销所有 Token，需要重新登录
    /// </summary>
    /// <returns>(是否成功, 错误消息)</returns>
    Task<(bool success, string? error)> ChangePasswordAsync(string currentPassword, string newPassword);

    /// <summary>
    /// 通知密码修改完成（由 UI 层在用户确认通知后调用，触发 LoginStateChanged 执行登出导航）
    /// </summary>
    void NotifyPasswordChangeCompleted();

    /// <summary>
    /// 修改当前用户名
    /// </summary>
    /// <returns>(是否成功, 错误消息)</returns>
    Task<(bool success, string? error)> ChangeUsernameAsync(string newUsername);

    /// <summary>
    /// 获取当前 accessToken（用于后续 HTTP 请求认证）
    /// </summary>
    string? AccessToken { get; }

    /// <summary>
    /// 确保 AccessToken 有效（过期时自动使用 RefreshToken 续期）
    /// </summary>
    /// <returns>false 表示刷新失败，需要重新登录</returns>
    Task<bool> EnsureValidAccessTokenAsync();

    /// <summary>
    /// 检查用户名是否可用（未被注册）
    /// </summary>
    /// <returns>(是否可用, 若不可用返回错误消息)</returns>
    Task<(bool available, string? error)> CheckUsernameAvailabilityAsync(string username);

    /// <summary>登录状态变更事件（登录/登出时触发）</summary>
    event Action<bool>? LoginStateChanged;
}
