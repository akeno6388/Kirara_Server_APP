using System.Text.Json;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 信息流卡片本地持久化存储 — 将原始 API DTO 缓存在 JSON 文件中。
///
/// ## 设计原则
/// - 存储原始 InfoCardResponseData（完整 DTO），非 AppNotification
/// - 存储路径：%APPDATA%/Kirara/info_cards.json
/// - 版本变更后全量替换；无变更时不写盘
/// - "清除"操作：直接删除本地存储文件，下次启动从服务器重新拉取
/// </summary>
public class LocalInfoCardStore
{
    private static readonly string StoreFilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "info_cards.json");

    private readonly object _lock = new();

    /// <summary>
    /// 从本地文件加载已持久化的信息流卡片 DTO 列表。
    /// </summary>
    public List<InfoCardResponseData> Load()
    {
        try
        {
            lock (_lock)
            {
                if (!File.Exists(StoreFilePath))
                    return new List<InfoCardResponseData>();

                var json = File.ReadAllText(StoreFilePath);
                var items = JsonSerializer.Deserialize<List<InfoCardResponseData>>(json);
                return items ?? new List<InfoCardResponseData>();
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalInfoCardStore] 加载失败: {ex.Message}");
            return new List<InfoCardResponseData>();
        }
    }

    /// <summary>
    /// 全量保存信息流卡片 DTO 列表到本地文件。
    /// </summary>
    public void SaveAll(List<InfoCardResponseData> cards)
    {
        if (cards == null || cards.Count == 0)
        {
            Clear();
            return;
        }

        try
        {
            lock (_lock)
            {
                var dir = Path.GetDirectoryName(StoreFilePath);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                var json = JsonSerializer.Serialize(cards);
                File.WriteAllText(StoreFilePath, json);
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalInfoCardStore] 保存失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 清除所有本地持久化的信息流卡片（直接删除文件）。
    /// </summary>
    public void Clear()
    {
        try
        {
            lock (_lock)
            {
                if (File.Exists(StoreFilePath))
                {
                    File.Delete(StoreFilePath);
                    System.Diagnostics.Debug.WriteLine(
                        "[LocalInfoCardStore] 本地信息流缓存已清除");
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalInfoCardStore] 清除失败: {ex.Message}");
        }
    }
}