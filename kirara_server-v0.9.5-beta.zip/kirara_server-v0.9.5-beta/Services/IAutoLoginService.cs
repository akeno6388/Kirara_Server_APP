using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;
using Microsoft.Web.WebView2.Core;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 自动登录服务 — 封装 WebView2 自动登录的全部编排逻辑。
/// 所有方法接收 CoreWebView2 参数（由页面持有），自身不管理 WebView2 生命周期。
/// </summary>
public interface IAutoLoginService
{
    /// <summary>
    /// 执行自动登录完整流程：
    /// 等待 URL 稳定 → 检测通知页 → 快速检测已登录 → 等待 SPA 就绪 → 二次检测 →
    /// 预登录脚本 → 密码页分流 → 主登录脚本 → 导航等待 → 登录检测。
    /// </summary>
    /// <param name="webView">目标 CoreWebView2</param>
    /// <param name="scheme">当前方案</param>
    /// <param name="binding">当前绑定</param>
    /// <param name="token">已解密的令牌</param>
    /// <param name="loginProvider">自动登录提供者</param>
    /// <returns>自动登录结果</returns>
    Task<AutoLoginResult> ExecuteAutoLoginAsync(
        CoreWebView2 webView,
        Scheme scheme,
        SchemeBinding binding,
        Token token,
        IAutoLoginProvider loginProvider);

    /// <summary>
    /// 执行工作区登录阶段 — 填入密码并提交（分步/延迟方案）。
    /// </summary>
    Task<AutoLoginResult> ExecuteWorkspaceLoginAsync(
        CoreWebView2 webView,
        Scheme scheme,
        SchemeBinding binding,
        Token token,
        IAutoLoginProvider loginProvider);

    /// <summary>
    /// 等待页面加载完成（轮询 document.readyState），最多 10 秒。
    /// </summary>
    Task WaitForPageLoadCompleteAsync(CoreWebView2 webView);

    /// <summary>
    /// 轮询登录成功 DOM 选择器，最多 10 秒。
    /// </summary>
    Task PollLoginSuccessDomAsync(CoreWebView2 webView, IAutoLoginProvider loginProvider);
}