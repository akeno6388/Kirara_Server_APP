using System.Text.Json;
using Kirara_Server_WinUI.Helpers;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// OpenVPN 配置文件缓存服务 — 从服务端下载 .ovpn 配置文件并缓存到本地。
///
/// ## 设计说明
/// 所有用户共用同一个 .ovpn 配置文件（服务端统一分发，MinIO `openvpn/config.ovpn`），
/// 服务端更新配置（Version++）后客户端自动下载新版。
/// 链路（对应 API 文档第十二章，与 RemoteQuickStartService / SchemeIconCacheService 预签名 URL + ETag 模式一致）：
///   1. GET {openvpn_api}/api/openvpn（Bearer Token 认证）
///      → 响应: { "success": true, "data": { "version": 3, "configKey": "openvpn/config.ovpn" } }
///      → 本地版本号一致且缓存存在 → 直接使用本地缓存（跳过下载）
///   2. GET {openvpn_api}/api/openvpn/download（Bearer Token 认证）
///      → 响应: { "success": true, "data": { "downloadUrl": "..." } }
///   3. GET 预签名下载 URL → ETag 比对 → 原子写入本地缓存
///
/// ## 缓存结构（方案A — 全量加密合并）
///   %APPDATA%/Kirara/openvpn/
///     ovpn_config.enc    — 加密缓存（内容 + 版本号 + ETag 合并单文件，AES-256-GCM）
///   %APPDATA%/Kirara/tmp/
///     ovpn_config.ovpn   — 解密后的临时明文（openvpn.exe 加载，启动时清理）
///
/// ## 版本比对策略（双保险）
/// - 版本号（ResourceVersions 表 Version）快速预检：一致 → 直接读本地缓存，零网络开销
/// - ETag（MinIO MD5 哈希）最终确认：下载时比对，一致 → 跳过写入
///
/// ## 防篡改
/// - 内容/版本/ETag 绑定在同一加密信封内：篡改任意字节 → GCM 认证失败 → 解密抛异常
/// - 解密失败视为缓存不可信 → 重新下载；无降级链路（本地缓存不可用则连接中断）
///
/// ## 降级策略
/// - 本地已有缓存 → 直接使用（秒连）
/// - 网络不可达/未登录 → 静默保留本地缓存，不阻塞连接
/// </summary>
public class OvpnConfigCacheService : IDisposable
{
    /// <summary>OpenVPN API URL 注册键（独立键，与其他 Remote* 服务模式一致）</summary>
    private const string OpenVpnApiUrlKey = "openvpn_api";

    private const string DefaultApiBaseUrl = "https://api.akeno6388.online:1010";

    /// <summary>配置信息 API 路径（返回版本号 + 存储键）</summary>
    private const string ConfigApiPath = "/api/openvpn";

    /// <summary>预签名下载 URL API 路径</summary>
    private const string DownloadApiPath = "/api/openvpn/download";

    /// <summary>缓存根目录（与 VpnConnectionService 配置目录一致）</summary>
    private static readonly string CacheDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "openvpn");

    /// <summary>加密缓存配置文件路径（方案A：内容+版本+ETag 合并加密单文件）</summary>
    private static readonly string CacheFilePath = Path.Combine(CacheDirectory, "ovpn_config" + SecureCacheService.EncryptedExtension);

    /// <summary>解密后的临时明文 .ovpn 路径（openvpn.exe 加载用）</summary>
    private static readonly string TempConfigFilePath = Path.Combine(SecureCacheService.TempDirectory, "ovpn_config.ovpn");

    private readonly IServerUrlService _serverUrlService;
    private readonly ILoginService _loginService;
    private readonly SecureCacheService _secureCache;
    private readonly HttpClient _httpClient;
    private bool _disposed;

    /// <summary>同步互斥门（SemaphoreSlim 排队串行：并发 SyncAsync 排队执行，绝不跳过）</summary>
    private readonly SemaphoreSlim _syncGate = new(1, 1);

    /// <summary>同步是否进行中（供 WaitForSyncIdleAsync 轮询查询，volatile 保证跨线程可见）</summary>
    private volatile bool _syncInProgress;

    /// <summary>
    /// 配置文件缓存刷新完成事件（服务端更新后触发，供 UI 提示配置已更新）
    /// </summary>
    public event Action? ConfigRefreshed;

    // 版本号 + ETag 元数据已内嵌于加密信封（方案A），不再使用独立 meta 文件

    public OvpnConfigCacheService(IServerUrlService serverUrlService, ILoginService loginService,
        SecureCacheService secureCache)
    {
        _serverUrlService = serverUrlService;
        _loginService = loginService;
        _secureCache = secureCache;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
        _httpClient.Timeout = TimeSpan.FromSeconds(15);

        // 登录成功后重新同步（启动时未登录，API 返回 401 静默跳过）
        loginService.LoginStateChanged += OnLoginStateChanged;
    }

    /// <summary>
    /// API 基础地址（openvpn_api 键，默认 https://api.akeno6388.online:1010）
    /// </summary>
    private string ApiBaseUrl =>
        _serverUrlService.GetDecryptedUrl(OpenVpnApiUrlKey) ?? DefaultApiBaseUrl;

    /// <summary>
    /// 登录成功时重新同步配置文件（服务端更新后自动下载新版）
    /// </summary>
    private void OnLoginStateChanged(bool isLoggedIn)
    {
        if (!isLoggedIn) return;
        System.Diagnostics.Debug.WriteLine("[OvpnConfigCacheService] 用户登录成功，重新同步 .ovpn 配置");
        _ = SyncAsync();
    }

    // ================================================================
    //  公开方法
    // ================================================================

    /// <summary>
    /// 获取可供 openvpn.exe 加载的 .ovpn 配置路径：
    /// 解密加密缓存到临时明文文件并返回其路径；
    /// 无缓存/解密失败（被篡改/损坏/旧明文格式）返回 null。
    /// </summary>
    public string? GetCachedConfigPath()
    {
        return _secureCache.DecryptToTempFile(CacheFilePath, "ovpn_config.ovpn");
    }

    /// <summary>
    /// 初始化：加载本地缓存（秒用），随后后台同步服务端最新版本。
    /// </summary>
    public async Task InitializeAsync()
    {
        System.Diagnostics.Debug.WriteLine("[OvpnConfigCacheService] === InitializeAsync ===");
        try
        {
            if (File.Exists(CacheFilePath))
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[OvpnConfigCacheService] 本地缓存已存在: {CacheFilePath}");
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("[OvpnConfigCacheService] 无本地缓存，等待登录后下载");
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[OvpnConfigCacheService] 初始化失败: {ex.Message}");
        }

        // 已登录 → 立即同步；未登录 → 由 LoginStateChanged 触发
        if (_loginService.IsLoggedIn)
        {
            await SyncAsync();
        }
    }

    /// <summary>
    /// 同步服务端最新 .ovpn 配置（串行化：并发调用排队执行，绝不跳过）。
    ///
    /// 比对流程（双保险，与项目其他远程缓存服务一致）：
    ///   ① GET /api/openvpn 获取版本号 → 与本地 meta 比对
    ///      - 版本一致且本地有缓存 → 直接使用本地缓存（零网络开销）
    ///   ② 版本不一致 → GET /api/openvpn/download 获取预签名 URL → 下载
    ///   ③ 下载后 ETag 比对 → 一致跳过写入；不一致原子覆盖缓存 + 更新 meta
    ///
    /// 返回 true = 同步完成后本地缓存可用（下载成功 / 版本一致 / 服务端无配置但保留旧缓存）；
    /// 返回 false = 本地缓存不可用（未登录 / 网络失败 / 下载失败）。
    /// </summary>
    public async Task<bool> SyncAsync()
    {
        // 排队串行（修复：原"if (_syncInProgress) return;"在并发下会跳过执行，
        // 导致 ClearCache 后同步被跳过、缓存被删但未重新下载）
        await _syncGate.WaitAsync();
        _syncInProgress = true;
        try
        {
            // 1. 确保 AccessToken 有效
            bool tokenValid = await _loginService.EnsureValidAccessTokenAsync();
            var accessToken = _loginService.AccessToken;
            if (!tokenValid || string.IsNullOrEmpty(accessToken))
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[OvpnConfigCacheService] 跳过同步: " +
                    (_loginService.IsLoggedIn ? "AccessToken 刷新失败" : "用户未登录"));
                return false;
            }

            // 2. 获取配置信息（版本号 + 存储键）
            var info = await FetchConfigInfoAsync(accessToken);
            if (info == null)
            {
                // 服务端无配置（404）→ 保留本地缓存（降级），不清除
                System.Diagnostics.Debug.WriteLine("[OvpnConfigCacheService] 服务端无 .ovpn 配置，保留本地缓存");
                return File.Exists(CacheFilePath);
            }

            // 3. 快速版本比对：本地加密信封版本号一致 → 直接使用本地缓存
            if (_secureCache.TryReadEnvelope(CacheFilePath, out _, out _, out var localVersion) &&
                localVersion == info.Version)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[OvpnConfigCacheService] 版本一致 (v{info.Version})，直接使用本地缓存");
                return true;
            }

            // 4. 版本不一致 → 获取预签名下载 URL
            var downloadUrl = await FetchDownloadUrlAsync(accessToken);
            if (downloadUrl == null)
            {
                // 服务端无配置（404）→ 保留本地缓存（降级），不清除
                System.Diagnostics.Debug.WriteLine("[OvpnConfigCacheService] 获取下载 URL 失败，保留本地缓存");
                return File.Exists(CacheFilePath);
            }

            // 5. 下载 + ETag 比对（有变更才写入缓存）
            bool changed = await DownloadAndCacheAsync(downloadUrl, info.Version);
            if (changed)
            {
                System.Diagnostics.Debug.WriteLine("[OvpnConfigCacheService] .ovpn 配置已更新");
                ConfigRefreshed?.Invoke();
            }

            // 返回缓存可用性（下载失败 / ClearCache 后未下载成功 → false）
            return File.Exists(CacheFilePath);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[OvpnConfigCacheService] 同步失败: {ex.Message}");
            return false;
        }
        finally
        {
            _syncInProgress = false;
            _syncGate.Release();
        }
    }

    /// <summary>
    /// 强制重新同步（忽略版本号与 ETag，覆盖下载）
    /// </summary>
    public async Task ForceSyncAsync()
    {
        // 删除加密缓存强制跳过版本/ETag 检查，重新下载
        if (File.Exists(CacheFilePath))
        {
            try { File.Delete(CacheFilePath); } catch { }
        }
        await SyncAsync();
    }

    /// <summary>
    /// 确保 .ovpn 配置可用（方案初始化场景调用）：
    /// 同步完成后返回本地缓存路径（null = 无法获取）。
    ///
    /// SyncAsync 已改为排队串行（不会因互斥跳过），并发调用自动排队执行，
    /// 方案加载（含硬重载）保证配置真正可用后才继续。
    /// </summary>
    public async Task<string?> EnsureConfigReadyAsync()
    {
        await SyncAsync();
        return GetCachedConfigPath();
    }

    /// <summary>
    /// 硬重载专用：等待任何进行中的同步完成后，完全清除本地缓存并强制重新下载。
    ///
    /// 目的：① 等待可避免 ClearCache 与后台下载写入竞态；② 清缓存后 SyncAsync
    /// 排队执行（绝不跳过）→ 版本比对必然不一致 → 保证 .ovpn 一定重新从服务器拉取。
    /// 返回 false = 等待超时（放弃清理，避免缓存丢失）或重新下载失败（缓存不可用）。
    /// </summary>
    public async Task<bool> ClearCacheAndResyncAsync()
    {
        // 等待进行中的同步完成（避免 ClearCache 与下载写入竞态、后续 SyncAsync 被互斥跳过）
        if (!await WaitForSyncIdleAsync(TimeSpan.FromSeconds(60)))
        {
            System.Diagnostics.Debug.WriteLine(
                "[OvpnConfigCacheService] 等待同步完成超时，放弃清理缓存（避免缓存丢失）");
            return false;
        }

        ClearCache();

        // SyncAsync 排队执行：清缓存后版本比对必然不一致 → 强制全新下载。
        // 返回 false = 下载失败（缓存不可用），调用方报错提示。
        return await SyncAsync();
    }

    /// <summary>
    /// 初始化实例专用：等待任何进行中的同步完成后，完全清除本地缓存，但【不】立即重新下载。
    ///
    /// 语义：初始化实例 = 强制全新开始——仅删除本地 .ovpn 配置与版本文件；
    /// 下次用户点击"开始部署"时，方案初始化走 EnsureConfigReadyAsync → SyncAsync，
    /// 缓存不存在 → 版本比对必然不一致 → 自动从服务器全新下载。
    /// 返回 false = 等待进行中同步超时（放弃同步清除，避免与后台下载写入竞态）；
    /// 但会转为后台等待清理（尽力而为），同步结束后缓存仍会被清除。
    /// </summary>
    public async Task<bool> ClearCacheOnlyAsync()
    {
        if (!await WaitForSyncIdleAsync(TimeSpan.FromSeconds(60)))
        {
            System.Diagnostics.Debug.WriteLine(
                "[OvpnConfigCacheService] 等待同步完成超时，转为后台等待清理（尽力而为）");

            // 超时不阻塞调用方：后台继续等待同步结束再清除缓存，
            // 确保下次部署时 .ovpn 仍会重新下载（而非复用旧配置）。
            _ = Task.Run(async () =>
            {
                if (await WaitForSyncIdleAsync(TimeSpan.FromSeconds(60)))
                    ClearCache();
            });
            return false;
        }

        ClearCache();
        return true;
    }

    /// <summary>
    /// 等待互斥锁（_syncInProgress）释放。
    /// 返回 true = 已释放可安全同步；false = 等待超时（同步仍在进行）。
    /// </summary>
    private async Task<bool> WaitForSyncIdleAsync(TimeSpan maxWait)
    {
        var deadline = DateTime.UtcNow + maxWait;
        while (_syncInProgress && DateTime.UtcNow < deadline)
        {
            await Task.Delay(100);
        }
        return !_syncInProgress;
    }

    /// <summary>
    /// 完全清除本地缓存（加密 .ovpn 文件 + 解密临时明文 + 目录内残留临时文件）。
    /// 用于方案硬重载：清除后下一次 SyncAsync 因缓存不存在会强制重新下载
    /// （跳过版本比对，保证 .ovpn 一定从服务器重新拉取）。
    /// </summary>
    public void ClearCache()
    {
        try { if (File.Exists(CacheFilePath)) File.Delete(CacheFilePath); } catch { }

        // 清理解密后的临时明文 .ovpn（防止残留旧配置被误用）
        try { if (File.Exists(TempConfigFilePath)) File.Delete(TempConfigFilePath); } catch { }

        // 清理目录内残留的临时文件（历史 auth / 下载中断的 tmp），保留目录本身
        try
        {
            if (Directory.Exists(CacheDirectory))
            {
                foreach (var file in Directory.GetFiles(CacheDirectory))
                {
                    var name = Path.GetFileName(file);
                    if (name.EndsWith(".auth", StringComparison.OrdinalIgnoreCase) ||
                        name.EndsWith(".tmp", StringComparison.OrdinalIgnoreCase))
                    {
                        try { File.Delete(file); } catch { }
                    }
                }
            }
        }
        catch { /* 清理失败不影响硬重载主流程 */ }
    }

    /// <summary>
    /// 确保 OpenVPN API URL 注册键存在。如果尚未注册，使用生产环境地址创建一条记录。
    /// </summary>
    public void EnsureOpenVpnApiUrlRecord()
    {
        try
        {
            var existing = _serverUrlService.GetByKey(OpenVpnApiUrlKey);
            if (existing != null) return;

            _serverUrlService.Register(
                key: OpenVpnApiUrlKey,
                displayName: "OpenVPN 配置 API 服务地址",
                plainUrl: DefaultApiBaseUrl,
                category: "Infrastructure");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[OvpnConfigCacheService] 注册 OpenVPN API URL 失败: {ex.Message}");
        }
    }

    // ================================================================
    //  内部实现
    // ================================================================

    /// <summary>
    /// 获取配置信息（版本号 + 存储键）。
    /// GET /api/openvpn → { "success": true, "data": { "version": 3, "configKey": "openvpn/config.ovpn" } }
    /// </summary>
    private async Task<OpenVpnInfoResponse?> FetchConfigInfoAsync(string accessToken)
    {
        using var request = new HttpRequestMessage(
            HttpMethod.Get, $"{ApiBaseUrl}{ConfigApiPath}");
        request.Headers.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

        using var response = await _httpClient.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[OvpnConfigCacheService] 获取配置信息失败: HTTP {(int)response.StatusCode}");
            return null;
        }

        var json = await response.Content.ReadAsStringAsync();
        var apiResponse = JsonSerializer.Deserialize<ApiResponse<OpenVpnInfoResponse>>(json);
        if (apiResponse?.Success != true || apiResponse.Data == null)
        {
            System.Diagnostics.Debug.WriteLine("[OvpnConfigCacheService] 响应中无配置信息");
            return null;
        }

        return apiResponse.Data;
    }

    /// <summary>
    /// 获取配置文件预签名下载 URL。
    /// GET /api/openvpn/download → { "success": true, "data": { "downloadUrl": "..." } }
    /// </summary>
    private async Task<string?> FetchDownloadUrlAsync(string accessToken)
    {
        using var request = new HttpRequestMessage(
            HttpMethod.Get, $"{ApiBaseUrl}{DownloadApiPath}");
        request.Headers.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

        using var response = await _httpClient.SendAsync(request);

        if (!response.IsSuccessStatusCode)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[OvpnConfigCacheService] 获取下载 URL 失败: HTTP {(int)response.StatusCode}");
            return null;
        }

        var json = await response.Content.ReadAsStringAsync();
        var apiResponse = JsonSerializer.Deserialize<ApiResponse<OpenVpnDownloadResponse>>(json);
        if (apiResponse?.Success != true || apiResponse.Data?.DownloadUrl == null)
        {
            System.Diagnostics.Debug.WriteLine("[OvpnConfigCacheService] 响应中无 downloadUrl");
            return null;
        }

        return apiResponse.Data.DownloadUrl;
    }

    /// <summary>
    /// 下载 .ovpn 文件并加密缓存（方案A：内容 + 版本号 + ETag 合并加密单文件），
    /// 与 SchemeIconCacheService / RemoteQuickStartService 一致的范式。
    /// ETag 一致 → 跳过写入；不一致 → 加密覆盖缓存 + 解密到临时明文供 openvpn.exe 加载。
    /// </summary>
    /// <param name="downloadUrl">预签名下载 URL（GET /api/openvpn/download 返回）</param>
    /// <param name="serverVersion">服务端当前版本号（GET /api/openvpn 返回）</param>
    /// <returns>true = 缓存已更新；false = 无变更或下载失败</returns>
    private async Task<bool> DownloadAndCacheAsync(string downloadUrl, int serverVersion)
    {
        try
        {
            using var response = await _httpClient.GetAsync(downloadUrl,
                HttpCompletionOption.ResponseContentRead);

            if (!response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[OvpnConfigCacheService] 下载 HTTP {(int)response.StatusCode}");
                return false;
            }

            // 提取 ETag
            string? serverEtag = null;
            if (response.Headers.ETag is { } etagHeader && etagHeader.Tag is { } tagValue)
            {
                serverEtag = tagValue.Trim('"');
            }

            // ETag 比对（一致则跳过写入，防御性检查）
            if (serverEtag != null &&
                _secureCache.TryReadEnvelope(CacheFilePath, out _, out var localEtag, out _) &&
                localEtag == serverEtag)
            {
                System.Diagnostics.Debug.WriteLine("[OvpnConfigCacheService] ETag 一致，跳过下载");
                return false;
            }

            var configBytes = await response.Content.ReadAsByteArrayAsync();

            // 加密写入（方案A：内容 + 版本 + ETag 合并加密单文件，原子写入）
            _secureCache.SaveEnvelope(CacheFilePath, configBytes, serverEtag, serverVersion);

            // 解密到临时明文文件供 openvpn.exe 加载
            _secureCache.DecryptToTempFile(CacheFilePath, "ovpn_config.ovpn");

            System.Diagnostics.Debug.WriteLine(
                $"[OvpnConfigCacheService] 已加密缓存 v{serverVersion} ({configBytes.Length:N0} bytes)");
            return true;
        }
        catch (TaskCanceledException)
        {
            CleanupTempFile();
            System.Diagnostics.Debug.WriteLine("[OvpnConfigCacheService] 下载超时");
            return false;
        }
        catch (HttpRequestException ex)
        {
            CleanupTempFile();
            System.Diagnostics.Debug.WriteLine($"[OvpnConfigCacheService] 下载网络错误: {ex.Message}");
            return false;
        }
    }

    /// <summary>
    /// 清理残留的临时下载文件（确保缓存目录内只有唯一加密 .ovpn 文件）
    /// </summary>
    private static void CleanupTempFile()
    {
        try
        {
            var tmpPath = CacheFilePath + ".tmp";
            if (File.Exists(tmpPath))
                File.Delete(tmpPath);
        }
        catch { /* 清理失败不影响主流程 */ }
    }

    // ================================================================
    //  IDisposable
    // ================================================================

    /// <summary>
    /// 释放服务（应用退出时由 Hosting 容器调用）。
    /// 释放 HttpClient 连接池，确保进程可完全退出。
    /// </summary>
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _httpClient.Dispose();
        GC.SuppressFinalize(this);
    }
}
