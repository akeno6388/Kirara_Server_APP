using Kirara_Server_WinUI.Views.Comment;
using Microsoft.UI.Xaml;
using Windows.Graphics;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 评论面板管理服务实现 — 管理评论窗口的创建、定位和生命周期
/// 评论窗口重叠在主窗口底部内侧，类似 VS 输出面板，随主窗口移动/缩放自动跟随
/// </summary>
public class CommentPanelService : ICommentPanelService
{
    /// <summary>评论窗口实例</summary>
    private CommentWindow? _commentWindow;

    /// <summary>当前资源键</summary>
    private string _currentResourceKey = string.Empty;

    /// <summary>当前方案 ID</summary>
    private Guid _currentSchemeId;

    /// <summary>当前资源标题</summary>
    private string? _currentResourceTitle;

    /// <summary>评论窗口默认高度</summary>
    private const int DefaultHeight = 300;

    /// <summary>评论窗口最小高度</summary>
    private const int MinHeight = 150;

    /// <inheritdoc />
    public bool IsPanelOpen => _commentWindow != null;

    /// <inheritdoc />
    public event Action<bool>? PanelVisibilityChanged;

    /// <inheritdoc />
    public void OpenPanel(string resourceKey, Guid schemeId, string? resourceTitle = null)
    {
        _currentResourceKey = resourceKey;
        _currentSchemeId = schemeId;
        _currentResourceTitle = resourceTitle;

        if (_commentWindow == null)
        {
            // 首次打开：创建评论窗口
            _commentWindow = new CommentWindow();
            _commentWindow.Closed += OnCommentWindowClosed;

            // 订阅主窗口事件以跟随位置
            SubscribeMainWindowEvents();

            // 定位到主窗口底部内侧
            RepositionCommentWindow();

            _commentWindow.Activate();
            PanelVisibilityChanged?.Invoke(true);

            // [修复] 延迟重定位：确保主窗口布局完成后正确计算位置
            _ = RepositionAfterDelayAsync();
        }
        else
        {
            // 窗口已存在，激活并刷新
            _commentWindow.BringToFront();
        }

        // 通知 ViewModel 加载评论
        _commentWindow?.LoadComments(resourceKey, schemeId, resourceTitle);
    }

    /// <inheritdoc />
    public void ClosePanel()
    {
        if (_commentWindow != null)
        {
            _commentWindow.Close();
            // Closed 事件会触发清理
        }
    }

    /// <inheritdoc />
    public void RepositionPanel() => RepositionCommentWindow();

    /// <inheritdoc />
    public void UpdateResourceContext(string resourceKey, Guid schemeId, string? resourceTitle = null)
    {
        // 如果资源键未变化，忽略
        if (_currentResourceKey == resourceKey && _currentSchemeId == schemeId)
            return;

        _currentResourceKey = resourceKey;
        _currentSchemeId = schemeId;
        _currentResourceTitle = resourceTitle;

        // 如果面板已打开，刷新评论列表
        if (_commentWindow != null)
        {
            _commentWindow.LoadComments(resourceKey, schemeId, resourceTitle);
        }
    }

    /// <summary>
    /// 评论窗口关闭时清理引用
    /// </summary>
    private void OnCommentWindowClosed(object sender, WindowEventArgs args)
    {
        if (_commentWindow != null)
        {
            _commentWindow.Closed -= OnCommentWindowClosed;
            _commentWindow = null;
        }

        UnsubscribeMainWindowEvents();
        PanelVisibilityChanged?.Invoke(false);
    }

    // ================================================================
    //  主窗口跟随逻辑
    // ================================================================

    /// <summary>
    /// 订阅主窗口尺寸/位置变化事件
    /// </summary>
    private void SubscribeMainWindowEvents()
    {
        var mainWindow = MainWindow.Current;
        if (mainWindow != null)
        {
            mainWindow.AppWindow.Changed += OnMainWindowChanged;
            // [评论区功能] 主窗口关闭（应用退出）时同步关闭评论窗口
            mainWindow.Closed += OnMainWindowClosed;
        }
    }

    /// <summary>
    /// 取消订阅主窗口事件
    /// </summary>
    private void UnsubscribeMainWindowEvents()
    {
        var mainWindow = MainWindow.Current;
        if (mainWindow != null)
        {
            mainWindow.AppWindow.Changed -= OnMainWindowChanged;
            mainWindow.Closed -= OnMainWindowClosed;
        }
    }

    /// <summary>
    /// [评论区功能] 主窗口关闭（应用退出）时，同步关闭评论窗口，避免残留
    /// </summary>
    private void OnMainWindowClosed(object sender, WindowEventArgs args)
    {
        if (_commentWindow != null)
        {
            // 先解除 Closed 订阅避免重入，再关闭并清理引用
            _commentWindow.Closed -= OnCommentWindowClosed;
            _commentWindow.Close();
            _commentWindow = null;
        }

        UnsubscribeMainWindowEvents();
    }

    /// <summary>
    /// 主窗口尺寸或位置变化时，重新定位评论窗口
    /// </summary>
    private void OnMainWindowChanged(Microsoft.UI.Windowing.AppWindow sender,
        Microsoft.UI.Windowing.AppWindowChangedEventArgs args)
    {
        if (args.DidSizeChange || args.DidPositionChange)
        {
            RepositionCommentWindow();
        }
    }

    /// <summary>
    /// 延迟 200ms 后重新定位评论窗口（解决启动时主窗口布局未完成的时序问题）
    /// </summary>
    private async Task RepositionAfterDelayAsync()
    {
        await Task.Delay(200);
        if (_commentWindow != null)
        {
            RepositionCommentWindow();
        }
    }

    /// <summary>
    /// 将评论窗口定位到主窗口：
    /// 折叠状态 → 主窗口右下角 40×40 悬浮展开按钮（样式保持现状）；
    /// 气泡状态 → 主窗口下方悬浮（左右/底部各留 24px，高度为折叠前高度）；
    /// 全展开状态 → 悬浮面板（全宽、底对齐、顶边留 24px）
    /// </summary>
    private void RepositionCommentWindow()
    {
        if (_commentWindow == null) return;

        var mainWindow = MainWindow.Current;
        if (mainWindow == null) return;

        var mainPos = mainWindow.AppWindow.Position;
        var mainSize = mainWindow.AppWindow.Size;

        switch (_commentWindow.State)
        {
            case CommentPanelState.Collapsed:
                // [评论区功能] 折叠：主窗口右下角 40×40 悬浮按钮（留出边距）
                const int btnSize = 40;
                const int btnMargin = 12;
                var x = mainPos.X + mainSize.Width - btnSize - btnMargin;
                var y = mainPos.Y + mainSize.Height - btnSize - btnMargin;
                _commentWindow.AppWindow.MoveAndResize(new RectInt32(x, y, btnSize, btnSize));
                break;

            case CommentPanelState.Expanded:
                // [评论区功能] 气泡：主窗口下方悬浮，左右/底部各留 24px，高度 = 拖拽记忆高度
                const int bubbleMargin = 24;
                var bubbleHeight = _commentWindow.GetCurrentHeight();
                var bubbleY = mainPos.Y + mainSize.Height - bubbleMargin - bubbleHeight;
                _commentWindow.AppWindow.MoveAndResize(
                    new RectInt32(mainPos.X + bubbleMargin, bubbleY,
                                  mainSize.Width - bubbleMargin * 2, bubbleHeight));
                break;

            case CommentPanelState.FullExpanded:
                // [评论区功能] 全展开：悬浮面板，全宽、底对齐、顶边留 24px
                const int topGap = 24;
                var fullHeight = mainSize.Height - topGap;
                _commentWindow.AppWindow.MoveAndResize(
                    new RectInt32(mainPos.X, mainPos.Y + topGap, mainSize.Width, fullHeight));
                break;
        }
    }
}
