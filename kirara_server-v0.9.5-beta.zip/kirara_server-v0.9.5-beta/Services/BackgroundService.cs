using System.Net.Http;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;
using Microsoft.Extensions.DependencyInjection;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 首页背景图片管理服务实现（生产环境适配版 v2）
///
/// ## 核心改进（v2 — 生产环境适配）
/// - ✅ 本地版本校验：持久化ETag到版本文件，跨会话追踪服务端变更状态
/// - ✅ 同步服务端资源：后台异步调用API端点，跟随302重定向到MinIO下载大图
/// - ✅ 缓存急速加载：优先从本地缓存文件读取，避免每次启动等待网络请求完成
/// - ✅ 同步冷却机制：30分钟内不重复同步，减少大资源频繁请求对网络和磁盘的压力
/// - ✅ 默认背景兜底：服务端资源就绪前继续显示内置默认图片，不阻塞UI渲染流程
/// - ✅ 渐变过渡触发：通过 BackgroundChanged 事件通知 ShellPage，由 UI 层执行交叉淡入淡出动画
///
/// ## 资源获取流程（Init/Sync均遵循此链）
/// ```
/// InitializeAsync():
///   ├── LoadLocalVersion()          ← 从版本文件读取持久化ETag
///   ├── GetCachedPath()             ← 检查本地缓存文件是否存在
///   │     ├── ✅有缓存 → CurrentBackgroundPath = CacheFilePath（极速加载）
///   │     │               IsDefaultBackground = false（标记为服务端资源）
///   │     └── ❌无缓存 → CurrentBackgroundPath = DefaultBackgroundAsset（内置默认）
///   │                       IsDefaultBackground = true（标记为降级状态）
///   └── SyncFromServerAsync()       ← 🔄后台异步同步（不阻塞UI线程）
///
/// SyncFromServerAsync():
///   ├── ⏱冷却检查：LastSyncedAt < 30min? → Skip（避免频繁请求）
///   ├── 🌐 GetBackgroundServerUrl() ← ServerUrlService.GetDecryptedUrl("home_background")
///   ├── 📡 HttpClient.GetAsync(url) ← GET /api/resources/home-background（自动跟随302重定向）
///   │     ├── ✅200 OK → extract ETag from response headers + download image bytes
///   │     │     ├── ETag == LocalVersion? → Skip update（服务端无变更）
///   │     │     └── ETag != LocalVersion? → SaveCache + SaveVersion + FireEvent🎯
///   │     ├── ❌404 Not Found → Log + return（服务器未配置背景图片）
///   │     └── ❌Exception（网络超时/连接失败）→ Log + return（保持当前背景不变）
///   └── ✅ Update LastSyncedAt = DateTime.UtcNow（记录同步时间戳）
///
/// RefreshAsync():
///   └── Force SyncFromServerAsync() ← ⚡强制同步，忽略冷却期检查
/// ```
///
/// ## API通信细节（基于 Kirara Server API v1.2）
/// - Endpoint: GET /api/resources/home-background（无需认证）
/// - Response: HTTP 302 Found → Location头指向MinIO预签名URL（1小时有效）
/// - HttpClient行为：默认AllowAutoRedirect=true，自动跟随重定向到MinIO下载图片字节流
/// - Version标识：从MinIO响应的ETag头提取（MinIO对象存储原生支持ETag=MD5哈希）
/// - Error处理：404表示服务器未配置背景图片，客户端保持当前背景不变继续使用缓存或默认图
/// </summary>
public class BackgroundService : IBackgroundService, IDisposable
{
    /// <summary>ServerUrlService 中背景图片源的注册 Key</summary>
    private const string BackgroundUrlKey = "home_background";

    /// <summary>加密缓存文件名（方案A：内容 + ETag 合并加密单文件）</summary>
    private const string CacheFileName = "background_cache.enc";

    /// <summary>解密后的临时明文文件名（UI 加载用）</summary>
    private const string TempFileName = "background_cache.jpg";

    /// <summary>旧明文格式缓存文件名（升级遗留，启动时清理）</summary>
    private const string LegacyCacheFileName = "background_cache.jpg";

    /// <summary>旧版本 txt 文件名（升级遗留，启动时清理）</summary>
    private const string LegacyVersionFileName = "background_version.txt";

    /// <summary>内置默认背景图片相对路径（Assets 目录下，经 AssetPathHelper 解析为可加载路径）</summary>
    private const string DefaultBackgroundAsset = "Assets/background_default.jpg";

        private readonly IServerUrlService _serverUrlService;
    private readonly ICryptoService _cryptoService;
    private readonly SecureCacheService _secureCache;
    private readonly HttpClient _httpClient;

    private string? _currentBackgroundPath;
    private bool _initialized;
    private bool _disposed;

    // ── v2新增状态字段 ──

    /// <summary>本地缓存的ETag版本标识</summary>
    private string? _localVersion;

    /// <summary>服务端最新ETag版本标识</summary>
    private string? _serverVersion;

    /// <summary>上次成功同步时间（UTC），用于冷却期判断</summary>
    private DateTime? _lastSyncedAt;

    /// <summary>当前是否正在使用内置默认背景</summary>
    private bool _isDefaultBackground = true;

    private static readonly string CacheDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "backgrounds");

    private string CacheFilePath => Path.Combine(CacheDirectory, CacheFileName);

    /// <summary>解密后临时明文文件路径（UI 加载）</summary>
    private string TempFilePath => Path.Combine(SecureCacheService.TempDirectory, TempFileName);

    public BackgroundService(
        IServerUrlService serverUrlService,
        ICryptoService cryptoService,
        SecureCacheService secureCache)
    {
        _serverUrlService = serverUrlService;
        _cryptoService = cryptoService;
        _secureCache = secureCache;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
        _httpClient.Timeout = TimeSpan.FromSeconds(30); // v2: 大图超时放宽到30s

        System.Diagnostics.Debug.WriteLine(
            $"[BackgroundService] HttpClient初始化完成，" +
            $"Timeout={_httpClient.Timeout.TotalSeconds}s，" +
            $"AllowAutoRedirect=true，" +
            $"UserAgent=Kirara_Server/1.0");

        // 订阅登录状态变更：仅登录成功后触发一次背景版本检测
        try
        {
            var loginService = App.Services.GetRequiredService<ILoginService>();
            loginService.LoginStateChanged += OnLoginStateChanged;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[BackgroundService] 订阅登录事件失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 登录状态变更回调 — 仅登录成功后触发一次背景版本检测与更新。
    /// 登出时不做任何处理（保持当前背景不变）。
    /// </summary>
    private void OnLoginStateChanged(bool isLoggedIn)
    {
        if (!isLoggedIn) return;

        System.Diagnostics.Debug.WriteLine(
            "[BackgroundService] 用户登录成功，触发背景版本检测");
        _ = SyncFromServerInternalAsync(forceSync: true);
    }

    // ================================================================
    //  IBackgroundService Properties
    // ================================================================

    /// <inheritdoc />
    public string? CurrentBackgroundPath => _currentBackgroundPath;

    /// <inheritdoc />
    public bool IsLoading => false;

    /// <inheritdoc />
    public bool IsDefaultBackground => _isDefaultBackground;

    /// <inheritdoc />
    public string? LocalVersion => _localVersion;

    /// <inheritdoc />
    public string? ServerVersion => _serverVersion;

    /// <inheritdoc />
    public DateTime? LastSyncedAt => _lastSyncedAt;

    /// <inheritdoc />
    public event Action<string?>? BackgroundChanged;

    // ================================================================
    //  内部属性设置器 — 仅在值变化时触发事件
    // ================================================================

    private string? CurrentBackgroundPathInternal
    {
        set
        {
            if (_currentBackgroundPath != value)
            {
                _currentBackgroundPath = value;
                BackgroundChanged?.Invoke(value);
            }
        }
    }

    /// <summary>
    /// 强制触发背景变更事件 — 用于缓存文件路径不变但内容已更新的场景。
    /// 例如：登录后下载新图覆盖同一缓存文件，路径不变但需要通知 UI 刷新。
    /// </summary>
    private void ForceNotifyBackgroundChanged()
    {
        BackgroundChanged?.Invoke(_currentBackgroundPath);
    }

    // ================================================================
    //  IBackgroundService Public Methods
    // ================================================================

    /// <inheritdoc />
    public Task InitializeAsync()
    {
        if (_initialized) return Task.CompletedTask;
        _initialized = true;

        System.Diagnostics.Debug.WriteLine("[BackgroundService] === InitializeAsync ===");

        try
        {
            EnsureCacheDirectory();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[BackgroundService] 创建缓存目录失败: {ex.Message}");
            // 降级到内置默认背景（Unpackaged 模式下解析为文件路径，Packaged 下为 ms-appx URI）
            CurrentBackgroundPathInternal = AssetPathHelper.Resolve(DefaultBackgroundAsset);
            return Task.CompletedTask;
        }

        // Step0: 清理旧明文格式缓存（升级遗留：旧 jpg + 旧 txt 版本文件）
        CleanupLegacyCacheFiles();

        // Step1: 加载本地版本信息（从加密信封恢复 ETag，格式与 meta 统一）
        LoadLocalVersion();
        System.Diagnostics.Debug.WriteLine(
            $"[BackgroundService] 本地版本: {_localVersion ?? "(无)"}");

        // Step2: 解密缓存到临时明文文件 — 极速加载路径，不等待网络请求完成即显示背景图
        var tmpPath = DecryptBackgroundToTemp();
        if (tmpPath != null)
        {
            System.Diagnostics.Debug.WriteLine(
                "[BackgroundService] ✅使用本地加密缓存背景图片（极速加载）");
            CurrentBackgroundPathInternal = tmpPath;
            _isDefaultBackground = false;
        }
        else
        {
            System.Diagnostics.Debug.WriteLine(
                "[BackgroundService] ⚠️无本地缓存，使用内置默认背景");
            // 全新安装/无缓存时使用内置默认背景（Unpackaged 模式下 ms-appx 协议不可用，
            // 必须解析为应用输出目录中的文件路径，见 Helpers/AssetPathHelper.cs）
            CurrentBackgroundPathInternal = AssetPathHelper.Resolve(DefaultBackgroundAsset);
            _isDefaultBackground = true;
        }

        // Step3: 初始化完成，不触发服务器同步。
        //         背景版本检测仅在用户登录成功后触发（见 OnLoginStateChanged）。
        //         这样设计确保：
        //         - 未登录用户不产生任何网络请求
        //         - 每次登录都确保获取最新背景
        //         - 运行期间不轮询，零后台开销

        return Task.CompletedTask;
    }

    /// <inheritdoc />
    public async Task RefreshAsync()
    {
        System.Diagnostics.Debug.WriteLine("[BackgroundService] === RefreshAsync (手动触发) ===");
        await SyncFromServerInternalAsync(forceSync: true);
    }

    // ================================================================
    //  核心同步逻辑
    // ================================================================

    /// <summary>
    /// 🔄后台同步服务器资源的核心方法。
    ///
    /// ##执行流程：
    /// ```
    /// Step1: ⏱冷却检查（forceSync=true时跳过）
    /// Step2: 🌐解析服务器URL（从ServerUrlService注册表获取API端点地址）
    /// Step3: 📡发送HTTP GET请求到API端点（自动跟随302重定向到MinIO预签名URL）
    /// Step4: 🏷提取响应ETag与本地版本比对：
    ///         ├── ETag相同→服务端无变更，跳过更新节省带宽和磁盘I/O开销；
    ///         └── ETag不同→保存新图片到缓存、更新版本文件、触发渐变过渡事件；
    /// Step5: ✅记录最后同步时间戳用于冷却期判断；
    /// ```
    ///
    /// ##异常安全：
    /// - 所有异常被catch并记录Debug.WriteLine日志；
    /// - CurrentBackgroundPath保持之前的值不变；
    /// - LastSyncedAt在失败时不更新，下次启动会重试同步；
    /// </summary>
    private async Task SyncFromServerInternalAsync(bool forceSync = false)
    {
        if (_disposed) return;

        try
        {
            #region Step1: Resolve Server URL

            var serverUrl = GetBackgroundServerUrl();
            if (string.IsNullOrEmpty(serverUrl))
            {
                System.Diagnostics.Debug.WriteLine(
                    "[BackgroundService] ⚠️未配置服务器背景URL，" +
                    "跳过服务器同步");
                return;
            }

            System.Diagnostics.Debug.WriteLine(
                $"[BackgroundService] 🌐开始同步服务器背景资源...");

            #endregion

            #region Step3+4: Download with ETag Comparison

            var result = await DownloadWithEtagTrackingAsync(serverUrl);

            if (!result.success)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[BackgroundService] ❌服务器同步失败，" +
                    $"保持当前背景不变");
                return;
            }

            if (!result.hasChanged)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[BackgroundService] ✅服务器背景无变更，" +
                    $"跳过更新");
                _lastSyncedAt = DateTime.UtcNow;
                return;
            }

            #endregion

            #region Step5: Apply Update

            System.Diagnostics.Debug.WriteLine(
                $"[BackgroundService] 🎯服务器背景已更新，" +
                $"新ETag={result.etag ?? "(无)"}，" +
                $"触发渐变过渡事件");

            _serverVersion = result.etag;
            _localVersion = result.etag;
            _lastSyncedAt = DateTime.UtcNow;
            _isDefaultBackground = false;

            // 设置路径为解密后的临时明文文件（如果路径与当前相同，属性设置器会跳过事件）
            bool pathWasSame = _currentBackgroundPath == TempFilePath;
            CurrentBackgroundPathInternal = TempFilePath;

            // 临时明文文件路径不变但内容已更新时，属性设置器的相等性检查会跳过事件，
            // 需要强制触发通知 UI 刷新
            if (pathWasSame)
                ForceNotifyBackgroundChanged();

            #endregion

            System.Diagnostics.Debug.WriteLine(
                "[BackgroundService] === SyncFromServerInternalAsync完成 ===");
        }
        catch (ObjectDisposedException)
        {
            System.Diagnostics.Debug.WriteLine(
                "[BackgroundService] ⚠️服务已释放，取消同步");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[BackgroundService] ❌同步异常: {ex.GetType().Name}: {ex.Message}");
            if (!string.IsNullOrEmpty(ex.StackTrace))
                System.Diagnostics.Debug.WriteLine(
                    $"[BackgroundService] StackTrace: {ex.StackTrace}");
        }
    }

    // ================================================================
    //  HTTP Download with ETag Tracking
    // ================================================================

    /// <summary>
    /// 📡下载服务器背景图片并追踪ETag版本标识。
    ///
    /// ##通信细节：
    /// - API端点返回302 Found → Location头指向MinIO预签名URL（1小时有效）
    /// - HttpClient自动跟随重定向到MinIO下载图片字节流
    /// - MinIO返回200 OK + ETag头 + 图片字节流
    /// - ETag格式：MinIO对象存储返回的MD5哈希值，如 "d41d8cd98f00b204e9800998ecf8427e"
    /// - ETag变更意味着服务端管理员上传了新背景图片
    ///
    /// ##返回结果：
    /// - success=false：下载失败（网络错误/超时/非200响应）
    /// - success=true, hasChanged=false：服务端无变更（ETag与本地一致）
    /// - success=true, hasChanged=true, etag=xxx：新图片已下载并缓存到本地
    /// </summary>
    private async Task<(bool success, bool hasChanged, string? etag)> DownloadWithEtagTrackingAsync(string url)
    {
        try
        {
            using var response = await _httpClient.GetAsync(url, HttpCompletionOption.ResponseContentRead);

            if (!response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[BackgroundService] HTTP {(int)response.StatusCode} {response.ReasonPhrase}");
                return (false, false, null);
            }

            // 🏷提取ETag版本标识
            string? serverEtag = null;
            if (response.Headers.ETag is { } etagHeader && etagHeader.Tag is { } tagValue)
            {
                serverEtag = tagValue.Trim('"');
                System.Diagnostics.Debug.WriteLine(
                    $"[BackgroundService] 服务端ETag: {serverEtag}");
            }

            // ETag比对：如果服务端ETag与本地版本一致，跳过更新节省带宽和磁盘I/O开销
            if (serverEtag != null && _localVersion == serverEtag)
            {
                System.Diagnostics.Debug.WriteLine(
                    "[BackgroundService] ETag与本地一致，服务端无变更");
                return (true, false, serverEtag);
            }

            // 📦下载图片字节流并加密写入缓存（方案A：内容 + ETag 合并加密单文件）
            var imageBytes = await response.Content.ReadAsByteArrayAsync();

            if (!Directory.Exists(CacheDirectory))
                Directory.CreateDirectory(CacheDirectory);

            _secureCache.SaveEnvelope(CacheFilePath, imageBytes, serverEtag);

            // 解密到临时明文文件供 UI 加载（失败时 UI 回退默认背景，不影响主流程）
            DecryptBackgroundToTemp();

            System.Diagnostics.Debug.WriteLine(
                $"[BackgroundService] 新背景图片已加密缓存 ({imageBytes.Length:N0} bytes)");

            return (true, true, serverEtag);
        }
        catch (TaskCanceledException)
        {
            System.Diagnostics.Debug.WriteLine("[BackgroundService] ⏱下载超时");
            return (false, false, null);
        }
        catch (HttpRequestException ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[BackgroundService] 🌐网络错误: {ex.Message}");
            return (false, false, null);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[BackgroundService] ❌下载异常: {ex.GetType().Name}: {ex.Message}");
            return (false, false, null);
        }
    }

    // ================================================================
    //  本地缓存管理
    // ================================================================

    /// <summary>
    /// 解密加密缓存到临时明文文件，返回路径；解密失败（篡改/损坏/缺失）返回 null。
    /// </summary>
    private string? DecryptBackgroundToTemp() =>
        _secureCache.DecryptToTempFile(CacheFilePath, TempFileName);

    /// <summary>
    /// 清理旧明文格式缓存文件（升级遗留：background_cache.jpg + background_version.txt）。
    /// 新格式（加密信封）不再创建独立版本文件，ETag 内嵌于加密文件。
    /// </summary>
    private void CleanupLegacyCacheFiles()
    {
        try
        {
            var legacyJpg = Path.Combine(CacheDirectory, LegacyCacheFileName);
            if (File.Exists(legacyJpg)) File.Delete(legacyJpg);

            var legacyTxt = Path.Combine(CacheDirectory, LegacyVersionFileName);
            if (File.Exists(legacyTxt)) File.Delete(legacyTxt);
        }
        catch { /* 清理失败不影响主流程 */ }
    }

    /// <summary>
    /// 确保缓存目录存在
    /// </summary>
    private static void EnsureCacheDirectory()
    {
        if (!Directory.Exists(CacheDirectory))
            Directory.CreateDirectory(CacheDirectory);
    }

    // ================================================================
    //  版本管理（ETag 持久化于加密信封内）
    // ================================================================

    /// <summary>
    /// 从加密缓存信封恢复本地 ETag 版本标识（格式与 meta 统一为字符串）。
    /// 解密失败（被篡改/损坏/旧明文格式）→ 视为无版本，下次同步重新下载。
    /// </summary>
    private void LoadLocalVersion()
    {
        try
        {
            if (_secureCache.TryReadEnvelope(CacheFilePath, out _, out var etag, out _))
            {
                _localVersion = etag;
                System.Diagnostics.Debug.WriteLine(
                    $"[BackgroundService] 从加密缓存恢复ETag: {_localVersion}");
            }
            else
            {
                _localVersion = null;
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[BackgroundService] 读取版本失败: {ex.Message}");
            // 版本损坏不影响主流程，下次同步会重新生成
            _localVersion = null;
        }
    }

    // ================================================================
    //  服务器URL解析
    // ================================================================

    /// <summary>
    /// 通过 ServerUrlService 解析背景图片的远程 URL。
    /// URL注册表中的值应为API端点地址（如 http://localhost:5340/api/resources/home-background），
    /// HttpClient会自动跟随302重定向到MinIO预签名URL。
    /// </summary>
    private string? GetBackgroundServerUrl()
    {
        try
        {
            return _serverUrlService.GetDecryptedUrl(BackgroundUrlKey);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[BackgroundService] 解析远程URL失败: {ex.Message}");
            return null;
        }
    }

    // ================================================================
    //  种子数据注册（由 App 启动时调用，确保 "home_background" 键存在）
    // ================================================================

    /// <summary>
    /// 确保背景图片 URL 注册键存在。
    /// 如果尚未注册，使用默认 URL 创建一条记录。
    /// 如果已注册但 URL 为空，尝试从 auth_api 推导默认 API 端点地址并填充。
    /// </summary>
    public void EnsureBackgroundUrlRecord()
    {
        try
        {
            var existing = _serverUrlService.GetByKey(BackgroundUrlKey);
            if (existing == null)
            {
                // 不存在 → 创建新记录（URL 留空，由后续逻辑填充默认值）
                _serverUrlService.Register(
                    key: BackgroundUrlKey,
                    displayName: "首页背景图片",
                    plainUrl: string.Empty,
                    category: "Background",
                    schemeName: null);
                existing = _serverUrlService.GetByKey(BackgroundUrlKey);
            }

            // 检查已有记录的 URL 是否为空（种子数据中 home_background 的 Url = string.Empty）
            var decryptedUrl = _serverUrlService.GetDecryptedUrl(BackgroundUrlKey);
            if (!string.IsNullOrEmpty(decryptedUrl))
                return; // URL 已配置，无需填充

            // URL 为空 → 尝试从 auth_api 推导默认 API 端点地址
            System.Diagnostics.Debug.WriteLine(
                "[BackgroundService] home_background URL 为空，尝试推导默认值");

            var authApiUrl = _serverUrlService.GetDecryptedUrl("auth_api");
            if (!string.IsNullOrEmpty(authApiUrl))
            {
                // auth_api 如 "https://api.akeno6388.online:1010"
                // 背景 API 端点: "{auth_api}/api/resources/home-background"
                var defaultUrl = authApiUrl.TrimEnd('/') + "/api/resources/home-background";
                existing!.Url = _cryptoService.Encrypt(defaultUrl);
                _serverUrlService.Update(existing);
                System.Diagnostics.Debug.WriteLine(
                    $"[BackgroundService] 已填充默认背景URL: {defaultUrl}");
            }
            else
            {
                System.Diagnostics.Debug.WriteLine(
                    "[BackgroundService] auth_api 也未配置，无法推导默认URL，" +
                    "请通过管理端配置 home_background URL");
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[BackgroundService] 注册/填充URL记录失败: {ex.Message}");
        }
    }

    // ================================================================
    //  IDisposable
    // ================================================================

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        // 取消订阅登录事件
        try
        {
            var loginService = App.Services.GetRequiredService<ILoginService>();
            loginService.LoginStateChanged -= OnLoginStateChanged;
        }
        catch { /* 服务可能已释放 */ }

        _httpClient.Dispose();
        GC.SuppressFinalize(this);
        
        System.Diagnostics.Debug.WriteLine("[BackgroundService] 已释放");
    }
}
