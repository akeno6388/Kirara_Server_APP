using System.Text.Json;
using Kirara_Server_WinUI.Helpers;
using Microsoft.AspNetCore.SignalR.Client;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 远程通知服务 — 基于 SignalR WebSocket 长连接实时接收服务端推送，
/// 辅以 HTTP REST 在连接断开期间补拉离线通知。
///
/// ## 实时推送链路（SignalR）
/// ```
/// 服务端 AdminController.BroadcastNotification()
///   → AdminService → PostgreSQL 持久化
///   → _hubContext.Clients.Group(userId).SendAsync("ReceiveNotification", {...})
///     → SignalR Hub → WebSocket → 客户端 HubConnection
///       → On("ReceiveNotification") → INotificationService.Publish(Service)
///         → NotificationCenterViewModel → "服务项" 标签页
/// ```
///
/// ## 离线补拉（HTTP REST，仅断线重连后触发）
/// - 记录 _lastConnectedAt 时间戳
/// - SignalR 重连成功后，通过 GET /api/notifications?since={_lastConnectedAt} 补拉遗漏
/// - 无轮询！HTTP 仅在以下场景触发：
///   1. 首次登录后（补拉登录前的通知）
///   2. 网络断开后重连成功（补拉断线期间遗漏）
///
/// ## 生命周期
/// - 登录成功 → 自动连接 SignalR + 离线补拉
/// - 退出登录 → 断开 SignalR
/// - 网络中断 → SignalR 内置自动重连（指数退避：0s→2s→10s→30s，最多 4 次）
///
/// ## API 规范
/// - SignalR Hub: /hubs/notifications?access_token={jwt}
/// - JWT 传递: WebSocket 不支持 Header，通过 QueryString ?access_token= 传递
/// - 事件名: "ReceiveNotification"
/// - HTTP 补拉: GET /api/notifications?page=1&pageSize=50&since={timestamp}
/// </summary>
public class RemoteNotificationService : IDisposable
{
    private readonly IServerUrlService _serverUrlService;
    private readonly ILoginService _loginService;
    private readonly INotificationService _notificationService;
    private readonly LocalNotificationStore _localStore;
    private readonly HttpClient _httpClient;

    /// <summary>通知 API URL 注册键名</summary>
    private const string NotificationsApiUrlKey = "notifications_api";

    /// <summary>默认 API 基础地址</summary>
    private const string DefaultApiBaseUrl = "https://api.akeno6388.online:1010";

    /// <summary>API 基础地址</summary>
    private string ApiBaseUrl =>
        _serverUrlService.GetDecryptedUrl(NotificationsApiUrlKey) ?? DefaultApiBaseUrl;

    /// <summary>SignalR Hub 端点路径</summary>
    private string HubUrl => $"{ApiBaseUrl}/hubs/notifications";

    /// <summary>
    /// 上次处于连接状态的时间戳（UTC）。
    /// 断线重连后通过此时间戳补拉离线期间的通知。
    /// </summary>
    private DateTime _lastConnectedAt = DateTime.MinValue;

    /// <summary>SignalR 连接实例</summary>
    private HubConnection? _hubConnection;

    /// <summary>连接级 CancellationTokenSource</summary>
    private CancellationTokenSource? _connectCts;

    /// <summary>是否已释放</summary>
    private bool _disposed;

    /// <summary>
    /// UI 线程调度器 — SignalR 回调和 HTTP 补拉均在后台线程执行，
    /// 发布通知到 INotificationService 前必须通过此调度器切换到 UI 线程，
    /// 避免 ObservableProperty 的 PropertyChanged 触发 RPC_E_WRONG_THREAD。
    /// </summary>
    private Microsoft.UI.Dispatching.DispatcherQueue? _dispatcherQueue;

    /// <summary>
    /// 本地已持久化的通知 ID 集合，用于服务端拉取时去重。
    /// 由 LoadLocalStoreAsync 初始化，CatchUpOfflineNotificationsAsync 中检查。
    /// </summary>
    private HashSet<Guid> _localStoreIds = new();

    /// <summary>
    /// 服务端推送事件的 JSON 数据模型。
    /// 服务端 broadcast 时通过 SendAsync("ReceiveNotification", {...}) 推送。
    /// 结构与 NotificationResponseData 一致。
    /// </summary>
    private class ServerPushNotification
    {
        [System.Text.Json.Serialization.JsonPropertyName("id")]
        public Guid Id { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("title")]
        public string Title { get; set; } = string.Empty;

        [System.Text.Json.Serialization.JsonPropertyName("content")]
        public string? Content { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("htmlContent")]
        public string? HtmlContent { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("category")]
        public string Category { get; set; } = string.Empty;

        [System.Text.Json.Serialization.JsonPropertyName("isRead")]
        public bool IsRead { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("createdAt")]
        public DateTime CreatedAt { get; set; }

        // ===== 互动通知定位字段（v1.10，广播通知为 null） =====

        [System.Text.Json.Serialization.JsonPropertyName("actionType")]
        public int? ActionType { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("actorUserId")]
        public Guid? ActorUserId { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("actorName")]
        public string? ActorName { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("targetId")]
        public Guid? TargetId { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("resourceKey")]
        public string? ResourceKey { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("contentTitle")]
        public string? ContentTitle { get; set; }
    }

    // ================================================================
    //  构造 / 销毁
    // ================================================================

    /// <summary>
    /// 由 App.OnLaunched 在 UI 线程调用，捕获 UI 线程的 DispatcherQueue。
    /// SignalR 回调和 HTTP 补拉均在后台线程执行，发布通知前需通过此调度器切换线程。
    /// </summary>
    public void CaptureUiDispatcher()
    {
        _dispatcherQueue = Microsoft.UI.Dispatching.DispatcherQueue.GetForCurrentThread();
        System.Diagnostics.Debug.WriteLine(
            $"[RemoteNotificationService] UI 调度器已捕获 (HasThreadAccess={_dispatcherQueue?.HasThreadAccess})");
    }

    public RemoteNotificationService(
        IServerUrlService serverUrlService,
        ILoginService loginService,
        INotificationService notificationService,
        LocalNotificationStore localStore)
    {
        _serverUrlService = serverUrlService;
        _loginService = loginService;
        _notificationService = notificationService;
        _localStore = localStore;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
        _httpClient.Timeout = TimeSpan.FromSeconds(15);

        // 订阅登录状态变更：登录 → 连接 SignalR，登出 → 断开
        loginService.LoginStateChanged += OnLoginStateChanged;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        DisconnectSignalRAsync().GetAwaiter().GetResult();
        _httpClient.Dispose();
        _connectCts?.Cancel();
        _connectCts?.Dispose();

        _loginService.LoginStateChanged -= OnLoginStateChanged;
    }

    // ================================================================
    //  登录状态变更
    // ================================================================

    /// <summary>
    /// 用户会话结束（登出）时触发 — 通知 UI 清空当前用户的通知集合。
    /// v2: 防止多用户先后登录时上一个用户的已读/未读状态残留给下一个用户。
    /// </summary>
    public event Action? SessionEnded;

    private void OnLoginStateChanged(bool isLoggedIn)
    {
        if (isLoggedIn)
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteNotificationService] 用户登录成功，连接 SignalR 实时通知");
            _ = ConnectAndCatchUpAsync();
        }
        else
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteNotificationService] 用户登出，断开 SignalR 并清理会话状态");
            _ = DisconnectSignalRAsync();

            // v2: 登出时重置会话状态，防止下一个登录用户继承上一个用户的通知状态
            // 1. 重置增量拉取窗口（下次登录由 LoadLocalStoreAsync 按新用户缓存重建）
            _lastConnectedAt = DateTime.MinValue;
            // 2. 清空去重集合（下次登录按新用户缓存重建）
            _localStoreIds.Clear();
            // 3. 清空内存通知总线中的 Service 通知（全局 Singleton 残留）
            _notificationService.Clear(NotificationCategory.Service);
            // 4. 通知 UI 清空当前用户的通知集合
            SessionEnded?.Invoke();
        }
    }

    // ================================================================
    //  连接 + 离线补拉
    // ================================================================

    /// <summary>
    /// 连接 SignalR 并补拉离线通知。
    /// 登录后由 OnLoginStateChanged 自动调用。
    /// </summary>
    private async Task ConnectAndCatchUpAsync()
    {
        // 取消之前的连接尝试
        _connectCts?.Cancel();
        _connectCts = new CancellationTokenSource();
        var token = _connectCts.Token;

        try
        {
            // Step 0: 从本地持久化存储加载已有通知（秒显，不等网络）
            await LoadLocalStoreAsync();

            // Step 1: 连接前先通过 HTTP 补拉离线期间的通知（跳过服务端已读的）
            await CatchUpOfflineNotificationsAsync(token);

            // Step 2: 建立 SignalR 实时连接
            await ConnectSignalRAsync(token);
        }
        catch (OperationCanceledException)
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteNotificationService] 连接被取消");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 连接失败: {ex.GetType().Name}: {ex.Message}");
        }
    }

    /// <summary>
    /// 建立 SignalR WebSocket 连接。
    /// </summary>
    private async Task ConnectSignalRAsync(CancellationToken token)
    {
        await DisconnectSignalRAsync();

        var accessToken = await GetValidAccessTokenAsync();
        if (string.IsNullOrEmpty(accessToken))
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteNotificationService] 无有效 AccessToken，跳过 SignalR 连接");
            return;
        }

        // 构建 HubConnection（JWT 通过 QueryString 传递，WebSocket 不支持 Header）
        _hubConnection = new HubConnectionBuilder()
            .WithUrl($"{HubUrl}?access_token={accessToken}", options =>
            {
                // 使用双栈 HttpClient 以复用 UserAgent、超时设置与 IPv4/IPv6 Happy Eyeballs
                options.HttpMessageHandlerFactory = _ => NetworkClientFactory.CreateHandler();
            })
            .WithAutomaticReconnect(new RetryPolicy())
            .Build();

        // 注册服务端推送事件
        _hubConnection.On<ServerPushNotification>("ReceiveNotification", push =>
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] SignalR 实时推送: {push.Title}");

            // 必须在 UI 线程发布通知（避免 ObservableProperty 触发 RPC_E_WRONG_THREAD）
            var notification = new AppNotification
            {
                Id = push.Id,  // 映射服务端 ID，用于后续标记已读 API 调用
                Category = NotificationCategory.Service,
                Severity = NotificationSeverity.Info,
                Title = push.Title,
                Message = push.Content ?? push.Title,
                HtmlContent = push.HtmlContent,
                Timestamp = push.CreatedAt.ToLocalTime(),
                // v2: 本地已读唯一权威 — 服务端 IsRead 可能被其他用户置位，一律不采信，初始化为未读
                IsRead = false,
                Source = "SignalR",
                // v1.10: 互动通知定位字段（广播通知为 null，向后兼容）
                ActionType = push.ActionType,
                ActorUserId = push.ActorUserId,
                ActorName = push.ActorName,
                TargetId = push.TargetId,
                ResourceKey = push.ResourceKey,
                ContentTitle = push.ContentTitle,
                // v1.11: 方案级通知图标关联（从资源键提取方案名，如 "media"、"openvpn"）
                SchemeName = ExtractSchemeName(push.ResourceKey),
            };

            // 持久化到本地存储
            _localStore.Append(notification);

            if (_dispatcherQueue?.HasThreadAccess == true)
                _notificationService.Publish(notification);
            else
                _dispatcherQueue?.TryEnqueue(() => _notificationService.Publish(notification));

            // 更新最后连接时间戳
            if (push.CreatedAt > _lastConnectedAt)
                _lastConnectedAt = push.CreatedAt;
        });

        // 注册重连事件：重连成功后补拉离线通知
        _hubConnection.Reconnected += async (connectionId) =>
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] SignalR 重连成功 (ConnectionId={connectionId})，补拉离线通知");
            try
            {
                await CatchUpOfflineNotificationsAsync(CancellationToken.None);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[RemoteNotificationService] 重连后补拉失败: {ex.Message}");
            }
        };

        // 注册断线事件
        _hubConnection.Closed += async (error) =>
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] SignalR 连接断开: {error?.Message ?? "正常关闭"}");
            await Task.CompletedTask;
        };

        System.Diagnostics.Debug.WriteLine(
            $"[RemoteNotificationService] 正在连接 SignalR Hub: {HubUrl}");

        await _hubConnection.StartAsync(token);

        _lastConnectedAt = DateTime.UtcNow;
        System.Diagnostics.Debug.WriteLine(
            $"[RemoteNotificationService] SignalR 连接成功 (State={_hubConnection.State})");
    }

    /// <summary>
    /// 断开 SignalR 连接。
    /// </summary>
    private async Task DisconnectSignalRAsync()
    {
        if (_hubConnection != null)
        {
            try
            {
                await _hubConnection.StopAsync();
                System.Diagnostics.Debug.WriteLine(
                    "[RemoteNotificationService] SignalR 连接已断开");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[RemoteNotificationService] 断开 SignalR 异常: {ex.Message}");
            }
            finally
            {
                await _hubConnection.DisposeAsync();
                _hubConnection = null;
            }
        }
    }

    // ================================================================
    //  HTTP 离线补拉（无轮询！仅在登录/重连时触发）
    // ================================================================

    /// <summary>
    /// 通过 HTTP REST 补拉离线期间遗漏的通知。
    /// 使用 ?since={_lastConnectedAt} 参数增量获取。
    /// </summary>
    private async Task CatchUpOfflineNotificationsAsync(CancellationToken token)
    {
        var accessToken = await GetValidAccessTokenAsync();
        if (string.IsNullOrEmpty(accessToken))
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteNotificationService] 无有效 AccessToken，跳过离线补拉");
            return;
        }

        try
        {
            // 构建增量拉取 URL
            var sinceParam = _lastConnectedAt > DateTime.MinValue
                ? $"&since={_lastConnectedAt:O}"
                : string.Empty;
            var url = $"{ApiBaseUrl}/api/notifications?page=1&pageSize=50{sinceParam}";

            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

            var response = await _httpClient.SendAsync(request, token);

            if (!response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[RemoteNotificationService] 离线补拉 HTTP {(int)response.StatusCode}");
                response.Dispose();
                return;
            }

            var json = await response.Content.ReadAsStringAsync(token);
            response.Dispose();

            var apiResponse = JsonSerializer.Deserialize<ApiResponse<NotificationListResponseData>>(json);

            if (apiResponse?.Success != true || apiResponse.Data == null)
            {
                System.Diagnostics.Debug.WriteLine(
                    "[RemoteNotificationService] 离线补拉响应异常");
                return;
            }

            var items = apiResponse.Data.Items;
            if (items.Count == 0)
            {
                // 无遗漏通知，更新时间戳防止重复请求
                if (_lastConnectedAt == DateTime.MinValue)
                    _lastConnectedAt = DateTime.UtcNow;
                return;
            }

            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 离线补拉 {items.Count} 条通知，过滤本地已存与服务端已读项...");

            // 构建通知对象列表
            // v3: 离线补拉仅统计「新增的未读通知」——
            //   1. 本地已存在（含已读/已清除）→ 跳过（时间戳边界重叠去重）
            //   2. 服务端已读（本会话标记已读已上报）→ 跳过（全部已读时无新增未读，不触发离线提醒）
            // 服务端 IsRead 按用户独立存储（PATCH /read、PUT /read-all 上报），采信安全；
            // 本地缓存 ID 集合仍为第一道去重兜底。
            var notificationsToPublish = new List<AppNotification>(items.Count);
            foreach (var item in items)
            {
                if (item.CreatedAt > _lastConnectedAt)
                    _lastConnectedAt = item.CreatedAt;

                // ID 已存在于本地存储 → 跳过（防止时间戳边界重叠导致重复）
                if (_localStoreIds.Contains(item.Id))
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[RemoteNotificationService] 跳过本地已存通知: {item.Title} ({item.Id}) ");
                    continue;
                }

                // 服务端已读 → 跳过（非新增未读，不展示、不触发离线提醒）
                if (item.IsRead)
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[RemoteNotificationService] 跳过已读通知: {item.Title} ({item.Id})");
                    continue;
                }

                notificationsToPublish.Add(new AppNotification
                {
                    Id = item.Id,  // 映射服务端 ID，用于后续标记已读 API 调用
                    Category = NotificationCategory.Service,
                    Severity = NotificationSeverity.Info,
                    Title = item.Title,
                    Message = item.Content ?? item.Title,
                    HtmlContent = item.HtmlContent,
                    Timestamp = item.CreatedAt.ToLocalTime(),
                    IsRead = false,  // 补拉发布的新增未读通知
                    Source = "OfflineCatchUp",
                    // v1.10: 互动通知定位字段（广播通知为 null，向后兼容）
                    ActionType = item.ActionType,
                    ActorUserId = item.ActorUserId,
                    ActorName = item.ActorName,
                    TargetId = item.TargetId,
                    ResourceKey = item.ResourceKey,
                    ContentTitle = item.ContentTitle,
                    // v1.11: 方案级通知图标关联（从资源键提取方案名）
                    SchemeName = ExtractSchemeName(item.ResourceKey),
                });
            }

            if (notificationsToPublish.Count == 0)
            {
                System.Diagnostics.Debug.WriteLine(
                    "[RemoteNotificationService] 无新增未读通知（已读或本地已存在），不触发离线提醒");
                return;
            }

            // 持久化新通知到本地存储（去重）
            _localStore.AppendRange(notificationsToPublish);

            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 展示 {notificationsToPublish.Count} 条新未读通知");

            // 批量发布到全局通知总线（必须在 UI 线程）
            Action publishAction = () =>
            {
                foreach (var n in notificationsToPublish)
                    _notificationService.Publish(n);
            };

            if (_dispatcherQueue?.HasThreadAccess == true)
                publishAction();
            else
                _dispatcherQueue?.TryEnqueue(() => publishAction());
        }
        catch (HttpRequestException ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 离线补拉网络错误: {ex.Message}");
        }
        catch (TaskCanceledException)
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteNotificationService] 离线补拉超时");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 离线补拉异常: {ex.Message}");
        }
    }

    // ================================================================
    //  本地持久化加载（从 JSON 文件恢复已接收的通知）
    // ================================================================

    /// <summary>
    /// 从本地持久化存储加载已有通知到通知总线。
    /// 确保重启后能秒显已接收的通知，不等网络请求完成。
    /// </summary>
    private async Task LoadLocalStoreAsync()
    {
        // 在后台线程读取文件
        var localNotifications = await Task.Run(() => _localStore.Load());

        // 读取已清除通知 ID 集合（清除后主文件为空，但已清除 ID 必须继续参与去重，
        // 防止重启后通过服务端全量拉取把已清除的通知重新拉取回来）
        var clearedIds = await Task.Run(() => _localStore.GetClearedIds());

        if (localNotifications.Count == 0 && clearedIds.Count == 0)
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteNotificationService] 本地无缓存通知");
            return;
        }

        // 加载本地已存在的通知 ID（含已清除的），供后续服务端拉取时去重
        _localStoreIds = new HashSet<Guid>(localNotifications.Select(n => n.Id));
        foreach (var id in clearedIds)
            _localStoreIds.Add(id);

        if (localNotifications.Count == 0)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 本地无活跃通知（{clearedIds.Count} 条已清除记录参与去重）");
            return;
        }

        System.Diagnostics.Debug.WriteLine(
            $"[RemoteNotificationService] 从本地加载 {localNotifications.Count} 条缓存通知");

        // 用本地最新通知的时间戳更新 _lastConnectedAt，
        // 确保后续服务端拉取 ?since= 参数跳过已存在的通知，避免重复
        var maxTimestamp = localNotifications
            .Select(n => n.Timestamp.ToUniversalTime())
            .Max();
        if (maxTimestamp > _lastConnectedAt)
        {
            _lastConnectedAt = maxTimestamp;
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 更新 _lastConnectedAt={_lastConnectedAt:O}");
        }

        // 补填旧数据缺失的 SchemeName（v1.11 前持久化的通知无该字段，从 ResourceKey 提取），
        // 保证本地恢复的通知也能关联方案图标；同时标记 IsRestored，
        // 通知飞入弹窗服务据此跳过恢复通知（历史通知不弹完整内容弹窗）
        foreach (var n in localNotifications)
        {
            n.IsRestored = true;
            if (string.IsNullOrEmpty(n.SchemeName))
                n.SchemeName = ExtractSchemeName(n.ResourceKey);
        }

        // 发布到通知总线（必须在 UI 线程）
        // 注意：_localStoreIds 已在上面合并（活跃 ID ∪ 已清除 ID），此处禁止重新赋值覆盖
        if (_dispatcherQueue?.HasThreadAccess == true)
        {
            foreach (var n in localNotifications)
                _notificationService.Publish(n);
        }
        else
        {
            _dispatcherQueue?.TryEnqueue(() =>
            {
                foreach (var n in localNotifications)
                    _notificationService.Publish(n);
            });
        }
    }

    // ================================================================
    //  工具方法
    // ================================================================

    /// <summary>
    /// 从资源键提取方案名（格式 "{schemeName}://..."，含首页分享打包键，
    /// 前缀在 "||" 分隔符之前，提取不受影响）。提取失败返回 null。
    /// </summary>
    private static string? ExtractSchemeName(string? resourceKey)
    {
        if (string.IsNullOrEmpty(resourceKey))
            return null;

        var separatorIndex = resourceKey.IndexOf("://", StringComparison.Ordinal);
        return separatorIndex > 0 ? resourceKey[..separatorIndex] : null;
    }

    /// <summary>
    /// 获取有效的 AccessToken（过期时自动使用 RefreshToken 续期）。
    /// </summary>
    private async Task<string?> GetValidAccessTokenAsync()
    {
        if (!_loginService.IsLoggedIn)
            return null;

        bool isValid = await _loginService.EnsureValidAccessTokenAsync();
        return isValid ? _loginService.AccessToken : null;
    }

    // ================================================================
    //  标记已读 API（与服务器同步）
    // ================================================================

    /// <summary>
    /// 标记单条通知为已读 — 本地已读状态先行持久化，再调用 PATCH /api/notifications/{id}/read 上报。
    /// v2: 本地已读唯一权威；服务端 IsRead 仅作状态呈现，客户端不读取。
    /// </summary>
    /// <param name="notificationId">服务端通知 ID</param>
    public async Task MarkAsReadAsync(Guid notificationId)
    {
        // 本地已读状态先行持久化（与服务器是否可达无关）
        _localStore.MarkAsRead(notificationId);

        var accessToken = await GetValidAccessTokenAsync();
        if (string.IsNullOrEmpty(accessToken))
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteNotificationService] 标记已读失败: 无有效 AccessToken");
            return;
        }

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Patch,
                $"{ApiBaseUrl}/api/notifications/{notificationId}/read");
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

            var response = await _httpClient.SendAsync(request);
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 标记已读 {notificationId}: HTTP {(int)response.StatusCode}");
            response.Dispose();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 标记已读异常: {ex.Message}");
        }
    }

    /// <summary>
    /// 标记全部通知为已读 — 本地已读状态先行持久化，再调用 PUT /api/notifications/read-all 上报。
    /// v2: 本地已读唯一权威；服务端 IsRead 仅作状态呈现，客户端不读取。
    /// </summary>
    public async Task MarkAllAsReadAsync()
    {
        // 本地已读状态先行持久化（与服务器是否可达无关）
        _localStore.MarkAllAsRead();

        var accessToken = await GetValidAccessTokenAsync();
        if (string.IsNullOrEmpty(accessToken))
        {
            System.Diagnostics.Debug.WriteLine(
                "[RemoteNotificationService] 标记全部已读失败: 无有效 AccessToken");
            return;
        }

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Put,
                $"{ApiBaseUrl}/api/notifications/read-all");
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

            var response = await _httpClient.SendAsync(request);
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 标记全部已读: HTTP {(int)response.StatusCode}");
            response.Dispose();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 标记全部已读异常: {ex.Message}");
        }
    }

    // ================================================================
    //  SignalR 重试策略
    // ================================================================

    /// <summary>
    /// SignalR 自动重连策略 — 指数退避，最多 4 次。
    /// 间隔: 0s → 2s → 10s → 30s
    /// </summary>
    private sealed class RetryPolicy : IRetryPolicy
    {
        private static readonly TimeSpan[] RetryDelays =
        [
            TimeSpan.FromSeconds(0),
            TimeSpan.FromSeconds(2),
            TimeSpan.FromSeconds(10),
            TimeSpan.FromSeconds(30),
        ];

        public TimeSpan? NextRetryDelay(RetryContext retryContext)
        {
            long attempt = retryContext.PreviousRetryCount;
            if (attempt < RetryDelays.Length)
                return RetryDelays[attempt];

            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] SignalR 重连已达最大次数 ({RetryDelays.Length})，停止重试");
            return null; // 停止重连
        }
    }

    // ================================================================
    //  启动初始化
    // ================================================================

    /// <summary>
    /// 确保通知 API URL 注册键存在。
    /// </summary>
    public void EnsureNotificationApiUrlRecord()
    {
        try
        {
            var existing = _serverUrlService.GetByKey(NotificationsApiUrlKey);
            if (existing != null) return;

            _serverUrlService.Register(
                key: NotificationsApiUrlKey,
                displayName: "通知系统 API 服务地址",
                plainUrl: DefaultApiBaseUrl,
                category: "Infrastructure");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[RemoteNotificationService] 注册通知 API URL 失败: {ex.Message}");
        }
    }
}