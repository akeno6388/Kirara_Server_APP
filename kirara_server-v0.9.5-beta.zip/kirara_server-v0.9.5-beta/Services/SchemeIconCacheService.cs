using System.Text.Json;
using Kirara_Server_WinUI.Helpers;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 方案图标缓存服务 — 通过 Kirara Server API 获取方案封面图片并缓存到本地。
///
/// ## 设计说明
/// 与 RemoteQuickStartService 的模板封面图缓存策略完全一致。
/// 每个方案通过其 Name（如 "media"、"drive"）作为 API Key 调用：
///   GET /api/scheme-urls/{key}/image → 302 → MinIO 预签名 URL → 下载 → ETag 比对 → 缓存
///
/// ## 缓存结构
///   %APPDATA%/Kirara/scheme_icons/
///     {schemeName}.png      — 缓存图片文件
///     {schemeName}.meta     — ETag 元数据文件
///
/// ## 降级策略
/// - IconGlyph（Segoe Fluent Icons 字符）作为保底方案
/// - 网络不可达/404/解析失败时不阻塞，继续使用本地缓存或 IconGlyph
/// </summary>
public class SchemeIconCacheService : IDisposable
{
    private readonly HttpClient _httpClient;
    private bool _disposed;
    private readonly IServerUrlService _serverUrlService;
    private readonly ISchemeService _schemeService;
    private readonly ILoginService _loginService;
    private readonly SecureCacheService _secureCache;

    /// <summary>方案图标 API URL 注册键名</summary>
    private const string SchemesApiUrlKey = "schemes_api";

    /// <summary>默认 API 基础地址</summary>
    private const string DefaultApiBaseUrl = "https://api.akeno6388.online:1010";

    /// <summary>API 基础地址</summary>
    private string ApiBaseUrl =>
        _serverUrlService.GetDecryptedUrl(SchemesApiUrlKey) ?? DefaultApiBaseUrl;

    /// <summary>图标缓存根目录</summary>
    private static readonly string CacheDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "scheme_icons");

    /// <summary>图标版本号（递增，用于 WinUI BitmapImage 缓存失效）</summary>
    private int _iconVersion;

    /// <summary>是否已完成过本地缓存加载</summary>
    private bool _localCacheLoaded;

    private string GetCachePath(string schemeName) =>
        Path.Combine(CacheDirectory, $"{schemeName}{SecureCacheService.EncryptedExtension}");

    /// <summary>解密后的临时明文图标路径</summary>
    private string GetTempPath(string schemeName) =>
        Path.Combine(SecureCacheService.TempDirectory, $"scheme_{schemeName}.png");

    /// <summary>
    /// 获取带版本号的图标临时明文 URI（WinUI BitmapImage 按 URI 缓存，追加 ?v= 强制刷新）
    /// </summary>
    private string GetCacheUrl(string schemeName)
    {
        var tempPath = GetTempPath(schemeName);
        return $"{tempPath}?v={_iconVersion}";
    }

    // 图标 ETag 元数据已内嵌于加密信封（方案A），不再使用独立 meta 文件

    /// <summary>
    /// 方案图标缓存刷新完成事件。
    /// 在 InitializeAsync 完成（含首次缓存和同步）后触发，
    /// 供 ViewModel/Code-behind 订阅以重新绑定图标数据。
    /// </summary>
    public static event Action? SchemeIconsRefreshed;

    public SchemeIconCacheService(
        IServerUrlService serverUrlService,
        ISchemeService schemeService,
        ILoginService loginService,
        SecureCacheService secureCache)
    {
        _serverUrlService = serverUrlService;
        _schemeService = schemeService;
        _loginService = loginService;
        _secureCache = secureCache;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
        _httpClient.Timeout = TimeSpan.FromSeconds(15);

        // 订阅登录状态变更：登录后重新同步（API 需要 Bearer Token）
        loginService.LoginStateChanged += OnLoginStateChanged;
    }

    /// <summary>
    /// 登录成功时重新同步方案图标。
    /// 启动时用户未登录，API 返回 401 静默跳过；
    /// 登录后再试即可获取有效 Token。
    /// </summary>
    private void OnLoginStateChanged(bool isLoggedIn)
    {
        if (!isLoggedIn || !_localCacheLoaded) return;
        System.Diagnostics.Debug.WriteLine(
            "[SchemeIconCacheService] 用户登录成功，重新同步方案图标");
        _ = SyncAllIconsAsync();
    }

    // ================================================================
    //  公开方法
    // ================================================================

    /// <summary>
    /// 获取指定方案的已缓存图标临时明文 URI（解密加密缓存后加载），无缓存时返回 null。
    /// 解密失败（被篡改/损坏/旧明文格式）→ 返回 null → UI 回退 IconGlyph。
    /// </summary>
    public string? GetCachedIconUrl(string schemeName)
    {
        var cachePath = GetCachePath(schemeName);
        if (_secureCache.TryReadEnvelope(cachePath, out var content, out _, out _))
        {
            _secureCache.WriteTempFile($"scheme_{schemeName}.png", content);
            return GetCacheUrl(schemeName);
        }
        return null;
    }

    // ================================================================
    //  初始化
    // ================================================================

    /// <summary>
    /// 启动时仅加载本地缓存的方案图标（秒显），不同步服务端。
    /// 服务端同步由 OnLoginStateChanged 在用户登录后触发，
    /// 避免启动时未登录状态下空转 API 请求。
    /// </summary>
    public async Task InitializeAsync()
    {
        System.Diagnostics.Debug.WriteLine(
            "[SchemeIconCacheService] === InitializeAsync ===");

        try
        {
            var schemes = _schemeService.GetAllSchemes().ToList();
            if (schemes.Count == 0)
            {
                System.Diagnostics.Debug.WriteLine(
                    "[SchemeIconCacheService] 无可用方案，跳过");
                return;
            }

            var loadedCount = 0;
            foreach (var scheme in schemes)
            {
                var url = GetCachedIconUrl(scheme.Name);
                if (url != null)
                {
                    scheme.CoverImageUrl = url;
                    loadedCount++;
                }
            }

            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 本地缓存图标加载完成: {loadedCount}/{schemes.Count}");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 初始化失败: {ex.Message}");
        }
        finally
        {
            _localCacheLoaded = true;
            System.Diagnostics.Debug.WriteLine(
                "[SchemeIconCacheService] 触发 SchemeIconsRefreshed 事件");
            SchemeIconsRefreshed?.Invoke();
        }
    }

    /// <summary>
    /// 并行同步所有方案的服务端最新图标。
    /// 由登录事件触发（登录后才有有效的 AccessToken）。
    /// </summary>
    private async Task SyncAllIconsAsync()
    {
        System.Diagnostics.Debug.WriteLine(
            "[SchemeIconCacheService] === SyncAllIconsAsync ===");

        try
        {
            var schemes = _schemeService.GetAllSchemes().ToList();
            var tasks = schemes.Select(async scheme =>
            {
                try
                {
                    await SyncSingleIconAsync(scheme.Name);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[SchemeIconCacheService] 方案 {scheme.Name} 同步失败: {ex.Message}");
                }
            });

            await Task.WhenAll(tasks);

            System.Diagnostics.Debug.WriteLine(
                "[SchemeIconCacheService] 全量重新同步完成");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 全量同步失败: {ex.Message}");
        }
        finally
        {
            SchemeIconsRefreshed?.Invoke();
        }
    }

    /// <summary>
    /// 强制刷新单个方案的图标缓存。
    /// </summary>
    public async Task RefreshIconAsync(string schemeName)
    {
        System.Diagnostics.Debug.WriteLine(
            $"[SchemeIconCacheService] 强制刷新方案 {schemeName} 图标");
        await SyncSingleIconAsync(schemeName, force: true);

        // 同步到 Scheme 模型
        var scheme = _schemeService.GetAllSchemes()
            .FirstOrDefault(s => s.Name.Equals(schemeName, StringComparison.OrdinalIgnoreCase));
        if (scheme != null)
        {
            var url = GetCachedIconUrl(schemeName);
            if (url != null)
            {
                _iconVersion++;
                scheme.CoverImageUrl = url;
            }
        }

        // 通知 UI 刷新
        SchemeIconsRefreshed?.Invoke();
    }

    // ================================================================
    //  同步逻辑
    // ================================================================

    private async Task SyncSingleIconAsync(string schemeName, bool force = false)
    {
        var cachePath = GetCachePath(schemeName);

        // 获取预签名 URL
        var presignedUrl = await FetchPresignedUrlAsync(schemeName);
        if (presignedUrl == null)
        {
            // 404 → 服务端无图标，删除本地缓存（如果存在）
            if (File.Exists(cachePath))
            {
                File.Delete(cachePath);
                System.Diagnostics.Debug.WriteLine(
                    $"[SchemeIconCacheService] 方案 {schemeName} 服务端无图标，已清除本地缓存");
            }
            // 同时清理临时明文文件
            try
            {
                var tempPath = GetTempPath(schemeName);
                if (File.Exists(tempPath)) File.Delete(tempPath);
            }
            catch { }
            return;
        }

        // 下载 + ETag 比对（force=true 时删除加密文件强制跳过 ETag 检查）
        if (force && File.Exists(cachePath))
            File.Delete(cachePath);
        var changed = await DownloadAndCacheAsync(presignedUrl, schemeName, cachePath);
        if (changed)
        {
            _iconVersion++;
            // 更新所有引用了此方案名实例的 CoverImageUrl
            InvalidateSchemeCache(schemeName);
            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 方案 {schemeName} 图标已更新");
        }
    }

    /// <summary>
    /// 获取预签名 URL。
    /// GET /api/scheme-urls/{key}/image → 302 → Location
    /// 该端点需要 [Authorize]，必须携带 Bearer Token。
    /// </summary>
    private async Task<string?> FetchPresignedUrlAsync(string schemeName)
    {
        // 确保 AccessToken 有效（过期时自动使用 RefreshToken 续期），检查返回值
        bool tokenValid = await _loginService.EnsureValidAccessTokenAsync();
        var accessToken = _loginService.AccessToken;

        if (!tokenValid || string.IsNullOrEmpty(accessToken))
        {
            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 跳过方案 {schemeName}: " +
                (_loginService.IsLoggedIn ? "AccessToken 刷新失败" : "用户未登录"));
            return null;
        }

        using var request = new HttpRequestMessage(
            HttpMethod.Get, $"{ApiBaseUrl}/api/scheme-urls/{schemeName}/image");
        request.Headers.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

        using var client = NetworkClientFactory.Create(allowAutoRedirect: false);
        client.Timeout = TimeSpan.FromSeconds(5);
        client.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");

        using var response = await client.SendAsync(request);

        if (response.StatusCode == System.Net.HttpStatusCode.Redirect)
        {
            var location = response.Headers.Location?.ToString();
            if (!string.IsNullOrEmpty(location))
                return location;

            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 方案 {schemeName} 302 无 Location 头");
            return null;
        }

        if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 方案 {schemeName} 无封面图标 (404)");
        }
        else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 方案 {schemeName} 认证失败 (401)，Token 可能已过期");
        }
        else
        {
            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 方案 {schemeName} 获取异常: HTTP {(int)response.StatusCode}");
        }

        return null;
    }

    /// <summary>
    /// 下载并缓存图标，ETag 版本比对（方案A：内容+ETag 合并加密单文件）。
    /// </summary>
    private async Task<bool> DownloadAndCacheAsync(string presignedUrl,
        string schemeName, string cachePath)
    {
        try
        {
            using var response = await _httpClient.GetAsync(presignedUrl,
                HttpCompletionOption.ResponseContentRead);

            if (!response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[SchemeIconCacheService] 下载 HTTP {(int)response.StatusCode}");
                return false;
            }

            // 提取 ETag
            string? serverEtag = null;
            if (response.Headers.ETag is { } etagHeader && etagHeader.Tag is { } tagValue)
            {
                serverEtag = tagValue.Trim('"');
            }

            // ETag 比对（仅当本地有加密缓存且 ETag 一致时跳过）
            if (serverEtag != null &&
                _secureCache.TryReadEnvelope(cachePath, out _, out var localEtag, out _) &&
                localEtag == serverEtag)
            {
                System.Diagnostics.Debug.WriteLine(
                    "[SchemeIconCacheService] ETag 一致，跳过下载");
                return false;
            }

            var imageBytes = await response.Content.ReadAsByteArrayAsync();

            // 加密写入（方案A：内容 + ETag 合并加密单文件，原子写入）
            _secureCache.SaveEnvelope(cachePath, imageBytes, serverEtag);

            // 解密到临时明文文件供 UI 加载
            _secureCache.DecryptToTempFile(cachePath, $"scheme_{schemeName}.png");

            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 已加密缓存 ({imageBytes.Length:N0} bytes)");
            return true;
        }
        catch (TaskCanceledException)
        {
            System.Diagnostics.Debug.WriteLine("[SchemeIconCacheService] 下载超时");
            return false;
        }
        catch (HttpRequestException ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 下载网络错误: {ex.Message}");
            return false;
        }
    }

    // ================================================================
    //  辅助方法
    // ================================================================

    /// <summary>
    /// 更新所有引用了此方案名实例的 CoverImageUrl 为最新版本（含 ?v=N 使 WinUI 缓存失效）。
    /// _iconVersion 已在调用方（SyncSingleIconAsync）中递增，此处不再重复操作。
    /// </summary>
    private void InvalidateSchemeCache(string schemeName)
    {
        foreach (var scheme in _schemeService.GetAllSchemes())
        {
            if (scheme.Name.Equals(schemeName, StringComparison.OrdinalIgnoreCase))
            {
                var url = GetCachedIconUrl(schemeName);
                if (url != null)
                {
                    scheme.CoverImageUrl = url;
                }
            }
        }
    }

    // ================================================================
    //  启动初始化
    // ================================================================

    /// <summary>
    /// 确保方案图标 API URL 注册键存在。
    /// </summary>
    public void EnsureSchemeApiUrlRecord()
    {
        try
        {
            var existing = _serverUrlService.GetByKey(SchemesApiUrlKey);
            if (existing != null) return;

            _serverUrlService.Register(
                key: SchemesApiUrlKey,
                displayName: "方案封面图标 API 服务地址",
                plainUrl: DefaultApiBaseUrl,
                category: "Infrastructure");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[SchemeIconCacheService] 注册方案图标 API URL 失败: {ex.Message}");
        }
    }

    // ================================================================
    //  IDisposable
    // ================================================================

    /// <summary>
    /// 释放服务（应用退出时由 Hosting 容器调用）。
    /// 释放 HttpClient 连接池，确保进程可完全退出。
    /// </summary>
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _httpClient.Dispose();
        GC.SuppressFinalize(this);
    }
}
