namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 导航服务接口 — 管理页面导航
/// </summary>
public interface INavigationService
{
    void NavigateTo<T>() where T : Microsoft.UI.Xaml.Controls.Page;
    void NavigateTo(Type pageType, object? parameter = null);
    void GoBack();
    bool CanGoBack { get; }
}
