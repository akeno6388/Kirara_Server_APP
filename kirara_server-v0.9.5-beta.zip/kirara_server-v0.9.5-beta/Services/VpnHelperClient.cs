using System.IO.Pipes;
using System.Text;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// KiraraVpnHelper 服务命名管道客户端。
/// 应用以普通权限运行，通过管道请求 LocalSystem 服务代启动 openvpn.exe，
/// 使 VPN 连接无需 UAC 提权。
/// 
/// 协议（每行一条命令，| 分隔）：
///   CONNECT|exePath|configPath|authPath|managementPort|logPath
///   DISCONNECT
///   STATUS
///   PING
/// 响应：
///   OK | ERROR|message | STATUS|...
/// </summary>
public static class VpnHelperClient
{
    /// <summary>管道名称（与服务端 PipeServer.PipeName 一致）</summary>
    public const string PipeName = "kirara-vpn";

    /// <summary>默认命令超时（毫秒）</summary>
    private const int DefaultTimeoutMs = 5000;

    /// <summary>
    /// 请求服务启动 openvpn 子进程。
    /// </summary>
    /// <param name="exePath">openvpn.exe 路径</param>
    /// <param name="configPath">.ovpn 配置路径</param>
    /// <param name="authFilePath">auth.txt 认证文件路径</param>
    /// <param name="managementPort">management 端口（应用侧 TcpListener）</param>
    /// <param name="logPath">openvpn 日志文件路径（--log）</param>
    /// <returns>null = 成功；否则返回错误信息</returns>
    public static async Task<string?> RequestConnectAsync(
        string exePath, string configPath, string authFilePath, int managementPort, string logPath)
    {
        var command = string.Join('|',
            "CONNECT", exePath, configPath, authFilePath, managementPort.ToString(), logPath);
        var response = await SendCommandAsync(command);
        return ParseOk(response);
    }

    /// <summary>
    /// 请求服务停止 openvpn 子进程（强制终止兜底）。
    /// </summary>
    public static async Task<string?> RequestDisconnectAsync()
    {
        var response = await SendCommandAsync("DISCONNECT");
        return ParseOk(response);
    }

    /// <summary>
    /// 查询服务端当前连接状态。
    /// </summary>
    /// <returns>null = 服务不可达；否则返回 STATUS|RUNNING|pid|config 或 STATUS|STOPPED</returns>
    public static async Task<string?> RequestStatusAsync()
    {
        return await SendCommandAsync("STATUS");
    }

    /// <summary>
    /// 探测服务是否可用（PING）。
    /// </summary>
    public static async Task<bool> IsServiceAvailableAsync()
    {
        var response = await SendCommandAsync("PING", timeoutMs: 2000);
        return response == "OK";
    }

    /// <summary>
    /// 发送单条命令并读取一行响应。
    /// </summary>
    private static async Task<string?> SendCommandAsync(string command, int timeoutMs = DefaultTimeoutMs)
    {
        try
        {
            await using var client = new NamedPipeClientStream(
                ".", PipeName, PipeDirection.InOut, PipeOptions.Asynchronous);

            using var cts = new CancellationTokenSource(timeoutMs);
            await client.ConnectAsync(cts.Token);

            // 无 BOM UTF-8（与 openvpn management 通信同一经验：BOM 会污染首条命令）
            var utf8NoBom = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false);
            // ⚠️ 必须 leaveOpen: true：StreamWriter.Dispose 默认会关闭底层 client 管道，
            //    导致写完命令后管道关闭，读取响应时抛 "Cannot access a closed pipe"
            await using (var writer = new StreamWriter(client, utf8NoBom, leaveOpen: true) { AutoFlush = true })
            {
                await writer.WriteLineAsync(command);
            }

            using var reader = new StreamReader(client, Encoding.UTF8);
            var response = await reader.ReadLineAsync(cts.Token);
            return response;
        }
        catch (OperationCanceledException)
        {
            return "ERROR|VPN Helper 服务响应超时";
        }
        catch (Exception ex)
        {
            // 连接失败 = 服务未运行/未安装
            return $"ERROR|VPN Helper 服务不可用（请确认已安装 KiraraVpnHelper 服务）: {ex.Message}";
        }
    }

    /// <summary>
    /// 解析响应：OK → null；ERROR|msg → msg。
    /// </summary>
    private static string? ParseOk(string? response)
    {
        if (response == "OK") return null;
        if (response != null && response.StartsWith("ERROR|", StringComparison.Ordinal))
        {
            return response.Substring("ERROR|".Length);
        }
        return response ?? "VPN Helper 服务无响应";
    }
}
