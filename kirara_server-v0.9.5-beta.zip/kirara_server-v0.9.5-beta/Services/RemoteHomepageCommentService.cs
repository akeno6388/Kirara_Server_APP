using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Models.Api;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 远程首页分享服务实现 — 通过 HTTP API 与远程服务器通信
/// 所有数据库操作均在服务端完成，客户端仅负责收发协议
/// </summary>
public class RemoteHomepageCommentService : IHomepageCommentService, IDisposable
{
    private readonly HttpClient _httpClient;
    private readonly ILoginService _loginService;
    private bool _disposed;

    /// <summary>API 基地址（生产环境）</summary>
    private const string ApiBaseUrl = "https://api.akeno6388.online:1010";

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public RemoteHomepageCommentService(ILoginService loginService)
    {
        _loginService = loginService;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.BaseAddress = new Uri(ApiBaseUrl);
        _httpClient.Timeout = TimeSpan.FromSeconds(30);
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
    }

    // ================================================================
    //  IHomepageCommentService 实现
    // ================================================================

    /// <inheritdoc />
    public async Task<IReadOnlyList<HomepageCommentItem>> GetHomepageCommentsAsync(
        int page = 1, int pageSize = 20)
    {
        try
        {
            var url = $"/api/homepage-comments?page={page}&pageSize={pageSize}";
            await AttachAuthHeaderAsync();

            var response = await _httpClient.GetAsync(url);
            var body = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine($"[HomepageCommentAPI] GET 失败: {response.StatusCode} - {body}");
                return Array.Empty<HomepageCommentItem>();
            }

            var apiResponse = JsonSerializer.Deserialize<ApiResponse<PagedResult<HomepageCommentResponse>>>(body, JsonOptions);
            if (apiResponse?.Success != true || apiResponse.Data?.Items == null)
                return Array.Empty<HomepageCommentItem>();

            return apiResponse.Data.Items.Select(MapToModel).ToList().AsReadOnly();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[HomepageCommentAPI] GET 异常: {ex.Message}");
            return Array.Empty<HomepageCommentItem>();
        }
    }

    /// <inheritdoc />
    public async Task<HomepageCommentItem> CreateHomepageCommentAsync(
        string resourceKey, Guid schemeId, Guid instanceId, string contentTitle, string sourceUrl, string content)
    {
        // v1.10 契约修正：instanceId/sourceUrl 不再发送（服务端不接收这两个字段）。
        // 定位信息（instanceId/contentTitle/sourceUrl）已由调用方编码进打包的 resourceKey 中
        // （格式 {key}||{instanceId}||{title}||{url}），读取时经 ResourceKeyPacker.Unpack() 还原。
        var payload = JsonSerializer.Serialize(new
        {
            resourceKey,
            schemeId,
            contentTitle,
            content
        });

        await AttachAuthHeaderAsync();
        var response = await _httpClient.PostAsync(
            "/api/homepage-comments",
            new StringContent(payload, Encoding.UTF8, "application/json"));

        var body = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            var error = TryParseError(body);
            throw new InvalidOperationException(error ?? $"创建首页分享失败: {response.StatusCode}");
        }

        var apiResponse = JsonSerializer.Deserialize<ApiResponse<HomepageCommentResponse>>(body, JsonOptions);
        if (apiResponse?.Success != true || apiResponse.Data == null)
            throw new InvalidOperationException("创建首页分享失败: 服务端返回异常");

        return MapToModel(apiResponse.Data);
    }

    /// <inheritdoc />
    public async Task<LikeResult> ToggleLikeAsync(Guid commentId)
    {
        await AttachAuthHeaderAsync();
        var response = await _httpClient.PostAsync(
            $"/api/homepage-comments/{commentId}/toggle-like", null);

        var body = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            var error = TryParseError(body);
            throw new InvalidOperationException(error ?? $"分享点赞操作失败: {response.StatusCode}");
        }

        var apiResponse = JsonSerializer.Deserialize<ApiResponse<LikeResult>>(body, JsonOptions);
        if (apiResponse?.Success != true || apiResponse.Data == null)
            throw new InvalidOperationException("分享点赞操作失败: 服务端返回异常");

        return apiResponse.Data;
    }

    // ================================================================
    //  私有辅助方法
    // ================================================================

    /// <summary>附加 JWT Bearer Token 认证头（自动续期）</summary>
    private async Task AttachAuthHeaderAsync()
    {
        await _loginService.EnsureValidAccessTokenAsync();

        var token = _loginService.AccessToken;
        if (!string.IsNullOrEmpty(token))
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);
        }
    }

    /// <summary>解析 API 错误响应中的 message 字段</summary>
    private static string? TryParseError(string body)
    {
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("error", out var error) &&
                error.TryGetProperty("message", out var msg))
                return msg.GetString();
        }
        catch { }
        return null;
    }

    /// <summary>将 API 响应 DTO 映射为客户端模型（从 resourceKey 中解包 instanceId/contentTitle/sourceUrl）</summary>
    private static HomepageCommentItem MapToModel(HomepageCommentResponse dto)
    {
        // 服务端未存储 instanceId/contentTitle/sourceUrl，它们被编码在 resourceKey 中
        var unpacked = Kirara_Server_WinUI.Helpers.ResourceKeyPacker.Unpack(dto.ResourceKey);

        return new HomepageCommentItem
        {
            Id = dto.Id,
            ResourceKey = unpacked.ResourceKey,
            SchemeId = dto.SchemeId,
            InstanceId = unpacked.InstanceId,
            ContentTitle = unpacked.ContentTitle,
            SourceUrl = unpacked.SourceUrl,
            Content = dto.Content,
            AuthorName = dto.AuthorName,
            AuthorUserId = dto.UserId,
            AuthorAvatarUrl = dto.AuthorAvatarUrl,
            LikeCount = dto.LikeCount,
            IsLikedByUser = dto.IsLikedByUser,
            CreatedAt = dto.CreatedAt
        };
    }

    // ================================================================
    //  IDisposable
    // ================================================================

    /// <summary>
    /// 释放服务（应用退出时由 Hosting 容器调用）。
    /// 释放 HttpClient 连接池，确保进程可完全退出。
    /// </summary>
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _httpClient.Dispose();
        GC.SuppressFinalize(this);
    }
}
