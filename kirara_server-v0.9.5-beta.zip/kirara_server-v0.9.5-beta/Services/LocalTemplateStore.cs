using System.Text.Json;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 模板列表本地持久化存储 — 将模板原始 DTO 缓存在加密 JSON 文件中。
///
/// ## 设计原则（与 LocalInfoCardStore 一致的范式）
/// - 存储原始 TemplateResponseData（完整 DTO，含 Version 字段）
/// - 存储路径：%APPDATA%/Kirara/templates.enc（方案A：内容+ETag 合并加密单文件，AES-256-GCM）
/// - 版本比对：启动时全量拉取服务端模板，按 Version 字段合并（新增/覆盖/移除）
/// - 仅在发生变更时写盘；无变更不写盘（避免无谓磁盘 IO）
/// - 冷启动离线降级：网络失败时直接使用本地缓存（秒显），不阻塞 UI
/// - 防篡改：任何对加密文件的修改都会导致 GCM 认证失败 → 解密失败 → 视为无缓存重新拉取
/// </summary>
public class LocalTemplateStore
{
    private static readonly string StoreFilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "templates" + SecureCacheService.EncryptedExtension);

    /// <summary>旧明文格式文件（升级遗留，首次访问时清理）</summary>
    private static readonly string LegacyStoreFilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "templates.json");

    private readonly SecureCacheService _secureCache;
    private readonly object _lock = new();

    public LocalTemplateStore(SecureCacheService secureCache)
    {
        _secureCache = secureCache;
    }

    /// <summary>
    /// 从本地文件加载已持久化的模板 DTO 列表。
    /// 解密失败（被篡改/损坏/旧明文格式）→ 视为无缓存，下次同步重新拉取。
    /// </summary>
    public List<TemplateResponseData> Load()
    {
        try
        {
            lock (_lock)
            {
                // 清理旧明文格式文件（升级遗留）
                CleanupLegacyFile();

                if (_secureCache.TryReadEnvelope(StoreFilePath, out var content, out _, out _))
                {
                    var json = System.Text.Encoding.UTF8.GetString(content);
                    var items = JsonSerializer.Deserialize<List<TemplateResponseData>>(json);
                    return items ?? new List<TemplateResponseData>();
                }
                return new List<TemplateResponseData>();
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalTemplateStore] 加载失败: {ex.Message}");
            return new List<TemplateResponseData>();
        }
    }

    /// <summary>
    /// 全量保存模板 DTO 列表到本地加密文件。
    /// </summary>
    public void SaveAll(List<TemplateResponseData> templates)
    {
        if (templates == null || templates.Count == 0)
        {
            Clear();
            return;
        }

        try
        {
            lock (_lock)
            {
                var json = JsonSerializer.Serialize(templates);
                _secureCache.SaveEnvelope(StoreFilePath,
                    System.Text.Encoding.UTF8.GetBytes(json));
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalTemplateStore] 保存失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 清除本地持久化的模板列表（直接删除加密文件）。
    /// </summary>
    public void Clear()
    {
        try
        {
            lock (_lock)
            {
                _secureCache.Delete(StoreFilePath);
                System.Diagnostics.Debug.WriteLine(
                    "[LocalTemplateStore] 本地模板缓存已清除");
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[LocalTemplateStore] 清除失败: {ex.Message}");
        }
    }

    /// <summary>清理旧明文 templates.json（升级遗留）</summary>
    private static void CleanupLegacyFile()
    {
        try
        {
            if (File.Exists(LegacyStoreFilePath))
                File.Delete(LegacyStoreFilePath);
        }
        catch { }
    }
}
