using Kirara_Server_WinUI.Views.Instance;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 方案宿主页全局缓存管理器
/// 确保切换实例时 WebView2 / RDP 等内容不销毁，保持 Cookie、缓存持久化
/// </summary>
public interface ISchemePageCache
{
    /// <summary>获取或创建指定实例-方案的宿主页（若已存在则复用）</summary>
    SchemeHostPage GetOrCreate(Guid instanceId, Guid schemeId);

    /// <summary>获取某实例下所有已缓存的方案页</summary>
    IReadOnlyDictionary<Guid, SchemeHostPage> GetInstancePages(Guid instanceId);

    /// <summary>挂起某实例的所有页面（隐藏，保留状态）</summary>
    void SuspendInstance(Guid instanceId);

    /// <summary>恢复某实例的页面（从挂起状态还原）</summary>
    void ResumeInstance(Guid instanceId);

    /// <summary>
    /// 获取指定实例-方案的 WebView2 用户数据目录代际号（0 = 默认路径）。
    /// 代际号由缓存层全局管理：初始化实例销毁页面后，新建页面仍能延续代际，
    /// 不会回退到已被异步清理的旧数据目录（防止复用旧 Cookie/表单状态导致"令牌秒链接"）。
    /// </summary>
    int GetGeneration(Guid instanceId, Guid schemeId);

    /// <summary>
    /// 升代并返回新代际号（首次升代为 1）。
    /// 初始化实例 / 方案硬重载时调用，确保后续创建 WebView2 使用干净数据目录。
    /// </summary>
    int BumpGeneration(Guid instanceId, Guid schemeId);

    /// <summary>销毁某实例的所有页面并清除磁盘用户数据（初始化/删除实例时调用）</summary>
    Task DestroyInstance(Guid instanceId);

    /// <summary>关闭某实例的所有页面，保留磁盘用户数据</summary>
    Task ShutdownInstance(Guid instanceId);

    /// <summary>
    /// 关闭当前缓存中所有实例的所有页面，保留磁盘用户数据。
    /// 退出登录时调用：等同关闭软件（WebView2 进程终止 + OpenVPN 断开），
    /// 但保留 Cookie/缓存供下次登录复用，且不删除磁盘数据。
    /// </summary>
    Task ShutdownAllInstancesAsync();

    /// <summary>销毁所有页面（应用退出时调用）</summary>
    void Shutdown();
}
