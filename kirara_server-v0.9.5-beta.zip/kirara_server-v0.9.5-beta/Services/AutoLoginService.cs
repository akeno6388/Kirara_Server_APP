using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;
using Microsoft.Web.WebView2.Core;
using Windows.Foundation;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 自动登录服务实现 — 封装 WebView2 自动登录的全部编排逻辑。
/// 所有方法接收 CoreWebView2 参数，自身不管理 WebView2 生命周期。
/// </summary>
public class AutoLoginService : IAutoLoginService
{
    public async Task<AutoLoginResult> ExecuteAutoLoginAsync(
        CoreWebView2 webView,
        Scheme scheme,
        SchemeBinding binding,
        Token token,
        IAutoLoginProvider loginProvider)
    {
        // ——— 步骤 0：等 URL 稳定（不再为 about:blank），检测通知/维护页面 ———
        await WaitForUrlSettledAsync(webView);

        if (await IsOnNoticePageAsync(webView, loginProvider))
        {
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 检测到通知页面，跳过自动登录: {scheme.Name}");
            return AutoLoginResult.NoticePage();
        }

        // ——— 步骤 0.1：快速轮询是否已登录（3 次 × 500ms，免 12s） ———
        if (await TryDetectAlreadyLoggedInAsync(webView, loginProvider))
        {
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 页面已登录（快速检测），跳过登录脚本: {scheme.Name}");
            return AutoLoginResult.Handled("界面加载完成");
        }

        // 等待页面 SPA 框架渲染完成（仅在未登录时运行）
        await WaitForPageReadyAsync(webView, loginProvider);

        // ——— 步骤 0.5：二次检查（SPA 渲染后可能才出现桌面 DOM） ———
        if (await IsAlreadyOnSuccessPageAsync(webView, loginProvider))
        {
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 页面已登录（二次检查），跳过: {scheme.Name}");
            return AutoLoginResult.Handled("界面加载完成");
        }

        // ——— 步骤0.6：方案要求延迟到工作区登录（IMM 等加载极慢的方案） ———
        if (loginProvider.DeferLoginToWorkspace)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 方案延迟到工作区登录: {scheme.Name}");
            return AutoLoginResult.WorkspacePending();
        }

        // ——— 步骤1：执行预登录脚本（如有） ———
        var preScript = loginProvider.GetPreLoginScript(token);
        if (!string.IsNullOrEmpty(preScript))
        {
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 执行预登录脚本: {scheme.Name}");
            var preResult = await webView.ExecuteScriptAsync(preScript);
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 预登录结果: {preResult}");

            // 预登录脚本没找到按钮，检查是否已在成功页
            if (preResult?.Trim('"') == "no_btn")
            {
                // [修复] 等待窗口：SPA 路由切换/重渲染期间成功特征可能延迟出现
                // （cookie 有效场景：URL 停留登录形态但成功 DOM 已渲染），
                // 命中即判定已登录，避免后续主登录脚本找不到表单而失败。
                if (await WaitForSuccessFeatureAsync(webView, loginProvider, TimeSpan.FromSeconds(5)))
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[AutoLogin] 预登录无按钮但页面已登录（等待窗口命中）: {scheme.Name}");
                    return AutoLoginResult.Handled("界面加载完成");
                }
            }

            // 等待动画/DOM 过渡
            await Task.Delay(loginProvider.PreLoginDelayMs);

            // 密码页方案：预加载只填用户名+点击，工作区执行密码阶段
            if (!string.IsNullOrEmpty(loginProvider.PasswordPageDomSelector))
            {
                // 重试一次点击：React state 首次 dispatch 后生效
                await Task.Delay(500);
                var retryResult = await webView.ExecuteScriptAsync(preScript);
                System.Diagnostics.Debug.WriteLine(
                    $"[AutoLogin] 重试预登录: {retryResult}");

                System.Diagnostics.Debug.WriteLine(
                    $"[AutoLogin] 密码页方案：预加载完成，留待工作区执行密码阶段");
                return AutoLoginResult.WorkspacePending();
            }
        }

        // ——— 步骤2：正常路径 — 注册导航监听 + 注入主登录脚本 ———
        var script = loginProvider.GetAutoLoginScript(token);
        if (string.IsNullOrEmpty(script))
        {
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 方案 {scheme.Name} 返回空脚本（凭据不完整或方案不支持）");
            return AutoLoginResult.Failed("令牌链接失败");
        }

        bool isSingleStep = string.IsNullOrEmpty(loginProvider.PasswordPageDomSelector)
            && !loginProvider.DeferLoginToWorkspace;

        var navTcs = new TaskCompletionSource<bool>();
        Windows.Foundation.TypedEventHandler<CoreWebView2, CoreWebView2NavigationCompletedEventArgs>? navHandler = null;
        navHandler = (_, e) =>
        {
            webView.NavigationCompleted -= navHandler;
            navTcs.TrySetResult(e.IsSuccess);
        };
        webView.NavigationCompleted += navHandler;

        System.Diagnostics.Debug.WriteLine(
            $"[AutoLogin] 注入登录脚本: {scheme.Name}");
        var scriptResult = await webView.ExecuteScriptAsync(script);
        System.Diagnostics.Debug.WriteLine(
            $"[AutoLogin] 登录脚本结果: {scriptResult}");

        // 如果脚本没找到表单且已在成功页，直接成功
        if (scriptResult?.Trim('"') == "no_form")
        {
            webView.NavigationCompleted -= navHandler;

            // [v2.6] no_form 恢复窗口：点击"手动登录"等展开类操作后表单可能延迟出现
            // （React 渲染数百 ms~数秒，v2.5 固定 PreLoginDelayMs 不够），轮询等待：
            //   ① 成功特征出现（已登录）→ 直接成功
            //   ② 登录表单出现（可见）→ 重新注入登录脚本（重新等待登录成功）
            // 超时（8s）→ 失败。
            var formSelector = loginProvider.LoginFormDomSelector
                ?? loginProvider.PageReadyDomSelector
                ?? loginProvider.PasswordPageDomSelector;

            var deadline = DateTime.UtcNow.AddSeconds(8);
            while (DateTime.UtcNow < deadline)
            {
                // ① 已登录 → 成功
                if (await IsAlreadyOnSuccessPageAsync(webView, loginProvider))
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[AutoLogin] 表单未找到但已检测到登录成功（等待窗口命中）: {scheme.Name}");
                    return AutoLoginResult.Handled("令牌已链接");
                }

                // ② 表单出现且可见 → 重试注入登录脚本
                if (!string.IsNullOrEmpty(formSelector)
                    && await DomQueryVisibilityAsync(webView, formSelector) == "visible")
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[AutoLogin] 登录表单已出现（等待窗口命中），重试登录脚本: {scheme.Name}");

                    // 重新注册导航监听
                    var navTcs2 = new TaskCompletionSource<bool>();
                    Windows.Foundation.TypedEventHandler<CoreWebView2, CoreWebView2NavigationCompletedEventArgs>? navH2 = null;
                    navH2 = (_, e) =>
                    {
                        webView.NavigationCompleted -= navH2;
                        navTcs2.TrySetResult(e.IsSuccess);
                    };
                    webView.NavigationCompleted += navH2;

                    var retryResult = await webView.ExecuteScriptAsync(script);
                    System.Diagnostics.Debug.WriteLine(
                        $"[AutoLogin] 重试登录脚本结果: {retryResult}");

                    if (retryResult?.Trim('"') != "no_form")
                    {
                        // 重试成功 → 走等待登录成功流程
                        await WaitForLoginSuccessAsync(webView, loginProvider, navTcs2, TimeSpan.FromSeconds(8));
                        webView.NavigationCompleted -= navH2;

                        // 额外等待（用于页面加载极慢的方案）
                        var postDelay = loginProvider.PostLoginDelayMs;
                        if (postDelay > 0)
                        {
                            System.Diagnostics.Debug.WriteLine(
                                $"[AutoLogin] 重试后等待方案自定义延迟: {postDelay}ms");
                            await Task.Delay(postDelay);
                        }

                        var retrySuccess = await DetectLoginSuccessAsync(webView, loginProvider);
                        System.Diagnostics.Debug.WriteLine(
                            $"[AutoLogin] 重试后登录检测结果: {scheme.Name}, success={retrySuccess}");

                        if (isSingleStep)
                            return AutoLoginResult.Handled(retrySuccess ? "界面加载完成" : "令牌链接失败");
                        return retrySuccess ? AutoLoginResult.WorkspacePending() : AutoLoginResult.Failed("令牌链接失败");
                    }

                    // 仍 no_form → 继续循环等待（表单可能又被收起）
                    webView.NavigationCompleted -= navH2;
                }

                await Task.Delay(300);
            }

            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 表单未找到且不在成功页: {scheme.Name}");
            return AutoLoginResult.Failed("令牌链接失败");
        }

        // 单步方案立即报告"令牌已链接"
        if (isSingleStep)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 单步方案已上报令牌已链接: {scheme.Name}");
        }

        // [修复] 等待导航完成或成功特征命中（事件驱动 + 轮询）：SPA 登录不触发 NavigationCompleted，
        // 成功特征（URL/DOM）出现即提前返回，避免登录成功后阻塞约 5~8s。
        await WaitForLoginSuccessAsync(webView, loginProvider, navTcs, TimeSpan.FromSeconds(8));
        webView.NavigationCompleted -= navHandler;

        // 额外等待（用于页面加载极慢的方案）
        var postLoginDelay = loginProvider.PostLoginDelayMs;
        if (postLoginDelay > 0)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 等待方案自定义延迟: {postLoginDelay}ms");
            await Task.Delay(postLoginDelay);
        }

        // 检测登录是否成功
        var success = await DetectLoginSuccessAsync(webView, loginProvider);
        System.Diagnostics.Debug.WriteLine(
            $"[AutoLogin] 登录检测结果: {scheme.Name}, success={success}");

        if (isSingleStep)
        {
            return AutoLoginResult.Handled(success ? "界面加载完成" : "令牌链接失败");
        }
        else
        {
            return success ? AutoLoginResult.WorkspacePending() : AutoLoginResult.Failed("令牌链接失败");
        }
    }

    public async Task<AutoLoginResult> ExecuteWorkspaceLoginAsync(
        CoreWebView2 webView,
        Scheme scheme,
        SchemeBinding binding,
        Token token,
        IAutoLoginProvider loginProvider)
    {
        // 必须：有 PasswordPageDomSelector（DSM 式）或 DeferLoginToWorkspace（IMM 式）
        if (string.IsNullOrEmpty(loginProvider.PasswordPageDomSelector)
            && !loginProvider.DeferLoginToWorkspace)
            return AutoLoginResult.Failed("令牌链接失败");

        var script = loginProvider.GetAutoLoginScript(token);
        if (string.IsNullOrEmpty(script))
            return AutoLoginResult.Failed("令牌链接失败");

        try
        {
            // 等待页面就绪：优先密码框选择器，回退到页面就绪选择器
            var waitSelector = loginProvider.PasswordPageDomSelector
                ?? loginProvider.PageReadyDomSelector;
            if (!string.IsNullOrEmpty(waitSelector))
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[WSL] 等待页面就绪: {waitSelector}");
                await WaitForPageReadyAsync(webView, loginProvider,
                    overrideDomSelector: waitSelector);
            }

            // 注册导航监听（须在点击/提交之前）
            var navTcs = new TaskCompletionSource<bool>();
            Windows.Foundation.TypedEventHandler<CoreWebView2, CoreWebView2NavigationCompletedEventArgs>? navH = null;
            navH = (_, e) =>
            {
                webView.NavigationCompleted -= navH;
                navTcs.TrySetResult(e.IsSuccess);
            };
            webView.NavigationCompleted += navH;

            if (!string.IsNullOrEmpty(loginProvider.PasswordPageDomSelector))
            {
                // === DSM 路径：先注入密码脚本，等 React 处理后再点击 ===
                System.Diagnostics.Debug.WriteLine("[WSL] 密码框已出现，注入密码脚本");
                var pwResult = await webView.ExecuteScriptAsync(script);
                System.Diagnostics.Debug.WriteLine(
                    $"[WSL] 密码脚本结果: {pwResult}");

                // 等 React 处理 state，然后点击
                await Task.Delay(500);
                System.Diagnostics.Debug.WriteLine("[WSL] 点击登录按钮");
                await webView.ExecuteScriptAsync(
                    "(function(){var b=document.querySelector('[syno-id=\"password-panel-next-btn\"]');if(b)b.click();})();");
            }
            else
            {
                // === IMM 路径：脚本自身含账密填写 + 点击 ===
                System.Diagnostics.Debug.WriteLine("[WSL] 注入登录脚本（含账密填写+点击）");
                var loginResult = await webView.ExecuteScriptAsync(script);
                System.Diagnostics.Debug.WriteLine(
                    $"[WSL] 登录脚本结果: {loginResult}");
            }

            // [修复] 并行等待导航完成与成功特征（事件驱动 + 轮询）：DSM 等 SPA 登录成功
            // 不触发 NavigationCompleted，成功特征（#sds-desktop / personal_space / .synofoto-menu-button）
            // 出现即提前返回，遮罩不再被阻塞约 5~10s。
            await WaitForLoginSuccessAsync(webView, loginProvider, navTcs, TimeSpan.FromSeconds(10));
            webView.NavigationCompleted -= navH;

            // 加载极慢方案的额外缓冲（IMM PostLoginDelayMs）
            var postDelay = loginProvider.PostLoginDelayMs;
            if (postDelay > 0)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[WSL] 等待方案自定义延迟: {postDelay}ms");
                await Task.Delay(postDelay);
            }

            var success = await DetectLoginSuccessAsync(webView, loginProvider);
            System.Diagnostics.Debug.WriteLine(
                $"[WSL] 登录检测结果: {scheme.Name}, success={success}");
            return success ? AutoLoginResult.Handled("界面加载完成") : AutoLoginResult.Failed("令牌链接失败");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[WSL] 失败: {ex.Message}");
            return AutoLoginResult.Failed("令牌链接失败");
        }
    }

    public async Task WaitForPageLoadCompleteAsync(CoreWebView2 webView)
    {
        var deadline = DateTime.UtcNow.AddSeconds(10);

        System.Diagnostics.Debug.WriteLine("[SchemeHost] 等待页面加载完成...");
        while (DateTime.UtcNow < deadline)
        {
            try
            {
                var state = await webView.ExecuteScriptAsync("document.readyState");
                if (state?.Trim('"') == "complete")
                {
                    await Task.Delay(400);
                    System.Diagnostics.Debug.WriteLine("[SchemeHost] 页面加载完成 (readyState=complete)");
                    return;
                }
            }
            catch { }
            await Task.Delay(300);
        }

        System.Diagnostics.Debug.WriteLine("[SchemeHost] 页面加载等待超时（10s）");
    }

    /// <summary>
    /// 等待登录成功（事件驱动 + 轮询兜底）：
    /// - NavigationCompleted：整页跳转完成（如 Alist 登录后 redirect 整页跳转）
    /// - SourceChanged：SPA hash/pushState 路由变化（DSM external_login、Alist 等 SPA 登录的即时唤醒）
    /// - 成功特征轮询：LoginSuccessUrlFragment / LoginSuccessDomSelector 命中
    /// 任一命中即返回；超时兜底。
    /// [修复] SPA 登录成功不触发 NavigationCompleted，旧实现仅靠 navTcs 会阻塞约 5~10s
    /// （登录成功进入界面后遮罩迟迟不消失）。成功特征出现即可提前返回。
    /// </summary>
    private async Task WaitForLoginSuccessAsync(
        CoreWebView2 webView,
        IAutoLoginProvider loginProvider,
        TaskCompletionSource<bool> navTcs,
        TimeSpan timeout)
    {
        var deadline = DateTime.UtcNow + timeout;
        var navTask = navTcs.Task;

        // SourceChanged 事件：SPA 路由变化（hash/pushState）的即时唤醒信号
        var sourceChangedTcs = new TaskCompletionSource<bool>();
        Windows.Foundation.TypedEventHandler<CoreWebView2, CoreWebView2SourceChangedEventArgs>? srcH = null;
        srcH = (_, _) => sourceChangedTcs.TrySetResult(true);
        webView.SourceChanged += srcH;

        try
        {
            while (DateTime.UtcNow < deadline)
            {
                // 整页导航完成 → 返回（成功与否由后续 DetectLoginSuccessAsync 判定）
                if (navTask.IsCompleted)
                    return;

                // SPA 路由变化（可能登录成功跳转）→ 立即做一次成功检测
                if (sourceChangedTcs.Task.IsCompleted)
                {
                    if (await IsAlreadyOnSuccessPageAsync(webView, loginProvider))
                        return;
                }

                // 常规轮询：成功特征命中即返回（登录成功但无路由事件时的兜底）
                if (await IsAlreadyOnSuccessPageAsync(webView, loginProvider))
                    return;

                await Task.Delay(300);
            }

            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 等待登录成功超时（{timeout.TotalSeconds:0}s），继续流程");
        }
        finally
        {
            webView.SourceChanged -= srcH;
        }
    }

    public async Task PollLoginSuccessDomAsync(CoreWebView2 webView, IAutoLoginProvider loginProvider)
    {
        var domSelector = loginProvider.LoginSuccessDomSelector;
        if (string.IsNullOrEmpty(domSelector)) return;

        var escapedSelector = domSelector.Replace("\\", "\\\\").Replace("\"", "\\\"");
        var deadline = DateTime.UtcNow.AddSeconds(10);

        System.Diagnostics.Debug.WriteLine(
            $"[SchemeHost] 等待登录成功 DOM: {domSelector}");
        while (DateTime.UtcNow < deadline)
        {
            try
            {
                var checkScript = $$"""
                    (() => {
                        try {
                            const el = document.querySelector("{{escapedSelector}}");
                            return el ? 'found' : 'not_found';
                        } catch(e) { return 'error'; }
                    })();
                    """;
                var result = await webView.ExecuteScriptAsync(checkScript);
                if (result?.Trim('"') == "found")
                {
                    await Task.Delay(400);
                    System.Diagnostics.Debug.WriteLine(
                        $"[SchemeHost] 登录成功 DOM 已出现: {domSelector}");
                    return;
                }
            }
            catch { }
            await Task.Delay(400);
        }

        System.Diagnostics.Debug.WriteLine(
            $"[SchemeHost] 登录成功 DOM 等待超时（10s）");
    }

    // ========== 私有辅助方法 ==========

    /// <summary>
    /// 查询 DOM 中是否存在匹配选择器的元素（异常安全，返回 false）。
    /// 所有检测共用的脚本注入点，避免重复代码。
    /// </summary>
    private static async Task<bool> DomQueryExistsAsync(CoreWebView2 webView, string selector)
    {
        var escapedSelector = selector.Replace("\\", "\\\\").Replace("\"", "\\\"");
        var checkScript = $$"""
            (() => {
                try {
                    const el = document.querySelector("{{escapedSelector}}");
                    return el ? 'found' : 'not_found';
                } catch(e) { return 'error'; }
            })();
            """;
        try
        {
            var result = await webView.ExecuteScriptAsync(checkScript);
            return result?.Trim('"') == "found";
        }
        catch { return false; }
    }

    /// <summary>
    /// 查询 DOM 元素的三态可见性状态：
    /// - "visible"   → 元素存在且可见（getClientRects 非空）
    /// - "hidden"    → 元素存在但不可见（display:none 等，getClientRects 为空）
    /// - "not_found" → 元素不存在
    /// - "error"     → 脚本异常
    /// [v2.2] 用于登录表单判据：Jellyfin 登录成功后将登录表单隐藏（display:none）
    /// 而非从 DOM 移除，仅做存在性检测会把成功页误判为"仍在登录页"。
    /// </summary>
    private static async Task<string> DomQueryVisibilityAsync(CoreWebView2 webView, string selector)
    {
        var escapedSelector = selector.Replace("\\", "\\\\").Replace("\"", "\\\"");
        var checkScript = $$"""
            (() => {
                try {
                    const el = document.querySelector("{{escapedSelector}}");
                    if (!el) return 'not_found';
                    return el.getClientRects().length > 0 ? 'visible' : 'hidden';
                } catch(e) { return 'error'; }
            })();
            """;
        try
        {
            var result = await webView.ExecuteScriptAsync(checkScript);
            return result?.Trim('"') ?? "error";
        }
        catch { return "error"; }
    }

    /// <summary>
    /// 等待登录成功特征出现（轮询 IsAlreadyOnSuccessPageAsync，DOM 优先判据）。
    /// 用于脚本报 no_form / no_btn 后的恢复窗口：SPA 路由切换/重渲染期间
    /// 成功特征可能延迟出现（cookie 有效场景：登录页 URL 停留 + 成功 DOM 已渲染），
    /// 命中即表示页面实际已登录。
    /// </summary>
    /// <returns>true=在超时前检测到已登录；false=超时未命中</returns>
    private async Task<bool> WaitForSuccessFeatureAsync(
        CoreWebView2 webView, IAutoLoginProvider loginProvider, TimeSpan timeout)
    {
        var deadline = DateTime.UtcNow + timeout;
        while (DateTime.UtcNow < deadline)
        {
            if (await IsAlreadyOnSuccessPageAsync(webView, loginProvider))
                return true;
            await Task.Delay(250);
        }
        return false;
    }

    /// <summary>快速轮询检测是否已登录（4 次 × 500ms）</summary>
    private async Task<bool> TryDetectAlreadyLoggedInAsync(CoreWebView2 webView, IAutoLoginProvider loginProvider)
    {
        for (int i = 0; i < 4; i++)
        {
            if (await IsAlreadyOnSuccessPageAsync(webView, loginProvider))
                return true;
            if (i < 3) await Task.Delay(500);
        }
        return false;
    }

    /// <summary>检查当前 URL 是否命中通知/维护页面特征</summary>
    private async Task<bool> IsOnNoticePageAsync(CoreWebView2 webView, IAutoLoginProvider loginProvider)
    {
        var noticeFragment = loginProvider.NoticeUrlFragment;
        if (string.IsNullOrEmpty(noticeFragment))
            return false;

        var url = await GetCurrentUrlAsync(webView);
        if (url.Contains(noticeFragment, StringComparison.OrdinalIgnoreCase))
        {
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 命中通知页特征: {noticeFragment}, url={url}");
            return true;
        }

        System.Diagnostics.Debug.WriteLine(
            $"[AutoLogin] 非通知页: {url}");
        return false;
    }

    /// <summary>
    /// 获取当前页面完整 URL（含 URL fragment/hash）。
    /// 优先通过 JS 读取 location.href —— CoreWebView2.Source 对 SPA hash 路由
    /// （如 DSM 登录页 #/signin）的反映不可靠，会导致 URL 特征检测（LoginPageUrlFragment 等）失效。
    /// 典型场景：Synology external_login 模式登录页同时含 query（launchApp=...）与 hash（#/signin），
    /// Source 可能只返回 query 部分 → 反向排除不生效 → 登录页被误判已登录。
    /// </summary>
    private static async Task<string> GetCurrentUrlAsync(CoreWebView2 webView)
    {
        try
        {
            var result = await webView.ExecuteScriptAsync("location.href");
            var url = result?.Trim('"');
            if (!string.IsNullOrEmpty(url) && url != "null" && url != "about:blank")
                return url;
        }
        catch { }
        return webView.Source ?? "";
    }

    /// <summary>等待 CoreWebView2.Source 不再是 about:blank</summary>
    private async Task WaitForUrlSettledAsync(CoreWebView2 webView)
    {
        for (int i = 0; i < 20; i++)
        {
            var url = webView.Source ?? "";
            if (!string.IsNullOrEmpty(url) && url != "about:blank")
            {
                await Task.Delay(500);
                System.Diagnostics.Debug.WriteLine(
                    $"[AutoLogin] URL 已稳定: {webView.Source}");
                return;
            }
            await Task.Delay(200);
        }

        System.Diagnostics.Debug.WriteLine("[AutoLogin] URL 稳定等待超时（4s）");
    }

    /// <summary>
    /// 检查当前页面是否已处于登录成功状态。
    /// 判据优先级（v2.4 实测校准，从可靠到兜底）：
    ///   1. 登录表单 DOM 可见 → 未登录（显式 LoginFormDomSelector；页面真实显示登录表单，最本质）
    ///   2. URL 正向特征（登录成功 URL 精确片段）→ 已登录（路由最终状态；显式表单 DOM 未渲染时不可信）
    ///   3. 登录表单 DOM 可见 → 未登录（回退 PageReadyDomSelector；仅当未显式设置时，兼容 Alist 等）
    ///   4. URL 反向排除（登录页 URL 特征）→ 未登录（表单折叠期兜底）
    ///   5. 登录表单 DOM 隐藏且方案声明 → 已登录（成功页残留隐藏表单=成功特征，Jellyfin）
    ///   6. 成功 DOM 存在 → 已登录（最弱正向确认，最后）
    /// [v2.4 实测] Jellyfin 的 URL 无法区分登录状态：未登录访问 #/home.html 路由时 SPA 先渲染
    /// 登录视图（#txtManualName 可见），hash 重定向是异步的；且 SPA 加载早期 URL 已是成功路由
    /// 而 DOM 尚未渲染（#txtManualName not_found）——此时 URL 正向命中会假阳性短路。
    /// 因此：显式表单选择器存在但 DOM 未渲染（not_found）时，URL 正向判据不可信（等待 DOM 渲染）；
    /// Media 方案已彻底放弃 LoginSuccessUrlFragment（null）。
    /// [v2.3] 显式 LoginFormDomSelector 时"表单可见"优先于 URL 正向（修复 Jellyfin 竞态短路）。
    /// [Alist 例外] @manage 个人资料页有【可见】的 username 输入框——不显式设置
    /// LoginFormDomSelector，走判据 3 回退（位于 URL 正向之后），登录判据完全依赖 URL。
    /// [v2.2] 可见性三态（getClientRects）解决 Jellyfin 成功页残留隐藏表单。
    /// [历史] URL 反向一票否决（v2.0）误伤 cookie 竞态；成功 DOM 优先于 URL 反向（v2.1）交集短路。
    /// </summary>
    private async Task<bool> IsAlreadyOnSuccessPageAsync(CoreWebView2 webView, IAutoLoginProvider loginProvider)
    {
        var loginFormSelector = loginProvider.LoginFormDomSelector;
        var fallbackFormSelector = loginProvider.PageReadyDomSelector
            ?? loginProvider.PasswordPageDomSelector;

        // 显式登录表单选择器的可见性状态（一次性查询，判据 1/2/5 复用）
        string? explicitVisibility = null;
        if (!string.IsNullOrEmpty(loginFormSelector))
        {
            explicitVisibility = await DomQueryVisibilityAsync(webView, loginFormSelector);

            // ——— 判据 1：显式登录表单 DOM 可见 → 仍在登录页 → 未登录 ———
            // 优先于 URL 正向：页面真实显示登录表单时 URL 不可信
            // （Jellyfin 未登录访问 #/home.html 的竞态窗口）。
            if (explicitVisibility == "visible")
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[AutoLogin] 已登录检测：登录表单 '{loginFormSelector}' 可见，仍在登录页");
                return false;
            }
        }

        // ——— 判据 2：URL 正向特征（登录成功 URL 精确片段）→ 已登录 ———
        // [v2.4] 显式表单选择器存在但 DOM 未渲染（not_found）时 URL 不可信：
        // SPA 加载早期 URL 已是成功路由而 DOM 尚未渲染，此时命中会假阳性短路。
        var urlFragment = loginProvider.LoginSuccessUrlFragment;
        if (!string.IsNullOrEmpty(urlFragment))
        {
            var url = await GetCurrentUrlAsync(webView);
            if (url.Contains(urlFragment, StringComparison.OrdinalIgnoreCase))
            {
                if (explicitVisibility == "not_found")
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[AutoLogin] URL 命中 '{urlFragment}' 但登录表单 DOM 未渲染，暂不判定（等 DOM 渲染）: {url}");
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[AutoLogin] 已登录（URL 匹配）: {urlFragment}, url={url}");
                    return true;
                }
            }
        }

        // ——— 判据 3：回退登录表单 DOM 可见 → 未登录 ———
        // 仅当方案未显式设置 LoginFormDomSelector（如 Alist：@manage 页有可见的
        // username 输入框，不能提升优先级，否则已登录被误判为未登录）。
        if (string.IsNullOrEmpty(loginFormSelector) && !string.IsNullOrEmpty(fallbackFormSelector))
        {
            var visibility = await DomQueryVisibilityAsync(webView, fallbackFormSelector);
            if (visibility == "visible")
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[AutoLogin] 已登录检测：登录表单（回退）'{fallbackFormSelector}' 可见，仍在登录页");
                return false;
            }
        }

        // ——— 判据 4：URL 反向排除（登录页 URL 特征）→ 未登录 ———
        // 表单折叠期兜底（登录页表单未展开时不可见，不能靠判据 1/3）。
        var loginPageFragment = loginProvider.LoginPageUrlFragment;
        if (!string.IsNullOrEmpty(loginPageFragment))
        {
            var url = await GetCurrentUrlAsync(webView);
            if (url.Contains(loginPageFragment, StringComparison.OrdinalIgnoreCase))
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[AutoLogin] 已登录检测：URL 含登录页特征 '{loginPageFragment}', url={url}");
                return false;
            }
        }

        // ——— 判据 5：登录表单隐藏且方案声明 → 已登录 ———
        // Jellyfin 成功页残留 display:none 的登录表单：存在但不可见 = 成功页独特特征。
        if (loginProvider.HiddenLoginFormIndicatesLoggedIn && explicitVisibility == "hidden")
        {
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 已登录（登录表单隐藏残留）: {loginFormSelector}");
            return true;
        }

        // ——— 判据 6：成功 DOM 存在 → 已登录 ———
        // 最弱的正向确认，仅在 URL 无任何特征且表单无残留时兜底。
        var domSelector = loginProvider.LoginSuccessDomSelector;
        if (!string.IsNullOrEmpty(domSelector))
        {
            if (await DomQueryExistsAsync(webView, domSelector))
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[AutoLogin] 已登录（DOM 匹配）: {domSelector}");
                return true;
            }
        }

        return false;
    }

    /// <summary>等待页面 DOM 就绪</summary>
    private async Task WaitForPageReadyAsync(CoreWebView2 webView, IAutoLoginProvider? loginProvider = null,
        string? overrideDomSelector = null)
    {
        var domSelector = overrideDomSelector ?? loginProvider?.PageReadyDomSelector;

        if (!string.IsNullOrEmpty(domSelector))
        {
            var escapedSelector = domSelector.Replace("\\", "\\\\").Replace("\"", "\\\"");
            var pollScript = $"(function(){{var e=document.querySelector(\"{escapedSelector}\");return e?'found':'wait';}})();";

            for (int i = 0; i < 60; i++)
            {
                try
                {
                    var result = await webView.ExecuteScriptAsync(pollScript);
                    if (result?.Trim('"') == "found")
                    {
                        System.Diagnostics.Debug.WriteLine(
                            $"[AutoLogin] SPA 就绪 (DOM '{domSelector}' 已出现, 耗时约 {i * 200}ms)");
                        await Task.Delay(300);
                        return;
                    }
                }
                catch { }
                await Task.Delay(200);
            }

            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] DOM 等待超时 ({domSelector}，12s)，继续执行");
            return;
        }

        // 回退：轮询 document.readyState
        for (int i = 0; i < 30; i++)
        {
            try
            {
                var state = await webView.ExecuteScriptAsync("document.readyState");
                var ready = state?.Trim('"');
                if (ready == "complete" || ready == "interactive")
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[AutoLogin] DOM 就绪 (readyState={ready}, 耗时约 {i * 200}ms)");
                    await Task.Delay(500);
                    return;
                }
            }
            catch { }
            await Task.Delay(200);
        }

        System.Diagnostics.Debug.WriteLine(
            "[AutoLogin] DOM 等待超时（6s），继续执行");
    }

    /// <summary>
    /// 检测登录是否成功（与 IsAlreadyOnSuccessPageAsync 同判据顺序）。
    /// [v2.4] 显式表单选择器 DOM 未渲染（not_found）时 URL 正向不可信（SPA 加载早期
    /// URL 已是成功路由而 DOM 未渲染）；Media 已放弃 LoginSuccessUrlFragment（null）。
    /// </summary>
    private async Task<bool> DetectLoginSuccessAsync(CoreWebView2 webView, IAutoLoginProvider loginProvider)
    {
        var urlFragment = loginProvider.LoginSuccessUrlFragment;
        var domSelector = loginProvider.LoginSuccessDomSelector;
        var loginFormSelector = loginProvider.LoginFormDomSelector;
        var fallbackFormSelector = loginProvider.PageReadyDomSelector
            ?? loginProvider.PasswordPageDomSelector;

        // 无任何正向判据时信任脚本执行成功（保持原行为）
        if (string.IsNullOrEmpty(urlFragment) && string.IsNullOrEmpty(domSelector)
            && !loginProvider.HiddenLoginFormIndicatesLoggedIn)
            return true;

        // 显式登录表单选择器的可见性状态（一次性查询，判据 1/2/5 复用）
        string? explicitVisibility = null;
        if (!string.IsNullOrEmpty(loginFormSelector))
        {
            explicitVisibility = await DomQueryVisibilityAsync(webView, loginFormSelector);

            // ——— 判据 1：显式登录表单 DOM 可见 → 仍未登录 ———
            if (explicitVisibility == "visible")
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[AutoLogin] DetectLoginSuccess: 登录表单 '{loginFormSelector}' 可见，判定未登录");
                return false;
            }
        }

        try
        {
            // ——— 判据 2：URL 正向特征（路由最终状态） ———
            // [v2.4] 显式表单 DOM 未渲染（not_found）时 URL 不可信，不短路。
            if (!string.IsNullOrEmpty(urlFragment))
            {
                var currentUrl = await GetCurrentUrlAsync(webView);
                if (currentUrl.Contains(urlFragment, StringComparison.OrdinalIgnoreCase))
                {
                    if (explicitVisibility == "not_found")
                    {
                        System.Diagnostics.Debug.WriteLine(
                            $"[AutoLogin] DetectLoginSuccess: URL 命中 '{urlFragment}' 但登录表单 DOM 未渲染，暂不判定");
                    }
                    else
                    {
                        System.Diagnostics.Debug.WriteLine(
                            $"[AutoLogin] URL 匹配成功: {urlFragment}");
                        return true;
                    }
                }
            }

            // ——— 判据 3：回退登录表单 DOM 可见 → 仍未登录 ———
            if (string.IsNullOrEmpty(loginFormSelector) && !string.IsNullOrEmpty(fallbackFormSelector))
            {
                var visibility = await DomQueryVisibilityAsync(webView, fallbackFormSelector);
                if (visibility == "visible")
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[AutoLogin] DetectLoginSuccess: 登录表单（回退）'{fallbackFormSelector}' 可见，判定未登录");
                    return false;
                }
            }

            // ——— 判据 4：URL 反向排除 → 未登录 ———
            // 表单折叠期兜底；先于判据 5/6，避免成功 DOM 与登录页 DOM 交集时误判已登录。
            var loginPageFragment = loginProvider.LoginPageUrlFragment;
            if (!string.IsNullOrEmpty(loginPageFragment))
            {
                var currentUrl = await GetCurrentUrlAsync(webView);
                if (currentUrl.Contains(loginPageFragment, StringComparison.OrdinalIgnoreCase))
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[AutoLogin] DetectLoginSuccess: URL 含 '{loginPageFragment}'，判定未登录");
                    return false;
                }
            }

            // ——— 判据 5：登录表单隐藏且方案声明 → 已登录 ———
            if (loginProvider.HiddenLoginFormIndicatesLoggedIn && explicitVisibility == "hidden")
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[AutoLogin] DetectLoginSuccess: 登录表单隐藏残留，判定已登录");
                return true;
            }

            // ——— 判据 6：DOM 正向检测（最弱的正向确认） ———
            if (!string.IsNullOrEmpty(domSelector))
            {
                if (await DomQueryExistsAsync(webView, domSelector))
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[AutoLogin] DOM 匹配成功: {domSelector}");
                    return true;
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[AutoLogin] 登录检测异常: {ex.Message}");
        }

        return false;
    }
}