namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 评论面板管理服务接口 — 控制评论窗口的生命周期和上下文
/// 由其他模块（如 SchemeHostPage）调用以打开/关闭/更新评论面板
/// </summary>
public interface ICommentPanelService
{
    /// <summary>打开评论窗口并加载指定资源的评论</summary>
    /// <param name="resourceKey">资源标识键（默认 URL 路径）</param>
    /// <param name="schemeId">方案 ID</param>
    /// <param name="resourceTitle">资源显示名称（用于窗口标题）</param>
    void OpenPanel(string resourceKey, Guid schemeId, string? resourceTitle = null);

    /// <summary>关闭评论窗口</summary>
    void ClosePanel();

    /// <summary>
    /// [评论区功能] 重新定位评论窗口（折叠/展开切换、主窗口移动缩放时调用）
    /// 折叠状态定位为主窗口右下角 40×40 悬浮按钮；展开状态定位为底部全宽面板
    /// </summary>
    void RepositionPanel();

    /// <summary>
    /// 更新当前资源键（WebView2 URL 变化时调用）
    /// 如果面板已打开，自动刷新评论列表；如果面板关闭，仅更新上下文
    /// </summary>
    void UpdateResourceContext(string resourceKey, Guid schemeId, string? resourceTitle = null);

    /// <summary>当前面板是否可见</summary>
    bool IsPanelOpen { get; }

    /// <summary>面板可见性变更事件（参数：是否可见）</summary>
    event Action<bool> PanelVisibilityChanged;
}
