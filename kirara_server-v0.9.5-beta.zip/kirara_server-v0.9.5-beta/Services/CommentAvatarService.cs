using System.Net.Http;
using Kirara_Server_WinUI.Helpers;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 评论作者头像服务 — 按 userId 获取评论作者头像并构建本地加密缓存（方案A）+ ETag(LastModified) 同步检查。
///
/// 资源获取链（与 UserAvatarService 一致）:
/// Step1: 立即显示本地加密缓存（秒显，解密到临时明文文件）
/// Step2: 后台调用 GET /api/resources/user-avatar/{userId}（302 自动跟随预签名 URL），
///        响应头 LastModified 与本地缓存 etag 比对，一致跳过 / 不一致重新下载缓存
/// Step3: 404 → 删除本地缓存；网络异常 → 静默保留现有显示
///
/// 缓存路径: %APPDATA%/Kirara/avatars/{userId:N}.enc（方案A：内容+ETag 合并加密单文件）。
/// 与 UserAvatarService 同目录同命名规则——键 = userId，评论作者即当前用户时天然复用同一缓存。
/// </summary>
public class CommentAvatarService : IDisposable
{
    private const string AuthApiUrlKey = "auth_api";
    private const string DefaultApiBaseUrl = "https://api.akeno6388.online:1010";

    private readonly IServerUrlService _serverUrlService;
    private readonly SecureCacheService _secureCache;
    private readonly HttpClient _httpClient;

    /// <summary>显示路径版本号（追加 ?v=N 使 WinUI 刷新图片缓存），按 userId 记录</summary>
    private readonly Dictionary<Guid, int> _versions = new();

    private bool _disposed;

    private static readonly string CacheDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", "avatars");

    private string ApiBaseUrl =>
        _serverUrlService.GetDecryptedUrl(AuthApiUrlKey) ?? DefaultApiBaseUrl;

    public CommentAvatarService(IServerUrlService serverUrlService, SecureCacheService secureCache)
    {
        _serverUrlService = serverUrlService;
        _secureCache = secureCache;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
        _httpClient.Timeout = TimeSpan.FromSeconds(15);
    }

    /// <summary>缓存文件路径（方案A加密信封）</summary>
    private static string GetCachePath(Guid userId) =>
        Path.Combine(CacheDirectory, $"{userId:N}.enc");

    /// <summary>判断字节数组是否为 GIF 图片（GIF magic bytes）</summary>
    private static bool IsGifImage(byte[] bytes)
    {
        return bytes.Length >= 6
            && bytes[0] == 'G' && bytes[1] == 'I' && bytes[2] == 'F'
            && bytes[3] == '8' && (bytes[4] == '7' || bytes[4] == '9') && bytes[5] == 'a';
    }

    /// <summary>
    /// 立即读取本地加密缓存，返回带版本号的显示路径（供 UI 绑定 BitmapImage）；
    /// 无缓存 / 解密失败（篡改/损坏）返回 null → UI 回退首字母头像。
    /// </summary>
    public string? GetCachedAvatarPath(Guid userId)
    {
        if (userId == Guid.Empty) return null;
        try
        {
            if (!_secureCache.TryReadEnvelope(GetCachePath(userId), out var content, out _, out _))
                return null;
            return GetDisplayPath(userId, WriteAvatarTemp(userId, content));
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[CommentAvatarService] 读取缓存失败: {ex.Message}");
            return null;
        }
    }

    /// <summary>
    /// 后台同步头像：GET /api/resources/user-avatar/{userId}（302 自动跟随 MinIO 预签名 URL）。
    /// 响应头 LastModified 与本地缓存 etag 一致 → 跳过下载；
    /// 不一致 → 重新下载、方案A加密缓存，并回调新显示路径；
    /// 404 → 删除本地缓存，回调空串（UI 回退首字母）。
    /// 网络异常 → 静默保留现有显示。回调可能在线程池线程，调用方需自行调度到 UI 线程。
    /// </summary>
    public async Task SyncAvatarAsync(Guid userId, Action<string>? onRefreshed = null)
    {
        if (userId == Guid.Empty) return;

        try
        {
            using var response = await _httpClient.GetAsync(
                $"{ApiBaseUrl}/api/resources/user-avatar/{userId:N}");

            if (response.IsSuccessStatusCode)
            {
                var imageBytes = await response.Content.ReadAsByteArrayAsync();
                if (imageBytes.Length == 0) return;

                // 版本比对：服务端 LastModified 与本地缓存 etag（ISO 格式）一致则跳过
                DateTime? serverModified = response.Content.Headers.LastModified?.UtcDateTime;
                if (serverModified.HasValue
                    && _secureCache.TryReadEnvelope(GetCachePath(userId), out _, out var localEtag, out _)
                    && DateTime.TryParse(localEtag, out var localModified)
                    && Math.Abs((serverModified.Value - localModified).TotalSeconds) < 1)
                {
                    return;
                }

                SaveAvatar(userId, imageBytes, serverModified);
                onRefreshed?.Invoke(GetDisplayPath(userId, WriteAvatarTemp(userId, imageBytes)));
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                if (File.Exists(GetCachePath(userId)))
                {
                    _secureCache.Delete(GetCachePath(userId));
                    onRefreshed?.Invoke(string.Empty); // 空串 = 清除显示，回退首字母
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[CommentAvatarService] 头像同步失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 方案A加密缓存头像（内容 + LastModified 合并加密单文件），原子写入
    /// </summary>
    private void SaveAvatar(Guid userId, byte[] imageBytes, DateTime? serverModified)
    {
        try
        {
            if (!Directory.Exists(CacheDirectory))
                Directory.CreateDirectory(CacheDirectory);

            // ETag 字段统一存字符串：LastModified ISO 格式（与 UserAvatarService 约定一致）
            string etag = serverModified?.ToString("O") ?? string.Empty;
            _secureCache.SaveEnvelope(GetCachePath(userId), imageBytes,
                string.IsNullOrEmpty(etag) ? null : etag);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[CommentAvatarService] 缓存写入失败: {ex.Message}");
        }
    }

    /// <summary>按内容格式（GIF/PNG）写入临时明文头像文件，返回路径</summary>
    private string WriteAvatarTemp(Guid userId, byte[] content)
    {
        var ext = IsGifImage(content) ? ".gif" : ".png";
        return _secureCache.WriteTempFile($"avatar_{userId:N}{ext}", content);
    }

    /// <summary>生成带版本号的显示路径（追加 ?v=N 使 WinUI BitmapImage 按 URI 缓存刷新）</summary>
    private string GetDisplayPath(Guid userId, string filePath)
    {
        _versions.TryGetValue(userId, out var v);
        v++;
        _versions[userId] = v;
        return $"{filePath}?v={v}";
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _httpClient.Dispose();
    }
}
