using System.Text.Json;
using Kirara_Server_WinUI.Data;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

public class InstanceService : IInstanceService
{
    private readonly IInstanceRepository _instanceRepo;
    private readonly ISchemeRepository _schemeRepo;
    private readonly ITokenRepository _tokenRepo;

    // 当前激活的实例
    private Instance? _activeInstance;

    public InstanceService(
        IInstanceRepository instanceRepo,
        ISchemeRepository schemeRepo,
        ITokenRepository tokenRepo)
    {
        _instanceRepo = instanceRepo;
        _schemeRepo = schemeRepo;
        _tokenRepo = tokenRepo;
    }

    public IEnumerable<Instance> GetAllInstances() =>
        _instanceRepo.GetAll();

    public IEnumerable<Instance> GetInstancesByUser(Guid userId) =>
        _instanceRepo.GetAll().Where(i => i.OwnerUserId == userId);

    public IEnumerable<Instance> GetInstancesByType(InstanceType type) =>
        _instanceRepo.GetByType(type);

    public Instance? GetInstance(Guid id) =>
        _instanceRepo.GetById(id);

    public Instance CreateInstance(string name, InstanceType type, Guid ownerUserId)
    {
        var instance = new Instance
        {
            Name = name,
            InstanceType = type,
            OwnerUserId = ownerUserId
        };
        _instanceRepo.Insert(instance);
        return instance;
    }

    public void UpdateInstance(Instance instance) =>
        _instanceRepo.Update(instance);

    public void DeleteInstance(Guid id) =>
        _instanceRepo.Delete(id);

    public void ToggleFavorite(Guid id)
    {
        var instance = _instanceRepo.GetById(id);
        if (instance != null)
        {
            instance.IsFavorite = !instance.IsFavorite;
            _instanceRepo.Update(instance);
        }
    }

    public void SetColorTag(Guid id, string? colorTag)
    {
        var instance = _instanceRepo.GetById(id);
        if (instance != null)
        {
            instance.ColorTag = colorTag;
            _instanceRepo.Update(instance);
        }
    }

    public void RenameInstance(Guid id, string newName)
    {
        var instance = _instanceRepo.GetById(id);
        if (instance != null)
        {
            instance.Name = newName;
        instance.UpdatedAt = DateTime.UtcNow;
        _instanceRepo.Update(instance);
    }
    }

    public Instance? ActivateInstance(Guid id)
    {
        var instance = _instanceRepo.GetById(id);
        if (instance == null)
            return null;

        // 检查权限：用户必须拥有实例内所有方案的权限
        foreach (var binding in instance.SchemeBindings)
    {
            if (binding.IsEnabled)
        {
                var scheme = _schemeRepo.GetById(binding.SchemeId);
                if (scheme == null)
                {
                    // 方案不存在，降级
                    binding.IsEnabled = false;
                    continue;
        }

                // 如果绑定令牌，检查令牌是否有效（简化：仅检查存在性）
                if (binding.TokenId.HasValue)
                {
                    var token = _tokenRepo.GetById(binding.TokenId.Value);
                    if (token == null)
                    {
                        // 令牌不存在但这不是权限错误，降级
                        binding.IsEnabled = false;
    }
}
            }
        }

        instance.LastUsedAt = DateTime.UtcNow;
        _instanceRepo.Update(instance);
        _activeInstance = instance;
        return instance;
    }

    public void DeactivateInstance()
    {
        _activeInstance = null;
    }

    public string ExportInstance(Guid id)
    {
        var instance = _instanceRepo.GetById(id);
        if (instance == null)
            throw new InvalidOperationException("实例不存在");

        var options = new JsonSerializerOptions
        {
            WriteIndented = true,
            ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles
        };
        return JsonSerializer.Serialize(instance, options);
    }

    public Instance? ImportInstance(string json)
    {
        var instance = JsonSerializer.Deserialize<Instance>(json);
        if (instance == null)
            return null;

        instance.Id = Guid.NewGuid(); // 重新生成 ID 避免冲突
        instance.CreatedAt = DateTime.UtcNow;
        instance.UpdatedAt = DateTime.UtcNow;
        instance.LastUsedAt = null;

        // 重新生成绑定 ID
        foreach (var binding in instance.SchemeBindings)
        {
            binding.Id = Guid.NewGuid();
            binding.InstanceId = instance.Id;
        }

        _instanceRepo.Insert(instance);
        return instance;
    }

    public void InsertInstanceAsIs(Instance instance)
    {
        instance.CreatedAt = DateTime.UtcNow;
        instance.UpdatedAt = DateTime.UtcNow;
        instance.LastUsedAt = null;

        foreach (var binding in instance.SchemeBindings)
            binding.Id = Guid.NewGuid(); // 内部绑定 ID 始终重新生成，避免冲突

        _instanceRepo.Insert(instance);
    }

    public void AddSchemeToInstance(Guid instanceId, Guid schemeId, Guid? tokenId = null)
    {
        var instance = _instanceRepo.GetById(instanceId);
        if (instance == null) return;

        var maxOrder = instance.SchemeBindings.Count > 0
            ? instance.SchemeBindings.Max(b => b.Order)
            : 0;

        instance.SchemeBindings.Add(new SchemeBinding
        {
            InstanceId = instanceId,
            SchemeId = schemeId,
            TokenId = tokenId,
            Order = maxOrder + 1,
            IsEnabled = true
        });

        _instanceRepo.Update(instance);
    }

    public void RemoveSchemeFromInstance(Guid instanceId, Guid schemeId)
    {
        var instance = _instanceRepo.GetById(instanceId);
        if (instance == null) return;

        instance.SchemeBindings.RemoveAll(b => b.SchemeId == schemeId);
        _instanceRepo.Update(instance);
    }

    public void UpdateSchemeBinding(Guid instanceId, Guid schemeId, Guid? tokenId, bool isEnabled)
    {
        var instance = _instanceRepo.GetById(instanceId);
        if (instance == null) return;

        var binding = instance.SchemeBindings.FirstOrDefault(b => b.SchemeId == schemeId);
        if (binding != null)
        {
            binding.TokenId = tokenId;
            binding.IsEnabled = isEnabled;
            _instanceRepo.Update(instance);
        }
    }
}

