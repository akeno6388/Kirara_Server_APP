using System.Text.Json.Serialization;

namespace Kirara_Server_WinUI.Services;

// ================================================================
//  Kirara Server API 统一响应模型
// ================================================================

/// <summary>
/// API 统一响应格式 — 对应服务端 ApiResponse&lt;T&gt;
/// </summary>
internal class ApiResponse<T>
{
    [JsonPropertyName("success")]
    public bool Success { get; set; }

    [JsonPropertyName("data")]
    public T? Data { get; set; }

    [JsonPropertyName("error")]
    public ApiErrorDetail? Error { get; set; }

    [JsonPropertyName("timestamp")]
    public DateTime Timestamp { get; set; }
}

/// <summary>
/// API 错误详情
/// </summary>
internal class ApiErrorDetail
{
    [JsonPropertyName("code")]
    public string Code { get; set; } = string.Empty;

    [JsonPropertyName("message")]
    public string Message { get; set; } = string.Empty;
}

// ================================================================
//  认证 API DTO
// ================================================================

/// <summary>
/// POST /api/auth/login 响应 data
/// </summary>
internal class LoginResponseData
{
    [JsonPropertyName("userId")]
    public Guid UserId { get; set; }

    [JsonPropertyName("username")]
    public string Username { get; set; } = string.Empty;

    [JsonPropertyName("nickname")]
    public string Nickname { get; set; } = string.Empty;

    [JsonPropertyName("role")]
    public string Role { get; set; } = string.Empty;

    [JsonPropertyName("accessToken")]
    public string AccessToken { get; set; } = string.Empty;

    [JsonPropertyName("refreshToken")]
    public string RefreshToken { get; set; } = string.Empty;
}

/// <summary>
/// POST /api/auth/register 请求体
/// </summary>
internal class RegisterRequest
{
    [JsonPropertyName("username")]
    public string Username { get; set; } = string.Empty;

    [JsonPropertyName("password")]
    public string Password { get; set; } = string.Empty;

    [JsonPropertyName("nickname")]
    public string? Nickname { get; set; }
}

/// <summary>
/// POST /api/auth/register 响应 data
/// </summary>
internal class RegisterResponseData
{
    [JsonPropertyName("userId")]
    public Guid UserId { get; set; }

    [JsonPropertyName("username")]
    public string Username { get; set; } = string.Empty;

    [JsonPropertyName("nickname")]
    public string Nickname { get; set; } = string.Empty;

    [JsonPropertyName("role")]
    public string Role { get; set; } = string.Empty;
}

/// <summary>
/// POST /api/auth/refresh 请求体
/// </summary>
internal class RefreshRequest
{
    [JsonPropertyName("refreshToken")]
    public string RefreshToken { get; set; } = string.Empty;
}

/// <summary>
/// POST /api/auth/refresh 响应 data
/// </summary>
internal class RefreshResponseData
{
    [JsonPropertyName("accessToken")]
    public string AccessToken { get; set; } = string.Empty;

    [JsonPropertyName("refreshToken")]
    public string RefreshToken { get; set; } = string.Empty;
}

/// <summary>
/// GET /api/auth/me 响应 data
/// </summary>
internal class UserInfoResponseData
{
    [JsonPropertyName("id")]
    public Guid Id { get; set; }

    [JsonPropertyName("username")]
    public string Username { get; set; } = string.Empty;

    [JsonPropertyName("nickname")]
    public string Nickname { get; set; } = string.Empty;

    [JsonPropertyName("avatar")]
    public string? Avatar { get; set; }

    [JsonPropertyName("role")]
    public string Role { get; set; } = string.Empty;

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }

    [JsonPropertyName("lastLoginAt")]
    public DateTime? LastLoginAt { get; set; }
}

// ================================================================
//  账户设置 API DTO
// ================================================================

/// <summary>
/// PUT /api/auth/me/username 请求体
/// </summary>
internal class ChangeUsernameRequest
{
    [JsonPropertyName("newUsername")]
    public string NewUsername { get; set; } = string.Empty;
}

/// <summary>
/// PUT /api/auth/me/password 请求体
/// </summary>
internal class ChangePasswordRequest
{
    [JsonPropertyName("currentPassword")]
    public string CurrentPassword { get; set; } = string.Empty;

    [JsonPropertyName("newPassword")]
    public string NewPassword { get; set; } = string.Empty;
}

/// <summary>
/// 通用消息响应 data
/// </summary>
internal class MessageResponseData
{
    [JsonPropertyName("message")]
    public string Message { get; set; } = string.Empty;
}

/// <summary>
/// ASP.NET Core ValidationProblemDetails — 参数校验失败时服务端返回的格式
/// </summary>
internal class ValidationProblemDetails
{
    [JsonPropertyName("title")]
    public string Title { get; set; } = string.Empty;

    [JsonPropertyName("status")]
    public int Status { get; set; }

    [JsonPropertyName("errors")]
    public Dictionary<string, string[]>? Errors { get; set; }
}

// ================================================================
//  本地持久化凭据模型（加密存储）
// ================================================================

// ================================================================
//  方案 URL API DTO（GET /api/scheme-urls / POST /api/scheme-urls/sync）
// ================================================================

/// <summary>
/// 方案 URL 响应数据项 — 对应服务端 SchemeUrlResponse
/// </summary>
internal class SchemeUrlResponseData
{
    [JsonPropertyName("key")]
    public string Key { get; set; } = string.Empty;

    [JsonPropertyName("displayName")]
    public string? DisplayName { get; set; }

    [JsonPropertyName("url")]
    public string Url { get; set; } = string.Empty;

    [JsonPropertyName("category")]
    public string? Category { get; set; }

    [JsonPropertyName("coverImageUrl")]
    public string? CoverImageUrl { get; set; }

    [JsonPropertyName("version")]
    public int Version { get; set; }

    [JsonPropertyName("isActive")]
    public bool IsActive { get; set; } = true;

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }

    [JsonPropertyName("updatedAt")]
    public DateTime? UpdatedAt { get; set; }
}

/// <summary>
/// POST /api/scheme-urls/sync 请求体
/// </summary>
internal class SchemeUrlSyncRequest
{
    [JsonPropertyName("clientVersion")]
    public string? ClientVersion { get; set; }

    [JsonPropertyName("localVersions")]
    public Dictionary<string, int> LocalVersions { get; set; } = new();
}

/// <summary>
/// POST /api/scheme-urls/sync 响应 data
/// </summary>
internal class SchemeUrlSyncResponseData
{
    [JsonPropertyName("updated")]
    public List<SchemeUrlResponseData>? Updated { get; set; }

    [JsonPropertyName("deleted")]
    public List<string>? Deleted { get; set; }
}

/// <summary>
/// GET /api/scheme-urls 响应 data 项（与 SchemeUrlResponseData 结构一致）
/// </summary>
internal class SchemeUrlListResponseData
{
    [JsonPropertyName("key")]
    public string Key { get; set; } = string.Empty;

    [JsonPropertyName("displayName")]
    public string? DisplayName { get; set; }

    [JsonPropertyName("url")]
    public string Url { get; set; } = string.Empty;

    [JsonPropertyName("category")]
    public string? Category { get; set; }

    [JsonPropertyName("coverImageUrl")]
    public string? CoverImageUrl { get; set; }

    [JsonPropertyName("version")]
    public int Version { get; set; }

    [JsonPropertyName("isActive")]
    public bool IsActive { get; set; } = true;

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }

    [JsonPropertyName("updatedAt")]
    public DateTime? UpdatedAt { get; set; }
}

// ================================================================
//  通知系统 API DTO（GET /api/notifications）
// ================================================================

/// <summary>
/// 通知响应数据项 — 对应服务端 NotificationResponse
/// </summary>
internal class NotificationResponseData
{
    [JsonPropertyName("id")]
    public Guid Id { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; } = string.Empty;

    [JsonPropertyName("content")]
    public string? Content { get; set; }

    [JsonPropertyName("htmlContent")]
    public string? HtmlContent { get; set; }

    [JsonPropertyName("category")]
    public string Category { get; set; } = string.Empty;

    [JsonPropertyName("isRead")]
    public bool IsRead { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }

    // ===== 互动通知定位字段（v1.10，广播通知为 null） =====

    [JsonPropertyName("actionType")]
    public int? ActionType { get; set; }

    [JsonPropertyName("actorUserId")]
    public Guid? ActorUserId { get; set; }

    [JsonPropertyName("actorName")]
    public string? ActorName { get; set; }

    [JsonPropertyName("targetId")]
    public Guid? TargetId { get; set; }

    [JsonPropertyName("resourceKey")]
    public string? ResourceKey { get; set; }

    [JsonPropertyName("contentTitle")]
    public string? ContentTitle { get; set; }
}

/// <summary>
/// GET /api/notifications 分页响应 data
/// </summary>
internal class NotificationListResponseData
{
    [JsonPropertyName("items")]
    public List<NotificationResponseData> Items { get; set; } = new();

    [JsonPropertyName("page")]
    public int Page { get; set; }

    [JsonPropertyName("pageSize")]
    public int PageSize { get; set; }

    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }

    [JsonPropertyName("totalPages")]
    public int TotalPages { get; set; }
}

/// <summary>
/// GET /api/notifications/unread-count 响应 data
/// </summary>
internal class UnreadCountResponseData
{
    [JsonPropertyName("unreadCount")]
    public int UnreadCount { get; set; }
}

// ================================================================
//  信息流卡片 API DTO（GET /api/info-cards / POST /api/info-cards/sync）
// ================================================================

/// <summary>
/// 信息流卡片响应数据项 — 对应服务端 InformationCardResponse
/// </summary>
public class InfoCardResponseData
{
    [JsonPropertyName("id")]
    public Guid Id { get; set; }

    [JsonPropertyName("title")]
    public string Title { get; set; } = string.Empty;

    [JsonPropertyName("summary")]
    public string? Summary { get; set; }

    [JsonPropertyName("mediaType")]
    public string MediaType { get; set; } = "image";

    [JsonPropertyName("coverImageUrl")]
    public string? CoverImageUrl { get; set; }

    [JsonPropertyName("thumbnailUrl")]
    public string? ThumbnailUrl { get; set; }

    [JsonPropertyName("externalUrl")]
    public string? ExternalUrl { get; set; }

    [JsonPropertyName("sortOrder")]
    public int SortOrder { get; set; }

    [JsonPropertyName("version")]
    public int Version { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }

    [JsonPropertyName("updatedAt")]
    public DateTime? UpdatedAt { get; set; }
}

/// <summary>
/// POST /api/info-cards/sync 请求体
/// </summary>
public class InfoCardSyncRequest
{
    [JsonPropertyName("localVersions")]
    public Dictionary<string, int> LocalVersions { get; set; } = new();
}

/// <summary>
/// POST /api/info-cards/sync 响应 data
/// </summary>
public class InfoCardSyncResponseData
{
    [JsonPropertyName("serverEpoch")]
    public long ServerEpoch { get; set; }

    [JsonPropertyName("updated")]
    public List<InfoCardResponseData>? Updated { get; set; }

    [JsonPropertyName("new")]
    public List<InfoCardResponseData>? New { get; set; }

    [JsonPropertyName("deactivated")]
    public List<string>? Deactivated { get; set; }
}

// ================================================================
//  预签名 URL 响应 DTO（GET /api/info-cards/{id}/media）
// ================================================================

public class PresignedUrlResponse
{
    [JsonPropertyName("presignedUrl")]
    public string? PresignedUrl { get; set; }
}

// ================================================================
//  OpenVPN 配置 API DTO（GET /api/openvpn、GET /api/openvpn/download）
// ================================================================

/// <summary>
/// GET /api/openvpn 响应 data — 配置信息（版本号 + MinIO 对象键）。
/// version 由服务端 ResourceVersions 表维护（每次覆盖上传 Version++），客户端用于缓存比对。
/// </summary>
public class OpenVpnInfoResponse
{
    [JsonPropertyName("version")]
    public int Version { get; set; }

    [JsonPropertyName("configKey")]
    public string? ConfigKey { get; set; }
}

/// <summary>
/// GET /api/openvpn/download 响应 data — 预签名下载 URL（1 小时有效，可直接访问下载）
/// </summary>
public class OpenVpnDownloadResponse
{
    [JsonPropertyName("downloadUrl")]
    public string? DownloadUrl { get; set; }
}

// ================================================================
//  应用更新 API DTO（GET /api/app/updates/latest — 公开端点，无需认证）
// ================================================================

/// <summary>
/// GET /api/app/updates/latest 响应 data — 应用版本校对结果。
/// 服务端比对策略：取 IsActive=true 记录中语义化版本最高的一条，与客户端 current 参数比较；
/// hasUpdate=false 时 latestVersion 等字段为 null。
/// </summary>
public class AppUpdateResponseData
{
    /// <summary>是否存在可用的新版本（服务端无发布记录时返回 null，按 false 处理）</summary>
    [JsonPropertyName("hasUpdate")]
    public bool? HasUpdate { get; set; }

    /// <summary>最新版本号（语义化版本）</summary>
    [JsonPropertyName("latestVersion")]
    public string? LatestVersion { get; set; }

    /// <summary>安装包直链（Alist 托管，仅 hasUpdate=true 时填充）</summary>
    [JsonPropertyName("downloadUrl")]
    public string? DownloadUrl { get; set; }

    /// <summary>安装包 SHA-256（客户端下载后校验防劫持）</summary>
    [JsonPropertyName("sha256")]
    public string? Sha256 { get; set; }

    /// <summary>版本说明</summary>
    [JsonPropertyName("releaseNotes")]
    public string? ReleaseNotes { get; set; }

    /// <summary>是否强制更新（服务端无发布记录时返回 null，按 false 处理）</summary>
    [JsonPropertyName("isMandatory")]
    public bool? IsMandatory { get; set; }

    /// <summary>发布时间 UTC</summary>
    [JsonPropertyName("publishedAt")]
    public DateTime? PublishedAt { get; set; }
}

// ================================================================
//  本地持久化凭据模型（加密存储）
// ================================================================

/// <summary>
/// 本地持久化存储的认证凭据 — 用于自动登录和会话恢复
/// </summary>
internal class StoredCredentials
{
    /// <summary>用户名</summary>
    public string Username { get; set; } = string.Empty;

    /// <summary>刷新令牌（用于自动续期 accessToken）</summary>
    public string RefreshToken { get; set; } = string.Empty;

    /// <summary>是否启用自动登录</summary>
    public bool AutoLoginEnabled { get; set; }
}