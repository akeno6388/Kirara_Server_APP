using Microsoft.UI.Xaml;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 对话框服务 — 统一管理弹窗、确认框、提示
/// </summary>
public interface IDialogService
{
    Task ShowMessageAsync(string title, string message);
    Task<bool> ShowConfirmAsync(string title, string message);
    Task<bool> ShowConfirmAsync(string title, string message, bool centerContent);
    Task<string?> ShowInputAsync(string title, string message, string? defaultValue = null);
    Task ShowErrorAsync(string title, string message);

    /// <summary>
    /// 显示带实时校验的重命名输入对话框
    /// </summary>
    /// <param name="title">对话框标题</param>
    /// <param name="currentName">当前名称（预填值）</param>
    /// <param name="validate">校验回调：返回 (isValid, errorMessage)，为 null 表示无校验</param>
    /// <returns>用户输入的新名称，取消则返回 null</returns>
    Task<string?> ShowRenameInputAsync(
        string title,
        string currentName,
        Func<string, (bool isValid, string? error)>? validate = null);

    /// <summary>
    /// 显示带自定义 UI 内容的确认对话框
    /// </summary>
    /// <param name="title">对话框标题（会自动居中）</param>
    /// <param name="content">自定义 UI 内容</param>
    /// <returns>用户是否点击了确认按钮</returns>
    Task<bool> ShowRichConfirmAsync(string title, FrameworkElement content);

    /// <summary>
    /// 显示带自定义 UI 内容的确认对话框（支持强制模式：无取消按钮，只能确认）
    /// </summary>
    /// <param name="title">对话框标题（会自动居中）</param>
    /// <param name="content">自定义 UI 内容</param>
    /// <param name="confirmText">确认按钮文字</param>
    /// <param name="isMandatory">true=强制更新，仅显示确认按钮（无取消/关闭）；false=显示确认+取消</param>
    /// <returns>用户是否点击了确认按钮</returns>
    Task<bool> ShowRichConfirmAsync(string title, FrameworkElement content, string confirmText, bool isMandatory);

    /// <summary>
    /// 显示飞入式通知消息（仿重命名/编辑备注样式）
    /// </summary>
    /// <param name="target">飞入菜单的附着元素</param>
    /// <param name="title">通知标题</param>
    /// <param name="message">通知正文</param>
    /// <param name="isError">是否为错误通知</param>
    Task ShowNotificationFlyoutAsync(FrameworkElement target, string title, string message, bool isError = false);
}
