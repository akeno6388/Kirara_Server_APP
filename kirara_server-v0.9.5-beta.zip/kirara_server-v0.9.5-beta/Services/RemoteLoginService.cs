using System.Net.Http.Json;
using System.Text.Json;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 远程登录服务实现 — 通过 Kirara Server API 进行认证
///
/// ## 设计说明
/// - 登录/注册通过 HTTP 调用服务端 API（BCrypt + JWT）
/// - 自动登录通过本地加密存储的 RefreshToken 实现（无需保存密码明文）
/// - 错误消息包含服务端返回的错误码，便于调试
/// - 本地 UserAccount 仅用于会话状态跟踪，密码/哈希不存储在本地
///
/// ## 凭据存储策略
/// - RefreshToken 使用 DPAPI + AES-256-GCM 加密后存储到本地文件
/// - AccessToken 仅在内存中保留，不落盘
/// - 退出登录时清除本地凭据并调用服务端吊销 RefreshToken
/// </summary>
public class RemoteLoginService : ILoginService, IDisposable
{
    private readonly HttpClient _httpClient;
    private readonly ICryptoService _cryptoService;
    private readonly IServerUrlService _serverUrlService;
    private readonly ITokenService _tokenService;
    private readonly IInstanceService _instanceService;
    private bool _disposed;

    /// <summary>默认令牌名称前缀</summary>
    private const string DefaultTokenName = "默认令牌";

    // ================================================================
    //  配置
    // ================================================================

    /// <summary>认证 API URL 注册键名</summary>
    private const string AuthApiUrlKey = "auth_api";

    /// <summary>
    /// 默认 API 基础地址 — 指向生产环境 Kirara Server API。
    /// 可通过 ServerUrlService 的 "auth_api" key 修改。
    /// </summary>
    private const string DefaultApiBaseUrl = "https://api.akeno6388.online:1010";

    /// <summary>
    /// API 基础地址 — 优先从 ServerUrlService 的 "auth_api" key 读取，
    /// 未配置时使用默认值 http://localhost:5340
    /// </summary>
    private string AuthApiBaseUrl =>
        _serverUrlService.GetDecryptedUrl(AuthApiUrlKey) ?? DefaultApiBaseUrl;

    /// <summary>凭据文件存储路径</summary>
    private static readonly string CredentialsFilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "Kirara", ".credentials");

    // ================================================================
    //  会话状态
    // ================================================================

    /// <summary>当前登录的用户（仅内存，不持久化）</summary>
    public UserAccount? CurrentUser { get; private set; }

    public Guid CurrentUserId => CurrentUser?.Id ?? Guid.Empty;
    public bool IsLoggedIn => CurrentUser != null;
    public bool IsAdmin => CurrentUser?.Group == UserGroup.Admin;

    /// <summary>上次登录的用户名（退出登录后保留）</summary>
    public string? LastLoginUsername { get; private set; }

    /// <summary>获取当前 accessToken（供后续 API 请求使用）</summary>
    public string? AccessToken => _accessToken;

    /// <summary>当前 accessToken（仅内存）</summary>
    private string? _accessToken;

    /// <summary>获取 accessToken 时的 UTC 时间戳（用于判断是否过期）</summary>
    private DateTime _accessTokenObtainedAt = DateTime.MinValue;

    /// <summary>自动刷新阈值（服务端 15min 过期，提前 3min 刷新）</summary>
    private static readonly TimeSpan AccessTokenRefreshThreshold = TimeSpan.FromMinutes(12);
    
    /// <summary>当前 refreshToken（用于自动续期）</summary>
    private string? _refreshToken;

    /// <summary>
    /// 是否启用自动登录。
    /// 首次读取时回退到检查本地加密凭据文件，避免重启后丢失状态。
    /// </summary>
    private bool? _autoLoginEnabled;
    public bool AutoLoginEnabled
    {
        get
        {
            if (_autoLoginEnabled.HasValue)
                return _autoLoginEnabled.Value;
            // 首次读取：从本地加密凭据文件恢复状态
            var creds = LoadCredentials();
            _autoLoginEnabled = creds?.AutoLoginEnabled ?? false;
            return _autoLoginEnabled.Value;
        }
        private set => _autoLoginEnabled = value;
    }

    public event Action<bool>? LoginStateChanged;

    // ================================================================
    //  错误码 → 用户友好消息映射
    // ================================================================

    private static readonly Dictionary<string, string> ErrorCodeMessages = new()
    {
        ["INVALID_CREDENTIALS"] = "用户名或密码错误",
        ["USERNAME_TAKEN"] = "该用户名已被注册",
        ["INVALID_TOKEN"] = "登录已过期，请重新登录",
        ["TOKEN_EXPIRED"] = "登录已过期，请重新登录",
        ["NOT_AUTHORIZED"] = "未授权，请重新登录",
        ["FORBIDDEN"] = "没有权限执行此操作",
        ["NOT_FOUND"] = "请求的资源不存在",
        ["VALIDATION_ERROR"] = "输入参数校验失败",
        ["CONFLICT"] = "资源冲突，请稍后重试",
        ["INTERNAL_ERROR"] = "服务器内部错误，请稍后重试",
    };

    public RemoteLoginService(ICryptoService cryptoService, IServerUrlService serverUrlService, ITokenService tokenService, IInstanceService instanceService)
    {
        _cryptoService = cryptoService;
        _serverUrlService = serverUrlService;
        _tokenService = tokenService;
        _instanceService = instanceService;
        _httpClient = NetworkClientFactory.Create();
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
        _httpClient.Timeout = TimeSpan.FromSeconds(15);
    }

    // ================================================================
    //  登录
    // ================================================================

    public async Task<(bool success, string? error)> LoginAsync(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username))
            return (false, "请输入用户名");

        if (string.IsNullOrEmpty(password))
            return (false, "请输入密码");

        try
        {
            var requestBody = new { username = username.Trim(), password };
            var response = await _httpClient.PostAsJsonAsync(
                $"{AuthApiBaseUrl}/api/auth/login", requestBody);

            var json = await response.Content.ReadAsStringAsync();
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<LoginResponseData>>(json);

            if (apiResponse == null)
                return (false, "服务器响应异常，请稍后重试");

            if (!apiResponse.Success || apiResponse.Data == null)
            {
                var errorMsg = FormatErrorMessage(apiResponse.Error);
                return (false, errorMsg);
            }

            // 登录成功：创建本地会话 + 异步写入默认令牌（供 WebView2 自动登录使用）
            var data = apiResponse.Data;
            ApplyLoginSession(data);
            _ = Task.Run(() => PopulateDefaultToken(username.Trim(), password));

            return (true, null);
        }
        catch (HttpRequestException ex) when (ex.InnerException is System.Net.Sockets.SocketException se
            && se.SocketErrorCode == System.Net.Sockets.SocketError.ConnectionRefused)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 登录连接被拒绝: {AuthApiBaseUrl} - {ex.Message}");
            return (false, $"无法连接到服务器（{AuthApiBaseUrl}），请确认 Kirara Server API 服务已启动");
        }
        catch (HttpRequestException ex) when (ex.InnerException is System.Net.Sockets.SocketException se
            && se.SocketErrorCode == System.Net.Sockets.SocketError.HostNotFound)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 登录 DNS 解析失败: {AuthApiBaseUrl} - {ex.Message}");
            return (false, $"无法解析服务器地址（{AuthApiBaseUrl}），请检查网络连接");
        }
        catch (HttpRequestException ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 登录网络错误: {AuthApiBaseUrl} - {ex.Message}");
            return (false, $"无法连接到服务器（{AuthApiBaseUrl}）: {ex.Message}");
        }
        catch (TaskCanceledException)
        {
            return (false, "连接服务器超时，请检查网络后重试");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 登录异常: {ex}");
            return (false, $"登录出错: {ex.Message}");
        }
    }

    // ================================================================
    //  注册
    // ================================================================

    public async Task<(bool success, string? error)> RegisterAsync(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username))
            return (false, "用户名不能为空");

        var trimmed = username.Trim();

        // 客户端侧基础校验（与服务端保持一致）
        if (trimmed.Any(c => c == ' ' || @"#\/*:?""<>|".Contains(c)))
            return (false, "用户名包含非法字符（空格或特殊符号 # \\ / : * ? \" < > |）");

        if (trimmed.Length < 3)
            return (false, "用户名至少需要 3 个字符");

        if (trimmed.Length > 50)
            return (false, "用户名不能超过 50 个字符");

        if (string.IsNullOrEmpty(password) || password.Length < 6)
            return (false, "密码至少需要 6 个字符");

        if (password.Length > 100)
            return (false, "密码不能超过 100 个字符");

        try
        {
            var requestBody = new RegisterRequest
            {
                Username = trimmed,
                Password = password,
                Nickname = trimmed // 默认昵称同用户名
            };

            var response = await _httpClient.PostAsJsonAsync(
                $"{AuthApiBaseUrl}/api/auth/register", requestBody);

            var json = await response.Content.ReadAsStringAsync();
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<RegisterResponseData>>(json);

            if (apiResponse == null)
                return (false, "服务器响应异常，请稍后重试");

            if (!apiResponse.Success)
            {
                var errorMsg = FormatErrorMessage(apiResponse.Error);
                return (false, errorMsg);
            }

            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 注册成功: {trimmed}");
            return (true, null);
        }
        catch (HttpRequestException ex) when (ex.InnerException is System.Net.Sockets.SocketException se
            && se.SocketErrorCode == System.Net.Sockets.SocketError.ConnectionRefused)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 注册连接被拒绝: {AuthApiBaseUrl} - {ex.Message}");
            return (false, $"无法连接到服务器（{AuthApiBaseUrl}），请确认 Kirara Server API 服务已启动");
        }
        catch (HttpRequestException ex) when (ex.InnerException is System.Net.Sockets.SocketException se
            && se.SocketErrorCode == System.Net.Sockets.SocketError.HostNotFound)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 注册 DNS 解析失败: {AuthApiBaseUrl} - {ex.Message}");
            return (false, $"无法解析服务器地址（{AuthApiBaseUrl}），请检查网络连接");
        }
        catch (HttpRequestException ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 注册网络错误: {AuthApiBaseUrl} - {ex.Message}");
            return (false, $"无法连接到服务器（{AuthApiBaseUrl}）: {ex.Message}");
        }
        catch (TaskCanceledException)
        {
            return (false, "连接服务器超时，请检查网络后重试");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 注册异常: {ex}");
            return (false, $"注册出错: {ex.Message}");
        }
    }

    // ================================================================
    //  自动登录
    // ================================================================

    public async Task<bool> TryAutoLoginAsync()
    {
        try
        {
            // 读取本地加密存储的凭据
            var credentials = LoadCredentials();
            if (credentials == null || !credentials.AutoLoginEnabled || string.IsNullOrEmpty(credentials.RefreshToken))
                return false;

            // 使用 RefreshToken 获取新的 Token Pair
            var refreshSuccess = await RefreshAccessTokenAsync(credentials.RefreshToken);
            if (!refreshSuccess)
            {
                // RefreshToken 失效，清除本地凭据
                ClearCredentials();
                return false;
            }

            // 获取用户信息
            var userInfo = await FetchCurrentUserAsync();
            if (userInfo == null)
            {
                ClearCredentials();
                return false;
            }

            // 构建本地会话
            CurrentUser = new UserAccount
            {
                Id = userInfo.Id,
                Username = userInfo.Username,
                Group = userInfo.Role == "Admin" ? UserGroup.Admin : UserGroup.User,
                CreatedAt = userInfo.CreatedAt,
                LastLoginAt = userInfo.LastLoginAt,
                AutoLoginEnabled = true
            };

            AutoLoginEnabled = true;
            LoginStateChanged?.Invoke(true);

            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 自动登录成功: {CurrentUser.Username}");
            return true;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 自动登录失败: {ex.Message}");
            ClearCredentials();
            return false;
        }
    }

    // ================================================================
    //  自动登录设置
    // ================================================================

    public void SetAutoLoginEnabled(bool enabled)
    {
        AutoLoginEnabled = enabled;

        if (enabled && !string.IsNullOrEmpty(_refreshToken))
        {
            // 保存凭据到本地加密存储
            SaveCredentials(new StoredCredentials
            {
                Username = CurrentUser?.Username ?? string.Empty,
                RefreshToken = _refreshToken,
                AutoLoginEnabled = true
            });
        }
        else if (!enabled)
        {
            ClearCredentials();
        }

        System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 自动登录 {(enabled ? "启用" : "禁用")}");
    }

    // ================================================================
    //  退出登录
    // ================================================================

    public void Logout()
    {
        if (CurrentUser == null) return;

        var username = CurrentUser.Username;
        LastLoginUsername = username;

        // 尝试通知服务端吊销 RefreshToken（fire-and-forget，不阻塞）
        if (!string.IsNullOrEmpty(_accessToken))
        {
            Task.Run(async () =>
            {
                try
                {
                    using var request = new HttpRequestMessage(HttpMethod.Post, $"{AuthApiBaseUrl}/api/auth/logout");
                    request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _accessToken);
                    await _httpClient.SendAsync(request);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 登出通知失败: {ex.Message}");
                }
            });
        }

        // 清除本地状态
        ClearCredentials();
        CurrentUser = null;
        _accessToken = null;
        _refreshToken = null;
        AutoLoginEnabled = false;

        System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 用户登出: {username}");
        LoginStateChanged?.Invoke(false);
    }

    // ================================================================
    //  Token 续期
    // ================================================================

    /// <summary>
    /// 确保 AccessToken 有效 — 过期时自动使用 RefreshToken 续期。
    /// 所有需要调用 API 的地方应在使用 AccessToken 前调用此方法。
    /// </summary>
    public async Task<bool> EnsureValidAccessTokenAsync()
    {
        if (string.IsNullOrEmpty(_accessToken) || string.IsNullOrEmpty(_refreshToken))
            return false;

        // 未到刷新阈值 → 无需操作
        if (DateTime.UtcNow - _accessTokenObtainedAt < AccessTokenRefreshThreshold)
            return true;

        System.Diagnostics.Debug.WriteLine("[RemoteLoginService] AccessToken 即将过期，自动刷新...");
        return await RefreshAccessTokenAsync(_refreshToken);
    }

    // ================================================================
    //  修改用户名 / 密码
    // ================================================================

    public async Task<(bool success, string? error)> ChangeUsernameAsync(string newUsername)
    {
        if (string.IsNullOrWhiteSpace(newUsername))
            return (false, "用户名不能为空");
        if (string.IsNullOrEmpty(_accessToken))
            return (false, "请先登录");

        try
        {
            var requestBody = new ChangeUsernameRequest { NewUsername = newUsername.Trim() };
            var request = new HttpRequestMessage(
                HttpMethod.Put, $"{AuthApiBaseUrl}/api/auth/me/username");
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _accessToken);
            request.Content = JsonContent.Create(requestBody);

            HttpResponseMessage response;
            try
            {
                response = await _httpClient.SendAsync(request);
            }
            finally
            {
                request.Dispose();
            }

            var json = await response.Content.ReadAsStringAsync();
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 修改用户名响应 ({(int)response.StatusCode}): {json}");
            response.Dispose();

            var apiResponse = JsonSerializer.Deserialize<ApiResponse<MessageResponseData>>(json);

            if (apiResponse?.Success != true)
            {
                // 优先从 ApiResponse 提取错误，回退到 ProblemDetails
                var errorMsg = apiResponse != null
                    ? FormatErrorMessage(apiResponse.Error)
                    : ExtractErrorMessageFromResponse(json);
                System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 修改用户名失败: {errorMsg} (HTTP {(int)response.StatusCode})");
                return (false, errorMsg);
            }

            // 更新本地会话的用户名
            if (CurrentUser != null)
            {
                CurrentUser.Username = newUsername.Trim();
            }

            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 用户名已更新: {newUsername}");
            return (true, null);
        }
        catch (HttpRequestException ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 修改用户名网络错误: {ex.Message}");
            return (false, $"网络错误: {ex.Message}");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 修改用户名异常: {ex}");
            return (false, $"修改用户名出错: {ex.Message}");
        }
    }

    public async Task<(bool success, string? error)> ChangePasswordAsync(string currentPassword, string newPassword)
    {
        if (string.IsNullOrEmpty(currentPassword))
            return (false, "请输入当前密码");
        if (string.IsNullOrEmpty(newPassword))
            return (false, "请输入新密码");
        if (newPassword.Length < 6)
            return (false, "新密码至少需要 6 个字符");
        if (string.IsNullOrEmpty(_accessToken))
            return (false, "请先登录");

        try
        {
            var requestBody = new ChangePasswordRequest
            {
                CurrentPassword = currentPassword,
                NewPassword = newPassword
            };
            var request = new HttpRequestMessage(
                HttpMethod.Put, $"{AuthApiBaseUrl}/api/auth/me/password");
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _accessToken);
            request.Content = JsonContent.Create(requestBody);

            HttpResponseMessage response;
            try
            {
                response = await _httpClient.SendAsync(request);
            }
            finally
            {
                request.Dispose();
            }

            var json = await response.Content.ReadAsStringAsync();
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 修改密码响应 ({(int)response.StatusCode}): {json}");
            response.Dispose();
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<MessageResponseData>>(json);

            if (apiResponse?.Success != true)
            {
                var errorMsg = apiResponse != null
                    ? FormatErrorMessage(apiResponse.Error)
                    : ExtractErrorMessageFromResponse(json);
                return (false, errorMsg);
            }

            // 密码修改成功 → 服务端已吊销所有 Token，执行登出
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 密码已修改，正在强制登出...");

            ClearCredentials();
            var username = CurrentUser?.Username ?? "";
            CurrentUser = null;
            _accessToken = null;
            _refreshToken = null;
            AutoLoginEnabled = false;

            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 密码已修改，凭据已清除: {username}");

            return (true, null);
        }
        catch (HttpRequestException ex)
        {
            return (false, $"网络错误: {ex.Message}");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 修改密码异常: {ex}");
            return (false, $"修改密码出错: {ex.Message}");
        }
    }

    /// <summary>
    /// 通知密码修改完成（由 UI 层在用户确认 Flyout 通知后调用）
    /// 触发 LoginStateChanged(false)，驱动 ShellPage 播放登出动画并导航到登录页
    /// </summary>
    public void NotifyPasswordChangeCompleted()
    {
        System.Diagnostics.Debug.WriteLine("[RemoteLoginService] NotifyPasswordChangeCompleted → 触发强登出");
        LoginStateChanged?.Invoke(false);
    }

    // ================================================================
    //  用户名可用性检查
    // ================================================================

    public async Task<(bool available, string? error)> CheckUsernameAvailabilityAsync(string username)
    {
        if (string.IsNullOrWhiteSpace(username) || username.Trim().Length < 3)
            return (false, "用户名至少需要 3 个字符");

        var trimmed = username.Trim();

        try
        {
            // 利用注册 API 校验用户名唯一性：
            // 发送一个明知会因密码过短而失败的注册请求，
            // 通过错误码判断用户名是否被占用。
            // - USERNAME_TAKEN → 用户名已被注册
            // - 其他错误（VALIDATION_ERROR 密码校验失败）→ 用户名可用
            var requestBody = new { username = trimmed, password = "x" }; // 密码仅1字符，必定被拒
            var response = await _httpClient.PostAsJsonAsync(
                $"{AuthApiBaseUrl}/api/auth/register", requestBody);

            if (response.IsSuccessStatusCode)
            {
                // 理论上不会发生（密码过短应被拒），但防御性处理
                System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 用户名检查异常: 注册意外成功 - {trimmed}");
                return (false, "该用户名不可用");
            }

            var json = await response.Content.ReadAsStringAsync();
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<object>>(json);

            var errorCode = apiResponse?.Error?.Code;
            if (errorCode == "USERNAME_TAKEN")
                return (false, "该用户名已被使用，请换一个");

            // 其他错误（VALIDATION_ERROR 等）说明用户名校验通过
            return (true, null);
        }
        catch (HttpRequestException ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 用户名检查网络错误: {ex.Message}");
            // 无法连接服务器时，容忍通过（由服务端在提交时最终校验）
            return (true, null);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 用户名检查异常: {ex}");
            return (true, null);
        }
    }

    // ================================================================
    //  内部方法
    // ================================================================

    /// <summary>
    /// 应用登录会话 — 从 API 响应数据创建本地会话状态
    /// </summary>
    private void ApplyLoginSession(LoginResponseData data)
    {
        CurrentUser = new UserAccount
        {
            Id = data.UserId,
            Username = data.Username,
            Group = data.Role == "Admin" ? UserGroup.Admin : UserGroup.User,
            CreatedAt = DateTime.UtcNow,
            LastLoginAt = DateTime.UtcNow,
        };

        _accessToken = data.AccessToken;
        _accessTokenObtainedAt = DateTime.UtcNow;
        _refreshToken = data.RefreshToken;

        LoginStateChanged?.Invoke(true);

        System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 登录成功: {data.Username} (Role={data.Role})");
    }

    /// <summary>
    /// 使用 RefreshToken 获取新的 Token Pair
    /// </summary>
    private async Task<bool> RefreshAccessTokenAsync(string refreshToken)
    {
        try
        {
            var requestBody = new RefreshRequest { RefreshToken = refreshToken };
            var response = await _httpClient.PostAsJsonAsync(
                $"{AuthApiBaseUrl}/api/auth/refresh", requestBody);

            if (!response.IsSuccessStatusCode)
                return false;

            var json = await response.Content.ReadAsStringAsync();
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<RefreshResponseData>>(json);

            if (apiResponse?.Success != true || apiResponse.Data == null)
                return false;

            _accessToken = apiResponse.Data.AccessToken;
            _accessTokenObtainedAt = DateTime.UtcNow;
            _refreshToken = apiResponse.Data.RefreshToken;

            // 更新本地存储的 RefreshToken
            if (AutoLoginEnabled)
            {
                SaveCredentials(new StoredCredentials
                {
                    Username = CurrentUser?.Username ?? string.Empty,
                    RefreshToken = _refreshToken,
                    AutoLoginEnabled = true
                });
            }

            return true;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] Token刷新失败: {ex.Message}");
            return false;
        }
    }

    /// <summary>
    /// 获取当前用户信息（需要有效的 accessToken）
    /// </summary>
    private async Task<UserInfoResponseData?> FetchCurrentUserAsync()
    {
        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, $"{AuthApiBaseUrl}/api/auth/me");
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _accessToken);

            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode)
                return null;

            var json = await response.Content.ReadAsStringAsync();
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<UserInfoResponseData>>(json);

            return apiResponse?.Data;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 获取用户信息失败: {ex.Message}");
            return null;
        }
    }

    /// <summary>
    /// 将登录凭据自动写入默认令牌（加密存储）。
    /// 供 WebView2 方案的 IAutoLoginProvider 脚本使用。
    /// 默认令牌全局唯一：Id 固定为 TokenService.DefaultTokenId（非空 Guid —
    /// LiteDB 5 会把 Guid.Empty 主键自动替换为新 Guid，导致固定 Id 约定失效），
    /// 首次使用时创建，之后每次登录复用同一条记录。
    /// </summary>
    private void PopulateDefaultToken(string username, string password)
    {
        try
        {
            var userId = CurrentUserId;
            if (userId == Guid.Empty) return;

            // 默认令牌 Id 固定（见 TokenService.DefaultTokenId 注释），不存在则创建
            var defaultToken = _tokenService.GetToken(TokenService.DefaultTokenId);
            if (defaultToken == null)
            {
                // 兼容旧库：历史默认令牌 Id 是随机 Guid（LiteDB 将 Guid.Empty
                // 主键自动替换所致），先尝试迁移为固定 Id，避免新旧两份并存
                defaultToken = MigrateLegacyDefaultToken(userId);
            }
            if (defaultToken == null)
            {
                defaultToken = new Token
                {
                    Id = TokenService.DefaultTokenId,
                    Name = DefaultTokenName,
                    TokenType = TokenType.Default,
                    OwnerUserId = userId,
                    IsSystem = true,
                    Notes = "系统内置默认令牌，自动写入登录凭据"
                };
                _tokenService.InsertSecureToken(defaultToken);
            }

            // 加载解密后的数据并写入登录凭据
            var secureToken = _tokenService.LoadSecureToken(defaultToken.Id);
            if (secureToken == null) return;

            secureToken.AccountName = username;
            secureToken.AccountPassword = password;
            secureToken.UpdatedAt = DateTime.UtcNow;
            secureToken.OwnerUserId = userId;

            _tokenService.SaveSecureToken(secureToken);

            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 已将登录凭据写入用户 ({username}) 的默认令牌");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 写入默认令牌失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 旧库迁移：将历史"随机 Id"默认令牌迁移为固定 Id（TokenService.DefaultTokenId）。
    /// LiteDB 5 会把 Guid.Empty 主键自动替换为随机 Guid，导致旧版本创建的默认令牌
    /// Id 不固定、GetToken(Guid.Empty) 永远查不到、每次登录重复创建同名副本。
    /// 此处将其迁移为固定 Id，并同步更新所有 SchemeBinding 中的 TokenId 引用。
    /// 幂等：迁移完成后 GetToken(DefaultTokenId) 命中，后续不再触发。
    /// </summary>
    private Token? MigrateLegacyDefaultToken(Guid userId)
    {
        var legacy = _tokenService.GetTokensByUser(userId)
            .FirstOrDefault(x => x.IsSystem && x.TokenType == TokenType.Default);
        if (legacy == null) return null;

        var oldId = legacy.Id;
        var secure = _tokenService.LoadSecureToken(oldId);
        if (secure == null) return null;

        secure.Id = TokenService.DefaultTokenId;
        _tokenService.InsertSecureToken(secure);  // 以固定 Id 重新落库（幂等加密）
        _tokenService.DeleteToken(oldId);         // 删除旧 Id 记录

        // 同步更新绑定引用（旧 Id → 固定 Id），避免方案绑定悬空
        try
        {
            foreach (var instance in _instanceService.GetInstancesByUser(userId))
            {
                var changed = false;
                foreach (var binding in instance.SchemeBindings)
                {
                    if (binding.TokenId == oldId)
                    {
                        binding.TokenId = TokenService.DefaultTokenId;
                        changed = true;
                    }
                }
                if (changed)
                    _instanceService.UpdateInstance(instance);
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 迁移默认令牌绑定引用失败: {ex.Message}");
        }

        System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 已将旧默认令牌迁移为固定 Id（{oldId} → {TokenService.DefaultTokenId}）");
        return secure;
    }

    /// <summary>
    /// 尝试从 HTTP 响应 JSON 中提取错误消息。
    /// 优先解析 ApiResponse 格式，回退到 ASP.NET Core ValidationProblemDetails 格式。
    /// </summary>
    private static string ExtractErrorMessageFromResponse(string json)
    {
        // 尝试 ApiResponse<T> 格式
        try
        {
            var apiError = JsonSerializer.Deserialize<ApiResponse<object>>(json);
            if (apiError?.Error != null && !string.IsNullOrEmpty(apiError.Error.Message))
                return apiError.Error.Message;
        }
        catch { /* 忽略反序列化失败 */ }

        // 尝试 ValidationProblemDetails 格式（ASP.NET Core 默认校验错误）
        try
        {
            var problem = JsonSerializer.Deserialize<ValidationProblemDetails>(json);
            if (problem?.Errors != null && problem.Errors.Count > 0)
            {
                // 拼接所有字段的第一个错误消息
                var messages = problem.Errors
                    .SelectMany(kv => kv.Value.Select(v => $"{v}"))
                    .Distinct();
                var combined = string.Join("；", messages);
                if (!string.IsNullOrEmpty(combined))
                    return combined;
            }
        }
        catch { /* 忽略反序列化失败 */ }

        return "操作失败，请稍后重试";
    }

    /// <summary>
    /// 格式化 API 错误消息 — 优先使用服务端的详细消息，回退到预定义的友好消息
    /// </summary>
    private static string FormatErrorMessage(ApiErrorDetail? error)
    {
        if (error == null)
            return "操作失败，请稍后重试";

        var serverMsg = !string.IsNullOrEmpty(error.Message) ? error.Message : null;

        // 1. 服务端有具体错误消息 → 直接使用（最准确）
        if (serverMsg != null)
            return serverMsg;

        // 2. 服务端无具体消息 → 回退到预定义的友好消息
        if (ErrorCodeMessages.TryGetValue(error.Code, out var friendlyMessage))
            return friendlyMessage;

        // 3. 未知错误码：返回错误码
        return $"未知错误 ({error.Code})";
    }

    // ================================================================
    //  凭据持久化（DPAPI + AES-256-GCM 加密存储到本地文件）
    // ================================================================

    /// <summary>
    /// 保存凭据到本地加密文件
    /// </summary>
    private void SaveCredentials(StoredCredentials credentials)
    {
        try
        {
            var json = JsonSerializer.Serialize(credentials);
            var encryptedBytes = _cryptoService.EncryptToBytes(json);
            var dir = Path.GetDirectoryName(CredentialsFilePath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);
            File.WriteAllBytes(CredentialsFilePath, encryptedBytes);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 保存凭据失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 从本地加密文件读取凭据
    /// </summary>
    private StoredCredentials? LoadCredentials()
    {
        try
        {
            if (!File.Exists(CredentialsFilePath))
                return null;

            var encryptedBytes = File.ReadAllBytes(CredentialsFilePath);
            var json = _cryptoService.DecryptFromBytes(encryptedBytes);
            return JsonSerializer.Deserialize<StoredCredentials>(json);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 读取凭据失败: {ex.Message}");
            return null;
        }
    }

    /// <summary>
    /// 清除本地加密凭据文件
    /// </summary>
    private void ClearCredentials()
    {
        try
        {
            if (File.Exists(CredentialsFilePath))
                File.Delete(CredentialsFilePath);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 清除凭据失败: {ex.Message}");
        }
    }

    // ================================================================
    //  启动初始化
    // ================================================================

    /// <summary>
    /// 确保认证 API URL 注册键存在。如果尚未注册，使用生产环境地址创建一条记录。
    /// </summary>
    public void EnsureAuthApiUrlRecord()
    {
        try
        {
            var existing = _serverUrlService.GetByKey(AuthApiUrlKey);
            if (existing != null) return;

            _serverUrlService.Register(
                key: AuthApiUrlKey,
                displayName: "认证 API 服务地址",
                plainUrl: DefaultApiBaseUrl,
                category: "Infrastructure");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RemoteLoginService] 注册认证API URL失败: {ex.Message}");
        }
    }

    // ================================================================
    //  IDisposable
    // ================================================================

    /// <summary>
    /// 释放服务（应用退出时由 Hosting 容器调用）。
    /// 释放 HttpClient 连接池，确保进程可完全退出。
    /// </summary>
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _httpClient.Dispose();
        GC.SuppressFinalize(this);
    }
}