using System.Linq;
using Kirara_Server_WinUI.Views.Controls;
using Kirara_Server_WinUI.Views.Instance;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 方案宿主页全局缓存管理器实现
/// 以 instanceId → (schemeId → SchemeHostPage) 的二级字典形式持久化所有页面
/// Cookie / 缓存随 WebView2 控件生命周期持久，仅在删除实例或退出应用时销毁
/// </summary>
public class SchemePageCache : ISchemePageCache
{
    /// <summary>instanceId → (schemeId → SchemeHostPage)</summary>
    private readonly Dictionary<Guid, Dictionary<Guid, SchemeHostPage>> _cache = new();

    /// <summary>被挂起的实例 ID 集合</summary>
    private readonly HashSet<Guid> _suspendedInstances = new();

    /// <summary>
    /// (instanceId, schemeId) → WebView2 用户数据目录代际号。
    /// 必须保存在缓存层而非 SchemeHostPage 实例内：初始化实例销毁页面后，
    /// 下次 GetOrCreate 新建的页面仍能延续代际，避免回退到旧数据目录（gen_0）
    /// 导致 WebView2 复用旧 Cookie/Session/表单状态（"令牌秒链接"且表单未清除）。
    /// </summary>
    private readonly Dictionary<(Guid InstanceId, Guid SchemeId), int> _generations = new();

    private readonly object _lock = new();

    /// <summary>实例服务（用于初始化/删除时从数据库获取方案绑定，即使缓存为空也能清理磁盘）</summary>
    private readonly IInstanceService _instanceService;

    public SchemePageCache(IInstanceService instanceService)
    {
        _instanceService = instanceService;
    }

    public SchemeHostPage GetOrCreate(Guid instanceId, Guid schemeId)
    {
        lock (_lock)
        {
            if (!_cache.TryGetValue(instanceId, out var pages))
            {
                pages = new Dictionary<Guid, SchemeHostPage>();
                _cache[instanceId] = pages;
            }

            if (!pages.TryGetValue(schemeId, out var page))
            {
                page = new SchemeHostPage();
                page.SetContext(instanceId, schemeId);
                pages[schemeId] = page;
            }

            return page;
        }
    }

    public IReadOnlyDictionary<Guid, SchemeHostPage> GetInstancePages(Guid instanceId)
    {
        lock (_lock)
        {
            if (_cache.TryGetValue(instanceId, out var pages))
                return new Dictionary<Guid, SchemeHostPage>(pages);
            return new Dictionary<Guid, SchemeHostPage>();
        }
    }

    public void SuspendInstance(Guid instanceId)
    {
        lock (_lock)
        {
            _suspendedInstances.Add(instanceId);
        }
    }

    public void ResumeInstance(Guid instanceId)
    {
        lock (_lock)
        {
            _suspendedInstances.Remove(instanceId);
        }
    }

    public int GetGeneration(Guid instanceId, Guid schemeId)
    {
        lock (_lock)
        {
            return _generations.TryGetValue((instanceId, schemeId), out var gen) ? gen : 0;
        }
    }

    public int BumpGeneration(Guid instanceId, Guid schemeId)
    {
        lock (_lock)
        {
            var key = (instanceId, schemeId);
            var next = _generations.TryGetValue(key, out var gen) ? gen + 1 : 1;
            _generations[key] = next;
            return next;
        }
    }

    public async Task DestroyInstance(Guid instanceId)
    {
        Dictionary<Guid, SchemeHostPage>? pages;
        lock (_lock)
        {
            _suspendedInstances.Remove(instanceId);
            _cache.TryGetValue(instanceId, out pages);
            _cache.Remove(instanceId);
        }

        // [初始化失效修复] 收集该实例的全部方案 ID：
        // ① 缓存中的页面（实例当前打开过）
        // ② 数据库实例的方案绑定（实例未打开/应用重启后缓存为空，但磁盘可能有历史数据！）
        // ③ 实例已删除时扫描磁盘目录（删除实例场景兜底）
        var schemeIds = new HashSet<Guid>();
        if (pages != null)
        {
            foreach (var schemeId in pages.Keys) schemeIds.Add(schemeId);
        }

        try
        {
            var instance = _instanceService.GetInstance(instanceId);
            if (instance != null)
            {
                foreach (var binding in instance.SchemeBindings)
                    schemeIds.Add(binding.SchemeId);
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SchemePageCache] 获取实例绑定失败 instance={instanceId}: {ex.Message}");
        }

        // 实例已从数据库删除：扫描磁盘 webview2/{instanceId}/ 下的方案子目录兜底
        if (schemeIds.Count == 0)
        {
            var instanceRoot = GetWebViewInstanceRoot(instanceId);
            if (Directory.Exists(instanceRoot))
            {
                foreach (var dir in Directory.GetDirectories(instanceRoot))
                {
                    var name = Path.GetFileName(dir);
                    if (Guid.TryParse(name, out var schemeId))
                        schemeIds.Add(schemeId);
                }
            }
        }

        // 关键：无论页面缓存是否存在，都要对所有方案升代 + 后台清理磁盘旧代目录。
        // 此前 pages == null 时直接跳过，导致实例未打开/应用重启后点"初始化实例"
        // 磁盘上历史 WebView2 数据（Cookie/表单/缓存）完全残留——下次打开复用旧目录。
        foreach (var schemeId in schemeIds)
        {
            // 同步升代（写入全局代际记录）→ 下次新建页面必然使用干净新目录
            var newGen = BumpGeneration(instanceId, schemeId);

            // 异步后台清理该方案所有旧代数据目录（gen_0..gen_{newGen-1}）
            // WebView2 浏览器进程释放 lockfile 可能需数秒，不能同步等待——
            // 即使清理失败，当前代已切到干净路径，不影响正确性。
            var root = GetWebViewSchemeRoot(instanceId, schemeId);
            if (Directory.Exists(root))
            {
                var gen = newGen;
                _ = Task.Run(async () => await CleanupOldGenerationsAsync(root, gen));
            }
        }

        if (pages != null)
        {
            foreach (var (_, page) in pages)
            {
                try
                {
                    // OpenVPN 用户版：断开连接 + 清除 .ovpn 配置缓存并强制重新下载
                    // （初始化实例 = 硬重载语义；删除实例时同样需要完全关闭）
                    if (page.CurrentCustomControl is OpenVpnControl ovpnControl)
                    {
                        await ovpnControl.ShutdownForReinitializeAsync();
                    }

                    // OpenVPN 服务版：断开连接 + 完全清除本方案配置文件及凭据
                    // （初始化实例 = 硬重载语义；删除实例时同样需要完全关闭）
                    if (page.CurrentOpenVpnServiceControl is OpenVpnServiceControl ovpnSvc)
                    {
                        await ovpnSvc.ShutdownForReinitializeAsync();
                    }

                    // 销毁 WebView2 环境并删除磁盘上的用户数据。
                    // 代际升代在 DestroyWebViewAsync 内部同步完成（BumpGeneration 写入缓存层），
                    // 之后新建的 SchemeHostPage 查询到新代际 → 使用干净数据目录。
                    await page.DestroyWebViewAsync(deleteUserData: true);
                }
                catch (Exception ex)
                {
                    // 单个页面销毁失败不中断其余页面
                    System.Diagnostics.Debug.WriteLine(
                        $"[SchemePageCache] 销毁页面失败 instance={instanceId}: {ex.Message}");
                }
            }
        }
    }

    /// <summary>获取某实例的 WebView2 用户数据根目录（%LOCALAPPDATA%/Kirara/webview2/{instanceId:N}）</summary>
    private static string GetWebViewInstanceRoot(Guid instanceId)
    {
        var baseDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Kirara", "webview2");
        return Path.Combine(baseDir, instanceId.ToString("N"));
    }

    /// <summary>获取某实例-方案的 WebView2 用户数据根目录（含所有代数）</summary>
    private static string GetWebViewSchemeRoot(Guid instanceId, Guid schemeId)
    {
        return Path.Combine(GetWebViewInstanceRoot(instanceId), schemeId.ToString("N"));
    }

    /// <summary>
    /// 后台清理指定方案根目录下所有旧代数据目录（gen_0..gen_{currentGen-1}）。
    /// 递增延迟重试，最多 30 秒。旧代目录无法清理也不影响正确性——当前代已切到干净路径。
    /// </summary>
    private static async Task CleanupOldGenerationsAsync(string root, int currentGen)
    {
        // gen_0 即无后缀的根目录本身
        for (int gen = 0; gen < currentGen; gen++)
        {
            var target = gen == 0 ? root : Path.Combine(root, $"gen_{gen}");
            if (!Directory.Exists(target)) continue;

            for (int retry = 0; retry < 6; retry++)
            {
                try
                {
                    await Task.Delay(5000);
                    Directory.Delete(target, true);
                    break;
                }
                catch (DirectoryNotFoundException) { break; }
                catch (IOException)
                {
                    // lockfile 仍被占用，继续重试
                }
            }
        }
    }

    public async Task ShutdownInstance(Guid instanceId)
    {
        Dictionary<Guid, SchemeHostPage>? pages;
        lock (_lock)
        {
            _suspendedInstances.Remove(instanceId);
            _cache.TryGetValue(instanceId, out pages);
            _cache.Remove(instanceId);
        }

        if (pages != null)
        {
            foreach (var (_, page) in pages)
            {
                try
                {
                    // OpenVPN 用户版：完全关闭（断开 VPN 连接并清理临时认证文件，保留 .ovpn 配置缓存）
                    if (page.CurrentCustomControl is OpenVpnControl ovpnControl)
                    {
                        await ovpnControl.ShutdownAsync();
                    }

                    // OpenVPN 服务版：完全关闭（断开 VPN 连接，保留配置文件及凭据）
                    if (page.CurrentOpenVpnServiceControl is OpenVpnServiceControl ovpnSvc)
                    {
                        await ovpnSvc.ShutdownAsync();
                    }

                    // 关闭实例时不删除磁盘数据
                    await page.DestroyWebViewAsync(deleteUserData: false);
                }
                catch (Exception ex)
                {
                    // 单个页面关闭失败不中断其余页面
                    System.Diagnostics.Debug.WriteLine(
                        $"[SchemePageCache] 关闭页面失败 instance={instanceId}: {ex.Message}");
                }
            }
        }
    }

    /// <summary>
    /// [账号安全] 关闭当前缓存中所有实例的所有页面（退出登录时调用）。
    /// 复用 ShutdownInstance 语义：关闭 WebView2 进程 + 断开 OpenVPN 连接，
    /// 保留磁盘用户数据（Cookie/缓存），下次登录可复用。
    /// [并行优化] 各实例并行关闭（VpnConnectionService 单例 + 状态检查保证
    /// OpenVPN 断开安全：同一时间只有一个连接处于 Connected，其余直接跳过）。
    /// </summary>
    public async Task ShutdownAllInstancesAsync()
    {
        List<Guid> instanceIds;
        lock (_lock)
        {
            instanceIds = _cache.Keys.ToList();
        }

        // 并行关闭所有实例（每个实例内部页面串行关闭，实例之间互不阻塞）
        var tasks = instanceIds.Select(instanceId => CloseInstanceSafelyAsync(instanceId));
        await Task.WhenAll(tasks);
    }

    /// <summary>安全关闭单个实例（异常不向外抛，记录日志）</summary>
    private async Task CloseInstanceSafelyAsync(Guid instanceId)
    {
        try
        {
            await ShutdownInstance(instanceId);
        }
        catch (Exception ex)
        {
            // 单个实例关闭失败不中断其余实例
            System.Diagnostics.Debug.WriteLine(
                $"[SchemePageCache] 退出登录关闭实例失败 instance={instanceId}: {ex.Message}");
        }
    }

    /// <summary>
    /// 销毁所有页面（应用退出时调用）。
    /// 关闭所有缓存的 WebView2 页面，断开所有 OpenVPN 连接，
    /// 保留磁盘用户数据（Cookie/缓存）供下次启动复用。
    /// [并行优化] 所有页面并行关闭，加快应用退出速度。
    /// </summary>
    public async void Shutdown()
    {
        List<SchemeHostPage> allPages;
        lock (_lock)
        {
            _suspendedInstances.Clear();
            allPages = _cache.Values.SelectMany(d => d.Values).ToList();
            _cache.Clear();
        }

        // 并行关闭所有页面（WebView2 Close 与 OpenVPN 断开互不阻塞）
        var tasks = allPages.Select(page => ClosePageSafelyAsync(page));
        await Task.WhenAll(tasks);
    }

    /// <summary>安全关闭单个页面（异常不向外抛，记录日志）</summary>
    private static async Task ClosePageSafelyAsync(SchemeHostPage page)
    {
        try
        {
            // 断开 OpenVPN 连接（与应用退出语义一致：断开但不删除配置）
            if (page.CurrentCustomControl is OpenVpnControl ovpnControl)
            {
                await ovpnControl.ShutdownAsync();
            }
            if (page.CurrentOpenVpnServiceControl is OpenVpnServiceControl ovpnSvc)
            {
                await ovpnSvc.ShutdownAsync();
            }

            // 关闭时不删除磁盘数据（下次启动可复用）
            await page.DestroyWebViewAsync(deleteUserData: false);
        }
        catch (Exception ex)
        {
            // 单个页面关闭失败不中断其余页面
            System.Diagnostics.Debug.WriteLine(
                $"[SchemePageCache] 应用退出关闭页面失败: {ex.Message}");
        }
    }
}
