using System.Net.Http.Json;
using System.Text.Json;
using Kirara_Server_WinUI.Data;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 集中式服务器 URL 管理服务
/// 所有 URL 均通过 AES-256-GCM 加密后存储到 LiteDB
/// 支持在线同步功能（通过 Kirara Server API 增量同步方案 URL）
/// </summary>
public class ServerUrlService : IServerUrlService
{
    private readonly IServerUrlRepository _repo;
    private readonly ICryptoService _crypto;

    /// <summary>方案 URL API 注册键名</summary>
    private const string SchemeUrlsApiUrlKey = "scheme_urls_api";

    /// <summary>默认 API 基础地址 — 指向生产环境 Kirara Server API</summary>
    private const string DefaultApiBaseUrl = "https://api.akeno6388.online:1010";

    /// <summary>
    /// API 基础地址 — 优先从 URL 注册表的 "scheme_urls_api" key 读取，
    /// 未配置时使用默认值。
    /// </summary>
    private string ApiBaseUrl =>
        GetDecryptedUrl(SchemeUrlsApiUrlKey) ?? DefaultApiBaseUrl;

    public event EventHandler<SchemeUrlChangedEventArgs>? OnSchemeUrlChanged;

    public ServerUrlService(IServerUrlRepository repo, ICryptoService crypto)
    {
        _repo = repo;
        _crypto = crypto;
    }

    // ===== 基础 CRUD =====

    public ServerUrlRecord? GetById(Guid id) => _repo.GetById(id);

    public ServerUrlRecord? GetByKey(string key) => _repo.GetByKey(key);

    public IEnumerable<ServerUrlRecord> GetAll() => _repo.GetAll();

    public ServerUrlRecord Register(string key, string displayName, string plainUrl,
        Guid? schemeId = null, string? schemeName = null, string? category = null)
    {
        var record = new ServerUrlRecord
        {
            Key = key,
            DisplayName = displayName,
            Url = _crypto.Encrypt(plainUrl),
            SchemeId = schemeId,
            SchemeName = schemeName,
            Category = category,
            SyncStatus = "Idle"
        };

        _repo.Insert(record);
        return record;
    }

    public void Update(ServerUrlRecord record)
    {
        // 如果 URL 尚未加密，先加密
        if (!_crypto.IsEncrypted(record.Url) && !string.IsNullOrEmpty(record.Url))
        {
            record.Url = _crypto.Encrypt(record.Url);
        }
        if (!string.IsNullOrEmpty(record.SyncEndpoint) && !_crypto.IsEncrypted(record.SyncEndpoint))
        {
            record.SyncEndpoint = _crypto.Encrypt(record.SyncEndpoint);
        }
        record.Version++;
        _repo.Update(record);
    }

    public void Delete(Guid id) => _repo.Delete(id);

    // ===== 解密访问 =====

    public string? GetDecryptedUrl(string key)
    {
        var record = _repo.GetByKey(key);
        if (record == null || string.IsNullOrEmpty(record.Url))
            return null;
        return _crypto.Decrypt(record.Url);
    }

    public string? GetDecryptedUrlById(Guid id)
    {
        var record = _repo.GetById(id);
        if (record == null || string.IsNullOrEmpty(record.Url))
            return null;
        return _crypto.Decrypt(record.Url);
    }

    // ===== URL 解析 =====

    /// <summary>
    /// 智能解析令牌的服务器 URL
    /// 优先级：令牌自身的 ServerUrl（解密后） > 集中注册表
    /// </summary>
    public string? ResolveTokenUrl(Token token)
    {
        // 1. 令牌有直接的 ServerUrl → 解密返回
        if (!string.IsNullOrEmpty(token.ServerUrl))
        {
            return _crypto.IsEncrypted(token.ServerUrl)
                ? _crypto.Decrypt(token.ServerUrl)
                : token.ServerUrl;
        }

        // 2. 尝试从 Metadata 中查找关联的注册表键
        if (token.Metadata != null &&
            token.Metadata.TryGetValue("ServerUrlKey", out var key) &&
            !string.IsNullOrEmpty(key))
        {
            return GetDecryptedUrl(key);
        }

        return null;
    }

    // ===== 批量操作 =====

    public void UpsertBatch(IEnumerable<ServerUrlRecord> records)
    {
        foreach (var record in records)
        {
            // 加密 URL（如果还是明文）
            if (!string.IsNullOrEmpty(record.Url) && !_crypto.IsEncrypted(record.Url))
            {
                record.Url = _crypto.Encrypt(record.Url);
            }
            if (!string.IsNullOrEmpty(record.SyncEndpoint) && !_crypto.IsEncrypted(record.SyncEndpoint))
            {
                record.SyncEndpoint = _crypto.Encrypt(record.SyncEndpoint);
            }

            _repo.Upsert(record);
        }
    }

    // ===== 在线同步 =====

    /// <summary>
    /// 从远程同步端点拉取方案 URL 更新。
    /// 使用增量同步模式（POST /api/scheme-urls/sync），
    /// 仅更新服务端版本高于本地的记录，不强制全量覆盖。
    /// 
    /// ## 同步流程
    /// ```
    /// Step 1: 构建本地版本字典（仅含 SchemeName 非空的记录）
    /// Step 2: POST /api/scheme-urls/sync → { localVersions }
    /// Step 3: 处理 updated 列表 → UpsertBatch() 更新本地 DB
    /// Step 4: 处理 deleted 列表 → 标记 SyncStatus="Removed" + Version++
    /// Step 5: 触发 OnSchemeUrlChanged 事件（通知已打开方案的页面）
    /// ```
    /// 
    /// ## 错误处理
    /// - 网络异常/超时 → 静默失败，仅输出 Debug 日志
    /// - 服务端返回错误 → 记录日志，不影响本地已有数据
    /// - 不阻塞启动流程：由 App.OnLaunched 以 fire-and-forget 方式调用
    /// </summary>
    /// <param name="endpoint">API 基础地址，为空时从 "scheme_urls_api" key 读取</param>
    /// <param name="ct">取消令牌</param>
    public async Task SyncFromServerAsync(string endpoint, CancellationToken ct = default)
    {
        try
        {
            // 确定 API 基础地址
            var baseUrl = endpoint;
            if (string.IsNullOrWhiteSpace(baseUrl))
            {
                baseUrl = ApiBaseUrl;
            }
            if (string.IsNullOrWhiteSpace(baseUrl))
            {
                System.Diagnostics.Debug.WriteLine(
                    "[ServerUrlService] 同步跳过：未配置 API 基础地址");
                return;
            }

            System.Diagnostics.Debug.WriteLine(
                "[ServerUrlService] === SyncFromServerAsync ===");

            // Step 1: 构建本地版本字典
            // 仅同步 SchemeName 非空的记录（排除 Infrastructure 等内部 URL）
            var allRecords = _repo.GetAll()
                .Where(r => !string.IsNullOrEmpty(r.SchemeName))
                .ToList();

            var localVersions = allRecords
                .Where(r => r.SyncStatus != "Removed")
                .ToDictionary(r => r.Key, r => r.Version);

            System.Diagnostics.Debug.WriteLine(
                $"[ServerUrlService] 本地待同步记录: {localVersions.Count} 条");

            // Step 2: 发起增量同步请求
            var requestBody = new SchemeUrlSyncRequest
            {
                ClientVersion = "1.0.0",
                LocalVersions = localVersions
            };

            using var client = NetworkClientFactory.Create();
            client.Timeout = TimeSpan.FromSeconds(15);
            client.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");

            // 确保 baseUrl 末尾没有多余的斜杠
            var apiBase = baseUrl.TrimEnd('/');
            var response = await client.PostAsJsonAsync(
                $"{apiBase}/api/scheme-urls/sync", requestBody, ct);

            if (!response.IsSuccessStatusCode)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[ServerUrlService] HTTP {(int)response.StatusCode}: 同步请求失败");
                return;
            }

            var json = await response.Content.ReadAsStringAsync(ct);
            var apiResponse = JsonSerializer.Deserialize<ApiResponse<SchemeUrlSyncResponseData>>(json);

            if (apiResponse?.Success != true || apiResponse.Data == null)
            {
                System.Diagnostics.Debug.WriteLine(
                    "[ServerUrlService] 服务端返回异常: success=false 或 data=null");
                return;
            }

            var syncData = apiResponse.Data;

            // Step 3: 收集变更信息（用于触发事件）
            var changedEntries = new List<(string key, string oldUrl, string newUrl, bool isRemoved)>();

            // Step 4: 处理 updated 列表 — 服务端版本 > 本地版本的记录
            if (syncData.Updated?.Count > 0)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[ServerUrlService] 服务端返回更新: {syncData.Updated.Count} 条");

                var updatedRecords = syncData.Updated.Select(dto =>
                {
                    var existing = _repo.GetByKey(dto.Key);
                    var oldUrl = existing != null ? GetDecryptedUrl(dto.Key) : null;

                    // 记录变更（URL 或版本有变化时）
                    var newUrl = dto.Url;
                    if (existing != null && oldUrl != newUrl)
                    {
                        changedEntries.Add((dto.Key, oldUrl ?? "", newUrl, false));
                    }
                    else if (existing == null)
                    {
                        changedEntries.Add((dto.Key, "", newUrl, false));
                    }

                    return new ServerUrlRecord
                    {
                        Id = existing?.Id ?? Guid.NewGuid(),
                        Key = dto.Key,
                        DisplayName = dto.DisplayName ?? dto.Key,
                        Url = newUrl, // 明文，UpsertBatch 会加密
                        SchemeName = dto.Key,
                        Category = dto.Category,
                        IsActive = dto.IsActive,
                        Version = dto.Version,
                        CreatedAt = existing?.CreatedAt ?? dto.CreatedAt,
                        UpdatedAt = dto.UpdatedAt ?? DateTime.UtcNow,
                        AutoSync = true,
                        LastSyncedAt = DateTime.UtcNow,
                        SyncStatus = "UpToDate",
                    };
                }).ToList();

                UpsertBatch(updatedRecords);
            }

            // Step 5: 处理 deleted 列表 — 服务端已删除的记录
            if (syncData.Deleted?.Count > 0)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[ServerUrlService] 服务端标记删除: {syncData.Deleted.Count} 条");

                foreach (var key in syncData.Deleted)
                {
                    var existing = _repo.GetByKey(key);
                    if (existing != null)
                    {
                        var oldUrl = GetDecryptedUrl(key);
                        changedEntries.Add((key, oldUrl ?? "", "(已移除)", true));

                        // 标记为已移除而非物理删除，保留历史记录
                        existing.SyncStatus = "Removed";
                        existing.IsActive = false;
                        existing.Version++;
                        existing.UpdatedAt = DateTime.UtcNow;
                        existing.LastSyncedAt = DateTime.UtcNow;
                        _repo.Update(existing);
                    }
                }
            }

            // Step 6: 触发 URL 变更事件
            foreach (var (key, oldUrl, newUrl, isRemoved) in changedEntries)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[ServerUrlService] URL 变更: {key}: {oldUrl} → {newUrl}");
                OnSchemeUrlChanged?.Invoke(this, new SchemeUrlChangedEventArgs
                {
                    Key = key,
                    OldUrl = oldUrl,
                    NewUrl = newUrl,
                    IsRemoved = isRemoved
                });
            }

            System.Diagnostics.Debug.WriteLine(
                $"[ServerUrlService] 同步完成，共 {changedEntries.Count} 条变更");
        }
        catch (TaskCanceledException)
        {
            System.Diagnostics.Debug.WriteLine(
                "[ServerUrlService] 同步超时（15s），将在下次启动时重试");
        }
        catch (HttpRequestException ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[ServerUrlService] 同步网络错误: {ex.Message}");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[ServerUrlService] 同步异常: {ex.GetType().Name}: {ex.Message}");
        }
    }

    /// <summary>
    /// 确保方案 URL API 基础地址注册键存在。
    /// 如果尚未注册，使用生产环境地址创建一条记录。
    /// </summary>
    public void EnsureSchemeUrlsApiUrlRecord()
    {
        try
        {
            var existing = _repo.GetByKey(SchemeUrlsApiUrlKey);
            if (existing != null) return;

            // Register 会加密存储
            var record = new ServerUrlRecord
            {
                Key = SchemeUrlsApiUrlKey,
                DisplayName = "方案 URL API 服务地址",
                Url = _crypto.Encrypt(DefaultApiBaseUrl),
                Category = "Infrastructure",
                AutoSync = false,
            };
            _repo.Insert(record);

            System.Diagnostics.Debug.WriteLine(
                $"[ServerUrlService] 已注册方案 URL API 地址: {DefaultApiBaseUrl}");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[ServerUrlService] 注册方案 URL API 地址失败: {ex.Message}");
        }
    }

    // ===== 迁移 =====

    /// <summary>
    /// 将已有令牌中的明文 ServerUrl 迁移到集中注册表
    /// 并加密存储
    /// </summary>
    public void MigratePlaintextUrls()
    {
        // 扫描所有现有记录，加密尚未加密的 URL
        var all = _repo.GetAll().ToList();
        foreach (var record in all)
        {
            if (!string.IsNullOrEmpty(record.Url) && !_crypto.IsEncrypted(record.Url))
            {
                record.Url = _crypto.Encrypt(record.Url);
                _repo.Update(record);
            }
        }
    }
}
