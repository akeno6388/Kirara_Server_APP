using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 方案 URL 变更事件参数 — 当通过服务端同步更新 URL 时触发
/// </summary>
public class SchemeUrlChangedEventArgs : EventArgs
{
    /// <summary>变更的 URL 注册表键（如 "media"、"drive"）</summary>
    public string Key { get; init; } = string.Empty;

    /// <summary>变更前的 URL（解密后明文）</summary>
    public string OldUrl { get; init; } = string.Empty;

    /// <summary>变更后的 URL（解密后明文）</summary>
    public string NewUrl { get; init; } = string.Empty;

    /// <summary>是否为删除/停用操作</summary>
    public bool IsRemoved { get; init; }
}

/// <summary>
/// 集中式服务器 URL 管理服务接口
/// 提供 URL 的加密存储、解析、批量同步等功能
/// </summary>
public interface IServerUrlService
{
    // ===== 基础 CRUD =====

    ServerUrlRecord? GetById(Guid id);
    ServerUrlRecord? GetByKey(string key);
    IEnumerable<ServerUrlRecord> GetAll();

    /// <summary>注册新的 URL 记录（URL 原文将自动加密存储）</summary>
    ServerUrlRecord Register(string key, string displayName, string plainUrl, Guid? schemeId = null, string? schemeName = null, string? category = null);

    void Update(ServerUrlRecord record);
    void Delete(Guid id);

    // ===== 解密访问 =====

    /// <summary>获取解密后的 URL</summary>
    string? GetDecryptedUrl(string key);

    /// <summary>获取解密后的 URL（按 ID）</summary>
    string? GetDecryptedUrlById(Guid id);

    // ===== URL 解析 =====

    /// <summary>
    /// 智能解析 URL：优先使用集中注册表中的记录，否则使用令牌自身的加密 URL
    /// </summary>
    string? ResolveTokenUrl(Token token);

    // ===== 事件 =====

    /// <summary>
    /// 方案 URL 变更事件 — 当通过服务端同步（SyncFromServerAsync）更新了 URL 时触发。
    /// SchemeHostPage 可订阅此事件，检测当前方案 URL 变更后提示用户刷新或自动重载。
    /// </summary>
    event EventHandler<SchemeUrlChangedEventArgs>? OnSchemeUrlChanged;

    // ===== 批量操作（用于同步） =====

    /// <summary>
    /// 批量导入/更新 URL 记录（同步场景）
    /// 每条记录的 Url 应为明文，由本方法负责加密
    /// </summary>
    void UpsertBatch(IEnumerable<ServerUrlRecord> records);

    /// <summary>
    /// 从同步端点拉取 URL 更新（预留：未来实现在线同步）
    /// </summary>
    Task SyncFromServerAsync(string endpoint, CancellationToken ct = default);

    // ===== 迁移 =====

    /// <summary>
    /// 将已有的明文 ServerUrl 迁移到集中注册表并加密
    /// </summary>
    void MigratePlaintextUrls();
}
