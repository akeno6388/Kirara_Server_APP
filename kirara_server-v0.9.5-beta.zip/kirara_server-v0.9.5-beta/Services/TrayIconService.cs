using System;
using System.Runtime.InteropServices;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// Windows 系统托盘角标服务 — Win32 Shell_NotifyIcon API。
///
/// unpackaged + asInvoker + self-contained WinUI3：
/// - 「关闭软件行为 = 最小化」时点击标题栏关闭按钮 → SW_HIDE 隐藏主窗口（任务栏图标消失）
///   → Show() 显示系统托盘角标。
/// - 左键单击托盘角标 → RestoreRequested（恢复主窗口）。
/// - 右键单击托盘角标 → TrackPopupMenu（打开 Kirara / 退出）。
///
/// ⚠️ WndProc Hook：本服务在 Initialize(hwnd) 时挂载 WndProc，插入
/// （WindowSizeLimiter → WindowAnimationHelper.WindowMessageHandler → DefWindowProc）
/// 链中接收 WM_TRAYICON。
/// </summary>
public class TrayIconService : IDisposable
{
    /// <summary>DI Singleton — WindowMessageHandler / App.xaml.cs / WndProc 通过此静态引用访问</summary>
    public static TrayIconService? Current { get; private set; }

    /// <summary>请求恢复主窗口（左键单击 / 「打开」菜单项）</summary>
    public event Action? RestoreRequested;

    /// <summary>请求退出应用（「退出」菜单项）</summary>
    public event Action? ExitRequested;

    // ===== Win32 / Shell_NotifyIcon =====
    private const int WM_USER = 0x0400;
    private const uint WM_TRAYICON = WM_USER + 101; // uCallbackMessage（自定义消息）
    private const int TRAY_ID = 100;                // uID（本应用唯一标识）

    private const uint NIM_ADD = 0x00000000;
    private const uint NIM_MODIFY = 0x00000001;
    private const uint NIM_DELETE = 0x00000002;

    private const uint NIF_MESSAGE = 0x00000001; // uCallbackMessage
    private const uint NIF_ICON = 0x00000002;     // hIcon
    private const uint NIF_TIP = 0x00000004;      // szTip

    // ===== Shell_NotifyIcon mouse messages (lParam of uCallbackMessage) =====
    private const uint WM_LBUTTONUP = 0x0202;
    private const uint WM_LBUTTONDBLCLK = 0x0203;
    private const uint WM_RBUTTONUP = 0x0205;

    // ===== TrackPopupMenu flags / AppendMenu flags =====
    private const uint MF_STRING = 0x00000000;
    private const uint MF_SEPARATOR = 0x00000800;
    private const uint TPM_RETURNCMD = 0x00000100;
    private const uint TPM_RIGHTBUTTON = 0x00000002;
    private const uint TPM_NONOTIFY = 0x00000080;

    // Menu item ids
    private const int MENU_ID_OPEN = 1001;
    private const int MENU_ID_EXIT = 1002;

    // WndProc hook fields（保持 delegate/oldWndProc 引用防 GC）
    private readonly WndProcDelegate _wndProcDelegate;
    private readonly IntPtr _oldWndProc;

    private readonly IntPtr _hwnd;
    private IntPtr _iconHandle;   // LoadIcon 返回的系统图标句柄（Dispose 时释放）
    private bool _shown;          // 托盘图标是否已显示
    private bool _disposed;
    private bool _hooked;

    private TrayIconService(IntPtr hwnd)
    {
        _hwnd = hwnd;
        _wndProcDelegate = WndProcCore;
        _oldWndProc = SetWindowLongPtr(hwnd, GWLP_WNDPROC,
            Marshal.GetFunctionPointerForDelegate(_wndProcDelegate));
        _hooked = true;
        Current = this;
    }

    /// <summary>
    /// 创建并初始化托盘服务（应用启动、窗口句柄就绪后调用；重复调用返回既有实例）。
    /// 在窗口句柄上挂载 WndProc 接收托盘回调消息。
    /// </summary>
    public static TrayIconService Initialize(IntPtr hwnd)
    {
        if (Current is { _disposed: false } existing && existing._hwnd == hwnd)
            return existing;
        var service = new TrayIconService(hwnd);
        return service;
    }

    /// <summary>
    /// 显示系统托盘角标（幂等）。图标取系统默认应用图标（LoadIcon IDI_APPLICATION）。
    /// </summary>
    public void Show()
    {
        if (_disposed || _shown) return;

        // 从当前进程 exe 提取程序图标（app.ico 已内嵌于 exe，取大图标 32x32）
        _iconHandle = ExtractAppIcon();

        var data = new NOTIFYICONDATA
        {
            cbSize = (uint)Marshal.SizeOf<NOTIFYICONDATA>(),
            hWnd = _hwnd,
            uID = TRAY_ID,
            uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP,
            uCallbackMessage = WM_TRAYICON,
            hIcon = _iconHandle,
        };
        // szTip: 托盘悬停提示
        data.szTip = "Kirara APP";

        Shell_NotifyIcon(NIM_ADD, ref data);
        _shown = true;
    }

    /// <summary>
    /// 从当前进程可执行文件（exe）提取程序图标。
    /// ExtractIconEx 返回大图标（32x32）与小图标（16x16），取大图标用于托盘角标。
    /// 提取失败时回退系统默认应用图标。
    /// </summary>
    private static IntPtr ExtractAppIcon()
    {
        try
        {
            var exePath = Environment.ProcessPath;
            if (!string.IsNullOrEmpty(exePath))
            {
                // 大图标句柄（32x32）
                if (ExtractIconEx(exePath, 0, out var large, out _, 1) != 0 && large != IntPtr.Zero)
                    return large;
            }
        }
        catch { /* 提取失败走回退 */ }

        // 回退：系统默认应用图标（IDI_APPLICATION = 32512）
        return LoadIcon(IntPtr.Zero, new IntPtr(IDI_APPLICATION));
    }

    /// <summary>
    /// 隐藏系统托盘角标（幂等）。
    /// </summary>
    public void Hide()
    {
        if (_disposed || !_shown) return;

        var data = new NOTIFYICONDATA
        {
            cbSize = (uint)Marshal.SizeOf<NOTIFYICONDATA>(),
            hWnd = _hwnd,
            uID = TRAY_ID,
        };
        Shell_NotifyIcon(NIM_DELETE, ref data);

        if (_iconHandle != IntPtr.Zero)
        {
            DestroyIcon(_iconHandle);
            _iconHandle = IntPtr.Zero;
        }
        _shown = false;
    }

    /// <summary>托盘角标是否当前可见</summary>
    public bool IsShown => _shown;

    /// <summary>
    /// WndProc — 接收 Shell_NotifyIcon 的回调消息（WM_TRAYICON）。
    /// 左键单击 → 恢复窗口；右键单击 → 弹出上下文菜单。
    /// </summary>
    private IntPtr WndProcCore(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam)
    {
        try
        {
            if (msg == WM_TRAYICON && wParam.ToInt32() == TRAY_ID)
            {
                switch (lParam.ToInt32())
                {
                    case (int)WM_LBUTTONUP:
                    case (int)WM_LBUTTONDBLCLK:
                        RestoreRequested?.Invoke();
                        return IntPtr.Zero;

                    case (int)WM_RBUTTONUP:
                        ShowContextMenu();
                        return IntPtr.Zero;
                }
            }
        }
        catch { /* 托盘消息处理异常不影响 WndProc 链 */ }

        return CallWindowProc(_oldWndProc, hWnd, msg, wParam, lParam);
    }

    /// <summary>
    /// 右键托盘角标 → 弹出上下文菜单（显示主窗口 / 退出）。
    /// TPM_RETURNCMD 模式：TrackPopupMenu 直接返回选中项 ID。
    /// </summary>
    private void ShowContextMenu()
    {
        var menu = CreatePopupMenu();
        if (menu == IntPtr.Zero) return;

        try
        {
            AppendMenu(menu, MF_STRING, MENU_ID_OPEN, "显示主窗口");
            AppendMenu(menu, MF_SEPARATOR, 0, null);
            AppendMenu(menu, MF_STRING, MENU_ID_EXIT, "退出");

            // 获取当前鼠标位置，菜单显示在鼠标处
            GetCursorPos(out var pt);

            // 使窗口前置，确保菜单能正常交互
            SetForegroundWindow(_hwnd);

            var cmd = TrackPopupMenu(menu, TPM_RIGHTBUTTON | TPM_RETURNCMD | TPM_NONOTIFY,
                pt.X, pt.Y, 0, _hwnd, IntPtr.Zero);

            // 根据选中项分发事件
            switch (cmd)
            {
                case MENU_ID_OPEN:
                    RestoreRequested?.Invoke();
                    break;
                case MENU_ID_EXIT:
                    ExitRequested?.Invoke();
                    break;
            }
        }
        finally
        {
            DestroyMenu(menu);
        }
    }

    /// <inheritdoc />
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        // 隐藏托盘角标
        if (_shown)
        {
            var data = new NOTIFYICONDATA
            {
                cbSize = (uint)Marshal.SizeOf<NOTIFYICONDATA>(),
                hWnd = _hwnd,
                uID = TRAY_ID,
            };
            Shell_NotifyIcon(NIM_DELETE, ref data);
            _shown = false;
        }

        if (_iconHandle != IntPtr.Zero)
        {
            DestroyIcon(_iconHandle);
            _iconHandle = IntPtr.Zero;
        }

        // 卸载 WndProc（还原旧 WndProc）
        if (_hooked)
        {
            try { SetWindowLongPtr(_hwnd, GWLP_WNDPROC, _oldWndProc); }
            catch { /* 窗口可能已销毁 */ }
            _hooked = false;
        }

        if (Current == this)
            Current = null;
    }

    // ===== Win32 P/Invoke =====

    private const int GWLP_WNDPROC = -4;

    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    private delegate IntPtr WndProcDelegate(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct NOTIFYICONDATA
    {
        public uint cbSize;
        public IntPtr hWnd;
        public uint uID;
        public uint uFlags;
        public uint uCallbackMessage;
        public IntPtr hIcon;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string szTip;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct POINT
    {
        public int X;
        public int Y;
    }

    // IDI_APPLICATION = 32512（系统默认应用图标）
    private const int IDI_APPLICATION = 32512;

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr LoadIcon(IntPtr hInstance, IntPtr lpIconName);

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern uint ExtractIconEx(string lpszFile, int nIconIndex,
        out IntPtr phiconLarge, out IntPtr phiconSmall, uint nIcons);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool DestroyIcon(IntPtr hIcon);

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern bool Shell_NotifyIcon(uint dwMessage, ref NOTIFYICONDATA lpdata);

    [DllImport("user32.dll", SetLastError = true, EntryPoint = "SetWindowLongPtr")]
    private static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr CallWindowProc(IntPtr lpPrevWndFunc, IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr CreatePopupMenu();

    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool AppendMenu(IntPtr hMenu, uint uFlags, int uIDNewItem, string? lpNewItem);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern int TrackPopupMenu(IntPtr hMenu, uint uFlags, int x, int y, int nReserved, IntPtr hWnd, IntPtr prcRect);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool DestroyMenu(IntPtr hMenu);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool GetCursorPos(out POINT lpPoint);

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);
}
