using System.Text.Json;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

public class ExportImportService : IExportImportService
{
    private readonly IInstanceService _instanceService;
    private readonly ITokenService _tokenService;
    private readonly ICryptoService _crypto;
    private readonly ILoginService _loginService;

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles
    };

    public ExportImportService(IInstanceService instanceService, ITokenService tokenService, ICryptoService crypto, ILoginService loginService)
    {
        _instanceService = instanceService;
        _tokenService = tokenService;
        _crypto = crypto;
        _loginService = loginService;
    }

    public string ExportAllInstances()
    {
        var userId = _loginService.CurrentUserId;
        var instances = _instanceService.GetInstancesByUser(userId).ToList();
        return JsonSerializer.Serialize(instances, JsonOptions);
    }

    public byte[] ExportAllTokens()
    {
        var userId = _loginService.CurrentUserId;
        var tokens = _tokenService.GetTokensByUser(userId)
            .Select(t => _tokenService.DecryptForExport(t))
            .ToList();
        var json = JsonSerializer.Serialize(tokens, JsonOptions);
        return CryptoService.EncryptWithUid(json, userId);
    }

    public (int Imported, int Skipped) ImportInstances(string json)
    {
        var instances = JsonSerializer.Deserialize<List<Instance>>(json, JsonOptions);
        if (instances == null) return (0, 0);

        int imported = 0, skipped = 0;
        foreach (var instance in instances)
        {
            if (_instanceService.GetInstance(instance.Id) != null)
            {
                skipped++;
                continue;
            }
            _instanceService.InsertInstanceAsIs(instance);
            imported++;
        }

        return (imported, skipped);
    }

    public (int Imported, int Skipped) ImportTokens(byte[] data)
    {
        var json = CryptoService.DecryptWithUid(data, _loginService.CurrentUserId).TrimStart();
        var tokens = json.StartsWith('[')
            ? JsonSerializer.Deserialize<List<Token>>(json, JsonOptions) ?? new()
            : JsonSerializer.Deserialize<Token>(json, JsonOptions) is { } t ? new List<Token> { t } : new();

        return ImportTokenList(tokens);
    }

    // ===== 私有辅助 =====

    private (int Imported, int Skipped) ImportTokenList(List<Token> tokens)
    {
        if (tokens.Count == 0) return (0, 0);

        int imported = 0, skipped = 0;
        var userId = _loginService.CurrentUserId;
        foreach (var t in tokens)
        {
            // 默认令牌特判：合并到本机默认令牌而不是新建，
            // 避免"清空后导入"产生"默认令牌（1）"副本
            if (t.IsSystem && t.TokenType == TokenType.Default)
            {
                if (ImportDefaultToken(t, userId)) imported++;
                else skipped++;
                continue;
            }

            // Id 冲突无法通过改名解决 → 仍跳过
            if (_tokenService.GetToken(t.Id) != null)
            { skipped++; continue; }

            // 同名令牌不再跳过：自动改名（原名 + （1）/（2）…以此类推）
            t.Name = GenerateUniqueTokenName(t.Name, userId);

            t.OwnerUserId = userId;
            t.CreatedAt = t.UpdatedAt = DateTime.UtcNow;
            // 导入的是明文 → 加密后单次落库（避免明文落库窗口）
            _tokenService.InsertSecureToken(t);
            imported++;
        }
        return (imported, skipped);
    }

    /// <summary>
    /// 导入默认令牌：本机已有则合并凭据（保留本机 Id 与既有绑定关系）；
    /// 本机没有则用固定 Id 恢复。返回是否成功。
    /// </summary>
    private bool ImportDefaultToken(Token imported, Guid userId)
    {
        var local = _tokenService.GetToken(TokenService.DefaultTokenId)
            ?? _tokenService.GetTokensByUser(userId)
                .FirstOrDefault(x => x.IsSystem && x.TokenType == TokenType.Default);

        if (local != null)
        {
            // 合并凭据：导入文件字段有值才覆盖，避免空占位覆盖本机已有凭据
            var secure = _tokenService.LoadSecureToken(local.Id);
            if (secure == null) return false;

            if (!string.IsNullOrEmpty(imported.AccountName))
                secure.AccountName = imported.AccountName;
            if (!string.IsNullOrEmpty(imported.AccountPassword))
                secure.AccountPassword = imported.AccountPassword;
            if (!string.IsNullOrEmpty(imported.ApiKey))
                secure.ApiKey = imported.ApiKey;
            if (!string.IsNullOrEmpty(imported.ServerUrl))
                secure.ServerUrl = imported.ServerUrl;
            secure.OwnerUserId = userId;

            // SaveSecureToken 幂等加密后单次落库
            _tokenService.SaveSecureToken(secure);
            return true;
        }

        // 本机无默认令牌 → 用固定 Id 恢复（保持"全局唯一"约定）
        imported.Id = TokenService.DefaultTokenId;
        imported.OwnerUserId = userId;
        imported.CreatedAt = imported.UpdatedAt = DateTime.UtcNow;
        _tokenService.InsertSecureToken(imported);
        return true;
    }

    /// <summary>生成当前用户下不重复的令牌名称：原名已占用时追加（1）（2）…</summary>
    private string GenerateUniqueTokenName(string baseName, Guid userId)
    {
        if (!_tokenService.IsTokenNameExists(userId, baseName))
            return baseName;

        var index = 1;
        while (true)
        {
            var candidate = $"{baseName}（{index}）";
            if (!_tokenService.IsTokenNameExists(userId, candidate))
                return candidate;
            index++;
        }
    }

    // ===== 一键导出/导入 =====

    public byte[] ExportAllData()
    {
        var userId = _loginService.CurrentUserId;
        var data = new
        {
            Instances = _instanceService.GetInstancesByUser(userId).ToList(),
            Tokens = _tokenService.GetTokensByUser(userId)
                .Select(t => _tokenService.DecryptForExport(t))
                .ToList()
        };
        return CryptoService.EncryptWithUid(JsonSerializer.Serialize(data, JsonOptions), userId);
    }

    public (int InstancesImported, int InstancesSkipped, int TokensImported, int TokensSkipped) ImportAllData(byte[] data)
    {
        var json = CryptoService.DecryptWithUid(data, _loginService.CurrentUserId);
        return ImportAllDataCore(json);
    }

    /// <summary>
    /// 一键导入（自动识别文件类型）：
    /// 1. UID 加密全量文件（实例 + 令牌）→ 校验当前账户后导入；
    /// 2. 明文实例分享文件（信封格式或裸 List）→ 仅导入实例，任何用户可导入。
    /// </summary>
    public (int InstancesImported, int InstancesSkipped, int TokensImported, int TokensSkipped, bool IsInstanceOnly) ImportData(byte[] data)
    {
        // 先尝试 UID 加密的全量数据格式
        try
        {
            var json = CryptoService.DecryptWithUid(data, _loginService.CurrentUserId);
            var (i, iSkip, t, tSkip) = ImportAllDataCore(json);
            return (i, iSkip, t, tSkip, false);
        }
        catch (UnauthorizedAccessException)
        {
            // 是 UID 加密文件但属于其他账户 → 保持抛出（由 UI 提示"文件不属于当前账户"）
            throw;
        }
        catch (InvalidOperationException)
        {
            // 非 UID 加密格式 → 尝试明文实例分享格式
        }

        var text = System.Text.Encoding.UTF8.GetString(data);

        // 信封格式：{ Format = "KiraraInstancesShare", Instances = [...] }
        try
        {
            using var doc = JsonDocument.Parse(text);
            if (doc.RootElement.TryGetProperty("Instances", out var ie))
            {
                var (imported, skipped) = ImportInstances(ie.GetRawText());
                return (imported, skipped, 0, 0, true);
            }
        }
        catch (JsonException) { /* 落入裸列表兜底 */ }

        // 兜底：直接明文 List&lt;Instance&gt;（兼容旧版实例 JSON）
        try
        {
            var (imported, skipped) = ImportInstances(text);
            if (imported > 0 || skipped > 0)
                return (imported, skipped, 0, 0, true);
        }
        catch (JsonException) { /* 两种格式均失败 → 抛出格式错误 */ }

        throw new InvalidOperationException("文件格式无效或已损坏");
    }

    // ===== 私有辅助 =====

    /// <summary>
    /// 解析已解密的全量数据 JSON 并导入（实例 + 令牌）
    /// </summary>
    private (int InstancesImported, int InstancesSkipped, int TokensImported, int TokensSkipped) ImportAllDataCore(string json)
    {
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;

        var tokens = root.TryGetProperty("Tokens", out var te)
            ? JsonSerializer.Deserialize<List<Token>>(te.GetRawText(), JsonOptions) ?? new()
            : new();
        var (tokensImported, tokensSkipped) = ImportTokenList(tokens);

        int instancesImported = 0, instancesSkipped = 0;
        if (root.TryGetProperty("Instances", out var ie))
            (instancesImported, instancesSkipped) = ImportInstances(ie.GetRawText());

        return (instancesImported, instancesSkipped, tokensImported, tokensSkipped);
    }
}
