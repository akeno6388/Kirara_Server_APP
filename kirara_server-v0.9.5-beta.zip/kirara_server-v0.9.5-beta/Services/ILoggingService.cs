using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 日志服务接口 — 统一收集和管理应用日志（Debug 输出、异常、业务日志）
/// 通过 TraceListener 捕获 Debug.WriteLine，同时支持显式写入。
/// </summary>
public interface ILoggingService
{
    /// <summary>
    /// 写入一条日志
    /// </summary>
    /// <param name="level">日志级别</param>
    /// <param name="source">来源模块名</param>
    /// <param name="message">日志消息</param>
    /// <param name="exception">可选的异常对象</param>
    void Log(LogLevel level, string source, string message, Exception? exception = null);

    /// <summary>
    /// 获取日志列表（支持按级别过滤）
    /// </summary>
    /// <param name="minLevel">最低级别，null 表示获取全部</param>
    IReadOnlyList<LogEntry> GetLogs(LogLevel? minLevel = null);

    /// <summary>
    /// 清空所有日志
    /// </summary>
    void ClearLogs();

    /// <summary>
    /// 日志添加事件（订阅者如 NotificationCenter 可实时接收）
    /// </summary>
    event Action<LogEntry>? OnLogAdded;
}
