using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Services;

/// <summary>
/// 权限服务接口 — 基于当前登录用户组别控制功能访问
/// </summary>
public interface IPermissionService
{
    /// <summary>当前用户是否可以创建服务实例</summary>
    bool CanCreateServiceInstance { get; }

    /// <summary>当前用户是否可以访问指定实例</summary>
    bool CanAccessInstance(Instance instance);

    /// <summary>当前用户是否可以访问指定类型的实例</summary>
    bool CanAccessInstanceType(InstanceType instanceType);

    /// <summary>获取当前用户可见的实例列表</summary>
    IEnumerable<Instance> FilterAccessibleInstances(IEnumerable<Instance> instances);
}
