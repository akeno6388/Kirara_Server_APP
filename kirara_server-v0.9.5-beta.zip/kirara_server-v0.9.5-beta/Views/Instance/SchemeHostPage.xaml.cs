﻿using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Animation;
using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Schemes.BuiltIn;
using Kirara_Server_WinUI.Schemes.Service;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.ViewModels.Comment;
using Kirara_Server_WinUI.ViewModels.InstanceSpace;
using Kirara_Server_WinUI.Views.Comment;
using Kirara_Server_WinUI.Views.Controls;
using Microsoft.Web.WebView2.Core;

namespace Kirara_Server_WinUI.Views.Instance;

/// <summary>
/// ONLY UI RENDERING — all business logic delegated to SchemeHostViewModel + AutoLoginService.
/// </summary>
public sealed partial class SchemeHostPage : Page
{
    private readonly SchemeHostViewModel _viewModel;
    private readonly ISchemeService _schemeService;

    private Scheme? _currentScheme;
    private SchemeBinding? _currentBinding;

    private Guid _instanceId;
    private Guid _schemeId;

    /// <summary>[Kirara Media] WebView2 是否处于 HTML5 全屏状态（video.requestFullscreen）</summary>
    private bool _isWebViewFullScreen;

    /// <summary>[Kirara Media] 全屏时 WebView2 被移入的窗口顶层容器（退出全屏时移回原宿主）</summary>
    private Grid? _fullScreenHost;

    /// <summary>[Kirara Media] 全屏时被隐藏的遮挡元素（标题栏/左侧栏/标签栏/状态栏），退出时恢复</summary>
    private readonly List<UIElement> _hiddenChrome = new();

    /// <summary>[Kirara Media] 进入真全屏前窗口是否处于最大化状态（退出全屏时恢复）</summary>
    private bool _wasMaximizedBeforeFullScreen;

    private bool _webViewInitialized;
    private CoreWebView2Environment? _webViewEnv;

    /// <summary>
    /// 数据目录代际号本地缓存（权威值存于 SchemePageCache 全局记录）。
    /// 0 = 默认路径；>0 = 新一代目录。初始化实例销毁页面后，新建页面通过
    /// SchemePageCache.GetGeneration 延续代际，确保 WebView2 不会复用旧 Cookies/Session Storage。
    /// </summary>
    private int _dataFolderGeneration;

    // [评论区功能] 页内评论面板 ViewModel
    private CommentWindowViewModel? _commentViewModel;

    // [首页分享功能] 页内分享面板 ViewModel
    private SharedContentViewModel? _sharedContentViewModel;

    /// <summary>[评论区功能] 所属实例是否绑定了议题方案（缓存，未绑定时不显示评论区）</summary>
    private bool? _hasTopicBinding;

    /// <summary>[评论区功能] 评论面板是否处于折叠状态</summary>
    private bool _isCommentCollapsed;

    /// <summary>[评论区功能] 评论面板三态状态（气泡/全展开；折叠由 _isCommentCollapsed 表示）</summary>
    private CommentPanelState _commentPanelState = CommentPanelState.Expanded;

    /// <summary>[评论区功能] 气泡态面板高度（默认 360 与分享区一致，拖拽后记忆，折叠/展开恢复时使用）</summary>
    private double _commentBubbleHeight = 360;

    /// <summary>[评论区功能] 气泡态最小/最大高度限制</summary>
    private const double CommentBubbleMinHeight = 150;

    /// <summary>[评论区功能] 气泡态拖拽调高状态</summary>
    private bool _isCommentResizing;
    private double _commentResizeStartY;
    private double _commentResizeStartHeight;

    /// <summary>[评论区功能] 评论面板展开高度（分享面板仍使用该常量，保持 360 不变）</summary>
    private const double CommentExpandedHeight = 360;

    /// <summary>[崩溃自愈] WebView2 浏览器进程崩溃后是否已触发通知（防重复横条）</summary>
    private bool _webViewFailureNotified;

    /// <summary>[外部跳转确认] 等待用户确认的外部跳转目标 URL（null = 无挂起跳转）</summary>
    private string? _pendingExternalNavUrl;

    /// <summary>[首页分享功能] 分享面板是否处于折叠状态</summary>
    private bool _isSharedContentCollapsed;

    /// <summary>[首页分享功能] 分享面板是否处于最大化（全展开）状态</summary>
    private bool _isSharedContentFullExpanded;

    /// <summary>[评论区功能] 淡化切换动画状态（引用类型包装，供 FadeSwitchPanel 内 lambda 回写）</summary>
    private readonly FadeState _commentFadeState = new();

    /// <summary>[首页分享功能] 分享面板淡化切换动画状态</summary>
    private readonly FadeState _sharedFadeState = new();

    /// <summary>淡化切换动画状态包装（避免 ref 参数无法在 lambda 中使用的问题）</summary>
    private sealed class FadeState
    {
        public Storyboard? Current;
    }

    /// <summary>当前已加载的方案 ID</summary>
    public Guid CurrentSchemeId => _currentScheme?.Id ?? Guid.Empty;
    public Guid CurrentBindingId => _currentBinding?.Id ?? Guid.Empty;
    public SchemeUIKind CurrentUIKind => _currentScheme?.UIKind ?? SchemeUIKind.WebView2;

    /// <summary>方案内容是否已加载完成</summary>
    public bool IsSchemeLoaded => _currentScheme != null;

    /// <summary>方案加载是否出错（CustomControl 初始化失败等）</summary>
    public bool HasSchemeError => _viewModel.HasError;

    /// <summary>当前 CustomControl 宿主控件（用户版 OpenVPN 方案部署令牌直连时使用）</summary>
    public OpenVpnControl? CurrentCustomControl => CustomControlHost.Content as OpenVpnControl;

    /// <summary>当前 CustomControl 宿主控件（服务版 OpenVPN 方案，多配置管理）</summary>
    public OpenVpnServiceControl? CurrentOpenVpnServiceControl => CustomControlHost.Content as OpenVpnServiceControl;

    /// <summary>当前方案是否为服务版 OpenVPN（不连服务器 API、本地配置库、不支持重链接令牌）</summary>
    public bool IsOpenVpnServiceScheme => _viewModel.SchemeInstance is OpenVpnServiceScheme;

    /// <summary>
    /// 是否为 IMM 方案（新窗口跳转特例）：IMM 控制台内嵌页面的跳转
    /// 不做任何拦截/确认，直接按 WebView2 默认行为在独立浏览器窗口中打开。
    /// </summary>
    public bool IsImmScheme => _viewModel.SchemeInstance is ImmScheme;

    /// <summary>上次自动登录的最终状态文字，用于恢复 UI 卡片状态</summary>
    public string? LastAutoLoginStatus => _viewModel.LastAutoLoginStatus;

    public event Action<Guid, string>? OnAutoLoginCompleted
    {
        add => _viewModel.OnAutoLoginCompleted += value;
        remove => _viewModel.OnAutoLoginCompleted -= value;
    }

    public SchemeHostPage()
    {
        _viewModel = App.Services.GetRequiredService<SchemeHostViewModel>();
        _schemeService = App.Services.GetRequiredService<ISchemeService>();
        InitializeComponent();
        DataContext = _viewModel;

        // [评论区功能] 初始化页内评论面板
        var commentService = App.Services.GetRequiredService<ICommentService>();
        var homepageCommentService = App.Services.GetRequiredService<IHomepageCommentService>();
        _commentViewModel = new CommentWindowViewModel(commentService, homepageCommentService);
        // v1.10 修复：注入页面标题主动读取器（提交评论时实时查询，不依赖 MutationObserver 被动推送）
        _commentViewModel.FetchPageTitleAsync = FetchMediaPageTitleAsync;
        CommentPanelControl.DataContext = _commentViewModel;
        CommentPanelControl.CollapseToggleRequested += OnCommentCollapseToggle;
        // [评论区功能] 页内面板同样支持「全展开」悬浮面板态，订阅全展开按钮事件
        CommentPanelControl.FullExpandToggleRequested += OnCommentFullExpandToggle;

        // [首页分享功能] 初始化页内分享面板
        var navigationService = App.Services.GetRequiredService<INavigationService>();
        _sharedContentViewModel = new SharedContentViewModel(homepageCommentService, navigationService);
        SharedContentPanelControl.DataContext = _sharedContentViewModel;
        SharedContentPanelControl.CollapseToggleRequested += OnSharedContentCollapseToggle;
        // [首页分享功能] 分享面板同样支持「最大化」悬浮面板态，订阅最大化按钮事件
        SharedContentPanelControl.FullExpandToggleRequested += OnSharedContentFullExpandToggle;
    }

    public void SetContext(Guid instanceId, Guid schemeId)
    {
        _instanceId = instanceId;
        _schemeId = schemeId;
        _viewModel.SetContext(instanceId, schemeId);
    }

    private void OnUnloaded(object sender, RoutedEventArgs e) { }

    /// <summary>
    /// [崩溃自愈] WebView2 浏览器进程失败事件处理。
    /// 仅在本页面内显示通知横条（提示用户手动重建），不自动重建——防止进程反复崩溃时
    /// 无限循环重建（渲染进程崩溃 RENDER_PROCESS_EXITED 常见于页面自身异常，重建大概率仍崩溃）。
    /// 用户通过横条"立即重建"按钮或方案标签页刷新/硬重载手动恢复。
    /// </summary>
    private void OnWebViewProcessFailed(CoreWebView2 sender, CoreWebView2ProcessFailedEventArgs args)
    {
        if (_webViewFailureNotified) return;
        _webViewFailureNotified = true;

        System.Diagnostics.Debug.WriteLine(
            $"[SchemeHostPage] WebView2 进程失败: {args.ProcessFailedKind}, exitCode={args.ExitCode}, {_currentScheme?.Name}");
        DispatcherQueue.TryEnqueue(() =>
        {
            ShowWebViewFailureBar();
        });
    }

    /// <summary>
    /// [外部跳转拦截] WebView2 新窗口请求（window.open / target="_blank"）。
    /// 先拦截并显示确认横条，提醒用户即将离开方案页面、
    /// 目标内容不受方案安全保障，需点击"继续前往"才在新浏览器窗口中打开。
    /// （IMM 方案不订阅此事件，直接按 WebView2 默认行为打开新窗口）
    /// </summary>
    private void OnWebViewNewWindowRequested(CoreWebView2 sender, CoreWebView2NewWindowRequestedEventArgs args)
    {
        // 拦截默认行为：阻止立即创建新窗口
        args.Handled = true;
        if (string.IsNullOrEmpty(args.Uri)) return;

        // 保存目标 URL 并显示确认横条（不立即打开）
        _pendingExternalNavUrl = args.Uri;
        System.Diagnostics.Debug.WriteLine($"[SchemeHostPage] 外部跳转请求已拦截，等待用户确认: {args.Uri}");
        DispatcherQueue.TryEnqueue(ShowExternalNavBar);
    }

    /// <summary>
    /// [外部跳转确认] 显示确认横条（带入场动画：左滑入 + 淡入）。
    /// 提示用户即将离开方案页面，目标内容不受方案安全保障，需点击确认才跳转。
    /// </summary>
    private void ShowExternalNavBar()
    {
        ExternalNavUrlText.Text = _pendingExternalNavUrl ?? string.Empty;

        // 复位动画状态（防止重复显示时残留 X/Opacity）
        ExternalNavBarTranslate.X = -60;
        ExternalNavBar.Opacity = 0;

        ExternalNavBar.Visibility = Visibility.Visible;

        var storyboard = (Storyboard)Resources["ExternalNavBarInAnimation"];
        storyboard.Begin();
    }

    /// <summary>
    /// [外部跳转确认] 隐藏确认横条（带退场动画：右滑出 + 淡出，完成后 Collapsed）
    /// </summary>
    private void HideExternalNavBar()
    {
        if (ExternalNavBar.Visibility != Visibility.Visible) return;

        var storyboard = (Storyboard)Resources["ExternalNavBarOutAnimation"];
        storyboard.Completed += (_, _) =>
        {
            ExternalNavBar.Visibility = Visibility.Collapsed;
            // 复位动画状态，供下次入场动画使用
            ExternalNavBarTranslate.X = -60;
            ExternalNavBar.Opacity = 1;
        };
        storyboard.Begin();
    }

    /// <summary>
    /// [外部跳转确认] 横条"继续前往"按钮：确认跳转，在新建的独立浏览器窗口
    /// （新 WebView2 实例，与宿主共享会话）中打开目标 URL，不改变当前方案页面。
    /// </summary>
    private async void OnExternalNavConfirmClick(object sender, RoutedEventArgs e)
    {
        var url = _pendingExternalNavUrl;
        _pendingExternalNavUrl = null;
        HideExternalNavBar();

        if (string.IsNullOrEmpty(url)) return;
        System.Diagnostics.Debug.WriteLine($"[SchemeHostPage] 用户确认外部跳转（新窗口）: {url}");

        try
        {
            // 复用宿主 WebView2 环境（同一数据目录 → 共享 Cookie/会话），
            // 创建独立浏览器窗口承载新页面，当前方案页面保持不变
            var env = WebViewControl.CoreWebView2?.Environment;
            if (env == null) return;

            var window = new Window
            {
                Title = _currentScheme?.DisplayName ?? "Kirara",
            };
            var newWebView = new Microsoft.UI.Xaml.Controls.WebView2();
            window.Content = newWebView;
            window.Activate();
            await newWebView.EnsureCoreWebView2Async(env);
            newWebView.CoreWebView2?.Navigate(url);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SchemeHostPage] 打开新窗口失败: {ex.Message}");
        }
    }

    /// <summary>
    /// [外部跳转确认] 横条"取消"按钮：放弃跳转，仅隐藏横条（页面保持原状）。
    /// </summary>
    private void OnExternalNavDismissClick(object sender, RoutedEventArgs e)
    {
        _pendingExternalNavUrl = null;
        HideExternalNavBar();
    }

    /// <summary>
    /// [崩溃自愈] 显示重建通知横条（带入场动画：左滑入 + 淡入 + 弹性微缩放）
    /// </summary>
    private void ShowWebViewFailureBar()
    {
        // 复位动画状态（防止重复显示时残留 X/Opacity）
        WebViewFailureBarTranslate.X = -60;
        WebViewFailureBar.Opacity = 0;

        WebViewFailureBar.Visibility = Visibility.Visible;

        var storyboard = (Storyboard)Resources["WebViewFailureBarInAnimation"];
        storyboard.Begin();
    }

    /// <summary>
    /// [崩溃自愈] 隐藏重建通知横条（带退场动画：右滑出 + 淡出，完成后 Collapsed）
    /// </summary>
    private void HideWebViewFailureBar()
    {
        if (WebViewFailureBar.Visibility != Visibility.Visible) return;

        var storyboard = (Storyboard)Resources["WebViewFailureBarOutAnimation"];
        storyboard.Completed += (_, _) =>
        {
            WebViewFailureBar.Visibility = Visibility.Collapsed;
            // 复位动画状态，供下次入场动画使用
            WebViewFailureBarTranslate.X = -60;
            WebViewFailureBar.Opacity = 1;
        };
        storyboard.Begin();
    }

    /// <summary>
    /// [崩溃自愈] 横条"立即重建"按钮：销毁并重建 WebView2（保留数据目录），
    /// 然后完整重走加载流程（ForceReloadSchemeAsync 绕过短路，初始化新控件）。
    /// 重建完成后隐藏横条并复位通知标记，允许后续再次崩溃时重新提示。
    /// </summary>
    private async void OnWebViewFailureRebuildClick(object sender, RoutedEventArgs e)
    {
        _webViewFailureNotified = false;

        HideWebViewFailureBar();

        await RestoreAfterWebViewFailureAsync();
        System.Diagnostics.Debug.WriteLine(
            $"[SchemeHostPage] WebView2 重建完成: {_currentScheme?.Name}");
    }

    /// <summary>
    /// [崩溃自愈] 横条关闭按钮：仅隐藏横条（带退场动画，用户稍后自行通过标签页刷新恢复）
    /// </summary>
    private void OnWebViewFailureDismissClick(object sender, RoutedEventArgs e)
    {
        HideWebViewFailureBar();
    }

    /// <summary>
    /// [崩溃自愈] 重建 WebView2（保留数据目录）并重走加载流程。
    /// </summary>
    public async Task RestoreAfterWebViewFailureAsync()
    {
        _webViewFailureNotified = false;
        await ResetAndRecreateWebViewAsync(deleteUserData: false);
        await ForceReloadSchemeAsync();
    }

    /// <summary>
    /// 返回 WebView2 用户数据文件夹路径。
    /// 代际号 == 0 → 默认路径；>0 → 新一代数据目录（旧目录因 lockfile 无法清理时自动切换）。
    /// 代际号从 SchemePageCache 查询：初始化实例销毁页面后新建的页面仍能延续代际，
    /// 不会回退到已被异步清理的旧数据目录（否则 WebView2 会复用旧 Cookie/表单状态）。
    /// </summary>
    private string GetWebViewUserDataFolder()
    {
        var baseDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Kirara", "webview2");
        var path = Path.Combine(baseDir, _instanceId.ToString("N"), _schemeId.ToString("N"));
        var generation = GetDataFolderGeneration();
        if (generation > 0)
            path = Path.Combine(path, $"gen_{generation}");
        return path;
    }

    /// <summary>
    /// 从全局缓存查询当前代际号（容器不可用时回退本地字段）。
    /// </summary>
    private int GetDataFolderGeneration()
    {
        try
        {
            return App.Services.GetRequiredService<ISchemePageCache>()
                .GetGeneration(_instanceId, _schemeId);
        }
        catch
        {
            return _dataFolderGeneration;
        }
    }

    /// <summary>
    /// 升代：代际号写入全局缓存（SchemePageCache），确保销毁页面后新建的页面延续代际；
    /// 容器不可用时仅本地升代（只对当前页面生效）。
    /// </summary>
    private int BumpDataFolderGeneration()
    {
        try
        {
            return App.Services.GetRequiredService<ISchemePageCache>()
                .BumpGeneration(_instanceId, _schemeId);
        }
        catch
        {
            return ++_dataFolderGeneration;
        }
    }

    /// <summary>
    /// 获取该方案的所有数据目录（含所有代数），用于批量清理。
    /// </summary>
    private string GetWebViewUserDataRoot()
    {
        var baseDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Kirara", "webview2");
        return Path.Combine(baseDir, _instanceId.ToString("N"), _schemeId.ToString("N"));
    }

    public async Task DestroyWebViewAsync(bool deleteUserData = false)
    {
        // [Kirara Media] 销毁前退出全屏（若 WebView2 正悬浮在窗口顶层），避免残留
        if (_isWebViewFullScreen) ExitWebViewFullScreen();

        // 清理挂起的外部跳转确认（横条随页面销毁，避免残留）
        _pendingExternalNavUrl = null;
        HideExternalNavBar();

        // 先关闭 WebView2（终止浏览器进程、WebSocket/HTTP 连接）
        try { WebViewControl.Close(); } catch { }
        _webViewEnv = null;
        _webViewInitialized = false;

        if (deleteUserData)
        {
            // 代际切换：立即切到新一代目录，确保下次创建 WebView2 时使用干净数据。
            // 代际号写入全局缓存（SchemePageCache），初始化实例销毁页面后
            // 新建的页面仍能延续代际，不会回退到旧数据目录。
            // WebView2 浏览器进程释放 lockfile 可能需要数秒，
            // 不能同步等待——旧目录的清理完全异步。
            _dataFolderGeneration = BumpDataFolderGeneration();

            var root = GetWebViewUserDataRoot();
            if (Directory.Exists(root))
            {
                // 异步后台清理所有旧代数据（fire-and-forget）
                var oldGens = _dataFolderGeneration; // 捕获当前代数前一代
                _ = Task.Run(async () =>
                {
                    await CleanupOldGenerationsAsync(root, oldGens);
                });
            }
        }
    }

    /// <summary>
    /// 后台清理旧代数据目录。递增延迟重试，最多 30 秒。
    /// 旧代目录无法清理也不影响正确性——当前代已经切到干净路径。
    /// </summary>
    private static async Task CleanupOldGenerationsAsync(string root, int currentGen)
    {
        // gen_0 即无后缀的根目录本身
        for (int gen = 0; gen < currentGen; gen++)
        {
            var target = gen == 0 ? root : Path.Combine(root, $"gen_{gen}");
            if (!Directory.Exists(target)) continue;

            for (int retry = 0; retry < 6; retry++)
            {
                try
                {
                    await Task.Delay(5000);
                    Directory.Delete(target, true);
                    break;
                }
                catch (DirectoryNotFoundException) { break; }
                catch (IOException)
                {
                    // lockfile 仍被占用，继续重试
                }
            }
        }
    }

    public async Task ResetAndRecreateWebViewAsync(bool deleteUserData)
    {
        // [Kirara Media] 重建前退出全屏（若 WebView2 正悬浮在窗口顶层），避免残留
        if (_isWebViewFullScreen) ExitWebViewFullScreen();

        // 清理挂起的外部跳转确认（横条随 WebView2 重建隐藏，避免残留）
        _pendingExternalNavUrl = null;
        HideExternalNavBar();

        try { WebViewControl.Close(); } catch { }
        try { WebViewHost.Children.Clear(); } catch { }
        _webViewInitialized = false;
        _webViewEnv = null;

        if (deleteUserData)
        {
            // 代际切换：立即切到新一代目录（写入全局缓存，硬重载后页面自身延续代际）
            _dataFolderGeneration = BumpDataFolderGeneration();

            var root = GetWebViewUserDataRoot();
            if (Directory.Exists(root))
            {
                var oldGens = _dataFolderGeneration;
                _ = Task.Run(async () => await CleanupOldGenerationsAsync(root, oldGens));
            }
        }

        var newWebView = new Microsoft.UI.Xaml.Controls.WebView2();
        WebViewHost.Children.Add(newWebView);
        WebViewControl = newWebView;
        await Task.Delay(100);
    }

    public async Task LoadSchemeAsync(Guid schemeId, SchemeBinding binding)
    {
        // 方案 ID、绑定 ID、令牌 ID 三者均未变化 → 无需重新加载
        // 必须比较 TokenId：令牌被删除后绑定 TokenId 变为 null，或重新绑定新令牌后变化，
        // 如果只比较 schemeId+bindingId，会导致 _viewModel.Reset() 不被调用，
        // _autoLoginState.IsHandled 保持 true，AutoLoginAsync 直接返回旧状态，重链接永久失效。
        if (_currentScheme?.Id == schemeId
            && _currentBinding?.Id == binding.Id
            && _currentBinding?.TokenId == binding.TokenId)
            return;

        _viewModel.Reset();

        // [评论区功能] 重置议题绑定缓存（实例绑定可能在两次加载间发生变化）
        _hasTopicBinding = null;

        var scheme = _schemeService.GetScheme(schemeId);
        if (scheme == null)
        {
            ShowError("找不到该方案");
            return;
        }

        HideAllContent();
        var (ui, hasPlugin) = await _viewModel.LoadSchemeAsync(scheme, binding);
        _currentScheme = scheme;
        _currentBinding = binding;

        if (_viewModel.HasError) { ShowError(_viewModel.ErrorMessage ?? "方案加载失败"); return; }

        if (hasPlugin && ui != null)
        {
            // 有 IScheme 插件：使用插件返回的 SchemeUI 渲染
            await RenderSchemeUIAsync(ui);
        }
        else
        {
            // 无插件：从 Scheme 模型直接渲染
            await RenderFromSchemeModelAsync(scheme);
        }

        // [评论区功能] 方案内容渲染完成后显示评论面板
        ShowCommentPanel(scheme);
    }

    /// <summary>
    /// 根据 SchemeUI 对象渲染内容
    /// </summary>
    private async Task RenderSchemeUIAsync(SchemeUI ui)
    {
        switch (ui.Kind)
        {
            case SchemeUIKind.WebView2: await ShowWebViewAsync(ui.WebViewUrl ?? _currentScheme?.WebViewUrl); break;
            case SchemeUIKind.CustomControl: ShowCustomControl(ui.CustomControl); break;
            case SchemeUIKind.RDP: ShowRdp(ui.RdpAddress); break;
            case SchemeUIKind.ExternalProcess: ShowExternalProcess(ui.ExternalProcessPath ?? _currentScheme?.ExecutablePath, ui.ExternalProcessArgs ?? _currentScheme?.Arguments); break;
            case SchemeUIKind.Overlay: ShowOverlay(); break;
            default: await ShowWebViewAsync(_currentScheme?.WebViewUrl); break;
        }
    }

    private async Task RenderFromSchemeModelAsync(Scheme scheme)
    {
        switch (scheme.UIKind)
        {
            case SchemeUIKind.WebView2: await ShowWebViewAsync(scheme.WebViewUrl); break;
            case SchemeUIKind.CustomControl: ShowCustomControl(null); break;
            case SchemeUIKind.RDP: ShowRdp(scheme.EntryAssembly); break;
            case SchemeUIKind.ExternalProcess: ShowExternalProcess(scheme.ExecutablePath, scheme.Arguments); break;
            case SchemeUIKind.Overlay: ShowOverlay(); break;
        }
    }

    private async Task ShowWebViewAsync(string? url)
    {
        // ===== 临时测试：强制显示错误遮罩 =====
        //ShowError("WebView2 初始化失败：CoreWebView2 为空");
        //return;

        EmptyContentPlaceholder.Visibility = Visibility.Collapsed;
        if (string.IsNullOrWhiteSpace(url)) { ShowError("无法加载方案：服务器地址未配置"); return; }

        WebViewHost.Visibility = Visibility.Visible;

        try
        {
            if (!_webViewInitialized)
            {
                const string lang = "zh-CN", langPrimary = "zh";
                var userDataFolder = GetWebViewUserDataFolder();
                Directory.CreateDirectory(userDataFolder);

                var options = new CoreWebView2EnvironmentOptions { Language = lang };
                _webViewEnv = await CoreWebView2Environment.CreateWithOptionsAsync(null, userDataFolder, options);
                await WebViewControl.EnsureCoreWebView2Async(_webViewEnv);

                var wv = WebViewControl.CoreWebView2;
                if (wv == null)
                {
                    try { WebViewControl.Close(); } catch { }
                    _webViewEnv = null;
                    ShowError("WebView2 初始化失败：CoreWebView2 为空");
                    return;
                }

                wv.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
                wv.WebResourceRequested += (_, args) => args.Request.Headers.SetHeader("Accept-Language", $"{lang},{langPrimary};q=0.9,en;q=0.5");
                await wv.AddScriptToExecuteOnDocumentCreatedAsync(
                    "(()=>{const L='zh-CN',LP='zh';Object.defineProperty(navigator,'language',{get:()=>L,configurable:true});Object.defineProperty(navigator,'languages',{get:()=>[L,LP,'en-US'],configurable:true});Object.defineProperty(navigator,'userLanguage',{get:()=>L,configurable:true});})();");

                // [方案页锁定] 封锁浏览器默认功能，刷新/控制台仅能通过方案标签页操作：
                // - AreDefaultContextMenusEnabled = false   → 禁用右键默认菜单（复制/检查/打印等）
                // - AreBrowserAcceleratorKeysEnabled = false → 禁用浏览器加速键（F5 刷新、F12 DevTools、Ctrl+R 等）
                // - AreDevToolsEnabled = false               → 彻底禁用 DevTools（双保险，防代码途径打开）
                //   说明：Ctrl+C/Ctrl+V 等文本编辑剪贴板键不受影响（非浏览器加速键）；
                //   页面自绘菜单（如视频播放器右键菜单）属于页面功能，不受浏览器级设置影响。
                // - IsStatusBarEnabled = false → 禁用左下角状态栏（鼠标悬停链接时不再显示目标 URL）
                wv.Settings.AreDefaultContextMenusEnabled = false;
                wv.Settings.AreBrowserAcceleratorKeysEnabled = false;
                wv.Settings.AreDevToolsEnabled = false;
                wv.Settings.IsStatusBarEnabled = false;

                // [崩溃自愈] 订阅 WebView2 浏览器进程失败事件：进程崩溃/退出/渲染进程崩溃时
                // 通知 InstanceWorkspace 显示横条提示用户手动重建（不自动重建，防循环崩溃）。
                wv.ProcessFailed -= OnWebViewProcessFailed;
                wv.ProcessFailed += OnWebViewProcessFailed;

                // [新窗口跳转] IMM 方案不订阅拦截事件：其控制台内嵌页面的新窗口请求
                // 按 WebView2 默认行为直接在独立浏览器窗口中打开（无拦截/无确认）；
                // 其他方案订阅拦截 → 显示确认横条，用户确认后才在新建浏览器窗口中打开。
                wv.NewWindowRequested -= OnWebViewNewWindowRequested;
                if (!IsImmScheme)
                {
                    wv.NewWindowRequested += OnWebViewNewWindowRequested;
                }

                // [Kirara Media] HTML5 全屏脱出适配：订阅全屏元素变化事件。
                // 仅当当前方案为 media（Jellyfin）时在回调中执行脱出逻辑，其他方案不干扰。
                wv.ContainsFullScreenElementChanged -= OnContainsFullScreenElementChanged;
                wv.ContainsFullScreenElementChanged += OnContainsFullScreenElementChanged;

                // [评论区功能] 注入 MutationObserver 脚本：监听目标 <bdi> 元素出现/变化，通过 postMessage 推送标题
                await wv.AddScriptToExecuteOnDocumentCreatedAsync(CommentTitleObserverScript);
                // [首页分享功能] 注入 SPA URL 变化监听脚本：pushState/popstate 触发 postMessage 通知 C# 端
                await wv.AddScriptToExecuteOnDocumentCreatedAsync(SpaUrlChangeObserverScript);
                wv.WebMessageReceived += OnCommentTitleWebMessage;

                _webViewInitialized = true;
            }

            _viewModel.TrackNavigationUrl(url);
            WebViewControl.Source = new Uri(url);

            if (WebViewControl.CoreWebView2 != null)
            {
                WebViewControl.CoreWebView2.SourceChanged -= OnWebViewSourceChangedForComment;
                WebViewControl.CoreWebView2.SourceChanged += OnWebViewSourceChangedForComment;
            }
        }
        catch (Exception ex) { ShowError($"WebView2 导航失败: {ex.Message}"); }
    }

    // ========== [Kirara Media] HTML5 全屏脱出 ==========

    /// <summary>
    /// WebView2 HTML5 全屏元素变化（Jellyfin 视频 requestFullscreen）。
    /// 仅当当前方案为 media（Kirara Media）时执行脱出逻辑：
    /// 全屏时将 WebView2 提升到窗口最顶层容器，使其覆盖标题栏/左侧栏/标签栏/状态栏，
    /// 实现视频真正脱出窗口限制；退出全屏时移回原宿主并恢复遮挡元素。
    /// 其他方案（如 Drive/Live 等 WebView2 方案）不启用此行为，保持原有内嵌显示。
    /// </summary>
    private void OnContainsFullScreenElementChanged(CoreWebView2 sender, object args)
    {
        // 仅 Kirara Media 方案启用全屏脱出
        if (_currentScheme?.Name != "media") return;

        var isFullScreen = sender.ContainsFullScreenElement;
        _ = DispatcherQueue.TryEnqueue(() => HandleFullScreenChange(isFullScreen));
    }

    private void HandleFullScreenChange(bool isFullScreen)
    {
        if (isFullScreen == _isWebViewFullScreen) return;
        _isWebViewFullScreen = isFullScreen;

        if (isFullScreen) EnterWebViewFullScreen();
        else ExitWebViewFullScreen();
    }

    private void EnterWebViewFullScreen()
    {
        // 1. 记录原宿主并移除 WebView2
        _fullScreenHost = WebViewHost;
        WebViewHost.Children.Remove(WebViewControl);

        // 2. 添加到窗口最顶层容器（MainWindow.Content 的根 Grid）
        var root = MainWindow.Current?.Content as Grid;
        if (root == null)
        {
            // 找不到顶层容器则回退：放回原宿主，保持原行为
            WebViewHost.Children.Add(WebViewControl);
            _fullScreenHost = null;
            return;
        }

        root.Children.Add(WebViewControl);
        WebViewControl.HorizontalAlignment = HorizontalAlignment.Stretch;
        WebViewControl.VerticalAlignment = VerticalAlignment.Stretch;

        // 3. 隐藏遮挡元素（标题栏/左侧栏/标签栏/状态栏）
        HideShellChrome();

        // 4. 将主窗口切换为真正的全屏演示器：无论窗口之前是普通/最大化，
        //    都覆盖整个屏幕（含系统任务栏），实现视频真正全屏
        EnterTrueFullScreen();
    }

    private void ExitWebViewFullScreen()
    {
        // 0. 退出真全屏演示器（若窗口处于全屏状态），恢复之前的窗口状态
        ExitTrueFullScreen();

        // 1. 从顶层容器移除
        var root = MainWindow.Current?.Content as Grid;
        if (root != null)
            root.Children.Remove(WebViewControl);

        // 2. 移回原宿主（原宿主不可用时回退 WebViewHost）
        if (_fullScreenHost != null)
            _fullScreenHost.Children.Add(WebViewControl);
        else
            WebViewHost.Children.Add(WebViewControl);
        _fullScreenHost = null;

        // 3. 恢复遮挡元素
        ShowShellChrome();
    }

    /// <summary>
    /// 将主窗口切换为全屏演示器（AppWindowPresenterKind.FullScreen）：
    /// 窗口覆盖整个屏幕（包括系统任务栏），与窗口之前是否最大化无关。
    /// 切换前保存最大化状态，供退出时恢复。
    /// </summary>
    private void EnterTrueFullScreen()
    {
        try
        {
            var window = MainWindow.Current;
            if (window == null) return;

            var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(window);
            var windowId = Microsoft.UI.Win32Interop.GetWindowIdFromWindow(hwnd);
            var appWindow = Microsoft.UI.Windowing.AppWindow.GetFromWindowId(windowId);
            if (appWindow == null) return;

            // 记录当前显示状态（退出全屏时恢复）
            if (appWindow.Presenter is Microsoft.UI.Windowing.OverlappedPresenter op)
            {
                _wasMaximizedBeforeFullScreen =
                    op.State == Microsoft.UI.Windowing.OverlappedPresenterState.Maximized;
            }

            // 切换为全屏演示器：覆盖整个屏幕（含任务栏）
            appWindow.SetPresenter(Microsoft.UI.Windowing.AppWindowPresenterKind.FullScreen);
            System.Diagnostics.Debug.WriteLine("[SchemeHostPage] 已进入真全屏（覆盖整个屏幕）");
        }
        catch (Exception ex)
        {
            // 全屏演示器切换失败不致命：WebView2 仍已提升到窗口顶层（填满窗口）
            System.Diagnostics.Debug.WriteLine($"[SchemeHostPage] 进入真全屏失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 退出全屏演示器，恢复为之前的窗口状态（最大化/普通）。
    /// 幂等：非全屏状态直接返回。
    /// </summary>
    private void ExitTrueFullScreen()
    {
        try
        {
            var window = MainWindow.Current;
            if (window == null) return;

            var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(window);
            var windowId = Microsoft.UI.Win32Interop.GetWindowIdFromWindow(hwnd);
            var appWindow = Microsoft.UI.Windowing.AppWindow.GetFromWindowId(windowId);
            if (appWindow == null) return;

            // 仅当当前处于全屏演示器时才退出（避免干扰其他 presenter）
            if (appWindow.Presenter.Kind != Microsoft.UI.Windowing.AppWindowPresenterKind.FullScreen)
                return;

            appWindow.SetPresenter(Microsoft.UI.Windowing.AppWindowPresenterKind.Overlapped);

            // 恢复之前的最大化状态
            if (appWindow.Presenter is Microsoft.UI.Windowing.OverlappedPresenter op)
            {
                if (_wasMaximizedBeforeFullScreen) op.Maximize();
                else op.Restore();
            }

            System.Diagnostics.Debug.WriteLine("[SchemeHostPage] 已退出真全屏");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SchemeHostPage] 退出真全屏失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 退出全屏状态（供外部在导航离开/切换标签前调用，避免 WebView2 残留悬浮在窗口顶层）。
    /// 幂等：非全屏状态直接返回。
    /// </summary>
    public void ExitFullScreenIfNeeded()
    {
        if (!_isWebViewFullScreen) return;
        _ = DispatcherQueue.TryEnqueue(() => ExitWebViewFullScreen());
    }

    /// <summary>
    /// 隐藏窗口内会遮挡全屏视频的元素：自定义标题栏、左侧功能栏、全局忙遮罩
    /// （ShellPage 内）以及方案标签栏、状态栏（InstanceWorkspace 内）。
    /// </summary>
    private void HideShellChrome()
    {
        _hiddenChrome.Clear();

        var root = MainWindow.Current?.Content as Grid;
        if (root == null) return;

        // MainWindow.Content → RootFrame → ShellPage
        var rootFrame = root.Children.OfType<Frame>().FirstOrDefault();
        var shellPage = rootFrame?.Content as FrameworkElement;
        if (shellPage == null) return;

        HideIfFound(shellPage, "TitleBarControl");
        HideIfFound(shellPage, "LeftBar");
        HideIfFound(shellPage, "GlobalBusyOverlay");

        // ShellPage.ContentFrame → 当前页面（可能为 InstanceWorkspace）
        if (shellPage.FindName("ContentFrame") is Frame contentFrame
            && contentFrame.Content is FrameworkElement currentPage)
        {
            HideIfFound(currentPage, "SchemeTabBarControl");
            HideIfFound(currentPage, "StatusBarControl");
        }
    }

    private void ShowShellChrome()
    {
        foreach (var el in _hiddenChrome)
            el.Visibility = Visibility.Visible;
        _hiddenChrome.Clear();
    }

    private void HideIfFound(FrameworkElement root, string name)
    {
        var el = root.FindName(name) as UIElement;
        if (el != null && el.Visibility == Visibility.Visible)
        {
            el.Visibility = Visibility.Collapsed;
            _hiddenChrome.Add(el);
        }
    }

    private void ShowCustomControl(object? control)
    {
        EmptyContentPlaceholder.Visibility = Visibility.Collapsed;
        CustomControlHost.Visibility = Visibility.Visible;

        // OpenVPN 用户版：注入方案重载委托（硬重载时强制重走部署流程，绕过 LoadSchemeAsync 相同参数短路）
        if (control is OpenVpnControl ovpnControl)
        {
            ovpnControl.SchemeReloader = async () =>
            {
                if (_currentScheme != null && _currentBinding != null)
                {
                    await ForceReloadSchemeAsync();
                    return !_viewModel.HasError;
                }
                return false;
            };
        }

        // OpenVPN 服务版：注入方案重载委托（硬重载时清空配置库 → 重走部署流程，重建面板）
        if (control is OpenVpnServiceControl ovpnServiceControl)
        {
            ovpnServiceControl.SchemeReloader = async () =>
            {
                if (_currentScheme != null && _currentBinding != null)
                {
                    await ForceReloadSchemeAsync();
                    return !_viewModel.HasError;
                }
                return false;
            };
        }

        CustomControlHost.Content = control is FrameworkElement fe ? fe : new TextBlock { Text = _currentScheme?.DisplayName ?? "自定义方案", HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, FontSize = 14, Opacity = 0.4 };
    }

    private void ShowRdp(string? address)
    {
        EmptyContentPlaceholder.Visibility = Visibility.Collapsed;
        RdpHost.Visibility = Visibility.Visible;
        RdpAddressText.Text = !string.IsNullOrWhiteSpace(address) ? $"远程桌面: {address}" : "远程桌面连接";
    }

    private void ShowExternalProcess(string? path, string? args)
    {
        EmptyContentPlaceholder.Visibility = Visibility.Collapsed;
        ExternalProcessHost.Visibility = Visibility.Visible;
        // [占位提示] 游戏服务器方案当前显示"开发中"占位，不展示进程信息
        ExternalProcessName.Text = "该功能正在开发中，敬请期待...";
        ExternalProcessStatus.Text = "游戏服务器方案";
    }

    private void ShowOverlay()
    {
        EmptyContentPlaceholder.Visibility = Visibility.Collapsed;
        OverlayHost.Visibility = Visibility.Visible;
    }

    private void OnWebViewSourceChangedForComment(Microsoft.Web.WebView2.Core.CoreWebView2 sender, Microsoft.Web.WebView2.Core.CoreWebView2SourceChangedEventArgs args)
    {
        SyncCommentResourceKey();
    }

    private async void SyncCommentResourceKey(string? jsReportedUrl = null)
    {
        try
        {
            // 优先使用 JS 端报告的 URL（SPA hash 路由变化时 WebView2.Source 可能尚未更新）
            var currentUrl = jsReportedUrl ?? WebViewControl.CoreWebView2?.Source ?? string.Empty;

            // [首页分享功能] 同步当前页面 URL 到评论 ViewModel（“发送并分享”时存入源地址）
            if (_commentViewModel != null)
                _commentViewModel.CurrentPageUrl = currentUrl;

            // [评论区功能] 评论区/分享区仅在 Kirara Media 方案中显示（其他方案一律隐藏且不拉取）
            if (!IsMediaScheme())
            {
                HideSharedContentPanel();
                HideCommentPanel();
                return;
            }

            // [首页分享功能] 根据是否为首页控制分享面板显示/隐藏
            if (IsHomePage(currentUrl))
            {
                ShowSharedContentPanel();
            }
            else
            {
                HideSharedContentPanel();
            }

            // [评论区功能] 仅当 URL 归一化路径为 details 时显示评论区，其他页面隐藏且不拉取
            if (!IsDetailsPath(currentUrl))
            {
                HideCommentPanel();
                return;
            }

            var schemeName = _currentScheme?.Name ?? "unknown";
            string resourceKey;
            string? resourceTitle;

            // 尝试加载方案插件实例，检查是否实现了 IResourceContextProvider
            var schemeInstance = _currentScheme != null ? _schemeService.LoadSchemeInstance(_currentScheme) : null;

            if (schemeInstance is IResourceContextProvider contextProvider)
            {
                var customKey = contextProvider.GetResourceKey();
                resourceKey = customKey != null
                    ? $"{schemeName}://{new Uri(currentUrl).Authority}{customKey}"
                    : ResourceKeyBuilder.FromUrl(schemeName, currentUrl);
                resourceTitle = contextProvider.GetResourceTitle();
            }
            else
            {
                resourceKey = ResourceKeyBuilder.FromUrl(schemeName, currentUrl);
                resourceTitle = _currentScheme?.DisplayName;
            }

            // [评论区功能] 资源键未变化时跳过（标题由 WebMessageReceived 事件驱动更新）
            if (_commentViewModel!.ResourceKey == resourceKey) return;

            // [评论区功能] 实例未绑定议题方案时不显示评论区
            if (!EnsureTopicBindingChecked()) return;

            // 资源键变化：重置标题（避免显示上一页的旧标题，新标题由 MutationObserver 事件推送）
            _commentViewModel.ResourceTitle = "评论区";

            // 仅重置 JS 端 lastTitle（不立即 check，因为此时 SPA 尚未渲染新页面 DOM）
            // 后续 DOM 变化时 observer 自然触发 check，因 lastTitle 已清空必定推送新标题
            try { await WebViewControl.CoreWebView2!.ExecuteScriptAsync("window.__resetCommentTitleObserver && window.__resetCommentTitleObserver()"); } catch { }

            // 更新评论数据上下文并加载评论（标题传 null，不覆盖 "评论区"，由 observer 事件异步更新）
            _ = _commentViewModel.SetContextAndLoadAsync(resourceKey, _currentScheme?.Id ?? Guid.Empty, null, _instanceId);

            // [三态持久化] 折叠态：仅显示右下角缩成钮，不显示面板
            if (_isCommentCollapsed)
            {
                CommentExpandButton.Opacity = 1.0;
                CommentExpandButtonScale.ScaleX = 1.0;
                CommentExpandButtonScale.ScaleY = 1.0;
                CommentExpandButton.Visibility = Visibility.Visible;
                return;
            }

            // 仅在未折叠时才显示评论面板（带动画）
            if (CommentOverlay.Visibility != Visibility.Visible)
            {
                ShowCommentPanelWithAnimation();
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[评论区] 资源上下文同步失败: {ex.Message}");
        }
    }

    // ================================================================
    //  [首页分享功能] SPA URL 变化监听脚本（pushState/popstate → postMessage）
    // ================================================================

    /// <summary>
    /// 注入到 WebView2 的 SPA URL 变化监听脚本。
    /// 拦截 history.pushState / replaceState，并监听 popstate 事件，
    /// 当 URL 变化时通过 chrome.webview.postMessage 通知 C# 端。
    /// </summary>
    private const string SpaUrlChangeObserverScript = @"
(function() {
    var lastUrl = location.href;
    function notify() {
        var url = location.href;
        if (url !== lastUrl) {
            lastUrl = url;
            chrome.webview.postMessage({ type: 'spaUrlChange', url: url });
        }
    }
    var origPush = history.pushState;
    var origReplace = history.replaceState;
    history.pushState = function() {
        origPush.apply(this, arguments);
        notify();
    };
    history.replaceState = function() {
        origReplace.apply(this, arguments);
        notify();
    };
    window.addEventListener('popstate', notify);
    window.addEventListener('hashchange', notify);
})();";

    // ================================================================
    //  [评论区功能] 事件驱动标题获取（MutationObserver + WebMessageReceived）
    // ================================================================

    /// <summary>
    /// 注入到 WebView2 的 MutationObserver 脚本。
    /// 监听 DOM 变化，当目标 &lt;bdi&gt; 元素出现或文本变化时，
    /// 通过 chrome.webview.postMessage 推送标题到 C# 端。
    /// </summary>
    private const string CommentTitleObserverScript = @"
(function() {
    var lastTitle = '';
    var timer = null;
    var reconnectTimer = null;
    function isVisible(el) {
        var node = el;
        while (node && node !== document.body) {
            if (node.classList && node.classList.contains('hide')) return false;
            node = node.parentElement;
        }
        return true;
    }
    function check() {
        var els = document.querySelectorAll('.parentName.focuscontainer-x bdi a, .parentName.focuscontainer-x bdi, .itemName.infoText.parentNameLast bdi');
        var el = null;
        for (var i = els.length - 1; i >= 0; i--) {
            if (isVisible(els[i])) { el = els[i]; break; }
        }
        if (!el && els.length) el = els[els.length - 1];
        var title = el ? el.textContent.trim() : '';
        if (title && title !== lastTitle) {
            lastTitle = title;
            chrome.webview.postMessage({ type: 'commentTitleUpdate', title: title });
        }
    }
    var observer = new MutationObserver(function() {
        if (timer) clearTimeout(timer);
        timer = setTimeout(check, 100);
    });
    function startObserving() {
        observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    }
    // 供 C# 端调用：页面切换时重置。
    // 断开 observer 并延迟重连，跳过 SPA 过渡动画期（等待 Jellyfin 对旧页面添加 .hide）。
    window.__resetCommentTitleObserver = function() {
        lastTitle = '';
        if (timer) { clearTimeout(timer); timer = null; }
        observer.disconnect();
        if (reconnectTimer) clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(function() {
            reconnectTimer = null;
            check();
            startObserving();
        }, 600);
    };
    function start() {
        check();
        startObserving();
    }
    if (document.body) start();
    else document.addEventListener('DOMContentLoaded', start);
})();";

    /// <summary>
    /// [评论区功能] 页面标题主动探针脚本（v1.10 修复）。
    /// 提交评论时由 C# 端 ExecuteScriptAsync 调用，实时查询当前页面视频标题。
    /// 与 CommentTitleObserverScript 共用选择器逻辑；额外提供：
    /// - 多选择器兜底（兼容 Jellyfin 不同版本的 DOM 类名变化）
    /// - document.title 清洗兜底（"阿凡达 - Jellyfin" → "阿凡达"）
    /// 返回：标题字符串（无匹配时返回空字符串）
    /// </summary>
    private const string PageTitleProbeScript = @"
(() => {
    try {
        var selectors = [
            '.parentName.focuscontainer-x bdi a',
            '.parentName.focuscontainer-x bdi',
            '.itemName.infoText.parentNameLast bdi',
            '.itemName.parentNameLast bdi'
        ];
        var all = [];
        for (var i = 0; i < selectors.length; i++) {
            var found = document.querySelectorAll(selectors[i]);
            for (var j = 0; j < found.length; j++) all.push(found[j]);
        }
        // 从后往前找可见元素（SPA 过渡期旧页面带 .hide 类，跳过）
        var el = null;
        for (var k = all.length - 1; k >= 0; k--) {
            var node = all[k];
            var visible = true;
            while (node && node !== document.body) {
                if (node.classList && node.classList.contains('hide')) { visible = false; break; }
                node = node.parentElement;
            }
            if (visible) { el = all[k]; break; }
        }
        if (el) {
            var t = el.textContent.trim();
            if (t) return t;
        }
        // 兜底：document.title 清洗（去掉站点后缀）
        var dt = (document.title || '').replace(/\s*[-–—|]\s*(Jellyfin|Kirara\s*Media).*$/i, '').trim();
        return dt;
    } catch (e) { return ''; }
})();";

    /// <summary>
    /// [评论区功能] 通过 WebView2 主动读取当前页面视频标题（v1.10 修复）。
    /// 提交评论时被 _commentViewModel.FetchPageTitleAsync 调用。
    /// ExecuteScriptAsync 返回 JSON 编码字符串，需反序列化还原。
    /// </summary>
    private async Task<string?> FetchMediaPageTitleAsync()
    {
        try
        {
            if (WebViewControl.CoreWebView2 == null) return null;
            var json = await WebViewControl.CoreWebView2.ExecuteScriptAsync(PageTitleProbeScript);
            if (string.IsNullOrWhiteSpace(json) || json == "null") return null;
            var title = System.Text.Json.JsonSerializer.Deserialize<string>(json);
            return string.IsNullOrWhiteSpace(title) ? null : title;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[评论区] 页面标题主动读取失败: {ex.Message}");
            return null;
        }
    }

    /// <summary>
    /// [评论区功能] 处理 WebView2 推送的消息。
    /// 支持两种消息类型：
    /// - commentTitleUpdate：MutationObserver 检测到标题变化
    /// - spaUrlChange：SPA pushState/popstate 检测到 URL 变化
    /// </summary>
    private void OnCommentTitleWebMessage(object? sender, CoreWebView2WebMessageReceivedEventArgs args)
    {
        try
        {
            var json = args.WebMessageAsJson;
            using var doc = System.Text.Json.JsonDocument.Parse(json);
            var root = doc.RootElement;

            if (!root.TryGetProperty("type", out var typeProp)) return;
            var type = typeProp.GetString();

            if (type == "commentTitleUpdate" &&
                root.TryGetProperty("title", out var titleProp))
            {
                var title = titleProp.GetString();
                if (!string.IsNullOrWhiteSpace(title))
                {
                    System.Diagnostics.Debug.WriteLine($"[评论区] MutationObserver 标题推送: {title}");
                    if (_commentViewModel != null)
                        _commentViewModel.ResourceTitle = title;
                }
            }
            else if (type == "spaUrlChange")
            {
                // SPA 内部路由变化：用 JS 报告的 URL 重新判断首页/详情页
                var url = root.TryGetProperty("url", out var urlProp) ? urlProp.GetString() : null;
                SyncCommentResourceKey(url);
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[评论区] 消息解析失败: {ex.Message}");
        }
    }

    /// <summary>
    /// [评论区功能] 判断 URL 归一化路径是否为 details 页面。
    /// 仅 details 页面显示评论区，其他页面（首页、列表等）不显示。
    /// </summary>
    private static bool IsDetailsPath(string url)
    {
        if (string.IsNullOrWhiteSpace(url) || url == "about:blank")
            return false;

        try
        {
            var uri = new Uri(url);
            // SPA hash 路由：检查 fragment（如 #/details.html?id=xxx）
            if (!string.IsNullOrEmpty(uri.Fragment))
                return uri.Fragment.Contains("details", StringComparison.OrdinalIgnoreCase);

            // 传统路径：检查 AbsolutePath（如 /details/123）
            return uri.AbsolutePath.Contains("details", StringComparison.OrdinalIgnoreCase);
        }
        catch (UriFormatException)
        {
            return false;
        }
    }

    /// <summary>
    /// [首页分享功能] 判断 URL 归一化路径是否为 home 页面。
    /// 仅 home 页面显示分享面板，其他页面隐藏。
    /// </summary>
    private static bool IsHomePage(string url)
    {
        if (string.IsNullOrWhiteSpace(url) || url == "about:blank")
            return false;

        try
        {
            var uri = new Uri(url);
            // SPA hash 路由：检查 fragment 中的路径部分（不含查询参数，避免 context=home 等误判）
            if (!string.IsNullOrEmpty(uri.Fragment))
            {
                // Fragment 如 #/details?id=xxx&context=home → 取 ? 前的 #/details 部分
                var fragment = uri.Fragment;
                var queryIndex = fragment.IndexOf('?');
                var hashIndex = fragment.IndexOf('#', 1); // 跳过开头的 #
                var pathEnd = fragment.Length;
                if (queryIndex > 0) pathEnd = Math.Min(pathEnd, queryIndex);
                if (hashIndex > 0) pathEnd = Math.Min(pathEnd, hashIndex);
                var fragmentPath = fragment.Substring(0, pathEnd);
                return fragmentPath.Contains("home", StringComparison.OrdinalIgnoreCase);
            }

            // 传统路径：检查 AbsolutePath（如 /home）
            return uri.AbsolutePath.Contains("home", StringComparison.OrdinalIgnoreCase);
        }
        catch (UriFormatException)
        {
            return false;
        }
    }

    /// <summary>
    /// [评论区功能] 隐藏评论面板（URL 离开 details 页面时调用）
    /// [三态持久化] 不重置折叠状态（_isCommentCollapsed）：用户离开再返回时保持折叠/全屏态，
    /// 仅隐藏可视元素，重新进入由 ShowCommentPanel / SyncCommentResourceKey 按状态恢复。
    /// </summary>
    private void HideCommentPanel()
    {
        if (CommentOverlay.Visibility == Visibility.Visible)
            CommentOverlay.Visibility = Visibility.Collapsed;

        // 离开 details 页面时同时隐藏展开按钮，防止在非 details 页面打开评论区
        if (CommentExpandButton.Visibility == Visibility.Visible)
            CommentExpandButton.Visibility = Visibility.Collapsed;

        // [BUG 修复] 重置资源键：离开 details 页后必须清空 ResourceKey，
        // 否则"返回主页 → 再次进入同一个详情页"时 SyncCommentResourceKey 中
        // `ResourceKey == resourceKey` 短路 return，评论区将无法再次显示
        // （表现为：同一视频第二次跳转评论区消失，换其他视频后才恢复）
        if (_commentViewModel != null)
            _commentViewModel.ResourceKey = string.Empty;
    }

    // ================================================================
    //  [首页分享功能] 分享面板显示/隐藏/折叠/展开（与评论区完全一致）
    // ================================================================

    /// <summary>
    /// [首页分享功能] 分享面板滑入动画（按当前状态应用布局：气泡 / 最大化）
    /// </summary>
    private void ShowSharedContentPanelWithAnimation()
    {
        // [首页分享功能] 按当前状态应用布局（气泡留白 / 最大化顶边空隙），面板未可见时直接设置
        ApplySharedContentLayout(animate: false);
        SharedContentPanelControl.SetFullExpandedVisualState(_isSharedContentFullExpanded);

        // 滑入距离 = 分享面板容器总高度（卡片 280 + 底部留白 24）
        SharedContentSlideTransform.Y = CommentExpandedHeight + 24;
        SharedContentOverlay.Visibility = Visibility.Visible;
        var slideIn = new Storyboard();
        var animY = new DoubleAnimation
        {
            From = CommentExpandedHeight + 24,
            To = 0,
            Duration = TimeSpan.FromMilliseconds(350),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(animY, SharedContentSlideTransform);
        Storyboard.SetTargetProperty(animY, "Y");
        slideIn.Children.Add(animY);
        slideIn.Begin();
    }

    /// <summary>
    /// [首页分享功能] 显示分享面板（页内覆盖层，与评论区一致）
    /// </summary>
    private void ShowSharedContentPanel()
    {
        if (_sharedContentViewModel == null) return;

        // [跨设备分享修复] 注入当前实例 ID：分享面板在实例工作区内打开，
        // 分享项来源实例跨设备可能无效，跳转时优先回退到当前所在实例
        _sharedContentViewModel.CurrentInstanceId = _instanceId;

        // 加载分享列表（仅首次或未加载时）
        _ = _sharedContentViewModel.LoadHomepageCommentsAsync();

        // [三态持久化] 折叠态：仅显示右下角缩成钮，不显示面板
        if (_isSharedContentCollapsed)
        {
            SharedContentExpandButton.Opacity = 1.0;
            SharedContentExpandButtonScale.ScaleX = 1.0;
            SharedContentExpandButtonScale.ScaleY = 1.0;
            SharedContentExpandButton.Visibility = Visibility.Visible;
            return;
        }

        // 仅在未折叠时才显示分享面板（带动画）
        if (SharedContentOverlay.Visibility != Visibility.Visible)
        {
            ShowSharedContentPanelWithAnimation();
        }
    }

    /// <summary>
    /// [首页分享功能] 隐藏分享面板和展开按钮（URL 离开 home 页面时调用）
    /// [三态持久化] 不重置折叠状态（_isSharedContentCollapsed）：用户离开再返回时保持折叠/全屏态，
    /// 仅隐藏可视元素，重新进入由 ShowSharedContentPanel 按状态恢复。
    /// </summary>
    private void HideSharedContentPanel()
    {
        if (SharedContentOverlay.Visibility == Visibility.Visible)
            SharedContentOverlay.Visibility = Visibility.Collapsed;

        if (SharedContentExpandButton.Visibility == Visibility.Visible)
            SharedContentExpandButton.Visibility = Visibility.Collapsed;
    }

    /// <summary>
    /// [首页分享功能] 折叠分享面板：向下滑出隐藏，显示右下角圆形展开按钮（与评论折叠完全一致）
    /// 抽屉式滑出距离与时长按当前状态自适应：
    ///   气泡态：滑出 304px（卡片高+留白），300ms
    ///   全屏态：滑出整页高度（距离更大），按距离比例延长时长，保证动画完整播放
    /// </summary>
    private void OnSharedContentCollapseToggle()
    {
        _isSharedContentCollapsed = true;

        // [首页分享功能] 抽屉式滑出距离：按当前状态自适应（全屏态为整页高度，气泡态为卡片高+留白）
        double slideDistance = GetSharedContentPanelHeight(_isSharedContentFullExpanded);

        // [首页分享功能] 时长随距离自适应：以气泡态 304px/300ms 为基准，全屏态按比例延长
        var slideDuration = TimeSpan.FromMilliseconds(
            Math.Clamp(300 * slideDistance / (CommentExpandedHeight + 24), 300, 700));

        var slideOut = new Storyboard();
        var animY = new DoubleAnimation
        {
            From = SharedContentSlideTransform.Y,
            To = slideDistance,
            Duration = slideDuration,
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
        };
        Storyboard.SetTarget(animY, SharedContentSlideTransform);
        Storyboard.SetTargetProperty(animY, "Y");
        slideOut.Children.Add(animY);
        slideOut.Completed += (_, _) =>
        {
            slideOut.Stop();
            SharedContentOverlay.Visibility = Visibility.Collapsed;
            SharedContentSlideTransform.Y = slideDistance;

            SharedContentExpandButton.Opacity = 0;
            SharedContentExpandButtonScale.ScaleX = 0.88;
            SharedContentExpandButtonScale.ScaleY = 0.88;
            SharedContentExpandButton.Visibility = Visibility.Visible;
            var appearSb = new Storyboard();
            var appOpacity = new DoubleAnimation
            {
                From = 0,
                To = 1.0,
                Duration = TimeSpan.FromMilliseconds(280),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(appOpacity, SharedContentExpandButton);
            Storyboard.SetTargetProperty(appOpacity, "Opacity");
            appearSb.Children.Add(appOpacity);
            var appScaleX = new DoubleAnimation
            {
                From = 0.88,
                To = 1.0,
                Duration = TimeSpan.FromMilliseconds(350),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(appScaleX, SharedContentExpandButtonScale);
            Storyboard.SetTargetProperty(appScaleX, "ScaleX");
            appearSb.Children.Add(appScaleX);
            var appScaleY = new DoubleAnimation
            {
                From = 0.88,
                To = 1.0,
                Duration = TimeSpan.FromMilliseconds(350),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(appScaleY, SharedContentExpandButtonScale);
            Storyboard.SetTargetProperty(appScaleY, "ScaleY");
            appearSb.Children.Add(appScaleY);
            appearSb.Begin();
        };
        slideOut.Begin();
    }

    /// <summary>
    /// [首页分享功能] 点击右下角展开按钮：隐藏按钮，分享面板向上滑入（与评论展开完全一致）
    /// </summary>
    private void OnSharedContentExpandButtonClick(object sender, RoutedEventArgs e)
    {
        _isSharedContentCollapsed = false;

        var btnSb = new Storyboard();
        var btnScaleX = new DoubleAnimation
        {
            From = 1.0,
            To = 0.3,
            Duration = TimeSpan.FromMilliseconds(180),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
        };
        Storyboard.SetTarget(btnScaleX, SharedContentExpandButtonScale);
        Storyboard.SetTargetProperty(btnScaleX, "ScaleX");
        btnSb.Children.Add(btnScaleX);
        var btnScaleY = new DoubleAnimation
        {
            From = 1.0,
            To = 0.3,
            Duration = TimeSpan.FromMilliseconds(180),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
        };
        Storyboard.SetTarget(btnScaleY, SharedContentExpandButtonScale);
        Storyboard.SetTargetProperty(btnScaleY, "ScaleY");
        btnSb.Children.Add(btnScaleY);
        btnSb.Completed += (_, _) =>
        {
            SharedContentExpandButton.Visibility = Visibility.Collapsed;
            SharedContentExpandButton.Opacity = 1.0;
            SharedContentExpandButtonScale.ScaleX = 1.0;
            SharedContentExpandButtonScale.ScaleY = 1.0;

            SharedContentOverlay.Visibility = Visibility.Visible;
            // [首页分享功能] 恢复为气泡态（重置最大化状态与布局）
            _isSharedContentFullExpanded = false;
            ApplySharedContentLayout(animate: false);
            SharedContentPanelControl.SetFullExpandedVisualState(false);
            SharedContentSlideTransform.Y = CommentExpandedHeight + 24;
            var slideIn = new Storyboard();
            var animY = new DoubleAnimation
            {
                From = CommentExpandedHeight + 24,
                To = 0,
                Duration = TimeSpan.FromMilliseconds(350),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(animY, SharedContentSlideTransform);
            Storyboard.SetTargetProperty(animY, "Y");
            slideIn.Children.Add(animY);
            slideIn.Begin();
        };
        btnSb.Begin();
    }

    /// <summary>
    /// [评论区功能] 评论面板滑入动画（按当前状态应用布局：气泡 / 全展开）
    /// </summary>
    private void ShowCommentPanelWithAnimation()
    {
        // [评论区功能] 按当前状态应用布局（气泡留白 / 全展开顶边空隙），面板未可见时直接设置
        ApplyCommentPanelLayout(animate: false);
        CommentPanelControl.SetPanelState(_commentPanelState);

        // 滑入距离 = 面板当前高度（全展开更高，从底部滑入更远）
        var slideDistance = GetCommentPanelSlideDistance();
        CommentSlideTransform.Y = slideDistance;
        CommentOverlay.Visibility = Visibility.Visible;
        var slideIn = new Storyboard();
        var animY = new DoubleAnimation
        {
            From = slideDistance,
            To = 0,
            Duration = TimeSpan.FromMilliseconds(350),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(animY, CommentSlideTransform);
        Storyboard.SetTargetProperty(animY, "Y");
        slideIn.Children.Add(animY);
        slideIn.Begin();
    }

    /// <summary>
    /// [评论区功能] 计算评论面板滑入/滑出距离：面板容器总高度（卡片 + 底部留白；全展开 = 页面高度）
    /// </summary>
    private double GetCommentPanelSlideDistance()
    {
        if (_commentPanelState == CommentPanelState.FullExpanded)
        {
            // 全展开：容器高度 = 页面可用高度；页面未布局时兜底气泡容器高度
            return ActualHeight > 0 ? ActualHeight : _commentBubbleHeight + 24;
        }
        return _commentBubbleHeight + 24;
    }

    /// <summary>
    /// [评论区功能] 切换 气泡 ↔ 全展开（标题栏全展开按钮）
    /// 淡化过渡：淡出 → 透明状态下切换布局（无视觉移位）→ 淡入
    /// </summary>
    private void OnCommentFullExpandToggle()
    {
        if (_isCommentCollapsed) return;

        _commentPanelState = _commentPanelState == CommentPanelState.FullExpanded
            ? CommentPanelState.Expanded
            : CommentPanelState.FullExpanded;

        // [评论区功能] 优雅过渡：淡出+轻微收缩 → 透明状态下切换布局（无移位） → 淡入+缩放浮现
        FadeSwitchPanel(CommentOverlay, CommentPanelCardScale, _commentFadeState, () =>
        {
            ApplyCommentPanelLayout(animate: false);
            CommentPanelControl.SetPanelState(_commentPanelState);
        });
    }

    /// <summary>
    /// [评论区功能] 优雅过渡切换：
    /// 淡出（100ms EaseIn，Opacity 1→0 + 卡片轻微收缩 Scale 1→0.96）
    ///   → 透明状态下执行布局切换（无视觉移位）
    ///   → 淡入（240ms EaseOut，Opacity 0→1 + 卡片缩放浮现 Scale 0.96→1）
    /// 每个动画 Completed 中先 Stop() 释放属性控制（HoldEnd 会永久钉住属性），再显式赋终值
    /// </summary>
    private static void FadeSwitchPanel(UIElement overlay, ScaleTransform cardScale, FadeState state, Action switchAction)
    {
        // 快速连点时先停掉进行中的动画
        state.Current?.Stop();

        const double shrinkScale = 0.96;
        const double expandScale = 1.0;
        var fadeOutDuration = TimeSpan.FromMilliseconds(100);
        var fadeInDuration = TimeSpan.FromMilliseconds(240);

        // ===== 淡出：透明度 + 轻微收缩 =====
        var fadeOut = new Storyboard();
        var animOut = new DoubleAnimation
        {
            From = overlay.Opacity,
            To = 0,
            Duration = fadeOutDuration,
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
        };
        Storyboard.SetTarget(animOut, overlay);
        Storyboard.SetTargetProperty(animOut, "Opacity");
        fadeOut.Children.Add(animOut);

        var scaleOutX = new DoubleAnimation
        {
            From = cardScale.ScaleX,
            To = shrinkScale,
            Duration = fadeOutDuration,
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
        };
        Storyboard.SetTarget(scaleOutX, cardScale);
        Storyboard.SetTargetProperty(scaleOutX, "ScaleX");
        fadeOut.Children.Add(scaleOutX);
        var scaleOutY = new DoubleAnimation
        {
            From = cardScale.ScaleY,
            To = shrinkScale,
            Duration = fadeOutDuration,
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
        };
        Storyboard.SetTarget(scaleOutY, cardScale);
        Storyboard.SetTargetProperty(scaleOutY, "ScaleY");
        fadeOut.Children.Add(scaleOutY);

        fadeOut.Completed += (_, _) =>
        {
            fadeOut.Stop();          // 释放属性控制（HoldEnd）
            overlay.Opacity = 0;     // 显式置为透明（布局切换期间不可见）
            cardScale.ScaleX = shrinkScale;
            cardScale.ScaleY = shrinkScale;

            switchAction();          // 透明状态下切换布局，无视觉移位

            // ===== 淡入：透明度 + 缩放浮现 =====
            var fadeIn = new Storyboard();
            var animIn = new DoubleAnimation
            {
                From = 0,
                To = 1,
                Duration = fadeInDuration,
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(animIn, overlay);
            Storyboard.SetTargetProperty(animIn, "Opacity");
            fadeIn.Children.Add(animIn);

            var scaleInX = new DoubleAnimation
            {
                From = shrinkScale,
                To = expandScale,
                Duration = fadeInDuration,
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(scaleInX, cardScale);
            Storyboard.SetTargetProperty(scaleInX, "ScaleX");
            fadeIn.Children.Add(scaleInX);
            var scaleInY = new DoubleAnimation
            {
                From = shrinkScale,
                To = expandScale,
                Duration = fadeInDuration,
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(scaleInY, cardScale);
            Storyboard.SetTargetProperty(scaleInY, "ScaleY");
            fadeIn.Children.Add(scaleInY);

            fadeIn.Completed += (_, _) =>
            {
                fadeIn.Stop();
                overlay.Opacity = 1.0;
                cardScale.ScaleX = expandScale;
                cardScale.ScaleY = expandScale;
                state.Current = null;
            };
            state.Current = fadeIn;
            fadeIn.Begin();
        };
        state.Current = fadeOut;
        fadeOut.Begin();
    }

    /// <summary>
    /// [评论区功能] 应用评论面板当前状态的布局（含半透明背景刷新）
    /// 气泡：左右/底部各留 24px，高度可拖拽（底部对齐）
    /// 全展开：悬浮面板，左右/底部贴合边线，顶边留 24px
    /// 布局切换统一由 FadeSwitchPanel 在透明状态下执行（无动画、无移位）
    /// </summary>
    private void ApplyCommentPanelLayout(bool animate = true)
    {
        double overlayHeight, cardHeight;
        Thickness overlayMargin, cardMargin;
        if (_commentPanelState == CommentPanelState.FullExpanded)
        {
            // 全展开：容器铺满页面，卡片上下各留 24px
            var pageHeight = ActualHeight > 0 ? ActualHeight : _commentBubbleHeight + 48;
            overlayHeight = pageHeight;
            cardHeight = Math.Max(pageHeight - 48, CommentBubbleMinHeight);
            overlayMargin = new Thickness(0);
            cardMargin = new Thickness(24, 24, 24, 24);
            CommentResizeDragArea.Visibility = Visibility.Collapsed;
        }
        else
        {
            // 气泡：容器高度 = 卡片高 + 底部留白 24（容器只覆盖卡片区域，不拦截页面其他区域）；左边距 600px
            overlayHeight = _commentBubbleHeight + 24;
            cardHeight = _commentBubbleHeight;
            overlayMargin = new Thickness(600, 0, 24, 0);
            cardMargin = new Thickness(0, 0, 0, 24);
            CommentResizeDragArea.Visibility = Visibility.Visible;
        }

        CommentOverlay.Height = overlayHeight;
        CommentPanelCard.Height = cardHeight;
        CommentOverlay.Margin = overlayMargin;
        CommentPanelCard.Margin = cardMargin;
    }

    /// <summary>
    /// [首页分享功能] 切换 气泡 ↔ 最大化（标题栏最大化按钮）
    /// 淡化过渡：淡出+轻微收缩 → 透明状态下切换布局（无视觉移位） → 淡入+缩放浮现
    /// </summary>
    private void OnSharedContentFullExpandToggle()
    {
        if (_isSharedContentCollapsed) return;

        _isSharedContentFullExpanded = !_isSharedContentFullExpanded;

        // [首页分享功能] 优雅过渡：淡出+轻微收缩 → 透明状态下切换布局（无移位） → 淡入+缩放浮现
        FadeSwitchPanel(SharedContentOverlay, SharedContentCardScale, _sharedFadeState, () =>
        {
            ApplySharedContentLayout(animate: false);
            SharedContentPanelControl.SetFullExpandedVisualState(_isSharedContentFullExpanded);
        });
    }

    /// <summary>
    /// [首页分享功能] 获取指定状态下分享面板的容器高度（用于抽屉动画的可变滑出/滑入距离）
    /// </summary>
    private double GetSharedContentPanelHeight(bool isFullExpanded)
    {
        if (isFullExpanded)
        {
            // 全屏态：容器铺满页面
            return ActualHeight > 0 ? ActualHeight : CommentExpandedHeight + 48;
        }
        // 气泡态：卡片高 + 底部留白
        return CommentExpandedHeight + 24;
    }

    /// <summary>
    /// [首页分享功能] 应用分享面板当前状态的布局（含半透明背景刷新）
    /// 气泡：容器 280+24 底部留白（左右/底部各留 24px）
    /// 最大化：容器铺满页面，卡片上下各留 24px（悬浮面板）
    /// 布局切换统一由 FadeSwitchPanel 在透明状态下执行（无动画、无移位）
    /// </summary>
    private void ApplySharedContentLayout(bool animate = true)
    {
        double overlayHeight, cardHeight;
        Thickness overlayMargin, cardMargin;
        if (_isSharedContentFullExpanded)
        {
            // 最大化：容器铺满页面，卡片上下各留 24px
            var pageHeight = ActualHeight > 0 ? ActualHeight : CommentExpandedHeight + 48;
            overlayHeight = pageHeight;
            cardHeight = Math.Max(pageHeight - 48, 150);
            overlayMargin = new Thickness(0);
            cardMargin = new Thickness(24, 24, 24, 24);
        }
        else
        {
            // 气泡：容器高度 = 卡片 280 + 底部留白 24（容器只覆盖卡片区域，不拦截页面其他区域）；左边距 600px
            overlayHeight = CommentExpandedHeight + 24;
            cardHeight = CommentExpandedHeight;
            overlayMargin = new Thickness(600, 0, 24, 0);
            cardMargin = new Thickness(0, 0, 0, 24);
        }

        SharedContentOverlay.Height = overlayHeight;
        SharedContentCard.Height = cardHeight;
        SharedContentOverlay.Margin = overlayMargin;
        SharedContentCard.Margin = cardMargin;
    }

    /// <summary>
    /// [评论区功能] 页面尺寸变化：全展开态下刷新布局（保持顶边 24px 空隙与全高）
    /// </summary>
    private void OnPageSizeChanged(object sender, SizeChangedEventArgs e)
    {
        if (_commentPanelState == CommentPanelState.FullExpanded
            && CommentOverlay.Visibility == Visibility.Visible)
        {
            ApplyCommentPanelLayout(animate: false);
        }

        // [首页分享功能] 分享面板最大化态下窗口缩放时同步刷新布局
        if (_isSharedContentFullExpanded
            && SharedContentOverlay.Visibility == Visibility.Visible)
        {
            ApplySharedContentLayout(animate: false);
        }
    }

    // ===== [评论区功能] 气泡态顶部拖拽调整高度 =====

    /// <summary>
    /// [评论区功能] 拖拽条按下 — 记录起始位置（仅气泡态允许拖拽调高）
    /// </summary>
    private void OnCommentResizePointerPressed(object sender, PointerRoutedEventArgs e)
    {
        if (_commentPanelState != CommentPanelState.Expanded) return;

        _commentResizeStartY = e.GetCurrentPoint(null).Position.Y;
        _commentResizeStartHeight = CommentPanelCard.ActualHeight;
        _isCommentResizing = true;
    }

    /// <summary>
    /// [评论区功能] 拖拽条移动 — 计算新高度并调整面板（最小 150 / 最大页面高度 60%）
    /// </summary>
    private void OnCommentResizePointerMoved(object sender, PointerRoutedEventArgs e)
    {
        if (!_isCommentResizing) return;

        var currentY = e.GetCurrentPoint(null).Position.Y;
        var delta = _commentResizeStartY - currentY; // 向上拖为正值
        var maxHeight = Math.Max(CommentBubbleMinHeight, ActualHeight * 0.6);

        _commentBubbleHeight = Math.Clamp(_commentResizeStartHeight + delta, CommentBubbleMinHeight, maxHeight);
        CommentPanelCard.Height = _commentBubbleHeight;
        // 同步容器高度（容器 = 卡片高 + 底部留白），保持命中测试区域与卡片一致
        CommentOverlay.Height = _commentBubbleHeight + 24;
    }

    /// <summary>
    /// [评论区功能] 显示评论面板。
    /// 仅当实例绑定了议题方案（议题被选中）时才显示；
    /// WebView2 方案由 SourceChanged 触发首次资源键同步与评论加载；
    /// 非 WebView2 方案立即使用默认资源键加载。
    /// </summary>
    private void ShowCommentPanel(Scheme scheme)
    {
        // [评论区功能] 评论区/分享区仅在 Kirara Media 方案中显示（议题等非媒体方案主界面不显示评论区）
        if (!IsMediaScheme()) return;

        // [评论区功能] 议题未被选中（实例未绑定议题方案）时不显示评论区，避免异常启动议题
        if (!EnsureTopicBindingChecked()) return;

        if (scheme.UIKind != SchemeUIKind.WebView2)
        {
            // 非 WebView2 方案（如议题 Overlay）：立即显示并加载
            // [三态持久化] 折叠态：仅显示右下角缩成钮，不显示面板
            if (_isCommentCollapsed)
            {
                CommentExpandButton.Opacity = 1.0;
                CommentExpandButtonScale.ScaleX = 1.0;
                CommentExpandButtonScale.ScaleY = 1.0;
                CommentExpandButton.Visibility = Visibility.Visible;
            }
            else
            {
                ShowCommentPanelWithAnimation();
            }
            var resourceKey = ResourceKeyBuilder.ForTopic();
            _ = _commentViewModel!.SetContextAndLoadAsync(resourceKey, scheme.Id, scheme.DisplayName, _instanceId);
        }
        // WebView2 方案：不在此处显示，由 SourceChanged → SyncCommentResourceKey
        // 判断 URL 路径是否为 details 后再决定是否显示
    }

    /// <summary>
    /// [评论区功能] 检查并缓存所属实例是否绑定了议题方案。
    /// 识别逻辑与议题方案判定一致：优先取代码中方案实例的 Name，回退数据库 Name。
    /// </summary>
    private bool EnsureTopicBindingChecked()
    {
        if (_hasTopicBinding.HasValue) return _hasTopicBinding.Value;

        var instanceService = App.Services.GetRequiredService<IInstanceService>();
        var instance = instanceService.GetInstance(_instanceId);

        _hasTopicBinding = instance?.SchemeBindings.Any(b => IsTopicScheme(_schemeService, b.SchemeId)) == true;
        return _hasTopicBinding.Value;
    }

    /// <summary>
    /// [评论区功能] 判断指定方案是否为议题方案。
    /// </summary>
    private static bool IsTopicScheme(ISchemeService schemeService, Guid schemeId)
    {
        var scheme = schemeService.GetScheme(schemeId);
        if (scheme == null) return false;

        var schemeInstance = schemeService.LoadSchemeInstance(scheme);
        var name = schemeInstance?.Name ?? scheme.Name;
        return name == "topic";
    }

    /// <summary>
    /// [评论区功能] 判断当前方案是否为 Kirara Media（评论区/分享区仅在此方案显示）。
    /// 识别逻辑与议题方案判定一致：优先取代码中方案实例的 Name，回退数据库 Name。
    /// </summary>
    private bool IsMediaScheme()
    {
        if (_currentScheme == null) return false;

        var schemeInstance = _schemeService.LoadSchemeInstance(_currentScheme);
        var name = schemeInstance?.Name ?? _currentScheme.Name;
        return name == "media";
    }

    /// <summary>
    /// [评论区功能] 折叠评论面板：向下滑出隐藏，显示右下角圆形展开按钮（带弹性缩放入场）。
    /// </summary>
    private void OnCommentCollapseToggle()
    {
        _isCommentCollapsed = true;

        // [评论区功能] 滑出距离 = 面板当前高度（气泡 / 全展开自适应）
        var slideDistance = GetCommentPanelSlideDistance();

        // 向下滑出动画
        var slideOut = new Storyboard();
        var animY = new DoubleAnimation
        {
            From = 0,
            To = slideDistance,
            Duration = TimeSpan.FromMilliseconds(300),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
        };
        Storyboard.SetTarget(animY, CommentSlideTransform);
        Storyboard.SetTargetProperty(animY, "Y");
        slideOut.Children.Add(animY);
        slideOut.Completed += (_, _) =>
        {
            CommentOverlay.Visibility = Visibility.Collapsed;
            CommentSlideTransform.Y = slideDistance; // 复位，为下次入场准备

            // 展开按钮灵动淡入：透明度 + 微缩放 + 微上浮，单调逼近无振荡避免模糊
            CommentExpandButton.Opacity = 0;
            CommentExpandButtonScale.ScaleX = 0.88;
            CommentExpandButtonScale.ScaleY = 0.88;
            CommentExpandButton.Visibility = Visibility.Visible;
            var appearSb = new Storyboard();
            var appOpacity = new DoubleAnimation
            {
                From = 0,
                To = 1.0,
                Duration = TimeSpan.FromMilliseconds(280),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(appOpacity, CommentExpandButton);
            Storyboard.SetTargetProperty(appOpacity, "Opacity");
            appearSb.Children.Add(appOpacity);
            var appScaleX = new DoubleAnimation
            {
                From = 0.88,
                To = 1.0,
                Duration = TimeSpan.FromMilliseconds(350),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(appScaleX, CommentExpandButtonScale);
            Storyboard.SetTargetProperty(appScaleX, "ScaleX");
            appearSb.Children.Add(appScaleX);
            var appScaleY = new DoubleAnimation
            {
                From = 0.88,
                To = 1.0,
                Duration = TimeSpan.FromMilliseconds(350),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(appScaleY, CommentExpandButtonScale);
            Storyboard.SetTargetProperty(appScaleY, "ScaleY");
            appearSb.Children.Add(appScaleY);
            appearSb.Begin();
        };
        slideOut.Begin();
    }

    /// <summary>
    /// [评论区功能] 点击右下角展开按钮：隐藏按钮，评论区向上滑入。
    /// </summary>
    private void OnCommentExpandButtonClick(object sender, RoutedEventArgs e)
    {
        _isCommentCollapsed = false;

        // 按钮快速缩小消失
        var btnSb = new Storyboard();
        var btnScaleX = new DoubleAnimation
        {
            From = 1.0,
            To = 0.3,
            Duration = TimeSpan.FromMilliseconds(180),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
        };
        Storyboard.SetTarget(btnScaleX, CommentExpandButtonScale);
        Storyboard.SetTargetProperty(btnScaleX, "ScaleX");
        btnSb.Children.Add(btnScaleX);
        var btnScaleY = new DoubleAnimation
        {
            From = 1.0,
            To = 0.3,
            Duration = TimeSpan.FromMilliseconds(180),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseIn }
        };
        Storyboard.SetTarget(btnScaleY, CommentExpandButtonScale);
        Storyboard.SetTargetProperty(btnScaleY, "ScaleY");
        btnSb.Children.Add(btnScaleY);
        btnSb.Completed += (_, _) =>
        {
            CommentExpandButton.Visibility = Visibility.Collapsed;
            CommentExpandButton.Opacity = 1.0;
            CommentExpandButtonScale.ScaleX = 1.0;
            CommentExpandButtonScale.ScaleY = 1.0;

            // 评论区向上滑入（恢复气泡态布局）
            CommentOverlay.Visibility = Visibility.Visible;
            _commentPanelState = CommentPanelState.Expanded;
            ApplyCommentPanelLayout(animate: false);
            CommentPanelControl.SetPanelState(CommentPanelState.Expanded);
            CommentSlideTransform.Y = _commentBubbleHeight + 24;
            var slideIn = new Storyboard();
            var animY = new DoubleAnimation
            {
                From = _commentBubbleHeight + 24,
                To = 0,
                Duration = TimeSpan.FromMilliseconds(350),
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
            };
            Storyboard.SetTarget(animY, CommentSlideTransform);
            Storyboard.SetTargetProperty(animY, "Y");
            slideIn.Children.Add(animY);
            slideIn.Begin();
        };
        btnSb.Begin();
    }

    // ========== 展开按钮悬停/按下动画 ==========

    /// <summary>
    /// [评论区功能] 展开按钮悬停放大（颜色变化由 VisualStateManager 处理）。
    /// </summary>
    private void OnCommentExpandButtonPointerEntered(object sender, PointerRoutedEventArgs e)
    {
        var sb = new Storyboard();
        var scaleX = new DoubleAnimation
        {
            To = 1.15,
            Duration = TimeSpan.FromMilliseconds(220),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(scaleX, CommentExpandButtonScale);
        Storyboard.SetTargetProperty(scaleX, "ScaleX");
        sb.Children.Add(scaleX);
        var scaleY = new DoubleAnimation
        {
            To = 1.15,
            Duration = TimeSpan.FromMilliseconds(220),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(scaleY, CommentExpandButtonScale);
        Storyboard.SetTargetProperty(scaleY, "ScaleY");
        sb.Children.Add(scaleY);
        sb.Begin();
    }

    /// <summary>
    /// [评论区功能] 展开按钮悬停离开恢复（颜色变化由 VisualStateManager 处理）。
    /// </summary>
    private void OnCommentExpandButtonPointerExited(object sender, PointerRoutedEventArgs e)
    {
        var sb = new Storyboard();
        var scaleX = new DoubleAnimation
        {
            To = 1.0,
            Duration = TimeSpan.FromMilliseconds(200),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(scaleX, CommentExpandButtonScale);
        Storyboard.SetTargetProperty(scaleX, "ScaleX");
        sb.Children.Add(scaleX);
        var scaleY = new DoubleAnimation
        {
            To = 1.0,
            Duration = TimeSpan.FromMilliseconds(200),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(scaleY, CommentExpandButtonScale);
        Storyboard.SetTargetProperty(scaleY, "ScaleY");
        sb.Children.Add(scaleY);
        sb.Begin();
    }

    /// <summary>
    /// [评论区功能] 展开按钮按下缩小。
    /// </summary>
    private void OnCommentExpandButtonPointerPressed(object sender, PointerRoutedEventArgs e)
    {
        var sb = new Storyboard();
        var scaleX = new DoubleAnimation
        {
            To = 0.92,
            Duration = TimeSpan.FromMilliseconds(120),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(scaleX, CommentExpandButtonScale);
        Storyboard.SetTargetProperty(scaleX, "ScaleX");
        sb.Children.Add(scaleX);
        var scaleY = new DoubleAnimation
        {
            To = 0.92,
            Duration = TimeSpan.FromMilliseconds(120),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(scaleY, CommentExpandButtonScale);
        Storyboard.SetTargetProperty(scaleY, "ScaleY");
        sb.Children.Add(scaleY);
        sb.Begin();
    }

    /// <summary>
    /// [评论区功能] 展开按钮释放恢复。
    /// </summary>
    private void OnCommentExpandButtonPointerReleased(object sender, PointerRoutedEventArgs e)
    {
        var sb = new Storyboard();
        var scaleX = new DoubleAnimation
        {
            To = 1.0,
            Duration = TimeSpan.FromMilliseconds(120),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(scaleX, CommentExpandButtonScale);
        Storyboard.SetTargetProperty(scaleX, "ScaleX");
        sb.Children.Add(scaleX);
        var scaleY = new DoubleAnimation
        {
            To = 1.0,
            Duration = TimeSpan.FromMilliseconds(120),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(scaleY, CommentExpandButtonScale);
        Storyboard.SetTargetProperty(scaleY, "ScaleY");
        sb.Children.Add(scaleY);
        sb.Begin();
    }

    // ========== 状态管理 ==========

    private void ShowError(string message)
    {
        HideAllContent();
        ErrorOverlay.Visibility = Visibility.Visible;
        ErrorMessageText.Text = message;

        // 配置类错误（URL为空、方案未找到）不可重试，隐藏重试按钮
        RetryButton.Visibility = IsRetryableError(message)
            ? Visibility.Visible : Visibility.Collapsed;
    }

    private static bool IsRetryableError(string message) => message switch
    {
        string m when m.Contains("CoreWebView2 为空") => true,
        string m when m.Contains("导航失败") => true,
        string m when m.Contains("方案加载失败") => true,
        _ => false
    };

    private void OnErrorRetryClick(object sender, RoutedEventArgs e)
    {
        ErrorOverlay.Visibility = Visibility.Collapsed;
        _ = ReloadCurrentSchemeAsync();
    }

    private async Task ReloadCurrentSchemeAsync()
    {
        // [重建修复] 统一走 ForceReloadSchemeAsync：先清空 _currentScheme/_currentBinding，
        // 绕过 LoadSchemeAsync 顶部的相同参数短路——否则重建后的新 WebView2 控件
        // （_webViewInitialized=false）永远不会执行 EnsureCoreWebView2Async，
        // CoreWebView2 保持 null（"WebView2 不可操作"），错误重试无限循环。
        await ForceReloadSchemeAsync();
    }

    /// <summary>
    /// 强制重新加载当前方案 — 先清空当前方案/绑定状态，绕过 LoadSchemeAsync 的相同参数短路，
    /// 保证硬重载（强制的全新开始方式）在任何时刻都会完整重走部署流程。
    /// </summary>
    private async Task ForceReloadSchemeAsync()
    {
        if (_currentScheme == null || _currentBinding == null) return;

        var schemeId = _currentScheme.Id;
        var binding = _currentBinding;

        // 清空当前状态，使 LoadSchemeAsync 顶部的相同参数短路失效
        _currentScheme = null;
        _currentBinding = null;
        await LoadSchemeAsync(schemeId, binding);
    }

    private void HideAllContent()
    {
        // [Kirara Media] 隐藏内容前退出全屏（若 WebView2 正悬浮在窗口顶层），避免残留
        if (_isWebViewFullScreen) ExitWebViewFullScreen();

        ErrorOverlay.Visibility = Visibility.Collapsed;
        WebViewHost.Visibility = Visibility.Collapsed;
        CustomControlHost.Visibility = Visibility.Collapsed;
        ExternalProcessHost.Visibility = Visibility.Collapsed;
        RdpHost.Visibility = Visibility.Collapsed;
        OverlayHost.Visibility = Visibility.Collapsed;
        EmptyContentPlaceholder.Visibility = Visibility.Collapsed;
        CommentOverlay.Visibility = Visibility.Collapsed;
        CommentExpandButton.Visibility = Visibility.Collapsed;
        CommentExpandButton.Opacity = 1.0;
    }

    public async Task SoftReloadAsync()
    {
        await _viewModel.SoftReloadAsync(
            getWebViewProvider: () => new CoreWebView2Provider(WebViewControl),
            // [重建修复] reloadScheme 统一走 ForceReloadSchemeAsync（清空状态绕过短路）：
            // WebView2 不可操作分支（未初始化/崩溃/已关闭）重建控件后必须完整重走加载流程，
            // 否则新控件永不初始化（CoreWebView2 为 null）。
            reloadScheme: ForceReloadSchemeAsync);
    }

    public async Task HardReloadAsync()
    {
        // OpenVPN 服务版（CustomControl）：断开 → 清空配置库（.ovpn+账密）→ 重走部署流程（不自动连接）
        if (IsOpenVpnServiceScheme)
        {
            if (CurrentOpenVpnServiceControl is OpenVpnServiceControl ovpnSvc)
            {
                await ovpnSvc.HardReloadAsync();
                return;
            }

            // 错误态（面板未创建）：清空配置库 + 强制重载，使用宿主页忙遮罩
            _viewModel.BusyOverlayText = "正在硬重载方案，请稍候...";
            _viewModel.IsBusyOverlayVisible = true;
            try
            {
                var store = App.Services.GetRequiredService<OpenVpnProfileStore>();
                await store.ClearAllAsync(_instanceId);
                await ForceReloadSchemeAsync();
            }
            finally
            {
                _viewModel.IsBusyOverlayVisible = false;
                _viewModel.BusyOverlayText = string.Empty;
            }
            return;
        }

        // OpenVPN 用户版（CustomControl）：断开连接 → 清除 .ovpn 缓存 → 强制重走部署流程（不自动令牌链接）
        if (_viewModel.SchemeInstance is OpenVpnScheme)
        {
            // 面板存在 → 控件级硬重载（遮罩由 OpenVpnControl 内部管理，
            // 隐藏探针 = 方案完整加载完成，含 .ovpn 重新下载完成）
            if (CurrentCustomControl is OpenVpnControl ovpnControl)
            {
                await ovpnControl.HardReloadAsync();
                return;
            }

            // 错误态（初始化失败，面板未创建）：清缓存 + 强制重载，使用宿主页忙遮罩
            _viewModel.BusyOverlayText = "正在硬重载方案，请稍候...";
            _viewModel.IsBusyOverlayVisible = true;
            try
            {
                var configCache = App.Services.GetRequiredService<OvpnConfigCacheService>();
                bool cacheCleared = await configCache.ClearCacheAndResyncAsync();
                if (!cacheCleared)
                {
                    // 等待同步超时：不执行强制重载（缓存未清除，重载也会失败），保持错误态
                    System.Diagnostics.Debug.WriteLine(
                        "[SchemeHostPage] 硬重载（错误态）：等待配置同步完成超时，已中止");
                    return;
                }
                await ForceReloadSchemeAsync();
            }
            finally
            {
                _viewModel.IsBusyOverlayVisible = false;
                _viewModel.BusyOverlayText = string.Empty;
            }
            return;
        }

        await _viewModel.HardReloadAsync(
            getWebViewProvider: () => new CoreWebView2Provider(WebViewControl),
            getUserDataFolder: () => GetWebViewUserDataFolder(),
            recreateWebView: async () => await ResetAndRecreateWebViewAsync(deleteUserData: true),
            // [重建修复] reloadScheme 统一走 ForceReloadSchemeAsync（清空状态绕过短路）：
            // 不可操作分支重建控件后必须完整重走加载流程（EnsureCoreWebView2Async + 导航），
            // 否则新控件永不初始化，硬重载无法完成重建。
            reloadScheme: ForceReloadSchemeAsync);
    }

    /// <summary>
    /// 后退（WebView2 导航历史）：返回上一页。
    /// 适用场景：弹出窗口被拦截转为内部导航后，用户需要回到原页面。
    /// </summary>
    public Task GoBackAsync()
    {
        return _viewModel.GoBackAsync(() => new CoreWebView2Provider(WebViewControl));
    }

    /// <summary>
    /// 前进（WebView2 导航历史）：回到后退前的页面。
    /// </summary>
    public Task GoForwardAsync()
    {
        return _viewModel.GoForwardAsync(() => new CoreWebView2Provider(WebViewControl));
    }

    /// <summary>是否可后退（WebView2 导航历史中存在上一页；未初始化/非 WebView2 时 false）</summary>
    public bool CanGoBack
    {
        get
        {
            try { return WebViewControl.CoreWebView2?.CanGoBack ?? false; }
            catch { return false; }
        }
    }

    /// <summary>是否可前进（WebView2 导航历史中存在下一页；未初始化/非 WebView2 时 false）</summary>
    public bool CanGoForward
    {
        get
        {
            try { return WebViewControl.CoreWebView2?.CanGoForward ?? false; }
            catch { return false; }
        }
    }

    public async Task RelinkTokenAsync()
    {
        // OpenVPN 服务版：不支持重链接令牌（方案标签栏菜单已隐藏该选项，此处兜底直接返回）
        if (IsOpenVpnServiceScheme)
            return;

        // OpenVPN 用户版（CustomControl）：不参与 WebView2 自动登录系统。
        // 重链接令牌 = 已连接则先断开，再重新走"传入令牌自动连接"流程；
        // 未连接则按实例总结页令牌链接流程处理（均在 OpenVpnControl.RelinkTokenAsync 内实现）
        if (CurrentCustomControl is OpenVpnControl ovpnControl)
        {
            await ovpnControl.RelinkTokenAsync();
            return;
        }

        await _viewModel.RelinkTokenAsync(() => new CoreWebView2Provider(WebViewControl));
    }

    public async Task AutoLoginAsync(Guid tokenId)
    {
        await _viewModel.AutoLoginAsync(tokenId, () => new CoreWebView2Provider(WebViewControl));
    }

    public async Task PerformWorkspaceLoginAsync()
    {
        await _viewModel.PerformWorkspaceLoginAsync(() => new CoreWebView2Provider(WebViewControl));
    }

    /// <summary>
    /// [首页分享功能] 导航到分享时的源 URL
    /// 对于含 hash 路由的 SPA URL（如 Jellyfin），分步处理：
    /// 1. 导航到基础 URL（不含 hash），等待页面加载完成
    /// 2. 通过 JS 设置 window.location.hash 触发 SPA 内部路由
    /// 对于普通 URL，直接导航
    /// </summary>
    public void NavigateToSourceUrl(string sourceUrl)
    {
        if (string.IsNullOrWhiteSpace(sourceUrl)) return;
        if (!_webViewInitialized || WebViewControl.CoreWebView2 == null) return;

        try
        {
            var uri = new Uri(sourceUrl);
            var hashFragment = uri.Fragment; // 如 #!/details?id=xxx 或 #/home.html

            if (!string.IsNullOrEmpty(hashFragment))
            {
                // SPA hash 路由：页面已加载（缓存页面），直接通过 JS 设置 hash 触发 SPA 路由
                var escapedHash = hashFragment.Replace("\\", "\\\\").Replace("'", "\\'");
                _ = WebViewControl.CoreWebView2.ExecuteScriptAsync(
                    $"window.location.hash = '{escapedHash}';");
            }
            else
            {
                // 普通 URL（无 hash），直接导航
                WebViewControl.CoreWebView2.Navigate(sourceUrl);
            }
        }
        catch (UriFormatException)
        {
            // URL 格式异常，尝试直接导航
            try { WebViewControl.CoreWebView2.Navigate(sourceUrl); } catch { }
        }
        catch (Exception) { }
    }

    /// <summary>
    /// [首页分享功能] 等待 WebView2 初始加载完成后导航到源 URL
    /// 避免初始导航与源 URL 导航冲突导致空白页
    /// </summary>
    public void NavigateToSourceUrlAfterLoad(string sourceUrl)
    {
        if (string.IsNullOrWhiteSpace(sourceUrl)) return;

        if (!_webViewInitialized || WebViewControl.CoreWebView2 == null)
        {
            // WebView2 尚未初始化，使用 DispatcherQueue 延迟重试
            DispatcherQueue.TryEnqueue(Microsoft.UI.Dispatching.DispatcherQueuePriority.Low, () =>
            {
                NavigateToSourceUrlAfterLoad(sourceUrl);
            });
            return;
        }

        // WebView2 已初始化，直接调用 NavigateToSourceUrl（页面已加载，无需等待导航完成）
        NavigateToSourceUrl(sourceUrl);
    }
}
