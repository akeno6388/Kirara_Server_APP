using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.ViewModels.Comment;
using Kirara_Server_WinUI.ViewModels.Controls;
using Kirara_Server_WinUI.ViewModels.InstanceSpace;
using Kirara_Server_WinUI.Views.Controls;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Kirara_Server_WinUI.Views.Instance;

/// <summary>
/// 实例主窗体 — 方案标签栏 + 方案内容区
/// 位于 LeftFunctionBar 右侧，占据窗体剩余全部空间
/// WebView2 / RDP 等内容通过 ISchemePageCache 全局持久化，切换实例不销毁
/// </summary>
public sealed partial class InstanceWorkspace : Page
{
    private InstanceWorkspaceViewModel? _viewModel;
    private ISchemePageCache? _pageCache;
    private ViewModels.Controls.LeftFunctionBarViewModel? _shellViewModel;

    /// <summary>当前显示的实例 ID</summary>
    private Guid _currentInstanceId;

    public InstanceWorkspace()
    {
        InitializeComponent();
    }

    /// <summary>
    /// 导航到该页面时，恢复或创建实例工作区
    /// </summary>
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        base.OnNavigatedTo(e);

        _viewModel = App.Services.GetRequiredService<InstanceWorkspaceViewModel>();
        _pageCache = App.Services.GetRequiredService<ISchemePageCache>();
        _shellViewModel = App.Services.GetRequiredService<ViewModels.Controls.LeftFunctionBarViewModel>();
        DataContext = _viewModel;

        // 订阅 ViewModel 方案标签选中事件（替代原 View.TabSelected 事件）
        var schemeTabBarVM = App.Services.GetRequiredService<SchemeTabBarViewModel>();
        schemeTabBarVM.TabSelectionChanged += OnTabSelected;
        schemeTabBarVM.TabSoftReloadRequested += OnTabSoftReloadRequested;
        schemeTabBarVM.TabHardReloadRequested += OnTabHardReloadRequested;
        schemeTabBarVM.TabTokenRelinkRequested += OnTabTokenRelinkRequested;
        schemeTabBarVM.TabGoBackRequested += OnTabGoBackRequested;
        schemeTabBarVM.TabGoForwardRequested += OnTabGoForwardRequested;

        // 订阅颜色标签变更事件，实现左侧栏改色时方案标签栏竖线同步刷新
        _shellViewModel.InstanceColorTagChanged += OnInstanceColorTagChanged;

        // [首页分享功能] 支持两种导航参数：Guid（普通实例导航）和 SharedContentNavigationParameter（分享“查看”跳转）
        Guid instanceId;
        string? navigateToUrl = null;
        Guid? targetSchemeId = null;

        if (e.Parameter is SharedContentNavigationParameter shareParam)
        {
            instanceId = shareParam.InstanceId;
            targetSchemeId = shareParam.SchemeId;
            navigateToUrl = shareParam.SourceUrl;
        }
        else if (e.Parameter is Guid guid)
        {
            instanceId = guid;
        }
        else
        {
            return;
        }

        if (instanceId != Guid.Empty)
        {
            _currentInstanceId = instanceId;

            // ✅ 立即隐藏占位文本，避免新页面实例 XAML 默认值或旧页面 OnNavigatedFrom 残留导致闪现
            EmptyPlaceholder.Visibility = Visibility.Collapsed;
            SchemePageHost.Visibility = Visibility.Visible;

            _viewModel.LoadInstance(instanceId);

            // [修复] 实例不存在（如分享指向已删除实例/其他设备的实例）时直接提示，
            // 避免继续执行挂载空白页面（SchemeHostPage 显示"未能加载任何方案"误导文案）
            if (_viewModel.CurrentInstance == null)
            {
                SchemePageHost.Visibility = Visibility.Collapsed;
                EmptyPlaceholder.Text = "该实例不存在，可能已被删除或来自其他设备。";
                EmptyPlaceholder.Visibility = Visibility.Visible;
                return;
            }

            // [高亮兜底] 任何进入工作区的路径（手动点击 / 通知跳转 / 分享跳转 / 自动部署）
            // 都统一确保左侧栏实例高亮与激活状态同步。此前个别路径（如首页分享"查看"、
            // 自动部署失败后手动"开始工作"）未设置 ActiveInstanceId，导致左侧栏标签
            // 无高亮、再点击标签时因状态不一致出现异常（如重复部署/误报多实例运行）。
            // 放在实例存在性校验之后：实例不存在时不高亮。
            _shellViewModel.EnsureInstanceActive(instanceId);

            // [评论区功能] 评论区的创建/销毁已收归 ShellPage.OnContentNavigated 集中管理，
            // 此处不再单独处理，避免分散逻辑导致旧数据实例绑定遗漏。

            // [侧栏自动折叠] 任何进入实例主界面的路径（开始工作 / 点击左侧标签 /
            // 切入另一实例 / 分享跳转）都触发折叠：首次进入记录状态，
            // 工作区 → 工作区不覆盖记录（VM 内部处理）；离开时由 OnNavigatedFrom 恢复
            _shellViewModel.PrepareWorkspaceAutoCollapse();

            // 方案标签底部颜色线 = 实例颜色标签色
            ApplyInstanceColorTag();

            // 从全局缓存恢复该实例的页面（若有），并通知缓存该实例已恢复
            _pageCache.ResumeInstance(instanceId);

            // [首页分享功能] 分享"查看"跳转：定位到目标方案标签并导航到源 URL
            if (targetSchemeId.HasValue && !string.IsNullOrEmpty(navigateToUrl))
            {
                var targetTab = SchemeTabBarControl.ViewModel.Tabs
                    .FirstOrDefault(t => t.SchemeId == targetSchemeId.Value);
                if (targetTab != null)
                {
                    ShowCachedPageWithUrl(targetTab.SchemeId, navigateToUrl);
                    _viewModel.SetActiveTab(targetTab);
                }
                else
                {
                    // 目标方案标签未找到，回退到默认行为（显示第一个方案）
                    var firstTab = SchemeTabBarControl.ViewModel.Tabs.FirstOrDefault();
                    if (firstTab != null)
                    {
                        ShowCachedPage(firstTab.SchemeId);
                        _viewModel.SetActiveTab(firstTab);
                    }
                    else
                    {
                        SchemePageHost.Visibility = Visibility.Collapsed;
                        EmptyPlaceholder.Visibility = Visibility.Visible;
                    }
                }
            }
            else
            {
                // 普通导航：显示第一个方案
                var firstTab = SchemeTabBarControl.ViewModel.Tabs.FirstOrDefault();
                if (firstTab != null)
                {
                    ShowCachedPage(firstTab.SchemeId);
                    _viewModel.SetActiveTab(firstTab);
                }
                else
                {
                    // 真正没有任何方案时，才显示占位提示
                    SchemePageHost.Visibility = Visibility.Collapsed;
                    EmptyPlaceholder.Visibility = Visibility.Visible;
                }
            }
        }
    }

    /// <summary>
    /// 将实例颜色标签应用到方案标签栏的底部颜色线。
    /// 无颜色标签时默认使用白色。
    /// </summary>
    private void ApplyInstanceColorTag(string? colorTag = null)
    {
        colorTag ??= _viewModel?.CurrentInstance?.ColorTag;

        try
        {
            SolidColorBrush? brush = null;

            if (!string.IsNullOrEmpty(colorTag))
            {
                var converter = new Kirara_Server_WinUI.Converters.ColorTagToBrushConverter();
                brush = converter.Convert(colorTag, typeof(SolidColorBrush),
                    null!, string.Empty) as SolidColorBrush;
            }

            // 无颜色标签时兜底白色，保证标签栏色条和悬停选中色始终可见
            SchemeTabBarControl.TagColorBrush = brush
                ?? new SolidColorBrush(Microsoft.UI.Colors.White);
        }
        catch
        {
            SchemeTabBarControl.TagColorBrush = new SolidColorBrush(Microsoft.UI.Colors.White);
        }
    }

    /// <summary>
    /// 响应左侧栏颜色标签变更事件，同步刷新方案标签栏底部颜色线
    /// </summary>
    private void OnInstanceColorTagChanged(Guid instanceId, string? colorTag)
    {
        // 仅处理当前显示的实例
        if (instanceId != _currentInstanceId) return;

        // 同步更新 ViewModel 中的 ColorTag（LiteDB 可能返回不同对象引用）
        if (_viewModel?.CurrentInstance != null)
            _viewModel.CurrentInstance.ColorTag = colorTag;

        ApplyInstanceColorTag(colorTag);
    }

    /// <summary>
    /// 导航离开时挂起当前实例（保留 WebView2 等状态），不销毁
    /// </summary>
    protected override void OnNavigatedFrom(NavigationEventArgs e)
    {
        base.OnNavigatedFrom(e);

        // [侧栏自动折叠] 离开实例主界面（回到其他页面）时恢复进入前的侧栏状态；
        // 工作区 → 工作区（分享跳转）不恢复，保持折叠态
        if (e.SourcePageType != typeof(InstanceWorkspace))
        {
            App.Services.GetRequiredService<ViewModels.Controls.LeftFunctionBarViewModel>()
                .RestorePaneStateAfterWorkspace();
        }

        // [评论区功能] 评论区的销毁已收归 ShellPage.OnContentNavigated 集中管理（导航到非工作区页面时关闭）。

        // 取消订阅 ViewModel 事件
        if (_shellViewModel != null)
            _shellViewModel.InstanceColorTagChanged -= OnInstanceColorTagChanged;

        var schemeTabBarVM = App.Services.GetRequiredService<SchemeTabBarViewModel>();
        schemeTabBarVM.TabSelectionChanged -= OnTabSelected;
        schemeTabBarVM.TabSoftReloadRequested -= OnTabSoftReloadRequested;
        schemeTabBarVM.TabHardReloadRequested -= OnTabHardReloadRequested;
        schemeTabBarVM.TabTokenRelinkRequested -= OnTabTokenRelinkRequested;
        schemeTabBarVM.TabGoBackRequested -= OnTabGoBackRequested;
        schemeTabBarVM.TabGoForwardRequested -= OnTabGoForwardRequested;

        // 挂起（而非销毁）当前实例的所有页面
        _pageCache?.SuspendInstance(_currentInstanceId);

        // [Kirara Media] 导航离开实例前，退出所有页面可能残留的 WebView2 全屏状态
        // （否则 WebView2 会继续悬浮在窗口最顶层容器中，遮挡其他页面）
        foreach (var p in _pageCache!.GetInstancePages(_currentInstanceId).Values)
        {
            p.ExitFullScreenIfNeeded();
        }

        // 清除当前显示（不设置 EmptyPlaceholder 可见，避免切换瞬间闪现）
        SchemePageHost.Content = null;
        SchemePageHost.Visibility = Visibility.Collapsed;
    }

    /// <summary>
    /// 方案标签被选中 — 从缓存切换显示
    /// </summary>
    private void OnTabSelected(SchemeTabItemViewModel tab)
    {
        if (tab == null || _viewModel?.CurrentInstance == null)
            return;

        ShowCachedPage(tab.SchemeId);
        _viewModel.SetActiveTab(tab);
    }

    /// <summary>
    /// 方案标签软重载请求（F5 刷新）— 执行方案刷新
    /// </summary>
    private async void OnTabSoftReloadRequested(SchemeTabItemViewModel tab)
    {
        if (tab == null || _viewModel?.CurrentInstance == null)
            return;

        var pages = _pageCache!.GetInstancePages(_currentInstanceId);
        if (pages.TryGetValue(tab.SchemeId, out var page))
        {
            await page.SoftReloadAsync();
        }
    }

    /// <summary>
    /// 方案标签硬重载请求（Ctrl+Shift+R）— 执行方案硬重载
    /// </summary>
    private async void OnTabHardReloadRequested(SchemeTabItemViewModel tab)
    {
        if (tab == null || _viewModel?.CurrentInstance == null)
            return;

        var pages = _pageCache!.GetInstancePages(_currentInstanceId);
        if (pages.TryGetValue(tab.SchemeId, out var page))
        {
            await page.HardReloadAsync();
        }
    }

    /// <summary>
    /// 方案标签后退请求（WebView2 导航历史）— 执行页面后退
    /// </summary>
    private async void OnTabGoBackRequested(SchemeTabItemViewModel tab)
    {
        if (tab == null || _viewModel?.CurrentInstance == null)
            return;

        var pages = _pageCache!.GetInstancePages(_currentInstanceId);
        if (pages.TryGetValue(tab.SchemeId, out var page))
        {
            await page.GoBackAsync();
        }
    }

    /// <summary>
    /// 方案标签前进请求（WebView2 导航历史）— 执行页面前进
    /// </summary>
    private async void OnTabGoForwardRequested(SchemeTabItemViewModel tab)
    {
        if (tab == null || _viewModel?.CurrentInstance == null)
            return;

        var pages = _pageCache!.GetInstancePages(_currentInstanceId);
        if (pages.TryGetValue(tab.SchemeId, out var page))
        {
            await page.GoForwardAsync();
        }
    }

    /// <summary>
    /// 方案标签重链接令牌请求 — 在当前页面重新执行令牌链接脚本
    /// </summary>
    private async void OnTabTokenRelinkRequested(SchemeTabItemViewModel tab)
    {
        if (tab == null || _viewModel?.CurrentInstance == null)
            return;

        var pages = _pageCache!.GetInstancePages(_currentInstanceId);
        if (pages.TryGetValue(tab.SchemeId, out var page))
        {
            await page.RelinkTokenAsync();
        }
    }

    /// <summary>
    /// 从全局缓存取出已加载的页面并显示，随后触发工作区登录阶段。
    /// 如果缓存未命中（绕过 InstanceSummaryPage 预加载的直接进入场景），
    /// 则通过 GetOrCreate 新建页面并加载方案内容。
    /// </summary>
    private async void ShowCachedPage(Guid schemeId)
    {
        var pages = _pageCache!.GetInstancePages(_currentInstanceId);
        SchemeHostPage page;
        bool isNewPage = false;

        if (pages.TryGetValue(schemeId, out var cachedPage))
        {
            page = cachedPage;
        }
        else
        {
            // 缓存未命中 → 新建页面并加载方案内容
            page = _pageCache.GetOrCreate(_currentInstanceId, schemeId);
            isNewPage = true;

            // 从实例的方案绑定中获取对应的 SchemeBinding
            var binding = _viewModel?.CurrentInstance?.SchemeBindings
                .FirstOrDefault(b => b.SchemeId == schemeId);

            if (binding != null)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[InstanceWorkspace] 缓存未命中，创建方案页并加载: schemeId={schemeId}");
                await page.LoadSchemeAsync(schemeId, binding);
            }
            else
            {
                // [修复] 方案未绑定到实例：显示明确提示而非挂载空白页面
                // （SchemeHostPage 的 EmptyContentPlaceholder 默认可见，会显示误导性的"未能加载任何方案"）
                ShowSchemeUnavailable("该方案未绑定到此实例，请返回实例列表检查方案配置。");
                return;
            }
        }

        // [Kirara Media] 切换标签前，退出旧页面可能残留的 WebView2 全屏状态
        // （否则旧方案的 WebView2 会继续悬浮在窗口最顶层容器中，覆盖新方案内容）
        if (SchemePageHost.Content is SchemeHostPage oldPage && oldPage != page)
        {
            oldPage.ExitFullScreenIfNeeded();
        }

        SchemePageHost.Content = page;
        SchemePageHost.Visibility = Visibility.Visible;
        EmptyPlaceholder.Visibility = Visibility.Collapsed;

        // 新建页面无需执行工作区登录（LoadSchemeAsync 已完成加载）
        if (!isNewPage)
        {
            // 服务版 OpenVPN：存在本地自动登录凭据时自动连接（VPN 未连接才触发）
            if (page.CurrentOpenVpnServiceControl is OpenVpnServiceControl ovpnSvc)
            {
                var vpnService = App.Services.GetRequiredService<VpnConnectionService>();
                if (vpnService.State != VpnConnectionState.Connected)
                {
                    await ovpnSvc.AutoLoginAsync();
                }
                return;
            }

            await page.PerformWorkspaceLoginAsync();
        }
    }

    /// <summary>
    /// [首页分享功能] 显示缓存页面并导航到指定 URL（分享“查看”跳转时使用）
    /// 先执行 ShowCachedPage 加载方案，然后调用 SchemeHostPage.NavigateToSourceUrl 导航
    /// </summary>
    private async void ShowCachedPageWithUrl(Guid schemeId, string sourceUrl)
    {
        var pages = _pageCache!.GetInstancePages(_currentInstanceId);
        SchemeHostPage page;
        bool isNewPage = false;

        if (pages.TryGetValue(schemeId, out var cachedPage))
        {
            page = cachedPage;
        }
        else
        {
            page = _pageCache.GetOrCreate(_currentInstanceId, schemeId);
            isNewPage = true;

            var binding = _viewModel?.CurrentInstance?.SchemeBindings
                .FirstOrDefault(b => b.SchemeId == schemeId);

            if (binding != null)
            {
                await page.LoadSchemeAsync(schemeId, binding);
            }
            else
            {
                // [修复] 方案未绑定到实例：显示明确提示而非挂载空白页面
                ShowSchemeUnavailable("该方案未绑定到此实例，请返回实例列表检查方案配置。");
                return;
            }
        }

        if (SchemePageHost.Content is SchemeHostPage oldPage && oldPage != page)
        {
            oldPage.ExitFullScreenIfNeeded();
        }

        SchemePageHost.Content = page;
        SchemePageHost.Visibility = Visibility.Visible;
        EmptyPlaceholder.Visibility = Visibility.Collapsed;

        if (!isNewPage)
        {
            if (page.CurrentOpenVpnServiceControl is OpenVpnServiceControl ovpnSvc)
            {
                var vpnService = App.Services.GetRequiredService<VpnConnectionService>();
                if (vpnService.State != VpnConnectionState.Connected)
                {
                    await ovpnSvc.AutoLoginAsync();
                }
                return;
            }

            await page.PerformWorkspaceLoginAsync();
        }

        // 方案页面加载完成后，导航到分享时的源 URL
        // 使用 NavigateToSourceUrlAfterLoad 等待 WebView2 初始加载完成后再跳转，避免空白页
        page.NavigateToSourceUrlAfterLoad(sourceUrl);
    }

    /// <summary>
    /// [修复] 显示方案不可用占位提示（不挂载空页面）。
    /// 先退出旧页面可能残留的全屏状态并卸载宿主内容，再显示明确文案。
    /// </summary>
    private void ShowSchemeUnavailable(string message)
    {
        if (SchemePageHost.Content is SchemeHostPage oldPage)
        {
            oldPage.ExitFullScreenIfNeeded();
            SchemePageHost.Content = null;
        }

        SchemePageHost.Visibility = Visibility.Collapsed;
        EmptyPlaceholder.Text = message;
        EmptyPlaceholder.Visibility = Visibility.Visible;
    }
}
