using Microsoft.UI.Xaml.Controls;

namespace Kirara_Server_WinUI.Views.Controls;

public sealed partial class NotificationBadge : UserControl
{
    public NotificationBadge()
    {
        InitializeComponent();
    }
}
