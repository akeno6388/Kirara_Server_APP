using Microsoft.UI.Xaml.Controls;

namespace Kirara_Server_WinUI.Views.Controls;

public sealed partial class InstanceCard : UserControl
{
    public InstanceCard()
    {
        InitializeComponent();
    }
}
