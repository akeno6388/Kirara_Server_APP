using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media.Imaging;
using Microsoft.UI.Windowing;
using Windows.UI;
using WinRT.Interop;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.Views.Controls;

public sealed partial class TopTitleBar : UserControl
{
    public TopTitleBar()
    {
        InitializeComponent();

        // 标题栏小图标（APP_32x32.ico，Unpackaged 模式经 AssetPathHelper 解析为输出目录路径）
        AppTitleIcon.Source = new BitmapImage(new Uri(AssetPathHelper.Resolve("Assets/APP_32x32.ico")));

        // 版本号 + 注释文字：版本号取程序集语义化版本，注释文字取 csproj <VersionNote> 属性
        // （经 AssemblyMetadata 注入，未配置时为空则不显示）
        VersionText.Text = $"v{AppUpdateService.CurrentVersion}";
        VersionNoteText.Text = AppUpdateService.VersionNote;

        Loaded += OnLoaded;
        Unloaded += OnUnloaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        var mainWindow = MainWindow.Current;
        if (mainWindow?.Content is FrameworkElement rootElement)
        {
            rootElement.ActualThemeChanged += OnActualThemeChanged;
        }
    }

    private void OnUnloaded(object sender, RoutedEventArgs e)
    {
        try
        {
            var mainWindow = MainWindow.Current;
            if (mainWindow?.Content is FrameworkElement rootElement)
            {
                rootElement.ActualThemeChanged -= OnActualThemeChanged;
            }
        }
        catch
        {
            // 窗口已关闭，忽略
        }
    }

    private void OnActualThemeChanged(FrameworkElement sender, object args)
    {
        // 主题切换时刷新所有缓存了 SystemAccentColor 的转换器
        Converters.BoolToHighlightBrushConverter.InvalidateCache();
        Converters.InstanceActiveToBrushConverter.InvalidateCache();
        Converters.StatusToBrushConverter.InvalidateCache();

        var mainWindow = MainWindow.Current;
        if (mainWindow != null)
        {
            bool isDark = sender.ActualTheme == ElementTheme.Dark;
            UpdateTitleBarButtons(mainWindow, isDark);
        }
    }

    public void SetParentWindow(Window window)
    {
        if (window != null)
        {
            window.SetTitleBar(AppTitleBar);
            InitializeTitleBarButtons(window);
        }
    }

    private static AppWindow GetAppWindow(Window window)
    {
        var hwnd = WindowNative.GetWindowHandle(window);
        var windowId = Microsoft.UI.Win32Interop.GetWindowIdFromWindow(hwnd);
        return AppWindow.GetFromWindowId(windowId);
    }

    private static void InitializeTitleBarButtons(Window window)
        {
        var titleBar = GetAppWindow(window).TitleBar;
        if (titleBar == null) return;

        titleBar.ButtonForegroundColor = Colors.Black;
        titleBar.ButtonHoverForegroundColor = Colors.Black;
        titleBar.ButtonHoverBackgroundColor = Color.FromArgb(0x19, 0x00, 0x00, 0x00);
        titleBar.ButtonPressedForegroundColor = Colors.Black;
        titleBar.ButtonPressedBackgroundColor = Color.FromArgb(0x33, 0x00, 0x00, 0x00);
        }

    private static void UpdateTitleBarButtons(Window window, bool isNowDark)
    {
        var titleBar = GetAppWindow(window).TitleBar;
        if (titleBar == null) return;

        if (isNowDark)
        {
            titleBar.ButtonForegroundColor = Colors.White;
            titleBar.ButtonHoverForegroundColor = Colors.White;
            titleBar.ButtonHoverBackgroundColor = Color.FromArgb(0x19, 0xFF, 0xFF, 0xFF);
            titleBar.ButtonPressedForegroundColor = Colors.White;
            titleBar.ButtonPressedBackgroundColor = Color.FromArgb(0x33, 0xFF, 0xFF, 0xFF);
        }
        else
        {
            titleBar.ButtonForegroundColor = Colors.Black;
            titleBar.ButtonHoverForegroundColor = Colors.Black;
            titleBar.ButtonHoverBackgroundColor = Color.FromArgb(0x19, 0x00, 0x00, 0x00);
            titleBar.ButtonPressedForegroundColor = Colors.Black;
            titleBar.ButtonPressedBackgroundColor = Color.FromArgb(0x33, 0x00, 0x00, 0x00);
        }
    }
}

