using System.Collections.ObjectModel;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Kirara_Server_WinUI.Services;
using Windows.UI;

namespace Kirara_Server_WinUI.Views.Controls;

/// <summary>
/// OpenVPN 自研管理面板 — 承载 VpnConnectionService 的连接状态、流量与日志展示。
/// 
/// 设计要点：
/// - 纯 UI 渲染层：所有业务逻辑委托给 VpnConnectionService（Singleton）。
/// - 事件订阅在 Loaded/Unloaded 成对管理，页面缓存切走时取消订阅防止泄漏。
/// - 后台线程事件通过 DispatcherQueue 切换到 UI 线程更新（与 RemoteNotificationService 一致）。
/// </summary>
public sealed partial class OpenVpnControl : UserControl
{
    private readonly VpnConnectionService _vpnService;
    private readonly DispatcherQueue _dispatcherQueue;
    private readonly ObservableCollection<string> _logLines = new();

    private readonly string _accountName;
    private readonly string? _accountPassword;
    private readonly string _serverHost;
    private readonly int _serverPort;
    private readonly string _displayName;
    private readonly string? _ovpnConfigPath;

    private DispatcherQueueTimer? _rateTimer;
    private long _lastBytesIn;
    private long _lastBytesOut;
    private DateTime _lastSampleTime;

    /// <summary>连接日志最大保留条数</summary>
    private const int MaxLogLines = 500;

    /// <summary>流量速率采样间隔（毫秒）</summary>
    private const int RateSampleIntervalMs = 2000;

    /// <summary>令牌直连等待连接结果的超时（秒）</summary>
    private const int TokenConnectTimeoutSeconds = 45;

    /// <summary>
    /// 方案重载委托（由 SchemeHostPage.ShowCustomControl 注入）：
    /// 硬重载时重走实例总结页部署流程（重新下载 .ovpn → 重新创建面板），
    /// 返回 true 表示方案完整加载成功。遮罩隐藏探针 = 该委托完成。
    /// </summary>
    public Func<Task<bool>>? SchemeReloader { get; set; }

    /// <summary>
    /// 创建 OpenVPN 管理面板
    /// </summary>
    /// <param name="accountName">认证用户名</param>
    /// <param name="accountPassword">认证密码</param>
    /// <param name="serverHost">服务器主机名/IP（.ovpn 含 remote 时仅作兜底）</param>
    /// <param name="serverPort">服务器端口（.ovpn 含 remote 时忽略）</param>
    /// <param name="displayName">方案显示名</param>
    /// <param name="ovpnConfigPath">服务端下载的 .ovpn 配置缓存路径（可空，空时动态生成模板）</param>
    public OpenVpnControl(string accountName, string? accountPassword,
        string serverHost, int serverPort, string displayName, string? ovpnConfigPath = null)
    {
        _vpnService = App.Services.GetRequiredService<VpnConnectionService>();
        _dispatcherQueue = DispatcherQueue.GetForCurrentThread();

        // 通知中心方案图标关联（内置版方案名）
        _vpnService.SchemeName = "openvpn";

        _accountName = accountName;
        _accountPassword = accountPassword;
        _serverHost = serverHost;
        _serverPort = serverPort;
        _displayName = displayName;
        _ovpnConfigPath = ovpnConfigPath;

        InitializeComponent();
        LogListView.ItemsSource = _logLines;
        ServerText.Text = $"服务器 URL: {serverHost}:{serverPort}";

        Loaded += OnLoaded;
        Unloaded += OnUnloaded;
    }

    /// <summary>
    /// 加载时订阅服务事件并恢复当前状态
    /// </summary>
    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        _vpnService.StateChanged += OnStateChanged;
        _vpnService.ByteCountChanged += OnByteCountChanged;
        _vpnService.LogLineAdded += OnLogLineAdded;

        // 恢复服务当前状态（页面缓存切回时）
        RefreshState(_vpnService.State);
        if (_vpnService.State == VpnConnectionState.Connected)
        {
            UpdateTraffic(_vpnService.BytesIn, _vpnService.BytesOut);
        }

        // 启动速率采样定时器
        _lastBytesIn = _vpnService.BytesIn;
        _lastBytesOut = _vpnService.BytesOut;
        _lastSampleTime = DateTime.Now;
        _rateTimer?.Stop();
        _rateTimer = _dispatcherQueue.CreateTimer();
        _rateTimer.Interval = TimeSpan.FromMilliseconds(RateSampleIntervalMs);
        _rateTimer.IsRepeating = true;
        _rateTimer.Tick += OnRateTick;
        _rateTimer.Start();
    }

    /// <summary>
    /// 卸载时取消订阅（页面缓存切走/控件销毁）
    /// </summary>
    private void OnUnloaded(object sender, RoutedEventArgs e)
    {
        _vpnService.StateChanged -= OnStateChanged;
        _vpnService.ByteCountChanged -= OnByteCountChanged;
        _vpnService.LogLineAdded -= OnLogLineAdded;
        _rateTimer?.Stop();
    }

    // ===== 事件处理（后台线程 → UI 线程） =====

    private void OnStateChanged(VpnConnectionState state)
    {
        _ = _dispatcherQueue.TryEnqueue(() => RefreshState(state));
    }

    private void OnByteCountChanged(long bytesIn, long bytesOut)
    {
        _ = _dispatcherQueue.TryEnqueue(() => UpdateTraffic(bytesIn, bytesOut));
    }

    private void OnLogLineAdded(string text)
    {
        _ = _dispatcherQueue.TryEnqueue(() => AddLogLine(text));
    }

    // ===== UI 刷新 =====

    /// <summary>
    /// 根据连接状态刷新状态指示、按钮可用性
    /// </summary>
    private void RefreshState(VpnConnectionState state)
    {
        // 状态文字与指示色（灰色/橙色/绿色/红色）
        string text;
        Color color;
        switch (state)
        {
            case VpnConnectionState.Connecting:
                text = "连接中...";
                color = Color.FromArgb(255, 0xF3, 0x9C, 0x12);
                break;
            case VpnConnectionState.Connected:
                text = "已连接";
                color = Color.FromArgb(255, 0x2E, 0xCC, 0x71);
                break;
            case VpnConnectionState.Disconnecting:
                text = "断开中...";
                color = Color.FromArgb(255, 0xF3, 0x9C, 0x12);
                break;
            case VpnConnectionState.Failed:
                text = "连接失败";
                color = Color.FromArgb(255, 0xE7, 0x4C, 0x3C);
                break;
            default:
                text = "未连接";
                color = Color.FromArgb(255, 0x80, 0x80, 0x80);
                break;
        }

        StateText.Text = text;
        StateDot.Fill = new SolidColorBrush(color);

        // 按钮可用性：连接中/断开中禁止操作
        var busy = state is VpnConnectionState.Connecting or VpnConnectionState.Disconnecting;
        ConnectButton.IsEnabled = !busy && state != VpnConnectionState.Connected;
        DisconnectButton.IsEnabled = !busy && state == VpnConnectionState.Connected;

        // 失败时显示原因
        if (state == VpnConnectionState.Failed && !string.IsNullOrEmpty(_vpnService.LastError))
        {
            StateText.Text = "连接失败: " + _vpnService.LastError;
            AddLogLine("[错误] " + _vpnService.LastError);
        }

        LocalIpText.Visibility = string.IsNullOrEmpty(_vpnService.LocalIp)
            ? Visibility.Collapsed : Visibility.Visible;
        if (!string.IsNullOrEmpty(_vpnService.LocalIp))
        {
            LocalIpText.Text = "本地 IP: " + _vpnService.LocalIp;
        }
    }

    /// <summary>
    /// 面板级显示连接失败（红色状态点 + "连接失败: 原因"）。
    /// 用于令牌链接失败场景：服务状态可能已回退为 Disconnected（连接建立阶段进程退出），
    /// 此时 RefreshState 会显示"未连接"，此方法保证 UI 呈现失败提示而非退回未连接。
    /// 必须在 UI 线程调用。
    /// </summary>
    private void ShowConnectFailure(string error)
    {
        StateText.Text = "连接失败: " + error;
        StateDot.Fill = new SolidColorBrush(Color.FromArgb(255, 0xE7, 0x4C, 0x3C));
        ConnectButton.IsEnabled = true;
        DisconnectButton.IsEnabled = false;
        AddLogLine("[错误] " + error);
    }

    /// <summary>
    /// 更新累计流量显示
    /// </summary>
    private void UpdateTraffic(long bytesIn, long bytesOut)
    {
        TrafficTotalText.Text = $"累计 {FormatBytes(bytesIn)} / {FormatBytes(bytesOut)}";
    }

    /// <summary>
    /// 速率采样定时器：基于累计字节差分计算瞬时速率
    /// </summary>
    private void OnRateTick(DispatcherQueueTimer sender, object args)
    {
        var now = DateTime.Now;
        var elapsed = (now - _lastSampleTime).TotalSeconds;
        if (elapsed <= 0) return;

        var deltaIn = _vpnService.BytesIn - _lastBytesIn;
        var deltaOut = _vpnService.BytesOut - _lastBytesOut;

        // 断开时 VpnConnectionService 会将累计字节清零（BytesIn/BytesOut = 0），
        // 而 _lastBytes* 仍是上次采样的旧值 → delta 为负，直接显示会出现瞬间负速率。
        // 处理：非连接状态速率归零；连接状态下负 delta（计数器重置）clamp 为 0。
        // 采样基准随之更新，避免后续持续负值。
        if (_vpnService.State != VpnConnectionState.Connected)
        {
            deltaIn = 0;
            deltaOut = 0;
        }
        else
        {
            if (deltaIn < 0) deltaIn = 0;
            if (deltaOut < 0) deltaOut = 0;
        }

        TrafficRateText.Text = $"↑ {FormatBytes((long)(deltaOut / elapsed))}/s   ↓ {FormatBytes((long)(deltaIn / elapsed))}/s";

        _lastBytesIn = _vpnService.BytesIn;
        _lastBytesOut = _vpnService.BytesOut;
        _lastSampleTime = now;
    }

    /// <summary>
    /// 添加日志行（限制条数 + 自动滚动到底部）
    /// </summary>
    private void AddLogLine(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return;

        _logLines.Add(text);
        while (_logLines.Count > MaxLogLines)
        {
            _logLines.RemoveAt(0);
        }

        if (_logLines.Count > 0)
        {
            LogListView.ScrollIntoView(_logLines[_logLines.Count - 1]);
        }
    }

    // ===== 按钮命令 =====

    private async void OnConnectClick(object sender, RoutedEventArgs e)
    {
        ConnectButton.IsEnabled = false;
        StateText.Text = "正在发起连接...";
        AddLogLine($"[系统] 正在连接 {_serverHost}:{_serverPort} ...");
        if (!string.IsNullOrEmpty(_ovpnConfigPath))
        {
            AddLogLine("[系统] 使用服务端下发的 .ovpn 配置文件");
        }

        var (success, error) = await _vpnService.ConnectAsync(
            _accountName, _accountPassword, _serverHost, _serverPort, _displayName, _ovpnConfigPath);

        if (!success && error != null)
        {
            AddLogLine("[错误] " + error);
        }

        RefreshState(_vpnService.State);
    }

    private async void OnDisconnectClick(object sender, RoutedEventArgs e)
    {
        DisconnectButton.IsEnabled = false;
        StateText.Text = "正在断开...";
        AddLogLine("[系统] 正在断开连接 ...");

        await _vpnService.DisconnectAsync();
        RefreshState(_vpnService.State);
    }

    /// <summary>
    /// 使用绑定令牌自动发起连接 — 实例部署阶段"链接令牌"调用。
    /// 令牌连接成功的读取标志 = VPN 连接成功（状态进入 Connected）；失败返回错误原因。
    /// ConnectAsync 返回仅代表 openvpn.exe 已拉起 + 管理接口已接入，
    /// 连接是否成功需等待状态机进入确定态（Connected / Failed / Disconnected）。
    /// </summary>
    public async Task<(bool success, string? error)> ConnectWithTokenAsync()
    {
        // 已有活动连接 → 直接返回当前结果（避免重复拉起 openvpn.exe）
        switch (_vpnService.State)
        {
            case VpnConnectionState.Connected:
                return (true, null);
            case VpnConnectionState.Connecting:
            case VpnConnectionState.Disconnecting:
                return (false, "已有 VPN 连接操作正在进行，请稍后再试");
        }

        AddLogLine($"[系统] 正在使用绑定令牌自动连接 {_serverHost}:{_serverPort} ...");
        if (!string.IsNullOrEmpty(_ovpnConfigPath))
        {
            AddLogLine("[系统] 使用服务端下发的 .ovpn 配置文件");
        }

        // 等待连接结果（后台线程事件，TaskCompletionSource 异步续延回 UI 线程）
        var tcs = new TaskCompletionSource<(bool success, string? error)>(
            TaskCreationOptions.RunContinuationsAsynchronously);

        void OnStateChanged(VpnConnectionState state)
        {
            switch (state)
            {
                case VpnConnectionState.Connected:
                    tcs.TrySetResult((true, null));
                    break;
                case VpnConnectionState.Failed:
                    tcs.TrySetResult((false, _vpnService.LastError ?? "连接失败"));
                    break;
                case VpnConnectionState.Disconnected:
                    // 连接建立阶段进程退出（服务器不可达/配置错误等）→ 判定失败
                    tcs.TrySetResult((false, _vpnService.LastError ?? "连接中断"));
                    break;
            }
        }

        _vpnService.StateChanged += OnStateChanged;
        try
        {
            var (launchOk, launchError) = await _vpnService.ConnectAsync(
                _accountName, _accountPassword, _serverHost, _serverPort, _displayName, _ovpnConfigPath);

            if (!launchOk)
            {
                ShowConnectFailure(launchError ?? "连接失败");
                return (false, launchError ?? "连接失败");
            }

            // 等待状态机进入确定态（openvpn.exe 已拉起不代表连接成功）
            var completed = await Task.WhenAny(
                tcs.Task,
                Task.Delay(TimeSpan.FromSeconds(TokenConnectTimeoutSeconds)));

            if (completed != tcs.Task)
            {
                ShowConnectFailure("等待连接结果超时，请查看连接日志");
                return (false, "等待连接结果超时，请进入工作区查看连接日志");
            }

            var result = await tcs.Task;
            if (!result.success)
            {
                // 面板级失败显示：服务状态可能已回退为 Disconnected（连接建立阶段进程退出），
                // 若不处理 RefreshState 会显示"未连接"，用户看不到失败提示
                ShowConnectFailure(result.error ?? "连接失败");
            }
            return result;
        }
        finally
        {
            _vpnService.StateChanged -= OnStateChanged;
        }
    }

    /// <summary>
    /// 重链接令牌 — 方案标签栏"重链接令牌"调用。
    /// 已连接：先断开当前连接，再重新走"传入令牌自动连接"流程（断开 → 令牌直连 → 等待连接成功）；
    /// 未连接（Disconnected）：按实例总结页面的令牌链接流程处理（ConnectWithTokenAsync）。
    /// 失败残留（Failed）：先断开清理进程/资源，再重新连接，避免旧进程抢占 TAP 适配器。
    /// 全程显示忙状态遮罩，遮罩的隐藏探针 = OpenVPN 连接成功（或失败确定态）。
    /// </summary>
    public async Task<(bool success, string? error)> RelinkTokenAsync()
    {
        ShowBusyOverlay("正在重链接令牌，请稍候...");
        try
        {
            // 已连接 / 失败残留 → 先断开清理
            if (_vpnService.State is VpnConnectionState.Connected or VpnConnectionState.Failed)
            {
                AddLogLine("[系统] 重链接令牌：正在断开当前连接 ...");
                await _vpnService.DisconnectAsync();
                AddLogLine("[系统] 已断开，正在使用绑定令牌重新连接 ...");
            }

            // 未连接 / 断开后：按实例总结页令牌链接流程处理
            // （Connecting/Disconnecting 忙状态由 ConnectWithTokenAsync 拒绝并返回提示）
            // 遮罩保持显示直至 VPN 连接成功（或失败）— 状态探针挂在 OpenVPN 连接结果上
            return await ConnectWithTokenAsync();
        }
        finally
        {
            HideBusyOverlay();
        }
    }

    /// <summary>
    /// 硬重载方案 — 方案标签栏"硬重载"调用（OpenVPN 分支）。
    /// 流程：
    ///   1. 断开当前 VPN 连接（如已连接）
    ///   2. 完全清除本地缓存（.ovpn 配置文件 + 元数据 + 临时文件）
    ///   3. 完全关闭当前方案并重走实例总结页部署流程
    ///      （重新从服务器下载 .ovpn → 重新创建面板）
    ///   4. 方案界面及程序加载完成后【不】进行令牌自动链接（面板停留"未连接"状态）
    /// 遮罩隐藏探针 = 方案完整加载完成（含 .ovpn 重新下载完成，LoadSchemeAsync 内部阻塞等待）。
    /// </summary>
    public async Task<bool> HardReloadAsync()
    {
        ShowBusyOverlay("正在硬重载方案，请稍候...");
        try
        {
            // 1. 断开当前连接（已连接 / 连接中 / 失败残留）
            await DisconnectIfAnyAsync("硬重载");

            // 2. 完全清除本地缓存并强制重新下载（等待进行中同步完成后执行，
            //    清缓存后版本比对必然不一致 → 保证 .ovpn 一定重新从服务器拉取）
            var configCache = App.Services.GetRequiredService<OvpnConfigCacheService>();
            bool cacheCleared = await configCache.ClearCacheAndResyncAsync();
            if (!cacheCleared)
            {
                AddLogLine("[错误] 硬重载：等待配置同步完成超时，已中止（缓存未被清除）");
                return false;
            }
            AddLogLine("[系统] 硬重载：已清除本地 .ovpn 配置缓存并重新下载");

            // 3. 完全关闭当前方案并重走部署流程
            //    （重新下载 .ovpn → 重新创建面板；不进行令牌自动链接）
            if (SchemeReloader == null)
            {
                AddLogLine("[错误] 硬重载：无法获取方案重载器");
                return false;
            }

            AddLogLine("[系统] 硬重载：正在重新下载配置并加载方案 ...");
            // 遮罩隐藏探针 = 方案完整加载完成（含 .ovpn 重新下载完成）
            bool reloaded = await SchemeReloader();
            AddLogLine(reloaded
                ? "[系统] 硬重载：方案加载完成"
                : "[错误] 硬重载：方案加载失败，请查看页面提示");
            return reloaded;
        }
        finally
        {
            HideBusyOverlay();
        }
    }

    /// <summary>
    /// 完全关闭方案（左侧功能栏"关闭实例"调用）—
    /// 断开当前 VPN 连接并清理临时认证文件，保留 .ovpn 配置缓存（与"关闭实例不删磁盘数据"同级语义）。
    /// </summary>
    public async Task ShutdownAsync()
    {
        await DisconnectIfAnyAsync("关闭实例");
    }

    /// <summary>
    /// 初始化清理（左侧功能栏"初始化实例"调用）—
    /// 断开 VPN 连接 + 完全清除 .ovpn 配置缓存（【不】立即重新下载）。
    /// 下次点击"开始部署"时，方案初始化（EnsureConfigReadyAsync）因缓存不存在
    /// 会自动从服务器全新下载。
    /// </summary>
    public async Task ShutdownForReinitializeAsync()
    {
        await DisconnectIfAnyAsync("初始化实例");

        var configCache = App.Services.GetRequiredService<OvpnConfigCacheService>();
        bool cacheCleared = await configCache.ClearCacheOnlyAsync();
        if (!cacheCleared)
        {
            System.Diagnostics.Debug.WriteLine(
                "[OpenVpnControl] 初始化实例：等待配置同步完成超时，缓存未被清除");
        }
    }

    /// <summary>
    /// 若存在活动/残留连接则断开（幂等）— 日志中标记操作来源
    /// </summary>
    private async Task DisconnectIfAnyAsync(string operation)
    {
        if (_vpnService.State is VpnConnectionState.Connected
            or VpnConnectionState.Connecting
            or VpnConnectionState.Failed)
        {
            AddLogLine($"[系统] {operation}：正在断开当前连接 ...");
            await _vpnService.DisconnectAsync();
            AddLogLine($"[系统] {operation}：连接已断开");
        }
    }

    /// <summary>
    /// 显示忙状态遮罩（与 SchemeHostPage 忙状态遮罩同款设计：半透明黑底 + ProgressRing + 文字）
    /// </summary>
    private void ShowBusyOverlay(string text)
    {
        BusyOverlayText.Text = text;
        BusyOverlay.Visibility = Visibility.Visible;
    }

    /// <summary>
    /// 隐藏忙状态遮罩
    /// </summary>
    private void HideBusyOverlay()
    {
        BusyOverlay.Visibility = Visibility.Collapsed;
    }

    /// <summary>
    /// 一键复制全部连接日志到剪贴板（日志区无法手动选择复制，提供兜底）。
    /// 空日志时按钮短暂显示"无日志"提示。
    /// </summary>
    private void OnCopyLogClick(object sender, RoutedEventArgs e)
    {
        if (_logLines.Count == 0)
        {
            ShowCopyFeedback("无日志");
            return;
        }

        string logText = string.Join(Environment.NewLine, _logLines);
        try
        {
            var package = new Windows.ApplicationModel.DataTransfer.DataPackage();
            package.SetText(logText);
            Windows.ApplicationModel.DataTransfer.Clipboard.SetContent(package);
            ShowCopyFeedback("已复制");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[OpenVpnControl] 复制日志失败: {ex.Message}");
            ShowCopyFeedback("复制失败");
        }
    }

    /// <summary>
    /// 复制按钮短暂文字反馈（1.5 秒后恢复原文本）
    /// </summary>
    private void ShowCopyFeedback(string feedbackText)
    {
        if (CopyLogButton == null) return;

        var originalText = CopyLogButton.Content?.ToString() ?? "复制日志";
        CopyLogButton.Content = feedbackText;
        CopyLogButton.IsEnabled = false;

        _dispatcherQueue.TryEnqueue(() =>
        {
            var timer = _dispatcherQueue.CreateTimer();
            timer.Interval = TimeSpan.FromSeconds(1.5);
            timer.IsRepeating = false;
            timer.Tick += (_, _) =>
            {
                CopyLogButton.Content = originalText;
                CopyLogButton.IsEnabled = true;
                timer.Stop();
            };
            timer.Start();
        });
    }

    // ===== 工具 =====

    /// <summary>
    /// 字节数格式化（B / KB / MB / GB）
    /// </summary>
    private static string FormatBytes(long bytes)
    {
        if (bytes < 1024) return $"{bytes} B";
        if (bytes < 1024 * 1024) return $"{bytes / 1024.0:0.0} KB";
        if (bytes < 1024L * 1024 * 1024) return $"{bytes / (1024.0 * 1024):0.0} MB";
        return $"{bytes / (1024.0 * 1024 * 1024):0.0} GB";
    }
}
