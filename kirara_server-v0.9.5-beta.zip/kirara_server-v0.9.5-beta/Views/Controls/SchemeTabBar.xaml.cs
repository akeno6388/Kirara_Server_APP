using System.Collections.ObjectModel;
using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.ViewModels.Controls;
using Windows.Foundation;
using Windows.UI;

namespace Kirara_Server_WinUI.Views.Controls;

/// <summary>
/// 将 ListViewItem.IsSelected (bool) 转换为 TabBackground 透明度 (double)。
/// 替代 VSM SelectionStates setter，彻底消除 WinUI 主题切换时 VSM 错误应用
/// Selected 状态导致所有标签短暂高亮的 bug。
/// </summary>
public class SelectionOpacityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        return value is true ? 0.4 : 0.0;
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        throw new NotImplementedException();
    }
}

/// <summary>
/// 方案标签栏 — 纯 View 层，负责将用户交互委托给 ViewModel。
/// 颜色线通过 XAML ElementName 绑定到 TagColorBrush DP，无需代码遍历可视化树。
/// 标签选中变更通过 ViewModel.TabSelectionChanged 事件暴露，外部订阅该事件而非 View 事件。
/// 拖拽排序通过手动 DragOver + Drop + 浮动预览面板实现，替代 CanReorderItems。
/// </summary>
public sealed partial class SchemeTabBar : UserControl
{
    public SchemeTabBarViewModel ViewModel { get; }

    /// <summary>拖拽时的浮动预览面板（跟随光标移动）</summary>
    private Border? _dragPreview;

    /// <summary>拖拽起始时被拖标签在 Tabs 中的索引</summary>
    private int _dragFromIndex = -1;

    // ── 指针拖拽状态（替代 ListView 系统拖拽）──

    /// <summary>指针按下时命中的标签项（拖拽候选，未超过阈值前可能只是点击）</summary>
    private SchemeTabItemViewModel? _dragCandidateTab;

    /// <summary>指针按下位置（RootPanel 坐标系）</summary>
    private Point _pressPoint;

    /// <summary>指针当前是否处于按下状态</summary>
    private bool _isPointerDown;

    /// <summary>是否已激活拖拽（超过移动阈值）</summary>
    private bool _dragActive;

    /// <summary>拖拽激活阈值（物理像素），小于该距离视为点击</summary>
    private const double DragThreshold = 8.0;

    /// <summary>标签底部颜色线的画刷（来自实例颜色标签，永久显示）
    /// XAML 模板内通过 {Binding TagColorBrush, ElementName=Root} 自动应用
    /// </summary>
    public SolidColorBrush TagColorBrush
    {
        get => (SolidColorBrush)GetValue(TagColorBrushProperty);
        set => SetValue(TagColorBrushProperty, value);
    }

    public static readonly DependencyProperty TagColorBrushProperty =
        DependencyProperty.Register(nameof(TagColorBrush), typeof(SolidColorBrush),
            typeof(SchemeTabBar), new PropertyMetadata(null));

    public SchemeTabBar()
    {
        ViewModel = App.Services.GetRequiredService<SchemeTabBarViewModel>();
        InitializeComponent();
        DataContext = this;

        // ⚠️ 用 AddHandler(handledEventsToo: true) 挂指针事件，确保即使事件被
        // 子元素标记为 Handled 也能收到。事件挂在 RootPanel（标签栏根 Grid）：
        // - 容器是 ItemsControl（无内部指针捕获逻辑），事件天然冒泡到 RootPanel
        // - 按下时把指针捕获转移到 RootPanel，保证 PointerMoved/Released 持续到达
        RootPanel.AddHandler(UIElement.PointerPressedEvent,
            new PointerEventHandler(OnRootPointerPressed), true);
        RootPanel.AddHandler(UIElement.PointerMovedEvent,
            new PointerEventHandler(OnRootPointerMoved), true);
        RootPanel.AddHandler(UIElement.PointerReleasedEvent,
            new PointerEventHandler(OnRootPointerReleased), true);
        RootPanel.AddHandler(UIElement.PointerCanceledEvent,
            new PointerEventHandler(OnRootPointerCanceled), true);
        RootPanel.AddHandler(UIElement.PointerCaptureLostEvent,
            new PointerEventHandler(OnRootPointerCaptureLost), true);
        RootPanel.AddHandler(UIElement.PointerExitedEvent,
            new PointerEventHandler(OnRootPointerExited), true);
    }

    // ================================================================
    //  指针拖拽排序（替代 ListView 系统拖拽 CanDragItems）
    // ================================================================
    //
    //  为什么不用系统拖拽 / ListView：
    //  1. ListViewBase 内部有指针跟踪逻辑，PointerPressed 后会捕获指针，后续
    //     PointerMoved/Released 只路由给 ListViewItem，外部自定义拖拽永远无法
    //     激活（此前"无法拖动"的根因）→ 容器改用 ItemsControl（无捕获逻辑）
    //  2. WinUI 3 的 DragItemsStartingEventArgs 没有 UWP 的 DragUI API，无法隐藏
    //     系统拖拽幽灵图 → 横向列表中幽灵会停在标签栏最左边（残影 bug）
    //
    //  本方案：在 RootPanel 上用 AddHandler(handledEventsToo:true) 接管指针事件。
    //  - PointerPressed：记录候选 + **立即捕获指针到 RootPanel** + Handled=true
    //  - 快速点击（< 8px）：释放时手动执行选中（捕获转移后 ItemClick 不再触发）
    //  - 按住拖动（≥ 8px）：激活拖拽，自定义 _dragPreview 浮动卡片跟随光标
    //  - 命中 "..." 等按钮时放行（FindTabRoot 遇 ButtonBase 返回 null）

    /// <summary>
    /// 指针按下：记录拖拽候选并**立即捕获指针**（仅鼠标左键，触摸留给 ScrollViewer）。
    /// 捕获转移的副作用：子元素收不到释放事件，点击选中改由 OnRootPointerReleased 手动执行。
    /// </summary>
    private void OnRootPointerPressed(object sender, PointerRoutedEventArgs e)
    {
        // 仅鼠标左键拖拽；触摸设备保留给 ScrollViewer 滚动/点击，避免手势冲突
        if (e.Pointer.PointerDeviceType != Microsoft.UI.Input.PointerDeviceType.Mouse) return;
        if (!e.GetCurrentPoint(RootPanel).Properties.IsLeftButtonPressed) return;

        // 命中按钮等交互控件（如标签上的 "..." 菜单按钮）→ 放行给按钮自身处理
        var root = FindTabRoot(e.OriginalSource as DependencyObject);
        if (root?.DataContext is not SchemeTabItemViewModel tab) return;
        if (ViewModel.Tabs.IndexOf(tab) < 0) return;

        _dragCandidateTab = tab;
        _pressPoint = e.GetCurrentPoint(RootPanel).Position;
        _isPointerDown = true;
        _dragActive = false;

        // 立即转移指针捕获到 RootPanel，确保后续 PointerMoved/Released 全部到达
        RootPanel.CapturePointer(e.Pointer);
        e.Handled = true;
    }

    /// <summary>
    /// 指针移动：未按下时更新悬停高亮；按下后超过阈值激活拖拽，持续更新预览位置。
    /// </summary>
    private void OnRootPointerMoved(object sender, PointerRoutedEventArgs e)
    {
        // 未按下：仅更新悬停高亮（ItemsControl 无内置 PointerOver 状态）
        if (!_isPointerDown || _dragCandidateTab == null)
        {
            UpdateHoverState(e.OriginalSource as DependencyObject);
            return;
        }

        var pos = e.GetCurrentPoint(RootPanel).Position;

        // 未激活：检测是否超过拖拽阈值（区分点击与拖拽）
        if (!_dragActive)
        {
            if (Math.Abs(pos.X - _pressPoint.X) < DragThreshold &&
                Math.Abs(pos.Y - _pressPoint.Y) < DragThreshold)
                return;

            // 激活拖拽（捕获已在按下时转移，此处无需再 CapturePointer）
            _dragActive = true;
            ActivateDrag();
        }

        UpdateDragPreview(pos);
        e.Handled = true;
    }

    /// <summary>
    /// 指针释放：已激活拖拽则完成排序；未激活（普通点击）手动执行选中
    /// （捕获转移后子元素不再收到释放事件，点击选中必须在此手动执行）。
    /// </summary>
    private void OnRootPointerReleased(object sender, PointerRoutedEventArgs e)
    {
        if (!_isPointerDown || _dragCandidateTab == null) return;

        if (_dragActive)
        {
            var hoverPos = e.GetCurrentPoint(TabListView).Position;
            CompleteDrag(hoverPos);
        }
        else
        {
            // 手动执行选中（与原来 ItemClick 行为一致）
            ViewModel.SelectTabCommand.Execute(_dragCandidateTab);
        }

        // 先置 false 再释放捕获，避免 PointerCaptureLost 处理器重复清理
        _isPointerDown = false;
        _dragCandidateTab = null;
        _dragActive = false;
        _pressPoint = default;
        RootPanel.ReleasePointerCaptures();
        e.Handled = true;
    }

    /// <summary>
    /// 指针取消（触摸系统取消 / 窗口失焦等）：放弃拖拽并释放捕获。
    /// </summary>
    private void OnRootPointerCanceled(object sender, PointerRoutedEventArgs e)
    {
        if (!_isPointerDown) return;
        _isPointerDown = false;
        _dragCandidateTab = null;
        _dragActive = false;
        RootPanel.ReleasePointerCaptures();
        CleanupDrag();
    }

    /// <summary>
    /// 指针捕获意外丢失（如其他元素抢走捕获）：放弃拖拽，恢复状态。
    /// </summary>
    private void OnRootPointerCaptureLost(object sender, PointerRoutedEventArgs e)
    {
        // ⚠️ 关键：PointerPressed 时调用 RootPanel.CapturePointer() 会把捕获从
        // 子元素转移到 RootPanel，此时子元素的 PointerCaptureLost 会冒泡到这里。
        // 若 RootPanel 仍持有该指针的捕获，说明是主动转移成功，拖拽继续，忽略本次丢失。
        if (RootPanel.PointerCaptures?.Contains(e.Pointer) == true) return;

        if (!_isPointerDown) return;
        _isPointerDown = false;
        _dragCandidateTab = null;
        _dragActive = false;
        CleanupDrag();
    }

    /// <summary>
    /// 指针离开标签栏：清除悬停高亮（未按下时）。
    /// </summary>
    private void OnRootPointerExited(object sender, PointerRoutedEventArgs e)
    {
        if (_isPointerDown) return;
        ClearHoverState();
    }

    // ================================================================
    //  悬停高亮（ItemsControl 无内置 PointerOver，手动模拟）
    // ================================================================

    /// <summary>当前悬停的标签根 Grid</summary>
    private Grid? _hoverTabRoot;

    /// <summary>
    /// 根据命中元素更新悬停高亮状态（切换时先清除旧状态）
    /// </summary>
    private void UpdateHoverState(DependencyObject? source)
    {
        var root = FindTabRoot(source);
        if (root == _hoverTabRoot) return;

        if (_hoverTabRoot != null)
            SetTabState(_hoverTabRoot, "Normal");

        _hoverTabRoot = root;
        if (root != null)
            SetTabState(root, "PointerOver");
    }

    /// <summary>清除悬停高亮</summary>
    private void ClearHoverState()
    {
        if (_hoverTabRoot != null)
        {
            SetTabState(_hoverTabRoot, "Normal");
            _hoverTabRoot = null;
        }
    }

    /// <summary>
    /// 从命中测试的原始元素向上遍历可视化树，查找标签模板根 Grid。
    /// 若路径上遇到交互控件（Button 等）则返回 null —— 放行给控件自身处理
    /// （如标签上的 "..." 菜单按钮，不应被拖拽/悬停逻辑劫持）。
    /// </summary>
    private static Grid? FindTabRoot(DependencyObject? source)
    {
        while (source != null)
        {
            if (source is Microsoft.UI.Xaml.Controls.Primitives.ButtonBase) return null;
            if (source is ContentPresenter cp)
            {
                // ItemsControl 容器是 ContentPresenter，模板根即标签根 Grid
                // （WinUI 3 无 ContentTemplateRoot API，用 VisualTreeHelper 获取）
                if (VisualTreeHelper.GetChildrenCount(cp) > 0)
                    return VisualTreeHelper.GetChild(cp, 0) as Grid;
                return null;
            }
            source = VisualTreeHelper.GetParent(source);
        }
        return null;
    }

    /// <summary>选中态 → 背景透明度转换器（重新绑定时复用，与 XAML 资源逻辑一致：选中 0.4 / 未选中 0.0）</summary>
    private static readonly SelectionOpacityConverter SelectionConverter = new();

    /// <summary>
    /// 设置标签模板的视觉状态（直接操作命名元素透明度，不依赖 VSM ——
    /// VisualStateManager.GoToState 只接受 Control，而模板根是 Grid）。
    /// </summary>
    /// <param name="root">标签模板根 Grid</param>
    /// <param name="state">Dragging / DragOver / PointerOver / Normal</param>
    private static void SetTabState(Grid root, string state)
    {
        var bg = root.FindName("TabBackground") as Border;
        var content = root.FindName("TabContent") as UIElement;
        var indicator = root.FindName("SelectionIndicator") as Border;
        if (bg == null) return;

        switch (state)
        {
            case "Dragging":
                // 被拖标签原位置完全透明（无残影）
                bg.Opacity = 0;
                if (content != null) content.Opacity = 0;
                if (indicator != null) indicator.Opacity = 0;
                break;
            case "DragOver":
                // 拖拽悬停的目标标签高亮
                bg.Opacity = 0.18;
                break;
            case "PointerOver":
                bg.Opacity = 0.2;
                break;
            default: // Normal / NotDragging：恢复选中态绑定驱动
                // ⚠️ 关键：代码赋值 Opacity（如 PointerOver 0.2）会覆盖并移除 XAML
                // 的 {Binding IsSelected} 绑定（绑定表达式即 LocalValue）。此时
                // ClearValue 只能回落到默认值 1.0（色线颜色全填充"持续高亮"），
                // 绑定不会自动恢复 → 必须重新 SetBinding。
                // （也不能用 Opacity = double.NaN，WinUI 3 会抛 ArgumentException）
                bg.ClearValue(FrameworkElement.OpacityProperty);
                bg.SetBinding(FrameworkElement.OpacityProperty, new Binding
                {
                    Path = new PropertyPath(nameof(SchemeTabItemViewModel.IsSelected)),
                    Converter = SelectionConverter,
                });
                if (content != null) content.Opacity = 1;
                if (indicator != null) indicator.Opacity = 1;
                break;
        }
    }

    /// <summary>
    /// 激活拖拽：原位置变透明（Dragging 状态），构建浮动预览面板并附加到浮层 Canvas。
    /// </summary>
    private void ActivateDrag()
    {
        var tab = _dragCandidateTab!;
        _dragFromIndex = ViewModel.Tabs.IndexOf(tab);

        // 悬停状态让位给拖拽状态
        ClearHoverState();

        var root = GetTabRoot(_dragFromIndex);
        if (root != null)
            SetTabState(root, "Dragging");

        _dragPreview = BuildDragPreview(tab);
        DragOverlay.Children.Add(_dragPreview);
        Canvas.SetLeft(_dragPreview, _pressPoint.X - 70);
        Canvas.SetTop(_dragPreview, 0);
    }

    /// <summary>
    /// 更新浮动预览位置（Y 锁定标签栏区域，仅水平跟随光标），并计算目标索引高亮。
    /// </summary>
    private void UpdateDragPreview(Point pos)
    {
        if (_dragPreview == null) return;

        // 锁定 Y 坐标到标签栏区域内（防止预览被拖到下方方案主界面）
        double lockedY = Math.Max(0, Math.Min(pos.Y, RootPanel.ActualHeight - 10));
        Canvas.SetLeft(_dragPreview, pos.X - 70);
        Canvas.SetTop(_dragPreview, lockedY - 17);

        // 计算悬停位置的目标索引，视觉提示目标位置
        int targetIndex = GetTargetIndex(pos.X);

        // 清除其他项的 target 状态，设置当前 target 项
        for (int i = 0; i < ViewModel.Tabs.Count; i++)
        {
            if (i == _dragFromIndex) continue;
            var root = GetTabRoot(i);
            if (root != null)
            {
                SetTabState(root, i == targetIndex ? "DragOver" : "NotDragging");
            }
        }
    }

    /// <summary>
    /// 完成拖拽：按释放位置计算目标索引并移动标签项。
    /// 若指针已拖出标签栏垂直范围（误拖到下方方案主界面），则取消排序。
    /// </summary>
    private void CompleteDrag(Point hoverPos)
    {
        if (_dragFromIndex < 0 || _dragFromIndex >= ViewModel.Tabs.Count)
        {
            CleanupDrag();
            return;
        }

        // 指针离开标签栏垂直范围 → 视为取消拖拽（与预览 Y 锁定策略一致）
        if (hoverPos.Y < -10 || hoverPos.Y > TabListView.ActualHeight + 10)
        {
            CleanupDrag();
            return;
        }

        int targetIndex = GetTargetIndex(hoverPos.X);

        // 移动标签项
        if (targetIndex != _dragFromIndex && targetIndex >= 0 && targetIndex < ViewModel.Tabs.Count)
        {
            var tabs = ViewModel.Tabs;
            var moved = tabs[_dragFromIndex];
            tabs.RemoveAt(_dragFromIndex);
            // 调整插入位置
            int insertAt = targetIndex > _dragFromIndex ? targetIndex - 1 : targetIndex;
            insertAt = Math.Clamp(insertAt, 0, tabs.Count);
            tabs.Insert(insertAt, moved);
            ViewModel.SyncTabOrder();
        }

        CleanupDrag();
    }

    /// <summary>
    /// 构建深色浮动预览标签卡片（图标与标签栏一致：本地缓存图标优先，降级 IconGlyph）
    /// </summary>
    private static Border BuildDragPreview(SchemeTabItemViewModel tab)
    {
        var grid = new Grid
        {
            MinWidth = 140,
            Height = 34,
            ColumnSpacing = 8,
            Background = new SolidColorBrush(Color.FromArgb(0xF0, 0x2D, 0x2D, 0x30)),
            CornerRadius = new CornerRadius(6),
        };

        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        // 图标：本地缓存图标（CoverImageUrl）优先，无缓存时降级 IconGlyph
        // （与标签栏模板的 SchemeIconConverter 逻辑一致）
        var iconContainer = new Grid
        {
            Width = 18,
            Height = 18,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(12, 0, 0, 0),
        };
        if (!string.IsNullOrEmpty(tab.CoverImageUrl))
        {
            // 转换器可能返回 null（缓存文件不存在时），需判空
            var iconSource = S_iconConverter.Convert(tab.CoverImageUrl, typeof(ImageSource), null!, string.Empty) as ImageSource;
            if (iconSource != null)
            {
                iconContainer.Children.Add(new Image
                {
                    Source = iconSource,
                    Stretch = Stretch.UniformToFill,
                });
            }
        }
        if (iconContainer.Children.Count == 0)
        {
            iconContainer.Children.Add(new FontIcon
            {
                Glyph = tab.IconGlyph,
                FontSize = 14,
                Foreground = new SolidColorBrush(Colors.White),
                Opacity = 0.9,
            });
        }
        Grid.SetColumn(iconContainer, 0);
        grid.Children.Add(iconContainer);

        var nameText = new TextBlock
        {
            Text = tab.DisplayName,
            FontSize = 13,
            Foreground = new SolidColorBrush(Colors.White),
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(0, 0, 14, 0),
            TextTrimming = TextTrimming.CharacterEllipsis,
        };
        Grid.SetColumn(nameText, 1);
        grid.Children.Add(nameText);

        return new Border
        {
            Child = grid,
            IsHitTestVisible = false,
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Top,
        };
    }

    /// <summary>拖拽预览图标的缓存路径转换器（与标签栏模板共用逻辑）</summary>
    private static readonly Converters.SchemeIconConverter S_iconConverter = new();

    /// <summary>
    /// 根据水平位置计算目标插入索引
    /// </summary>
    private int GetTargetIndex(double x)
    {
        for (int i = 0; i < ViewModel.Tabs.Count; i++)
        {
            var root = GetTabRoot(i);
            if (root == null || i == _dragFromIndex) continue;

            var transform = root.TransformToVisual(TabListView);
            var bounds = transform.TransformBounds(new Rect(0, 0, root.ActualWidth, root.ActualHeight));
            if (x < bounds.X + bounds.Width / 2)
                return i;
        }
        return ViewModel.Tabs.Count - 1;
    }

    /// <summary>
    /// 获取指定索引标签的模板根 Grid（非虚拟化 StackPanel 下容器始终可用）
    /// </summary>
    private Grid? GetTabRoot(int index)
    {
        if (index < 0 || index >= ViewModel.Tabs.Count) return null;
        var cp = TabListView.ContainerFromIndex(index) as ContentPresenter;
        if (cp == null || VisualTreeHelper.GetChildrenCount(cp) == 0) return null;
        return VisualTreeHelper.GetChild(cp, 0) as Grid;
    }

    /// <summary>
    /// 清理拖拽预览和所有视觉状态
    /// </summary>
    private void CleanupDrag()
    {
        if (_dragPreview != null)
        {
            DragOverlay.Children.Remove(_dragPreview);
            _dragPreview = null;
        }

        _dragFromIndex = -1;

        // 清除所有容器状态（含原位置项的 Dragging 状态）
        for (int i = 0; i < ViewModel.Tabs.Count; i++)
        {
            var root = GetTabRoot(i);
            if (root != null)
                SetTabState(root, "NotDragging");
        }
    }

    // ================================================================
    //  方案操作飞入菜单
    // ================================================================

    /// <summary>
    /// 点击标签上的 "..." 按钮，打开方案操作飞入菜单
    /// </summary>
    private void OnTabMenuButtonClick(object sender, RoutedEventArgs e)
    {
        if (sender is Button button)
        {
            ShowTabMenuFlyout(button);
        }
    }

    /// <summary>
    /// 构建方案操作飞入菜单（参照 LeftFunctionBar / 令牌管理器的样式设计）
    /// WebView2 方案：显示「刷新页面」+「硬重载」
    /// 其他方案：仅显示「硬重载」
    /// </summary>
    private void ShowTabMenuFlyout(Button anchor)
    {
        if (anchor.DataContext is not SchemeTabItemViewModel tab)
            return;

        var flyout = new Flyout
        {
            Placement = Microsoft.UI.Xaml.Controls.Primitives.FlyoutPlacementMode.BottomEdgeAlignedLeft,
        };

        var stackPanel = new StackPanel
        {
            Spacing = 4,
            Padding = new Thickness(-20, -5, -10, -5),
            MinWidth = 100,
        };

        // WebView2 方案专属：后退 / 前进（导航历史，用于弹出窗口内部重定向后返回）+ 刷新页面（F5 软重载）
        // 无导航历史时按钮置灰（IsEnabled=false），避免无效点击
        if (tab.IsWebView2)
        {
            var backButton = CreateFlyoutMenuButton("\uE72B 上级界面", () =>
            {
                tab.GoBackCommand.Execute(null);
                flyout.Hide();
            });
            backButton.IsEnabled = ViewModel.CanNavigateBack(tab);
            stackPanel.Children.Add(backButton);

            var forwardButton = CreateFlyoutMenuButton("\uE72A 下级界面", () =>
            {
                tab.GoForwardCommand.Execute(null);
                flyout.Hide();
            });
            forwardButton.IsEnabled = ViewModel.CanNavigateForward(tab);
            stackPanel.Children.Add(forwardButton);

            stackPanel.Children.Add(CreateFlyoutMenuButton("\uE777 刷新界面", () =>
            {
                tab.SoftReloadCommand.Execute(null);
                flyout.Hide();
            }));
        }

        // 重链接令牌（服务版 OpenVPN 等使用本地凭据的方案不支持，菜单隐藏该选项）
        if (tab.SupportsRelinkToken)
        {
            stackPanel.Children.Add(CreateFlyoutMenuButton("\uE71B 重链接令牌", () =>
            {
                tab.RelinkTokenCommand.Execute(null);
                flyout.Hide();
            }));
        }

        // 硬重载（放在最底部，橙色，点击弹出确认飞入）
        var hardReloadButton = CreateFlyoutMenuButton("\uE7AD 硬重载方案", async () =>
        {
            flyout.Hide();

            bool confirmed = await FlyoutHelper.ShowConfirmAsync(
                anchor,
                Microsoft.UI.Xaml.Controls.Primitives.FlyoutPlacementMode.BottomEdgeAlignedLeft,
                "\uE783",
                Color.FromArgb(255, 255, 165, 0),
                "确定要硬重载此方案吗？",
                "将清除全部缓存和表单数据，重置到初始状态",
                confirmText: "确定",
                confirmColor: Color.FromArgb(255, 255, 165, 0));

            if (confirmed)
                tab.HardReloadCommand.Execute(null);
        });
        hardReloadButton.Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 165, 0));
        stackPanel.Children.Add(hardReloadButton);

        flyout.Content = stackPanel;
        flyout.ShowAt(anchor);
    }

    /// <summary>
    /// 创建飞入菜单按钮（与 LeftFunctionBar / 令牌管理器样式一致）
    /// 支持图标+文本格式：text 格式为 "\uE777 刷新界面"，自动拆分图标字符和文本
    /// </summary>
    private static Button CreateFlyoutMenuButton(string text, Action action)
    {
        var grid = new Grid
        {
            ColumnDefinitions =
            {
                new ColumnDefinition { Width = GridLength.Auto },
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) },
            },
        };

        // 提取第一个 Unicode 图标字符（\uE777 等 Segoe Fluent Icons）
        string iconGlyph = text.Length > 0 && text[0] >= 0xE000 && text[0] <= 0xF000
            ? text[0].ToString()
            : "\uE7C3";

        // 提取图标后面的文本（去掉图标字符和开头的空格）
        string displayText = text.Length > 1 ? text[1..].TrimStart() : text;

        var icon = new FontIcon
        {
            Glyph = iconGlyph,
            FontSize = 14,
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(10, 0, 16, 0),
        };
        Grid.SetColumn(icon, 0);
        grid.Children.Add(icon);

        var textBlock = new TextBlock
        {
            Text = displayText,
            FontSize = 13,
            VerticalAlignment = VerticalAlignment.Center,
            TextTrimming = TextTrimming.CharacterEllipsis,
            Margin = new Thickness(0, 0, 12, 0),
        };
        Grid.SetColumn(textBlock, 1);
        grid.Children.Add(textBlock);

        var button = new Button
        {
            Content = grid,
            Style = (Style)Application.Current.Resources["NavigationButtonStyle"],
            Padding = new Thickness(0),
            MinHeight = 32,
        };
        button.Click += (_, _) => action();
        return button;
    }

    // ================================================================

    /// <summary>
    /// 程序化选中指定索引的标签（ItemsControl 无 SelectedItem，走 ViewModel 选中逻辑）
    /// </summary>
    public void SelectTabAt(int index)
    {
        if (index >= 0 && index < ViewModel.Tabs.Count)
        {
            ViewModel.SelectTabCommand.Execute(ViewModel.Tabs[index]);
        }
    }
}
