using System.Collections.ObjectModel;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;
using Windows.UI;

namespace Kirara_Server_WinUI.Views.Controls;

/// <summary>
/// OpenVPN 服务版管理面板 — 多配置文件导入/选择/账密/自动登录 + 连接/断开/状态/流量/日志。
///
/// 设计要点（服务版 OpenVPN 方案）：
/// - 纯 UI 渲染层：连接业务委托 VpnConnectionService（Singleton），配置持久化委托 OpenVpnProfileStore。
/// - 配置文件按实例隔离（OpenVpnProfileStore 以 instanceId 定位目录）。
/// - 每个配置文件对应一套独立账密（AES-256-GCM 加密存储），彼此互不干扰。
/// - 勾选"自动登录"时保存本配置账密为自动登录凭据（全局唯一），下次启动自动用它连接；
///   未勾选时下次进入仅到"方案加载完成"，不自动连接。
/// - 不支持重链接令牌（方案标签栏菜单已隐藏）。
/// - 事件订阅在 Loaded/Unloaded 成对管理，页面缓存切走时取消订阅防止泄漏。
/// </summary>
public sealed partial class OpenVpnServiceControl : UserControl
{
    private readonly VpnConnectionService _vpnService;
    private readonly OpenVpnProfileStore _profileStore;
    private readonly DispatcherQueue _dispatcherQueue;
    private readonly ObservableCollection<OpenVpnProfile> _profiles = new();

    private readonly Guid _instanceId;
    private readonly string _displayName;

    private DispatcherQueueTimer? _rateTimer;
    private long _lastBytesIn;
    private long _lastBytesOut;
    private DateTime _lastSampleTime;

    /// <summary>自动登录连接等待结果的超时（秒）</summary>
    private const int AutoLoginConnectTimeoutSeconds = 45;

    /// <summary>连接日志最大保留条数</summary>
    private const int MaxLogLines = 500;

    /// <summary>流量速率采样间隔（毫秒）</summary>
    private const int RateSampleIntervalMs = 2000;

    /// <summary>连接日志集合</summary>
    private readonly ObservableCollection<string> _logLines = new();

    /// <summary>
    /// 方案重载委托（由 SchemeHostPage.ShowCustomControl 注入）：
    /// 硬重载时重走部署流程（清空配置库 → 重新创建面板），返回 true 表示方案完整加载成功。
    /// 遮罩隐藏探针 = 该委托完成。
    /// </summary>
    public Func<Task<bool>>? SchemeReloader { get; set; }

    /// <summary>
    /// 创建服务版 OpenVPN 管理面板
    /// </summary>
    /// <param name="instanceId">所属实例 ID（定位实例隔离的配置文件库）</param>
    /// <param name="displayName">方案显示名</param>
    public OpenVpnServiceControl(Guid instanceId, string displayName)
    {
        _vpnService = App.Services.GetRequiredService<VpnConnectionService>();
        _profileStore = App.Services.GetRequiredService<OpenVpnProfileStore>();
        _dispatcherQueue = DispatcherQueue.GetForCurrentThread();

        // 通知中心方案图标关联（服务版方案名，与内置版区分）
        _vpnService.SchemeName = "openvpn-server";

        _instanceId = instanceId;
        _displayName = displayName;

        InitializeComponent();
        LogListView.ItemsSource = _logLines;
        ProfileListView.ItemsSource = _profiles;

        Loaded += OnLoaded;
        Unloaded += OnUnloaded;
    }

    /// <summary>
    /// 加载时：刷新配置列表 + 订阅服务事件 + 恢复连接状态
    /// </summary>
    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        _vpnService.StateChanged += OnStateChanged;
        _vpnService.ByteCountChanged += OnByteCountChanged;
        _vpnService.LogLineAdded += OnLogLineAdded;

        ReloadProfiles();
        UpdateServerDisplay();
        RefreshState(_vpnService.State);
        if (_vpnService.State == VpnConnectionState.Connected)
        {
            UpdateTraffic(_vpnService.BytesIn, _vpnService.BytesOut);
        }

        // 启动速率采样定时器
        _lastBytesIn = _vpnService.BytesIn;
        _lastBytesOut = _vpnService.BytesOut;
        _lastSampleTime = DateTime.Now;
        _rateTimer?.Stop();
        _rateTimer = _dispatcherQueue.CreateTimer();
        _rateTimer.Interval = TimeSpan.FromMilliseconds(RateSampleIntervalMs);
        _rateTimer.IsRepeating = true;
        _rateTimer.Tick += OnRateTick;
        _rateTimer.Start();
    }

    /// <summary>
    /// 卸载时取消订阅（页面缓存切走/控件销毁）
    /// </summary>
    private void OnUnloaded(object sender, RoutedEventArgs e)
    {
        _vpnService.StateChanged -= OnStateChanged;
        _vpnService.ByteCountChanged -= OnByteCountChanged;
        _vpnService.LogLineAdded -= OnLogLineAdded;
        _rateTimer?.Stop();
    }

    // ===== 配置列表 =====

    /// <summary>从存储刷新配置列表（保持选中项为原配置）</summary>
    private void ReloadProfiles()
    {
        var selectedId = (ProfileListView.SelectedItem as OpenVpnProfile)?.Id;
        _profiles.Clear();
        foreach (var p in _profileStore.GetProfiles(_instanceId))
        {
            _profiles.Add(p);
        }

        EmptyProfileText.Visibility = _profiles.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

        // 删除按钮：仅在选中了某个配置时才可用（灰色不可选状态）
        DeleteProfileButton.IsEnabled = SelectedProfile != null;

        if (selectedId.HasValue)
        {
            var match = _profiles.FirstOrDefault(p => p.Id == selectedId.Value);
            if (match != null)
            {
                ProfileListView.SelectedItem = match;
                // 恢复选中后同步编辑按钮状态（若处于编辑模式且选中仍有效则保持）
                EditCredentialsButton.IsEnabled = match != null && !_isCredentialsEditing;
            }
        }
    }

    /// <summary>当前选中配置（无返回 null）</summary>
    private OpenVpnProfile? SelectedProfile => ProfileListView.SelectedItem as OpenVpnProfile;

    // ===== 事件处理（后台线程 → UI 线程） =====

    private void OnStateChanged(VpnConnectionState state)
    {
        _ = _dispatcherQueue.TryEnqueue(() => RefreshState(state));
    }

    private void OnByteCountChanged(long bytesIn, long bytesOut)
    {
        _ = _dispatcherQueue.TryEnqueue(() => UpdateTraffic(bytesIn, bytesOut));
    }

    private void OnLogLineAdded(string text)
    {
        _ = _dispatcherQueue.TryEnqueue(() => AddLogLine(text));
    }

    // ===== UI 刷新 =====

    /// <summary>根据连接状态刷新状态指示、按钮可用性</summary>
    private void RefreshState(VpnConnectionState state)
    {
        string text;
        Color color;
        switch (state)
        {
            case VpnConnectionState.Connecting:
                text = "连接中...";
                color = Color.FromArgb(255, 0xF3, 0x9C, 0x12);
                break;
            case VpnConnectionState.Connected:
                text = "已连接";
                color = Color.FromArgb(255, 0x2E, 0xCC, 0x71);
                break;
            case VpnConnectionState.Disconnecting:
                text = "断开中...";
                color = Color.FromArgb(255, 0xF3, 0x9C, 0x12);
                break;
            case VpnConnectionState.Failed:
                text = "连接失败";
                color = Color.FromArgb(255, 0xE7, 0x4C, 0x3C);
                break;
            default:
                text = "未连接";
                color = Color.FromArgb(255, 0x80, 0x80, 0x80);
                break;
        }

        StateText.Text = text;
        StateDot.Fill = new SolidColorBrush(color);

        var busy = state is VpnConnectionState.Connecting or VpnConnectionState.Disconnecting;
        // 连接按钮：未连接且非忙时可用，但无选中配置时禁用（灰色）
        ConnectButton.IsEnabled = !busy && state != VpnConnectionState.Connected && SelectedProfile != null;
        DisconnectButton.IsEnabled = !busy && state == VpnConnectionState.Connected;

        if (state == VpnConnectionState.Failed && !string.IsNullOrEmpty(_vpnService.LastError))
        {
            StateText.Text = "连接失败: " + _vpnService.LastError;
            AddLogLine("[错误] " + _vpnService.LastError);
        }

        LocalIpText.Visibility = string.IsNullOrEmpty(_vpnService.LocalIp)
            ? Visibility.Collapsed : Visibility.Visible;
        if (!string.IsNullOrEmpty(_vpnService.LocalIp))
        {
            LocalIpText.Text = "本地 IP: " + _vpnService.LocalIp;
        }
    }

    /// <summary>更新累计流量显示</summary>
    private void UpdateTraffic(long bytesIn, long bytesOut)
    {
        TrafficTotalText.Text = $"累计 {FormatBytes(bytesIn)} / {FormatBytes(bytesOut)}";
    }

    /// <summary>速率采样定时器（负 delta 归零，防止断开瞬间显示负速率）</summary>
    private void OnRateTick(DispatcherQueueTimer sender, object args)
    {
        var now = DateTime.Now;
        var elapsed = (now - _lastSampleTime).TotalSeconds;
        if (elapsed <= 0) return;

        var deltaIn = _vpnService.BytesIn - _lastBytesIn;
        var deltaOut = _vpnService.BytesOut - _lastBytesOut;

        if (_vpnService.State != VpnConnectionState.Connected)
        {
            deltaIn = 0;
            deltaOut = 0;
        }
        else
        {
            if (deltaIn < 0) deltaIn = 0;
            if (deltaOut < 0) deltaOut = 0;
        }

        TrafficRateText.Text = $"↑ {FormatBytes((long)(deltaOut / elapsed))}/s   ↓ {FormatBytes((long)(deltaIn / elapsed))}/s";

        _lastBytesIn = _vpnService.BytesIn;
        _lastBytesOut = _vpnService.BytesOut;
        _lastSampleTime = now;
    }

    /// <summary>添加日志行（限制条数 + 自动滚动到底部）</summary>
    private void AddLogLine(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return;

        _logLines.Add(text);
        while (_logLines.Count > MaxLogLines)
        {
            _logLines.RemoveAt(0);
        }

        if (_logLines.Count > 0)
        {
            LogListView.ScrollIntoView(_logLines[_logLines.Count - 1]);
        }
    }

    // ===== 配置管理 =====

    /// <summary>导入 .ovpn 文件（文件选择器 → 复制到实例目录 → 刷新列表）</summary>
    private async void OnImportClick(object sender, RoutedEventArgs e)
    {
        try
        {
            // 使用 Win32 原生 GetOpenFileNameW（Win32FileDialogHelper）：
            // UWP FileOpenPicker（Windows.Storage.Pickers）在 WindowsAppSDKSelfContained
            // Unpackaged 模式下激活不可靠（头像选择器实测失效）；Win32 对话框任何模式下都可靠。
            var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(MainWindow.Current);
            var filter = "OpenVPN 配置文件 (*.ovpn;*.conf)|*.ovpn;*.conf|所有文件 (*.*)|*.*";
            var sourcePath = Win32FileDialogHelper.ShowOpenFileDialog(filter, "选择 .ovpn 配置文件", hwnd);

            if (string.IsNullOrEmpty(sourcePath))
            {
                AddLogLine("[系统] 已取消选择");
                return;
            }

            AddLogLine($"[系统] 已选择文件: {sourcePath}");

            var profile = await _profileStore.ImportProfileAsync(_instanceId, sourcePath);
            AddLogLine($"[系统] 已导入配置文件: {profile.Name}");

            ReloadProfiles();
            // 选中新导入的配置
            ProfileListView.SelectedItem = _profiles.FirstOrDefault(p => p.Id == profile.Id);
        }
        catch (Exception ex)
        {
            AddLogLine("[错误] 导入失败: " + ex.Message);
            System.Diagnostics.Debug.WriteLine($"[OpenVpnServiceControl] 导入异常: {ex}");
        }
    }

    /// <summary>删除所选配置（.ovpn 文件 + 元数据 + 账密 + 自动登录标记）— 带全局删除确认飞入框</summary>
    private async void OnDeleteProfileClick(object sender, RoutedEventArgs e)
    {
        var profile = SelectedProfile;
        if (profile == null) return;

        // 全局删除确认飞入框（FlyoutHelper.ShowDeleteConfirmAsync：同款 \uE783 警示图标 + 红色主题）
        bool confirmed = await FlyoutHelper.ShowDeleteConfirmAsync(
            DeleteProfileButton,
            Microsoft.UI.Xaml.Controls.Primitives.FlyoutPlacementMode.BottomEdgeAlignedRight,
            "确定要删除此配置文件吗？",
            "该配置文件绑定的账号和密码也将被永久清除");

        if (!confirmed) return;

        // 若该配置正连接中，先断开
        if (_vpnService.State == VpnConnectionState.Connected)
        {
            await _vpnService.DisconnectAsync();
        }

        await _profileStore.DeleteProfileAsync(_instanceId, profile.Id);
        AddLogLine($"[系统] 已删除配置文件: {profile.Name}");
        ReloadProfiles();
        RefreshState(_vpnService.State);
    }

    /// <summary>配置选中变化：更新删除/编辑按钮可用性 + 选中竖线状态 + 顶部服务器地址</summary>
    private void OnProfileSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        DeleteProfileButton.IsEnabled = SelectedProfile != null;
        EditCredentialsButton.IsEnabled = SelectedProfile != null && !_isCredentialsEditing;

        // 同步所有配置的 IsSelected 状态（驱动左侧主题色竖线）
        foreach (var p in _profiles)
        {
            p.IsSelected = p.Id == SelectedProfile?.Id;
        }

        // 更新顶部状态容器的服务器地址为当前选中配置
        UpdateServerDisplay();

        // 切换配置后立即锁定右侧账密输入（编辑按钮重新高亮可点，需重新点击编辑）
        // 且仅在选中变化发生时锁定：无选中时也锁定
        SetCredentialsEditing(false);

        // 无选中配置时连接按钮禁用（灰色），选中后恢复可用（若未连接）
        RefreshConnectButtonAvailability();
    }

    /// <summary>根据当前状态刷新连接按钮可用性（无选中配置时禁用）</summary>
    private void RefreshConnectButtonAvailability()
    {
        var busy = _vpnService.State is VpnConnectionState.Connecting or VpnConnectionState.Disconnecting;
        ConnectButton.IsEnabled = !busy
            && _vpnService.State != VpnConnectionState.Connected
            && SelectedProfile != null;
    }

    /// <summary>
    /// 更新顶部状态容器的服务器地址：当前选中配置的地址
    /// </summary>
    private void UpdateServerDisplay()
    {
        var profile = SelectedProfile;
        ServerText.Text = profile != null
            ? profile.ServerDisplay
            : "服务器 URL: --";
    }

    /// <summary>当前是否处于账密编辑模式</summary>
    private bool _isCredentialsEditing;

    /// <summary>
    /// 用户是否手动断开了连接。置位后 AutoLoginAsync 不再自动连接（切出/切入实例保持断开），
    /// 直到用户重新手动连接成功才清除。
    /// </summary>
    private bool _userDisconnected;

    /// <summary>
    /// 编辑按钮：解锁右侧账密输入框/自动登录/保存按钮
    /// </summary>
    private void OnEditCredentialsClick(object sender, RoutedEventArgs e)
    {
        if (SelectedProfile == null) return;
        SetCredentialsEditing(true);
    }

    /// <summary>
    /// 保存按钮：录入当前配置的账密并重新锁定
    /// </summary>
    private async void OnSaveCredentialsClick(object sender, RoutedEventArgs e)
    {
        var profile = SelectedProfile;
        if (profile == null) return;

        var account = AccountTextBox.Text.Trim();
        var password = PasswordBox.Password;

        if (string.IsNullOrEmpty(account))
        {
            AddLogLine("[错误] 请输入账号");
            return;
        }

        await _profileStore.SaveCredentialsAsync(
            _instanceId, profile.Id, account, password, AutoLoginCheckBox.IsChecked == true);

        AddLogLine($"[系统] 已保存配置 [{profile.Name}] 的账密" +
            (AutoLoginCheckBox.IsChecked == true ? "，并设为自动登录" : string.Empty));

        // 保存后重新加载列表（更新所有配置的"自动登录"徽标：非最新自动登录配置自动取消勾选）
        ReloadProfiles();

        // 同步右侧复选框为当前选中配置的最终自动登录状态（存储层已全局唯一化，
        // 若本配置非最新自动登录，此处自动取消勾选，统一视觉）
        var currentProfile = SelectedProfile;
        if (currentProfile != null)
        {
            var storeProfile = _profileStore.GetProfile(_instanceId, currentProfile.Id);
            if (storeProfile != null)
            {
                AutoLoginCheckBox.IsChecked = storeProfile.AutoLogin;
            }
        }

        SetCredentialsEditing(false);
    }

    /// <summary>
    /// 设置账密编辑模式：解锁/锁定右侧输入框与保存按钮。
    /// 解锁时加载当前选中配置的已存账密；锁定时也同步复选框为当前配置的最终自动登录状态
    /// （保证非最新自动登录的配置切换到它时复选框自动取消勾选，统一视觉）。
    /// </summary>
    private void SetCredentialsEditing(bool editing)
    {
        _isCredentialsEditing = editing;
        AccountTextBox.IsEnabled = editing;
        PasswordBox.IsEnabled = editing;
        AutoLoginCheckBox.IsEnabled = editing;
        SaveCredentialsButton.IsEnabled = editing;
        EditCredentialsButton.IsEnabled = !editing && SelectedProfile != null;

        if (SelectedProfile != null)
        {
            LoadProfileCredentials(SelectedProfile);
        }
        else
        {
            // 无选中配置（如删除配置后）：清空右侧账密区显示，避免残留已删配置的数据
            AccountTextBox.Text = string.Empty;
            PasswordBox.Password = string.Empty;
            AutoLoginCheckBox.IsChecked = false;
        }
    }

    /// <summary>
    /// 将指定配置的已保存账密与自动登录标记加载到输入框
    /// （解锁时 / 锁定切换时调用，保持复选框与存储一致）。
    /// </summary>
    private void LoadProfileCredentials(OpenVpnProfile profile)
    {
        var crypto = App.Services.GetRequiredService<ICryptoService>();
        AccountTextBox.Text = string.IsNullOrEmpty(profile.AccountNameEncrypted)
            ? string.Empty
            : crypto.Decrypt(profile.AccountNameEncrypted);
        PasswordBox.Password = string.IsNullOrEmpty(profile.AccountPasswordEncrypted)
            ? string.Empty
            : crypto.Decrypt(profile.AccountPasswordEncrypted);
        AutoLoginCheckBox.IsChecked = profile.AutoLogin;
    }

    // ===== 连接 / 断开 =====

    /// <summary>
    /// 使用选中配置发起连接。
    /// - 编辑模式（解锁中）：使用输入框中的账密（连接后保存）
    /// - 锁定模式：使用该配置已保存的账密（从存储解密）；未保存过则提示先编辑
    /// 勾选自动登录时保存凭据（仅编辑模式下保存）。
    /// </summary>
    private async void OnConnectClick(object sender, RoutedEventArgs e)
    {
        var profile = SelectedProfile;
        if (profile == null)
        {
            AddLogLine("[错误] 请先导入并选择一个配置文件");
            return;
        }

        var configPath = _profileStore.GetConfigPath(_instanceId, profile.Id);
        if (configPath == null)
        {
            AddLogLine("[错误] 配置文件不存在，请重新导入");
            return;
        }

        // 编辑模式：使用输入框账密；锁定模式：使用已保存账密
        string account;
        string password;
        if (_isCredentialsEditing)
        {
            account = AccountTextBox.Text.Trim();
            password = PasswordBox.Password;
        }
        else
        {
            var crypto = App.Services.GetRequiredService<ICryptoService>();
            account = string.IsNullOrEmpty(profile.AccountNameEncrypted)
                ? string.Empty
                : crypto.Decrypt(profile.AccountNameEncrypted);
            password = string.IsNullOrEmpty(profile.AccountPasswordEncrypted)
                ? string.Empty
                : crypto.Decrypt(profile.AccountPasswordEncrypted);
        }

        if (string.IsNullOrEmpty(account))
        {
            AddLogLine("[错误] 该配置未保存账密，请点击编辑并保存后连接");
            return;
        }

        ConnectButton.IsEnabled = false;
        StateText.Text = "正在发起连接...";
        AddLogLine($"[系统] 正在连接 {profile.ServerDisplay} ...");

        var (success, error) = await _vpnService.ConnectAsync(
            account, password,
            profile.ServerHost ?? string.Empty, profile.ServerPort,
            _displayName, configPath);

        // 用户手动连接成功 → 清除"手动断开"标记（后续仍可自动登录）
        if (success)
        {
            _userDisconnected = false;
        }

        if (!success && error != null)
        {
            AddLogLine("[错误] " + error);
        }

        // 编辑模式下连接成功 → 保存本配置账密（含自动登录标记；未勾选自动登录则清除旧标记）
        if (success && _isCredentialsEditing)
        {
            await _profileStore.SaveCredentialsAsync(
                _instanceId, profile.Id, account, password, AutoLoginCheckBox.IsChecked == true);
            AddLogLine("[系统] 已保存账密" +
                (AutoLoginCheckBox.IsChecked == true ? "，并设为自动登录" : string.Empty));

            // 重新加载列表（更新所有配置的"自动登录"徽标）+ 同步复选框为最终状态（全局唯一）
            ReloadProfiles();
            var storeProfile = _profileStore.GetProfile(_instanceId, profile.Id);
            if (storeProfile != null)
            {
                AutoLoginCheckBox.IsChecked = storeProfile.AutoLogin;
            }
            SetCredentialsEditing(false);   // 保存后锁定
        }

        RefreshState(_vpnService.State);
    }

    private async void OnDisconnectClick(object sender, RoutedEventArgs e)
    {
        DisconnectButton.IsEnabled = false;
        StateText.Text = "正在断开...";
        AddLogLine("[系统] 正在断开连接 ...");

        await _vpnService.DisconnectAsync();

        // 用户手动断开：标记后切出/切入实例不再自动重连（保持断开）
        _userDisconnected = true;
        RefreshState(_vpnService.State);
    }

    /// <summary>
    /// 自动登录 — 使用本方案本地保存的自动登录凭据发起连接（部署阶段 / 下次启动调用）。
    /// 令牌连接成功的读取标志 = VPN 连接成功（状态进入 Connected）。
    /// 无自动登录配置时返回 (true, null) 表示无需连接（仅"方案加载完成"）。
    /// </summary>
    public async Task<(bool success, string? error)> AutoLoginAsync()
    {
        // 用户手动断开过连接 → 不再自动连接（保持断开状态，直到用户手动重新连接）
        if (_userDisconnected)
        {
            return (true, null);
        }

        var autoProfile = _profileStore.GetAutoLoginProfile(_instanceId);
        if (autoProfile == null)
        {
            // 未勾选自动登录：无需自动连接（方案仅到"方案加载完成"）
            return (true, null);
        }

        var configPath = _profileStore.GetConfigPath(_instanceId, autoProfile.Id);
        if (configPath == null)
        {
            return (false, "自动登录配置文件不存在，请重新导入");
        }

        var account = _profileStore.GetProfile(_instanceId, autoProfile.Id)?.AccountNameEncrypted is { } encName
            ? App.Services.GetRequiredService<ICryptoService>().Decrypt(encName)
            : string.Empty;
        var password = _profileStore.GetProfile(_instanceId, autoProfile.Id)?.AccountPasswordEncrypted is { } encPwd
            ? App.Services.GetRequiredService<ICryptoService>().Decrypt(encPwd)
            : string.Empty;

        // 已有活动连接 → 直接返回当前结果（预选配置 + 输出日志）
        switch (_vpnService.State)
        {
            case VpnConnectionState.Connected:
                SelectAutoLoginProfile(autoProfile);
                return (true, null);
            case VpnConnectionState.Connecting:
            case VpnConnectionState.Disconnecting:
                return (false, "已有 VPN 连接操作正在进行，请稍后再试");
        }

        AddLogLine($"[系统] 正在使用自动登录凭据连接 {autoProfile.ServerDisplay} ...");

        // 等待连接结果（后台线程事件，TaskCompletionSource 异步续延）
        var tcs = new TaskCompletionSource<(bool success, string? error)>(
            TaskCreationOptions.RunContinuationsAsynchronously);

        void OnStateChanged(VpnConnectionState state)
        {
            switch (state)
            {
                case VpnConnectionState.Connected:
                    tcs.TrySetResult((true, null));
                    break;
                case VpnConnectionState.Failed:
                    tcs.TrySetResult((false, _vpnService.LastError ?? "连接失败"));
                    break;
                case VpnConnectionState.Disconnected:
                    tcs.TrySetResult((false, _vpnService.LastError ?? "连接中断"));
                    break;
            }
        }

        _vpnService.StateChanged += OnStateChanged;
        try
        {
            var (launchOk, launchError) = await _vpnService.ConnectAsync(
                account, password,
                autoProfile.ServerHost ?? string.Empty, autoProfile.ServerPort,
                _displayName, configPath);

            if (!launchOk)
            {
                AddLogLine("[错误] " + (launchError ?? "连接失败"));
                return (false, launchError ?? "连接失败");
            }

            var completed = await Task.WhenAny(
                tcs.Task,
                Task.Delay(TimeSpan.FromSeconds(AutoLoginConnectTimeoutSeconds)));

            if (completed != tcs.Task)
                return (false, "等待连接结果超时，请进入工作区查看连接日志");

            var result = await tcs.Task;
            if (result.success)
            {
                // 自动登录成功：预选所用配置文件（触发服务器地址显示）+ 输出成功日志
                SelectAutoLoginProfile(autoProfile);
                AddLogLine($"[系统] 自动登录成功，已连接 {autoProfile.ServerDisplay}");
            }
            else
            {
                AddLogLine("[错误] " + (result.error ?? "连接失败"));
            }
            return result;
        }
        finally
        {
            _vpnService.StateChanged -= OnStateChanged;
        }
    }

    /// <summary>
    /// 自动登录成功后：在配置列表中预选自动登录所使用的配置文件，
    /// 使顶部状态容器显示服务器地址（通过 SelectionChanged → UpdateServerDisplay）。
    /// </summary>
    private void SelectAutoLoginProfile(OpenVpnProfile autoProfile)
    {
        // 确保配置列表已加载（面板可能刚构造，OnLoaded 的 ReloadProfiles 尚未执行）
        if (_profiles.Count == 0)
        {
            ReloadProfiles();
        }

        var match = _profiles.FirstOrDefault(p => p.Id == autoProfile.Id);
        if (match != null)
        {
            ProfileListView.SelectedItem = match;
            // 若 SelectedItem 与当前相同则不触发 SelectionChanged → 手动刷新服务器显示
            UpdateServerDisplay();
        }
    }

    // ===== 硬重载 / 关闭 / 初始化 =====

    /// <summary>
    /// 硬重载方案 — 方案标签栏"硬重载"调用（服务版 OpenVPN 分支）。
    /// 流程：断开连接 → 完全清除本方案保存的配置文件及其账密等全部信息 →
    /// 重走部署流程（重建面板，配置库为空，用户需重新导入）。
    /// 遮罩隐藏探针 = 方案完整加载完成。
    /// </summary>
    public async Task<bool> HardReloadAsync()
    {
        ShowBusyOverlay("正在硬重载方案，请稍候...");
        try
        {
            await DisconnectIfAnyAsync("硬重载");

            await _profileStore.ClearAllAsync(_instanceId);
            AddLogLine("[系统] 硬重载：已清除全部配置文件及凭据");

            if (SchemeReloader == null)
            {
                AddLogLine("[错误] 硬重载：无法获取方案重载器");
                return false;
            }

            AddLogLine("[系统] 硬重载：正在重新加载方案 ...");
            bool reloaded = await SchemeReloader();
            AddLogLine(reloaded
                ? "[系统] 硬重载：方案加载完成"
                : "[错误] 硬重载：方案加载失败，请查看页面提示");
            return reloaded;
        }
        finally
        {
            HideBusyOverlay();
        }
    }

    /// <summary>完全关闭方案（左侧功能栏"关闭实例"调用）— 断开连接，保留配置库</summary>
    public async Task ShutdownAsync()
    {
        await DisconnectIfAnyAsync("关闭实例");
    }

    /// <summary>初始化清理（左侧功能栏"初始化实例"调用）— 断开连接 + 完全清除配置库</summary>
    public async Task ShutdownForReinitializeAsync()
    {
        await DisconnectIfAnyAsync("初始化实例");
        await _profileStore.ClearAllAsync(_instanceId);
    }

    /// <summary>若存在活动/残留连接则断开（幂等）— 日志中标记操作来源</summary>
    private async Task DisconnectIfAnyAsync(string operation)
    {
        if (_vpnService.State is VpnConnectionState.Connected
            or VpnConnectionState.Connecting
            or VpnConnectionState.Failed)
        {
            AddLogLine($"[系统] {operation}：正在断开当前连接 ...");
            await _vpnService.DisconnectAsync();
            AddLogLine($"[系统] {operation}：连接已断开");
        }
    }

    // ===== 遮罩 =====

    /// <summary>显示忙状态遮罩（与 SchemeHostPage 忙状态遮罩同款设计）</summary>
    private void ShowBusyOverlay(string text)
    {
        BusyOverlayText.Text = text;
        BusyOverlay.Visibility = Visibility.Visible;
    }

    /// <summary>隐藏忙状态遮罩</summary>
    private void HideBusyOverlay()
    {
        BusyOverlay.Visibility = Visibility.Collapsed;
    }

    // ===== 复制日志 =====

    private void OnCopyLogClick(object sender, RoutedEventArgs e)
    {
        if (_logLines.Count == 0)
        {
            ShowCopyFeedback("无日志");
            return;
        }

        string logText = string.Join(Environment.NewLine, _logLines);
        try
        {
            var package = new Windows.ApplicationModel.DataTransfer.DataPackage();
            package.SetText(logText);
            Windows.ApplicationModel.DataTransfer.Clipboard.SetContent(package);
            ShowCopyFeedback("已复制");
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[OpenVpnServiceControl] 复制日志失败: {ex.Message}");
            ShowCopyFeedback("复制失败");
        }
    }

    /// <summary>复制按钮短暂文字反馈（1.5 秒后恢复原文本）</summary>
    private void ShowCopyFeedback(string feedbackText)
    {
        if (CopyLogButton == null) return;

        var originalText = CopyLogButton.Content?.ToString() ?? "复制日志";
        CopyLogButton.Content = feedbackText;
        CopyLogButton.IsEnabled = false;

        _dispatcherQueue.TryEnqueue(() =>
        {
            var timer = _dispatcherQueue.CreateTimer();
            timer.Interval = TimeSpan.FromSeconds(1.5);
            timer.IsRepeating = false;
            timer.Tick += (_, _) =>
            {
                CopyLogButton.Content = originalText;
                CopyLogButton.IsEnabled = true;
                timer.Stop();
            };
            timer.Start();
        });
    }

    // ===== 工具 =====

    /// <summary>字节数格式化（B / KB / MB / GB）</summary>
    private static string FormatBytes(long bytes)
    {
        if (bytes < 1024) return $"{bytes} B";
        if (bytes < 1024 * 1024) return $"{bytes / 1024.0:0.0} KB";
        if (bytes < 1024L * 1024 * 1024) return $"{bytes / (1024.0 * 1024):0.0} MB";
        return $"{bytes / (1024.0 * 1024 * 1024):0.0} GB";
    }
}
