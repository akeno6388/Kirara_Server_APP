using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Kirara_Server_WinUI.ViewModels.Controls;

namespace Kirara_Server_WinUI.Views.Controls;

/// <summary>
/// 实例工作区底部状态栏 — 显示网络速率、VPN 状态、CPU 和内存使用率
/// </summary>
public sealed partial class StatusBar : UserControl
{
    /// <summary>
    /// 状态栏 ViewModel
    /// </summary>
    public StatusBarViewModel ViewModel { get; }

    /// <summary>
    /// VPN 连接状态颜色（连接时绿色，断开时灰色）
    /// </summary>
    public Brush VpnColor => ViewModel.IsVpnConnected
        ? new SolidColorBrush(Microsoft.UI.Colors.LimeGreen)
        : new SolidColorBrush(Microsoft.UI.Colors.Gray);

    public StatusBar()
    {
        InitializeComponent();

        ViewModel = App.Services.GetRequiredService<StatusBarViewModel>();
        ViewModel.Initialize();

        // 监听 VPN 状态变化以刷新颜色
        ViewModel.PropertyChanged += (s, e) =>
        {
            if (e.PropertyName == nameof(StatusBarViewModel.IsVpnConnected))
            {
                // 通知 VpnColor 绑定更新
                Bindings.Update();
            }
        };
    }
}