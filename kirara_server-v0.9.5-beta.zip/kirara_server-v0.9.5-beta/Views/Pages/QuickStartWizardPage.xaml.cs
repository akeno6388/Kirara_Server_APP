using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Navigation;
using Microsoft.UI.Xaml.Media.Animation;
using Microsoft.UI.Xaml.Media;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.ViewModels.Pages;

namespace Kirara_Server_WinUI.Views.Pages;

/// <summary>
/// 快速开始向导页 — 从预置模板一键创建实例
/// 完全套用 InstanceEditorPage Step3Container 的令牌绑定布局
/// </summary>
public sealed partial class QuickStartWizardPage : Page
{
    private QuickStartWizardViewModel? _vm;

    public QuickStartWizardPage()
    {
        InitializeComponent();
        try
        {
            _vm = App.Services.GetRequiredService<QuickStartWizardViewModel>();
            DataContext = _vm;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[QuickStartWizardPage] Failed to resolve ViewModel: {ex.Message}");
            throw;
        }

        // 订阅模式切换事件以驱动面板动画
        if (_vm != null)
        {
            _vm.PropertyChanged += OnViewModelPropertyChanged;
        }
    }

    /// <summary>
    /// 接收从主页传入的模板参数，初始化 ViewModel
    /// </summary>
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        base.OnNavigatedTo(e);

        if (e.Parameter is QuickStartTemplate template && _vm != null)
        {
            // 同步导航高亮
            var leftBar = App.Services.GetRequiredService<ViewModels.Controls.LeftFunctionBarViewModel>();
            leftBar.SetActivePage(quickStart: true);

            _vm.Initialize(template);
        }

        // 订阅方案图标刷新事件
        SchemeIconCacheService.SchemeIconsRefreshed += OnSchemeIconsRefreshed;
    }

    protected override void OnNavigatedFrom(NavigationEventArgs e)
    {
        base.OnNavigatedFrom(e);
        if (_vm != null)
        {
            _vm.PropertyChanged -= OnViewModelPropertyChanged;
        }
        SchemeIconCacheService.SchemeIconsRefreshed -= OnSchemeIconsRefreshed;
    }

    /// <summary>
    /// 方案图标缓存刷新后，强制重绘令牌绑定卡片。
    /// </summary>
    private void OnSchemeIconsRefreshed()
    {
        if (_vm == null) return;
        DispatcherQueue.TryEnqueue(() =>
        {
            var iconCache = App.Services.GetRequiredService<SchemeIconCacheService>();
            var bindings = _vm.SelectedSchemeTokenBindings.ToList();
            foreach (var b in bindings)
            {
                if (b.Scheme != null)
                    b.Scheme.CoverImageUrl = iconCache.GetCachedIconUrl(b.Scheme.Name);
            }
            _vm.SelectedSchemeTokenBindings = new System.Collections.ObjectModel.ObservableCollection<SchemeTokenBinding>(bindings);
        });
    }

    // ================================================================
    //  模式切换动画（与 InstanceEditorPage 完全一致）
    // ================================================================

    private void OnViewModelPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (_vm == null) return;

        switch (e.PropertyName)
        {
            case nameof(_vm.UseDomainAccount):
                if (_vm.UseDomainAccount)
                    AnimateToDomainMode();
                else
                    AnimateToNormalMode();
                break;
        }
    }

    /// <summary>
    /// 切换到普通模式：Domain 面板右滑淡出 → Normal 面板左滑淡入
    /// </summary>
    private void AnimateToNormalMode()
    {
        DomainModePanel.IsHitTestVisible = false;
        NormalModePanel.IsHitTestVisible = true;

        var fadeOutDomain = new Storyboard();
        AddDoubleAnim(fadeOutDomain, DomainModePanel, 250, 1.0, 0.0,
            new CubicEase { EasingMode = EasingMode.EaseIn }, "Opacity");
        AddDoubleAnim(fadeOutDomain, DomainPanelTranslate, 300, 0.0, 80.0,
            new CubicEase { EasingMode = EasingMode.EaseIn }, "X");
        fadeOutDomain.Begin();

        var fadeInNormal = new Storyboard { BeginTime = TimeSpan.FromMilliseconds(100) };
        AddDoubleAnim(fadeInNormal, NormalModePanel, 350, 0.0, 1.0,
            new CubicEase { EasingMode = EasingMode.EaseOut }, "Opacity");
        AddDoubleAnim(fadeInNormal, NormalPanelTranslate, 400, -40.0, 0.0,
            new QuarticEase { EasingMode = EasingMode.EaseOut }, "X");
        fadeInNormal.Begin();
    }

    /// <summary>
    /// 切换到 Domain 模式：Normal 面板左滑淡出 → Domain 面板右滑淡入
    /// </summary>
    private void AnimateToDomainMode()
    {
        NormalModePanel.IsHitTestVisible = false;
        DomainModePanel.IsHitTestVisible = true;

        var fadeOutNormal = new Storyboard();
        AddDoubleAnim(fadeOutNormal, NormalModePanel, 250, 1.0, 0.0,
            new CubicEase { EasingMode = EasingMode.EaseIn }, "Opacity");
        AddDoubleAnim(fadeOutNormal, NormalPanelTranslate, 300, 0.0, -40.0,
            new CubicEase { EasingMode = EasingMode.EaseIn }, "X");
        fadeOutNormal.Begin();

        var fadeInDomain = new Storyboard { BeginTime = TimeSpan.FromMilliseconds(100) };
        AddDoubleAnim(fadeInDomain, DomainModePanel, 350, 0.0, 1.0,
            new CubicEase { EasingMode = EasingMode.EaseOut }, "Opacity");
        AddDoubleAnim(fadeInDomain, DomainPanelTranslate, 400, 80.0, 0.0,
            new QuarticEase { EasingMode = EasingMode.EaseOut }, "X");
        fadeInDomain.Begin();
    }

    // ================================================================
    //  动画辅助方法
    // ================================================================

    private static void AddDoubleAnim(Storyboard sb, DependencyObject target, int ms, double from, double to,
        EasingFunctionBase? ease, string property)
    {
        var anim = new DoubleAnimation
        {
            From = from,
            To = to,
            Duration = TimeSpan.FromMilliseconds(ms),
            EasingFunction = ease,
        };
        Storyboard.SetTarget(anim, target);
        Storyboard.SetTargetProperty(anim, property);
        sb.Children.Add(anim);
    }
}
