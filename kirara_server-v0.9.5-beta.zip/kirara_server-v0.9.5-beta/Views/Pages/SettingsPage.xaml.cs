using System;
using System.IO;
using Microsoft.UI;
using Microsoft.UI.Text;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Media;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.ViewModels.Pages;
using WinRT.Interop;

namespace Kirara_Server_WinUI.Views.Pages;

public sealed partial class SettingsPage : Page
{
    private readonly SettingsViewModel _vm;

    public SettingsPage()
    {
        InitializeComponent();
        _vm = App.Services.GetRequiredService<SettingsViewModel>();
        DataContext = _vm;
    }

    /// <summary>
    /// 主题色色块点击 → 设置主题色。
    /// Tag 为 SwatchItemViewModel；选中态/禁用灰化/勾选标记全部由 VM 数据驱动，
    /// 禁用时（跟随系统）Button.IsEnabled=false，点击事件本身不会触发。
    /// </summary>
    private void OnPresetColorClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: SwatchItemViewModel item }) return;
        _vm.AccentColor = item.Color;
    }

    private async void OnExportAllClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button button) return;
        try
        {
            var bytes = _vm.ExportAllData();
            var name = $"kirara_all_{DateTime.Now:yyyyMMdd_HHmmss}.kirara";
            var path = PickFile(name, save: true);
            if (path is null) return;

            await File.WriteAllBytesAsync(path, bytes);
            ShowFlyout(button, "\uE73E", Colors.Success, "导出成功", Path.GetFileName(path));
        }
        catch (Exception ex)
        {
            ShowFlyout(button, "\uE783", Colors.Error, "导出失败", ex.Message);
        }
    }

    private async void OnImportAllClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button button) return;
        try
        {
            var path = PickFile(null, save: false);
            if (path is null) return;

            // 自动识别：UID 加密全量文件 / 明文实例分享文件
            var (i, iSkip, t, tSkip, isInstanceOnly) = _vm.ImportData(await File.ReadAllBytesAsync(path));

            if (i > 0 || t > 0)
            {
                var skip = (iSkip, tSkip) switch
                {
                    ( > 0, > 0) => $"（{iSkip} 个实例、{tSkip} 个令牌因重复跳过）",
                    ( > 0, _) => $"（{iSkip} 个实例因重复跳过）",
                    (_, > 0) => $"（{tSkip} 个令牌因重复跳过）",
                    _ => ""
                };
                var desc = isInstanceOnly
                    ? $"实例 {i} 个{skip}（分享文件，无需账户验证）"
                    : $"实例 {i} 个，令牌 {t} 个{skip}";
                ShowFlyout(button, "\uE73E", Colors.Success, "导入成功", desc);
            }
            else if (iSkip > 0 || tSkip > 0)
            {
                // 文件有效但全部因重复跳过 → 提示"未导入任何数据"，而非"文件格式错误"
                var skipDesc = (iSkip, tSkip) switch
                {
                    ( > 0, > 0) => $"{iSkip} 个实例、{tSkip} 个令牌因重复跳过",
                    ( > 0, _) => $"{iSkip} 个实例因重复跳过",
                    (_, > 0) => $"{tSkip} 个令牌因重复跳过",
                    _ => ""
                };
                ShowFlyout(button, "\uE946", Colors.Warning, "导入结果", $"未导入任何数据（{skipDesc}）");
            }
            else
            {
                ShowFlyout(button, "\uE946", Colors.Warning, "导入结果", "未导入任何数据，请检查文件格式");
            }
        }
        catch (UnauthorizedAccessException)
        {
            ShowFlyout(button, "\uE783", Colors.Error, "导入失败", "文件不属于当前账户");
        }
        catch (Exception ex)
        {
            ShowFlyout(button, "\uE783", Colors.Error, "导入失败", ex.Message);
        }
    }

    private static string? PickFile(string? name, bool save)
    {
        var hwnd = WindowNative.GetWindowHandle(MainWindow.Current);
        const string filter = "Kirara 数据文件 (*.kirara)|*.kirara|所有文件 (*.*)|*.*";
        return save
            ? Helpers.Win32FileDialogHelper.ShowSaveFileDialog(filter, "导出数据", name!, ".kirara", hwnd)
            : Helpers.Win32FileDialogHelper.ShowOpenFileDialog(filter, "导入数据", hwnd);
    }

    private static void ShowFlyout(Button button, string icon, Color color, string title, string desc) =>
        FlyoutHelper.ShowInfo(button, FlyoutPlacementMode.BottomEdgeAlignedRight, icon, color, title, desc);

    /// <summary>
    /// 撤回许可协议 — 弹窗警告（参考离开实例编辑器弹窗样式：窗口正中央、主题自适应），
    /// 确认后清除当前账户的同意标记并立即关闭软件。
    /// </summary>
    private async void OnRevokeLicenseClick(object sender, RoutedEventArgs e)
    {
        // 构建自定义内容（与离开实例编辑器弹窗一致的样式）
        var content = new StackPanel { Spacing = 16, MinWidth = 260 };

        content.Children.Add(new FontIcon
        {
            Glyph = "\uE783",
            FontSize = 45,
            Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 193, 7)),
            HorizontalAlignment = HorizontalAlignment.Center,
        });

        content.Children.Add(new TextBlock
        {
            Text = "确定要撤回许可协议吗？",
            FontSize = 18,
            FontWeight = FontWeights.SemiBold,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -5, 0, 0),
        });

        content.Children.Add(new TextBlock
        {
            Text = "撤回后需要重新同意许可协议才能创建实例，软件将立即关闭",
            FontSize = 15,
            Opacity = 0.7,
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -5, 0, 10),
        });

        // 跟随窗口当前主题
        var theme = MainWindow.Current?.Content is FrameworkElement root
            ? root.ActualTheme
            : ElementTheme.Default;

        var dialog = new ContentDialog
        {
            XamlRoot = this.XamlRoot,
            RequestedTheme = theme,
            Content = content,
            PrimaryButtonText = "取消",
            CloseButtonText = "撤回并关闭",
            DefaultButton = ContentDialogButton.Close,
        };

        var result = await dialog.ShowAsync();
        if (result != ContentDialogResult.None) return; // 用户取消

        // 确认撤回：清除持久化标记 → 立即关闭软件（走 MainWindow.Closed 完整清理链）
        _vm.RevokeLicenseAgreement();
        _vm.RefreshLicenseState();

        if (MainWindow.Current != null)
        {
            MainWindow.Current.Close();
        }
        else
        {
            Microsoft.UI.Xaml.Application.Current?.Exit();
        }
    }

    private static class Colors
    {
        public static readonly Color Success = Color.FromArgb(255, 80, 200, 120);
        public static readonly Color Warning = Color.FromArgb(255, 255, 165, 0);
        public static readonly Color Error = Color.FromArgb(255, 229, 115, 115);
    }
}
