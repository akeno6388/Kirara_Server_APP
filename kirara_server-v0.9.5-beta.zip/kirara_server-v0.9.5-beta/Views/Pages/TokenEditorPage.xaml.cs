using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Navigation;
using Kirara_Server_WinUI.ViewModels.Pages;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI;
using Windows.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media.Animation;
using System.ComponentModel;
using Windows.Foundation;

namespace Kirara_Server_WinUI.Views.Pages;

public sealed partial class TokenEditorPage : Page
{
    private TokenEditorViewModel? _vm;

    /// <summary>进度条容器的实际宽度（在 SizeChanged 时更新）</summary>
    private double _progressTrackWidth;

    public TokenEditorPage()
    {
        InitializeComponent();
        try
        {
            _vm = App.Services.GetRequiredService<TokenEditorViewModel>();
            DataContext = _vm;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[TokenEditorPage] Failed to resolve ViewModel: {ex.Message}");
            throw;
        }
    }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        base.OnNavigatedTo(e);

        if (_vm != null)
        {
            _vm.PropertyChanged += OnViewModelPropertyChanged;
            _vm.ResetForNew();
            PasswordBox.Password = string.Empty;
            ConfirmPasswordBox.Password = string.Empty;
        }
    }

    protected override void OnNavigatedFrom(NavigationEventArgs e)
    {
        base.OnNavigatedFrom(e);

        SyncPasswordToViewModel();

        if (_vm != null)
        {
            _vm.PropertyChanged -= OnViewModelPropertyChanged;
        }
    }

    private void OnViewModelPropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (_vm == null) return;

        switch (e.PropertyName)
        {
            case nameof(_vm.CurrentStep):
                UpdateProgressBarWidth();
                AnimateActiveStepDot();
                break;
            case nameof(_vm.IsStep0Visible):
                if (_vm.IsStep0Visible) AnimateStepIn(Step0Container);
                break;
            case nameof(_vm.IsStep1Visible):
                if (_vm.IsStep1Visible) AnimateStepIn(Step1Container);
                break;
            case nameof(_vm.IsStep2Visible):
                if (_vm.IsStep2Visible) AnimateStepIn(Step2Container);
                break;
        }
    }

    // ================================================================
    //  进度条动画
    // ================================================================

    private void OnProgressTrackSizeChanged(object sender, SizeChangedEventArgs e)
    {
        _progressTrackWidth = e.NewSize.Width;
        UpdateProgressBarWidth();
    }

    private void UpdateProgressBarWidth()
    {
        if (_vm == null || ProgressFill == null) return;

        if (_progressTrackWidth <= 0)
        {
            _progressTrackWidth = 620;
        }

        var targetWidth = _progressTrackWidth * _vm.ProgressBarWidthPercent;

        var storyboard = new Storyboard();
        var anim = new DoubleAnimation
        {
            To = targetWidth,
            Duration = TimeSpan.FromMilliseconds(400),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        };
        Storyboard.SetTarget(anim, ProgressFill);
        Storyboard.SetTargetProperty(anim, "Width");
        storyboard.Children.Add(anim);
        storyboard.Begin();
    }

    private void AnimateActiveStepDot()
    {
        if (_vm == null || StepsControl == null) return;

        var activeIndex = _vm.CurrentStep;
        if (activeIndex < 0 || activeIndex >= _vm.Steps.Count) return;

        var container = StepsControl.ContainerFromIndex(activeIndex) as DependencyObject;
        if (container == null) return;

        var dotBorder = FindDescendant<Border>(container, "StepDotBorder");
        if (dotBorder == null) return;

        if (dotBorder.RenderTransform is not ScaleTransform scale)
        {
            scale = new ScaleTransform { ScaleX = 1, ScaleY = 1 };
            dotBorder.RenderTransform = scale;
            dotBorder.RenderTransformOrigin = new Point(0.5, 0.5);
        }

        var storyboard = new Storyboard();

        var scaleXAnim = new DoubleAnimationUsingKeyFrames();
        scaleXAnim.KeyFrames.Add(new EasingDoubleKeyFrame
        {
            KeyTime = TimeSpan.FromMilliseconds(300),
            Value = 1.15,
            EasingFunction = new ElasticEase { EasingMode = EasingMode.EaseOut, Oscillations = 1 }
        });
        scaleXAnim.KeyFrames.Add(new EasingDoubleKeyFrame
        {
            KeyTime = TimeSpan.FromMilliseconds(600),
            Value = 1.0,
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        });
        Storyboard.SetTarget(scaleXAnim, dotBorder);
        Storyboard.SetTargetProperty(scaleXAnim, "(UIElement.RenderTransform).(ScaleTransform.ScaleX)");
        storyboard.Children.Add(scaleXAnim);

        var scaleYAnim = new DoubleAnimationUsingKeyFrames();
        scaleYAnim.KeyFrames.Add(new EasingDoubleKeyFrame
        {
            KeyTime = TimeSpan.FromMilliseconds(300),
            Value = 1.15,
            EasingFunction = new ElasticEase { EasingMode = EasingMode.EaseOut, Oscillations = 1 }
        });
        scaleYAnim.KeyFrames.Add(new EasingDoubleKeyFrame
        {
            KeyTime = TimeSpan.FromMilliseconds(600),
            Value = 1.0,
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
        });
        Storyboard.SetTarget(scaleYAnim, dotBorder);
        Storyboard.SetTargetProperty(scaleYAnim, "(UIElement.RenderTransform).(ScaleTransform.ScaleY)");
        storyboard.Children.Add(scaleYAnim);

        storyboard.Begin();
    }

    // ================================================================
    //  步骤内容切换动画
    // ================================================================

    private static void AnimateStepIn(UIElement element)
    {
        var transform = new CompositeTransform();
        element.RenderTransform = transform;
        element.RenderTransformOrigin = new Point(0.5, 0.5);

        transform.TranslateX = 80;
        element.Opacity = 0;

        var duration = TimeSpan.FromMilliseconds(350);
        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };

        var storyboard = new Storyboard();

        var opacityAnim = new DoubleAnimation
        {
            From = 0, To = 1,
            Duration = duration,
            EasingFunction = ease,
        };
        Storyboard.SetTarget(opacityAnim, element);
        Storyboard.SetTargetProperty(opacityAnim, "Opacity");
        storyboard.Children.Add(opacityAnim);

        var translateAnim = new DoubleAnimation
        {
            From = 80, To = 0,
            Duration = duration,
            EasingFunction = ease,
        };
        Storyboard.SetTarget(translateAnim, transform);
        Storyboard.SetTargetProperty(translateAnim, "TranslateX");
        storyboard.Children.Add(translateAnim);

        storyboard.Begin();
    }

    // ================================================================
    //  工具方法
    // ================================================================

    private static T? FindDescendant<T>(DependencyObject parent, string name) where T : DependencyObject
    {
        int count = VisualTreeHelper.GetChildrenCount(parent);
        for (int i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is T tChild)
            {
                if (tChild is FrameworkElement fe && fe.Name == name)
                    return tChild;
                var found = FindDescendant<T>(child, name);
                if (found != null) return found;
            }
            else
            {
                var found = FindDescendant<T>(child, name);
                if (found != null) return found;
            }
        }
        return null;
    }

    // ================================================================
    //  令牌名称实时校验
    // ================================================================

    private void OnTokenNameTextChanged(object sender, TextChangedEventArgs e)
    {
        if (_vm != null && sender is TextBox textBox)
        {
            _vm.TokenName = textBox.Text;
        }
    }

    // ================================================================
    //  PasswordBox 同步 + 空格过滤
    // ================================================================

    private bool _isCleaningPassword;

    private void SyncPasswordToViewModel()
    {
        if (_vm != null)
        {
            _vm.AccountPassword = PasswordBox.Password;
        }
    }

    private void OnPasswordChanged(object sender, RoutedEventArgs e)
    {
        if (_isCleaningPassword) return;
        if (PasswordBox.Password.Contains(' '))
        {
            _isCleaningPassword = true;
            PasswordBox.Password = PasswordBox.Password.Replace(" ", "");
            _isCleaningPassword = false;
        }
        SyncPasswordToViewModel();
    }

    // ================================================================
    //  确认密码框同步
    // ================================================================

    private void OnConfirmPasswordChanged(object sender, RoutedEventArgs e)
    {
        if (_vm != null)
        {
            _vm.ConfirmPassword = ConfirmPasswordBox.Password;
        }
    }
}
