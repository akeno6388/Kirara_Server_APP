using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Media;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.ViewModels.Pages;
using Windows.UI;
using System.Collections.Generic;

namespace Kirara_Server_WinUI.Views.Pages;

public sealed partial class TokenManagerPage : Page
{
    /// <summary>预定义颜色选项（十六进制色值），用于飞入菜单的颜色标签选择</summary>
    private static readonly IReadOnlyList<string> ColorOptions = new List<string>
    {
        "#FF6B6B",
        "#FFA94D",
        "#FFD43B",
        "#69DB7C",
        "#4DABF7",
        "#9775FA",
        "#F06595",
        "#868E96",
        "", // 空字符串 = 清除颜色
    };

    /// <summary>重命名非法字符集合</summary>
    private static readonly HashSet<char> ForbiddenNameChars = new(@"#\/*:?""<>|");

    public TokenManagerPage()
    {
        InitializeComponent();
        DataContext = App.Services.GetRequiredService<TokenManagerViewModel>();
    }

    // ================================================================
    //  颜色标签选择飞入
    // ================================================================

    private void OnColorPickerClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button button) return;
        if (button.Tag is not Token token) return;
        if (DataContext is not TokenManagerViewModel vm) return;

        var flyout = new Flyout
        {
            Placement = FlyoutPlacementMode.BottomEdgeAlignedRight,
        };

        var stackPanel = new StackPanel { Spacing = 8, Padding = new Thickness(4) };

        stackPanel.Children.Add(new TextBlock
        {
            Text = "选择颜色标签",
            FontSize = 13,
            Opacity = 0.6,
            Margin = new Thickness(0, 0, 0, 14),
        });

        var colorPanel = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Center,
        };

        foreach (var colorHex in ColorOptions)
        {
            var colorButton = CreateColorButton(colorHex, token, vm, flyout);
            colorPanel.Children.Add(colorButton);
        }

        stackPanel.Children.Add(colorPanel);
        flyout.Content = stackPanel;
        flyout.ShowAt(button);
    }

    private Button CreateColorButton(string colorHex, Token token, TokenManagerViewModel vm, Flyout parentFlyout)
    {
        var button = new Button
        {
            Style = (Style)Resources["ColorOptionButtonStyle"],
        };

        if (string.IsNullOrEmpty(colorHex))
        {
            button.Background = new SolidColorBrush(Color.FromArgb(40, 128, 128, 128));
            button.Content = new TextBlock
            {
                Text = "\uE10A",
                FontFamily = new Microsoft.UI.Xaml.Media.FontFamily("Segoe MDL2 Assets"),
                FontSize = 14,
                Foreground = new SolidColorBrush(Microsoft.UI.Colors.Gray),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
            };
        }
        else
        {
            try
            {
                var hex = colorHex.TrimStart('#');
                var r = System.Convert.ToByte(hex[..2], 16);
                var g = System.Convert.ToByte(hex[2..4], 16);
                var b = System.Convert.ToByte(hex[4..6], 16);
                button.Background = new SolidColorBrush(Color.FromArgb(255, r, g, b));
            }
            catch { }
        }

        var capturedColor = colorHex;
        button.Click += (_, _) =>
        {
            vm.ApplyTokenColor(token, capturedColor);
            parentFlyout.Hide();
        };

        return button;
    }

    // ================================================================
    //  重命名飞入
    // ================================================================

    private void OnRenameClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button button) return;
        if (button.Tag is not Token token) return;
        if (DataContext is not TokenManagerViewModel vm) return;

        var flyout = new Flyout
        {
            Placement = FlyoutPlacementMode.BottomEdgeAlignedRight,
        };

        var root = new StackPanel { Spacing = 12, MinWidth = 280, Padding = new Thickness(4) };

        root.Children.Add(new TextBlock
        {
            Text = "重命名令牌",
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 0, 0, 8),
            FontSize = 16,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
        });

        var textBox = new TextBox
        {
            Text = token.Name,
            PlaceholderText = "输入新名称",
            MaxLength = 64,
            Margin = new Thickness(0, 0, 0, 10),
        };
        root.Children.Add(textBox);

        var errorText = new TextBlock
        {
            FontSize = 12,
            Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 107, 107)),
            TextWrapping = TextWrapping.Wrap,
            Visibility = Visibility.Collapsed,
            Margin = new Thickness(5, -10, 0, 0),
        };
        root.Children.Add(errorText);

        var buttonPanel = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Center,
            Spacing = 12,
        };

        var cancelBtn = new Button
        {
            Content = "取消",
            Style = (Style)Application.Current.Resources["GrayButtonStyle"],
            MinWidth = 100,
        };
        cancelBtn.Click += (_, _) => flyout.Hide();
        buttonPanel.Children.Add(cancelBtn);

        var saveBtn = new Button
        {
            Content = "保存",
            Style = (Style)Application.Current.Resources["PrimaryButtonStyle"],
            MinWidth = 100,
            IsEnabled = false,
        };
        buttonPanel.Children.Add(saveBtn);

        root.Children.Add(buttonPanel);
        flyout.Content = root;
        flyout.ShowAt(button);

        // 选中全部文字
        textBox.SelectAll();

        // 实时校验
        textBox.TextChanged += (_, _) =>
        {
            var name = textBox.Text;
            var (isValid, errorMsg) = ValidateName(name, token, vm);
            saveBtn.IsEnabled = isValid;
            errorText.Text = errorMsg ?? string.Empty;
            errorText.Visibility = errorMsg != null ? Visibility.Visible : Visibility.Collapsed;
        };

        // 初始校验
        textBox.Focus(FocusState.Programmatic);

        saveBtn.Click += (_, _) =>
        {
            var newName = textBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(newName) || newName == token.Name)
            {
                flyout.Hide();
                return;
            }

            token.Name = newName;
            vm.RenameToken(token);
            flyout.Hide();
        };
    }

    private static (bool isValid, string? error) ValidateName(string name, Token token, TokenManagerViewModel vm)
    {
        if (string.IsNullOrWhiteSpace(name))
            return (false, "名称不能为空");

        if (name.Contains(' '))
            return (false, "名称不能包含空格");

        if (name.Any(c => ForbiddenNameChars.Contains(c)))
            return (false, "名称不能包含下列特殊字符：# \\ / : * ? \" < > |");

        if (name == token.Name)
            return (false, null); // 名称未变，禁用保存但不显示错误

        var allTokens = vm.GetAllTokens();
        if (allTokens.Any(t => t.Id != token.Id
            && t.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
            return (false, "该名称已被其他令牌使用，请换一个名称");

        return (true, null);
    }

    // ================================================================
    //  编辑备注飞入
    // ================================================================

    private void OnEditNotesClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button button) return;
        if (button.Tag is not Token token) return;
        if (DataContext is not TokenManagerViewModel vm) return;

        var flyout = new Flyout
        {
            Placement = FlyoutPlacementMode.BottomEdgeAlignedRight,
        };

        var root = new StackPanel { Spacing = 12, MinWidth = 280, MaxWidth = 360, Padding = new Thickness(4) };

        root.Children.Add(new TextBlock
        {
            Text = "编辑备注",
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 0, 0, 8),
            FontSize = 16,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
        });

        var textBox = new TextBox
        {
            Text = token.Notes ?? string.Empty,
            PlaceholderText = "输入备注内容",
            AcceptsReturn = true,
            MaxHeight = 120,
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(0, 0, 0, 10),
        };
        root.Children.Add(textBox);

        var buttonPanel = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Center,
            Spacing = 12,
        };

        var cancelBtn = new Button
        {
            Content = "取消",
            Style = (Style)Application.Current.Resources["GrayButtonStyle"],
            MinWidth = 100,
        };
        cancelBtn.Click += (_, _) => flyout.Hide();
        buttonPanel.Children.Add(cancelBtn);

        var saveBtn = new Button
        {
            Content = "保存",
            Style = (Style)Application.Current.Resources["PrimaryButtonStyle"],
            MinWidth = 100,
            IsEnabled = false,
        };
        buttonPanel.Children.Add(saveBtn);

        root.Children.Add(buttonPanel);
        flyout.Content = root;
        flyout.ShowAt(button);

        textBox.Focus(FocusState.Programmatic);

        // 实时校验：内容未变时禁用保存按钮，不报红字
        textBox.TextChanged += (_, _) =>
        {
            var currentText = textBox.Text;
            saveBtn.IsEnabled = currentText != token.Notes;
        };

        saveBtn.Click += (_, _) =>
        {
            var newNotes = textBox.Text;
            if (newNotes != token.Notes)
            {
                token.Notes = newNotes;
                vm.UpdateTokenAndRefresh(token);
            }
            flyout.Hide();
        };
    }

    // ================================================================
    //  删除确认飞入
    // ================================================================

    private async void OnDeleteClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button button) return;
        if (button.Tag is not Token token) return;
        if (DataContext is not TokenManagerViewModel vm) return;

        bool confirmed = await FlyoutHelper.ShowConfirmAsync(
            button,
            FlyoutPlacementMode.BottomEdgeAlignedRight,
            "\uE783",
            Color.FromArgb(255, 229, 115, 115),
            "确定要永久删除此令牌吗？",
            "链接了此令牌的方案将会丢失凭据，所有链接了该方案的实例都需要重新创建",
            confirmText: "删除",
            confirmColor: Color.FromArgb(255, 229, 115, 115));

        if (confirmed)
            vm.DeleteTokenById(token.Id);
    }

    // ================================================================
    //  导入导出
    // ================================================================

    private async void OnExportTokenClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button button) return;
        if (button.Tag is not Token token) return;
        if (DataContext is not TokenManagerViewModel vm) return;

        try
        {
            var fileName = await vm.ExportToken(token);
            if (fileName != null)
            {
                FlyoutHelper.ShowInfo(
                    button,
                    FlyoutPlacementMode.BottomEdgeAlignedRight,
                    "\uE73E",
                    Color.FromArgb(255, 80, 200, 120),
                    "导出成功",
                    $"令牌已导出到 {fileName}");
            }
        }
        catch (Exception ex)
        {
            FlyoutHelper.ShowInfo(
                button,
                FlyoutPlacementMode.BottomEdgeAlignedRight,
                "\uE783",
                Color.FromArgb(255, 229, 115, 115),
                "导出失败",
                ex.Message);
        }
    }

    private async void OnExportAllClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button button) return;
        if (DataContext is not TokenManagerViewModel vm) return;

        try
        {
            var fileName = await vm.ExportAllTokens();
            if (fileName != null)
            {
                FlyoutHelper.ShowInfo(
                    button,
                    FlyoutPlacementMode.BottomEdgeAlignedRight,
                    "\uE73E",
                    Color.FromArgb(255, 80, 200, 120),
                    "导出成功",
                    $"所有令牌已导出到 {fileName}");
            }
        }
        catch (Exception ex)
        {
            FlyoutHelper.ShowInfo(
                button,
                FlyoutPlacementMode.BottomEdgeAlignedRight,
                "\uE783",
                Color.FromArgb(255, 229, 115, 115),
                "导出失败",
                ex.Message);
        }
    }

    private async void OnImportClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button button) return;
        if (DataContext is not TokenManagerViewModel vm) return;

        try
        {
            var result = await vm.ImportTokens();
            if (result == null) return; // 用户取消

            var (imported, skipped) = result.Value;

            if (imported > 0 || skipped > 0)
            {
                var msg = $"成功导入 {imported} 个令牌";
                if (skipped > 0)
                    msg += $"，已跳过 {skipped} 个重复令牌";
                FlyoutHelper.ShowInfo(
                    button,
                    FlyoutPlacementMode.BottomEdgeAlignedRight,
                    imported > 0 ? "\uE73E" : "\uE946",
                    imported > 0
                        ? Color.FromArgb(255, 80, 200, 120)
                        : Color.FromArgb(255, 255, 165, 0),
                    imported > 0 ? "导入成功" : "导入结果",
                    msg);
            }
            else
            {
                FlyoutHelper.ShowInfo(
                    button,
                    FlyoutPlacementMode.BottomEdgeAlignedRight,
                    "\uE946",
                    Color.FromArgb(255, 255, 165, 0),
                    "导入结果",
                    "未导入任何令牌，请检查文件格式");
            }
        }
        catch (Exception ex)
        {
            FlyoutHelper.ShowInfo(
                button,
                FlyoutPlacementMode.BottomEdgeAlignedRight,
                "\uE783",
                Color.FromArgb(255, 229, 115, 115),
                "导入失败",
                $"导入令牌时出错：{ex.Message}");
        }
    }
}
