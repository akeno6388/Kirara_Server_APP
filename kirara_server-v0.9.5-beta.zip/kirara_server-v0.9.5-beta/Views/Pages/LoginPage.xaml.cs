using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Animation;
using Microsoft.UI.Xaml.Media.Imaging;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.ViewModels.Pages;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.Views.Pages;

/// <summary>
/// 登录页面 — 独立全屏登录界面，不显示左侧功能栏
/// </summary>
public sealed partial class LoginPage : Page
{
    /// <summary>登录页面 ViewModel</summary>
    public LoginPageViewModel ViewModel { get; }

    /// <summary>登录成功后的退出动画完成回调</summary>
    public Action? ExitAnimationCompleted { get; set; }

    /// <summary>当前显示的登录/注册表单面板</summary>
    private StackPanel? _currentFormPanel;

    /// <summary>是否跳过了入场动画（自动登录时）</summary>
    public bool CardAnimationSkipped { get; private set; }

    public LoginPage()
    {
        InitializeComponent();

        // 登录卡片 App 图标：Unpackaged 模式下 ms-appx 协议不可用，
        // 经 AssetPathHelper 解析为输出目录文件路径（见 Helpers/AssetPathHelper.cs）
        AppLogoImage.Source = new BitmapImage(new Uri(AssetPathHelper.Resolve("Assets/app_logo.png")));

        ViewModel = App.Services.GetRequiredService<LoginPageViewModel>();
        DataContext = ViewModel;

        // 订阅 IsRegisterMode 变化以播放切换动画
        ViewModel.PropertyChanged += OnViewModelPropertyChanged;

        Loaded += OnLoaded;
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= OnLoaded;
        _currentFormPanel = LoginForm;

        // 自动登录：跳过入场动画，隐藏卡片防止出现在遮罩上方，直接触发登录流程
        if (ViewModel.AutoLoginEnabled && !ViewModel.SuppressAutoLogin)
        {
            CardAnimationSkipped = true;
            LoginCard.Opacity = 0;
            _ = ViewModel.BeginAutoLoginAsync();

            // 🆕 如果自动登录失败，恢复卡片并播放入场动画
            if (!App.Services.GetRequiredService<ILoginService>().IsLoggedIn)
            {
                CardAnimationSkipped = false;
                LoginCard.Opacity = 1;
                PlayEnterAnimation();
            }
        }
        else
        {
            PlayEnterAnimation();
        }
    }

    private void OnViewModelPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(LoginPageViewModel.IsRegisterMode))
        {
            PlayFormSwitchAnimation();
        }
    }

    // ================================================================
    //  入场动画：卡片淡入 + 缩放
    // ================================================================
    private void PlayEnterAnimation()
    {
        const int durationMs = 500;
        var easing = new CubicEase { EasingMode = EasingMode.EaseOut };

        var sb = new Storyboard();

        // 透明度：0 → 1
        var fadeAnim = new DoubleAnimation
        {
            From = 0.0, To = 1.0,
            Duration = TimeSpan.FromMilliseconds(durationMs),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(fadeAnim, LoginCard);
        Storyboard.SetTargetProperty(fadeAnim, "Opacity");
        sb.Children.Add(fadeAnim);

        // 缩放：0.95 → 1.0
        var scaleAnim = new DoubleAnimation
        {
            From = 0.95, To = 1.0,
            Duration = TimeSpan.FromMilliseconds(durationMs),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(scaleAnim, CardScale);
        Storyboard.SetTargetProperty(scaleAnim, "ScaleX");
        sb.Children.Add(scaleAnim);

        var scaleYAnim = new DoubleAnimation
        {
            From = 0.95, To = 1.0,
            Duration = TimeSpan.FromMilliseconds(durationMs),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(scaleYAnim, CardScale);
        Storyboard.SetTargetProperty(scaleYAnim, "ScaleY");
        sb.Children.Add(scaleYAnim);

        // 位移：Y +20 → 0
        var translate = new TranslateTransform();
        LoginCard.RenderTransform = new TransformGroup
        {
            Children = { CardScale, translate }
        };

        var slideAnim = new DoubleAnimation
        {
            From = 20.0, To = 0.0,
            Duration = TimeSpan.FromMilliseconds(durationMs),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(slideAnim, translate);
        Storyboard.SetTargetProperty(slideAnim, "Y");
        sb.Children.Add(slideAnim);

        LoginCard.Opacity = 0;
        sb.Begin();
    }

    // ================================================================
    //  登录/注册表单切换动画
    //  ① 卡片微缩 + 标题+旧控件同步淡出 → ② 卡片弹性恢复 + 标题+新控件同步淡入
    //  标题文字在淡出完成后、淡入开始前手动更新
    // ================================================================
    private async void PlayFormSwitchAnimation()
    {
        var oldPanel = _currentFormPanel;
        var newPanel = ViewModel.IsRegisterMode ? RegisterForm : LoginForm;

        if (oldPanel == newPanel || oldPanel == null) return;

        const int shrinkMs = 280;
        const int fadeMs = 280;
        const int expandMs = 420;

        var shrinkEase = new QuarticEase { EasingMode = EasingMode.EaseOut };
        var expandEase = new ElasticEase { EasingMode = EasingMode.EaseOut, Oscillations = 1, Springiness = 6 };
        var fadeEase = new CircleEase { EasingMode = EasingMode.EaseInOut };

        // ── Phase 1: 卡片微缩 + 标题+旧控件同步淡出 ──
        var phase1Sb = new Storyboard();

        var shrinkX = new DoubleAnimation { From = 1.0, To = 0.975, Duration = TimeSpan.FromMilliseconds(shrinkMs), EasingFunction = shrinkEase };
        Storyboard.SetTarget(shrinkX, CardScale); Storyboard.SetTargetProperty(shrinkX, "ScaleX");
        phase1Sb.Children.Add(shrinkX);

        var shrinkY = new DoubleAnimation { From = 1.0, To = 0.975, Duration = TimeSpan.FromMilliseconds(shrinkMs), EasingFunction = shrinkEase };
        Storyboard.SetTarget(shrinkY, CardScale); Storyboard.SetTargetProperty(shrinkY, "ScaleY");
        phase1Sb.Children.Add(shrinkY);

        var titleOut = new DoubleAnimation { From = 1.0, To = 0.0, Duration = TimeSpan.FromMilliseconds(fadeMs), EasingFunction = fadeEase };
        Storyboard.SetTarget(titleOut, TitleContainer); Storyboard.SetTargetProperty(titleOut, "Opacity");
        phase1Sb.Children.Add(titleOut);

        var formOut = new DoubleAnimation { From = 1.0, To = 0.0, Duration = TimeSpan.FromMilliseconds(fadeMs), EasingFunction = fadeEase };
        Storyboard.SetTarget(formOut, oldPanel); Storyboard.SetTargetProperty(formOut, "Opacity");
        phase1Sb.Children.Add(formOut);

        var p1Done = new TaskCompletionSource();
        phase1Sb.Completed += (_, _) =>
        {
            oldPanel.Visibility = Visibility.Collapsed;
            oldPanel.Opacity = 1.0;
            p1Done.TrySetResult();
        };
        phase1Sb.Begin();
        await p1Done.Task;

        // ── 旧表单完全不可见后，清理校验字段 ──
        ViewModel.CompleteFormSwitch();

        // ── 标题文字在此手动更新（完全不可见时） ──
        ModeTitleText.Text = ViewModel.ModeTitle;

        // ── Phase 2: 卡片弹性恢复 + 标题+新控件同步淡入 ──
        newPanel.Opacity = 0;
        newPanel.Visibility = Visibility.Visible;

        var phase2Sb = new Storyboard();

        var expandX = new DoubleAnimation { From = 0.975, To = 1.0, Duration = TimeSpan.FromMilliseconds(expandMs), EasingFunction = expandEase };
        Storyboard.SetTarget(expandX, CardScale); Storyboard.SetTargetProperty(expandX, "ScaleX");
        phase2Sb.Children.Add(expandX);

        var expandY = new DoubleAnimation { From = 0.975, To = 1.0, Duration = TimeSpan.FromMilliseconds(expandMs), EasingFunction = expandEase };
        Storyboard.SetTarget(expandY, CardScale); Storyboard.SetTargetProperty(expandY, "ScaleY");
        phase2Sb.Children.Add(expandY);

        var titleIn = new DoubleAnimation { From = 0.0, To = 1.0, Duration = TimeSpan.FromMilliseconds(fadeMs), EasingFunction = fadeEase };
        Storyboard.SetTarget(titleIn, TitleContainer); Storyboard.SetTargetProperty(titleIn, "Opacity");
        phase2Sb.Children.Add(titleIn);

        var formIn = new DoubleAnimation { From = 0.0, To = 1.0, Duration = TimeSpan.FromMilliseconds(fadeMs), EasingFunction = fadeEase };
        Storyboard.SetTarget(formIn, newPanel); Storyboard.SetTargetProperty(formIn, "Opacity");
        phase2Sb.Children.Add(formIn);

        phase2Sb.Begin();

        _currentFormPanel = newPanel;
    }

    // ================================================================
    //  登录成功退出动画：卡片完全淡出 → 回调通知 ShellPage
    // ================================================================
    public void PlayExitAnimation(Action? onCompleted = null)
    {
        const int exitMs = 250;
        var easing = new QuinticEase { EasingMode = EasingMode.EaseIn };

        var sb = new Storyboard();

        // 卡片完全淡出到 0
        var fadeAnim = new DoubleAnimation
        {
            From = 1.0, To = 0.0,
            Duration = TimeSpan.FromMilliseconds(exitMs),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(fadeAnim, LoginCard);
        Storyboard.SetTargetProperty(fadeAnim, "Opacity");
        sb.Children.Add(fadeAnim);

        // 缩小到 0.85
        var scaleAnim = new DoubleAnimation
        {
            From = 1.0, To = 0.85,
            Duration = TimeSpan.FromMilliseconds(exitMs),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(scaleAnim, CardScale);
        Storyboard.SetTargetProperty(scaleAnim, "ScaleX");
        sb.Children.Add(scaleAnim);

        var scaleYAnim = new DoubleAnimation
        {
            From = 1.0, To = 0.85,
            Duration = TimeSpan.FromMilliseconds(exitMs),
            EasingFunction = easing,
        };
        Storyboard.SetTarget(scaleYAnim, CardScale);
        Storyboard.SetTargetProperty(scaleYAnim, "ScaleY");
        sb.Children.Add(scaleYAnim);

        sb.Completed += (_, _) =>
        {
            // 确保卡片完全隐藏
            LoginCard.Visibility = Visibility.Collapsed;
            onCompleted?.Invoke();
            ExitAnimationCompleted?.Invoke();
        };

        sb.Begin();
    }

    // ================================================================
    //  事件处理
    // ================================================================

    private void OnSwitchToRegisterClick(Microsoft.UI.Xaml.Documents.Hyperlink sender, Microsoft.UI.Xaml.Documents.HyperlinkClickEventArgs args)
    {
        ViewModel.SwitchToRegisterCommand.Execute(null);
    }

    private void OnSwitchToLoginClick(Microsoft.UI.Xaml.Documents.Hyperlink sender, Microsoft.UI.Xaml.Documents.HyperlinkClickEventArgs args)
    {
        ViewModel.SwitchToLoginCommand.Execute(null);
    }

    /// <summary>
    /// 所有密码框共享的 PasswordChanged — 禁止空格输入
    /// </summary>
    private bool _isCleaningPassword;

    private void OnPasswordBoxPasswordChanged(object sender, RoutedEventArgs e)
    {
        if (_isCleaningPassword) return;
        if (sender is PasswordBox pb && pb.Password.Contains(' '))
        {
            _isCleaningPassword = true;
            pb.Password = pb.Password.Replace(" ", "");
            _isCleaningPassword = false;
        }
    }
}
