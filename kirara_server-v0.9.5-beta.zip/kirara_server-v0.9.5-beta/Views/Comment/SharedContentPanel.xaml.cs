using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Kirara_Server_WinUI.ViewModels.Comment;

namespace Kirara_Server_WinUI.Views.Comment;

/// <summary>
/// [首页分享功能] 分享面板 UserControl — 分享卡片列表
/// 通过 DataContext 绑定 SharedContentViewModel
/// </summary>
public sealed partial class SharedContentPanel : UserControl
{
    /// <summary>分享窗口 ViewModel</summary>
    public SharedContentViewModel ViewModel =>
        (SharedContentViewModel)DataContext;

    /// <summary>
    /// [首页分享功能] 折叠/展开按钮点击事件（由 SchemeHostPage 订阅处理）
    /// </summary>
    public event Action? CollapseToggleRequested;

    /// <summary>
    /// [首页分享功能] 最大化/还原按钮点击事件（由 SchemeHostPage 订阅处理）
    /// </summary>
    public event Action? FullExpandToggleRequested;

    /// <summary>
    /// [首页分享功能] 是否显示「最大化」按钮（默认 true；宿主可按需隐藏）
    /// </summary>
    public bool IsFullExpandEnabled { get; set; } = true;

    public SharedContentPanel()
    {
        InitializeComponent();
    }

    /// <summary>
    /// [首页分享功能] 折叠/展开按钮点击 — 触发事件
    /// </summary>
    private void OnCollapseToggleClick(object sender, RoutedEventArgs e)
    {
        CollapseToggleRequested?.Invoke();
    }

    /// <summary>
    /// [首页分享功能] 最大化/还原按钮点击 — 触发事件
    /// </summary>
    private void OnFullExpandToggleClick(object sender, RoutedEventArgs e)
    {
        FullExpandToggleRequested?.Invoke();
    }

    /// <summary>
    /// [首页分享功能] 设置折叠视觉状态
    /// 折叠：完全隐藏标题信息与内容区，仅保留展开按钮
    /// 展开：恢复完整面板（标题栏右侧 最大化+折叠 按钮组）
    /// </summary>
    public void SetCollapsedVisualState(bool isCollapsed)
    {
        if (isCollapsed)
        {
            TitleInfoArea.Visibility = Visibility.Collapsed;
            ContentListArea.Visibility = Visibility.Collapsed;
            TitleActionArea.HorizontalAlignment = HorizontalAlignment.Stretch;
            TitleActionArea.VerticalAlignment = VerticalAlignment.Stretch;
            FullExpandToggleButton.Visibility = Visibility.Collapsed;
            CollapseToggleButton.HorizontalAlignment = HorizontalAlignment.Stretch;
            CollapseToggleButton.VerticalAlignment = VerticalAlignment.Stretch;
            TitleBarBorder.Padding = new Thickness(0);
            TitleBarBorder.BorderThickness = new Thickness(0);
            CollapseToggleIcon.Glyph = "\uEDDA"; // [首页分享功能] EDDA(缩成钮态)
        }
        else
        {
            TitleInfoArea.Visibility = Visibility.Visible;
            ContentListArea.Visibility = Visibility.Visible;
            TitleActionArea.HorizontalAlignment = HorizontalAlignment.Right;
            TitleActionArea.VerticalAlignment = VerticalAlignment.Center;
            FullExpandToggleButton.Visibility = IsFullExpandEnabled ? Visibility.Visible : Visibility.Collapsed;
            CollapseToggleButton.HorizontalAlignment = HorizontalAlignment.Right;
            CollapseToggleButton.VerticalAlignment = VerticalAlignment.Center;
            TitleBarBorder.Padding = new Thickness(16, 0, 12, 0);
            TitleBarBorder.BorderThickness = new Thickness(0, 0, 0, 1);
            CollapseToggleIcon.Glyph = "\uEDDA"; // [首页分享功能] EDDA(缩成钮态)
        }
    }

    /// <summary>
    /// [首页分享功能] 设置最大化视觉状态（按钮图标切换）
    /// 气泡：Maximize；全展开：RestoreDown（点击还原）
    /// </summary>
    public void SetFullExpandedVisualState(bool isFullExpanded)
    {
        // [首页分享功能] EDDB(气泡→全屏) / EDDC(全屏→气泡)
        FullExpandToggleIcon.Glyph = isFullExpanded ? "\uEDDC" : "\uEDDB";
    }
}
