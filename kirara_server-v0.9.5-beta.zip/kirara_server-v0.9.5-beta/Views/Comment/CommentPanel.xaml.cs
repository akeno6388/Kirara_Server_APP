using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Kirara_Server_WinUI.ViewModels.Comment;

namespace Kirara_Server_WinUI.Views.Comment;

/// <summary>
/// [评论区功能] 评论面板 UserControl — 评论列表 + 回复嵌套 + 输入区
/// 通过 DataContext 绑定 CommentWindowViewModel
/// </summary>
public sealed partial class CommentPanel : UserControl
{
    /// <summary>
    /// 评论窗口 ViewModel（便捷访问属性，供 x:Bind 使用）
    /// </summary>
    public CommentWindowViewModel ViewModel =>
        (CommentWindowViewModel)DataContext;

    /// <summary>
    /// [评论区功能] 折叠/展开按钮点击事件（由 CommentWindow 订阅处理）
    /// </summary>
    public event Action? CollapseToggleRequested;

    /// <summary>
    /// [评论区功能] 全展开/还原按钮点击事件（由 CommentWindow 订阅处理）
    /// </summary>
    public event Action? FullExpandToggleRequested;

    /// <summary>
    /// [评论区功能] 是否显示「全展开」按钮
    /// 悬浮窗场景显示；页内嵌面板（SchemeHostPage）无全展开概念，宿主置为 false 隐藏
    /// </summary>
    public bool IsFullExpandEnabled { get; set; } = true;

    public CommentPanel()
    {
        InitializeComponent();

        // [发送按钮即时亮起] DataContext 变化时订阅 VM 的 NewCommentInput 变化，
        // 用于发送成功后（VM 清空输入）同步清空 TextBox（TextBox 不再走 TwoWay 绑定）
        DataContextChanged += OnDataContextChanged;
    }

    /// <summary>
    /// DataContext 变化 — 订阅/退订 ViewModel 的 NewCommentInput 变化
    /// </summary>
    private void OnDataContextChanged(FrameworkElement sender, DataContextChangedEventArgs args)
    {
        if (_vm != null)
            _vm.PropertyChanged -= OnViewModelPropertyChanged;

        _vm = DataContext as CommentWindowViewModel;
        if (_vm != null)
            _vm.PropertyChanged += OnViewModelPropertyChanged;
    }

    private CommentWindowViewModel? _vm;

    /// <summary>
    /// 监听 ViewModel 输入清空（发送成功后 NewCommentInput = ""）→ 同步清空 TextBox，
    /// 保证「发送按钮灰化」与输入框内容一致
    /// </summary>
    private void OnViewModelPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(CommentWindowViewModel.NewCommentInput)
            && NewCommentTextBox != null
            && NewCommentTextBox.Text != _vm?.NewCommentInput)
        {
            NewCommentTextBox.Text = _vm?.NewCommentInput ?? string.Empty;
        }
    }

    /// <summary>
    /// [评论区功能] 折叠/展开按钮点击 — 触发事件
    /// </summary>
    private void OnCollapseToggleClick(object sender, RoutedEventArgs e)
    {
        CollapseToggleRequested?.Invoke();
    }

    /// <summary>
    /// 新评论输入框文本变化 — 即时同步到 ViewModel。
    /// ⚠️ WinUI 3 的 TextBox.Text TwoWay 绑定默认在失焦时才更新源，
    /// 会导致「输入后按钮不亮、需点击框外才变亮」；改用 TextChanged 中转即时刷新，
    /// 让发送按钮的 CanExecute（输入非空 + 未发送中）实时响应。
    /// </summary>
    private void OnNewCommentTextChanged(object sender, TextChangedEventArgs e)
    {
        if (DataContext is CommentWindowViewModel vm)
            vm.NewCommentInput = NewCommentTextBox.Text;
    }

    /// <summary>
    /// 回复输入框文本变化 — 即时同步到所属评论项的 ViewModel。
    /// 回复框位于 DataTemplate 内（x:Bind 默认失焦更新源），TextChanged 即时同步
    /// 让回复发送按钮的 CanExecute（输入非空 + 未发送中）实时响应；
    /// x:Bind 保留用于 VM→UI 回写（打开回复框/发送成功后清空输入框）。
    /// </summary>
    private void OnReplyTextChanged(object sender, TextChangedEventArgs e)
    {
        if (sender is TextBox tb && tb.DataContext is CommentItemViewModel vm)
            vm.ReplyInput = tb.Text;
    }

    /// <summary>
    /// [评论区功能] 全展开/还原按钮点击 — 触发事件
    /// </summary>
    private void OnFullExpandToggleClick(object sender, RoutedEventArgs e)
    {
        FullExpandToggleRequested?.Invoke();
    }

    /// <summary>
    /// [评论区功能] 设置三态视觉状态
    /// Collapsed：完全隐藏标题信息/内容区/全展开按钮，仅保留折叠按钮
    ///           （按钮拉伸填满窗口，图标为展开箭头）
    /// Expanded / FullExpanded：恢复完整标题栏（右侧 全展开+折叠 按钮组）、评论列表与输入区
    /// </summary>
    public void SetPanelState(CommentPanelState state)
    {
        if (state == CommentPanelState.Collapsed)
        {
            // 折叠：仅留展开按钮
            TitleInfoArea.Visibility = Visibility.Collapsed;
            CommentListArea.Visibility = Visibility.Collapsed;
            InputArea.Visibility = Visibility.Collapsed;
            TitleActionArea.HorizontalAlignment = HorizontalAlignment.Stretch;
            TitleActionArea.VerticalAlignment = VerticalAlignment.Stretch;
            FullExpandToggleButton.Visibility = Visibility.Collapsed;
            CollapseToggleButton.HorizontalAlignment = HorizontalAlignment.Stretch;
            CollapseToggleButton.VerticalAlignment = VerticalAlignment.Stretch;
            TitleBarBorder.Padding = new Thickness(0);
            TitleBarBorder.BorderThickness = new Thickness(0);
            CollapseToggleIcon.Glyph = "\uEDDA"; // [评论区功能] EDDA(缩成钮态)（与分享区一致）
        }
        else
        {
            // 展开/全展开：恢复完整面板
            TitleInfoArea.Visibility = Visibility.Visible;
            CommentListArea.Visibility = Visibility.Visible;
            InputArea.Visibility = Visibility.Visible;
            TitleActionArea.HorizontalAlignment = HorizontalAlignment.Right;
            TitleActionArea.VerticalAlignment = VerticalAlignment.Center;
            FullExpandToggleButton.Visibility = IsFullExpandEnabled ? Visibility.Visible : Visibility.Collapsed;
            CollapseToggleButton.HorizontalAlignment = HorizontalAlignment.Right;
            CollapseToggleButton.VerticalAlignment = VerticalAlignment.Center;
            TitleBarBorder.Padding = new Thickness(16, 0, 12, 0);
            TitleBarBorder.BorderThickness = new Thickness(0, 0, 0, 1);
            CollapseToggleIcon.Glyph = "\uEDDA"; // [评论区功能] EDDA(缩成钮态)（与分享区一致）
            // 全展开按钮图标（与分享区一致）：气泡态 EDDB（点击进入全屏）/ 全屏态 EDDC（点击还原气泡）
            FullExpandToggleIcon.Glyph = state == CommentPanelState.FullExpanded ? "\uEDDC" : "\uEDDB";
        }
    }
}
