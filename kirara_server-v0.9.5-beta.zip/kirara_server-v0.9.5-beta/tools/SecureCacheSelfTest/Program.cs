using System.Security.Cryptography;
using Kirara_Server_WinUI.Services;

namespace SecureCacheSelfTest;

/// <summary>
/// SecureCacheService 加密缓存自测程序（独立控制台，链接主项目真实源码）。
///
/// ## 覆盖场景
/// 方案A（全量加密合并）：
///   1. 正常加密写入 → 解密成功，内容/ETag/Version 往返一致
///   2. 密文不含明文内容（真实加密）
///   3. 篡改密文任意字节 → 解密失败（GCM 认证）
///   4. 截断文件 → 解密失败
/// 方案B（内容明文 + 加密 meta）：
///   5. 写入 → 完整性校验通过
///   6. 篡改内容 → 校验失败（SHA256 不匹配）
///   7. 篡改 meta → 校验失败（GCM 认证）
///   8. 缺失 meta → 校验失败
/// 旧明文兼容：
///   9. 旧明文格式文件 → 解密失败 → 视为无缓存重新下载
/// 临时明文：
///   10. 解密到临时文件成功 / 篡改后返回 null / 清理生效
///
/// ## 运行
///   dotnet run --project tools/SecureCacheSelfTest -c Debug -p:Platform=x64
/// （注意：会清理 %APPDATA%/Kirara/tmp/ 目录，运行前请关闭 Kirara_Server 应用）
/// </summary>
internal static class Program
{
    private static int _passed;
    private static int _failed;

    private static void Assert(bool condition, string name)
    {
        if (condition)
        {
            _passed++;
            Console.WriteLine($"  ✅ {name}");
        }
        else
        {
            _failed++;
            Console.WriteLine($"  ❌ {name}");
        }
    }

    private static async Task<int> Main()
    {
        Console.WriteLine("=============================================");
        Console.WriteLine("  SecureCacheService 加密缓存自测");
        Console.WriteLine("=============================================");
        Console.WriteLine();

        var crypto = new CryptoService();
        var secureCache = new SecureCacheService(crypto);

        // 使用独立测试目录，避免影响真实缓存
        var testDir = Path.Combine(Path.GetTempPath(), "kirara_securecache_test_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(testDir);

        try
        {
            TestPlanA(secureCache, testDir);
            TestPlanB(secureCache, testDir);
            TestLegacyPlaintext(secureCache, testDir);
            await TestTempFilesAsync(secureCache, testDir);
        }
        finally
        {
            try { Directory.Delete(testDir, true); } catch { }
        }

        Console.WriteLine("=============================================");
        Console.WriteLine($"  结果: {_passed} 通过, {_failed} 失败");
        Console.WriteLine("=============================================");
        return _failed == 0 ? 0 : 1;
    }

    // ================================================================
    //  方案A：全量加密合并
    // ================================================================

    private static void TestPlanA(SecureCacheService cache, string dir)
    {
        Console.WriteLine("--- 方案A：全量加密合并 ---");
        var path = Path.Combine(dir, "sample.enc");
        var content = "Hello Secure Cache 你好 🎉"u8.ToArray();
        const string etag = "\"d41d8cd98f00b204e9800998ecf8427e\"";
        const int version = 3;

        // 1. 正常加密写入
        cache.SaveEnvelope(path, content, etag, version);
        Assert(File.Exists(path), "加密文件已创建 (.enc)");

        // 2. 密文不包含明文内容
        var raw = File.ReadAllBytes(path);
        var rawStr = System.Text.Encoding.UTF8.GetString(raw);
        Assert(!rawStr.Contains("Hello"), "密文中不包含明文内容（真实加密）");

        // 3. 正常解密读取
        var ok = cache.TryReadEnvelope(path, out var decrypted, out var readEtag, out var readVersion);
        Assert(ok, "解密成功");
        Assert(decrypted.SequenceEqual(content), "解密内容与原始一致");
        Assert(readEtag == etag, "ETag 往返一致");
        Assert(readVersion == version, "Version 往返一致");

        // 4. 篡改密文 → 解密失败
        var tampered = raw.ToArray();
        tampered[tampered.Length / 2] ^= 0xFF;
        File.WriteAllBytes(path, tampered);
        ok = cache.TryReadEnvelope(path, out _, out _, out _);
        Assert(!ok, "篡改密文 → 解密失败（返回 false）");

        // 5. 恢复后解密成功
        cache.SaveEnvelope(path, content, etag, version);
        ok = cache.TryReadEnvelope(path, out var restored, out _, out _);
        Assert(ok && restored.SequenceEqual(content), "重新写入后解密恢复成功");

        // 6. 截断文件 → 解密失败
        File.WriteAllBytes(path, raw.Take(20).ToArray());
        ok = cache.TryReadEnvelope(path, out _, out _, out _);
        Assert(!ok, "截断文件 → 解密失败");

        // 7. 空 ETag / 零 Version 也正常
        var noMetaPath = Path.Combine(dir, "no_meta.enc");
        cache.SaveEnvelope(noMetaPath, content);
        ok = cache.TryReadEnvelope(noMetaPath, out var noMetaContent, out var emptyEtag, out var zeroVersion);
        Assert(ok && noMetaContent.SequenceEqual(content), "无 ETag/Version 写入解密成功");
        Assert(emptyEtag == string.Empty && zeroVersion == 0, "缺省 ETag/Version 返回空/0");

        Console.WriteLine();
    }

    // ================================================================
    //  方案B：内容明文 + 加密 meta
    // ================================================================

    private static void TestPlanB(SecureCacheService cache, string dir)
    {
        Console.WriteLine("--- 方案B：内容明文 + 加密 meta ---");
        var contentPath = Path.Combine(dir, "card_v1_media.png");
        var content = RandomNumberGenerator.GetBytes(64 * 1024); // 64KB 模拟媒体
        const string etag = "etag-123";
        const int version = 1;

        // 1. 写入
        cache.SaveWithMeta(contentPath, content, etag, version);
        Assert(File.Exists(contentPath), "内容文件已创建");
        Assert(File.Exists(SecureCacheService.GetMetaPath(contentPath)), "meta 文件已创建");

        // 2. meta 为加密内容（不含明文字段）
        var metaRaw = File.ReadAllText(SecureCacheService.GetMetaPath(contentPath));
        Assert(!metaRaw.Contains("sha256") && !metaRaw.Contains("etag-123"),
            "meta 为加密内容（不含明文哈希/ETag）");

        // 3. 完整性校验通过
        Assert(cache.VerifyWithMeta(contentPath), "完整性校验通过");

        // 4. 篡改内容 → 校验失败（SHA256 不匹配）
        var tamperedContent = content.ToArray();
        tamperedContent[1234] ^= 0xFF;
        File.WriteAllBytes(contentPath, tamperedContent);
        Assert(!cache.VerifyWithMeta(contentPath), "篡改内容 → 校验失败");
        cache.SaveWithMeta(contentPath, content, etag, version); // 恢复

        // 5. 篡改 meta → 校验失败（GCM 认证）
        var metaBytes = File.ReadAllBytes(SecureCacheService.GetMetaPath(contentPath));
        var tamperedMeta = metaBytes.ToArray();
        tamperedMeta[tamperedMeta.Length / 2] ^= 0xFF;
        File.WriteAllBytes(SecureCacheService.GetMetaPath(contentPath), tamperedMeta);
        Assert(!cache.VerifyWithMeta(contentPath), "篡改 meta → 校验失败");
        cache.SaveWithMeta(contentPath, content, etag, version); // 恢复

        // 6. 删除 meta → 校验失败
        File.Delete(SecureCacheService.GetMetaPath(contentPath));
        Assert(!cache.VerifyWithMeta(contentPath), "缺失 meta → 校验失败");

        // 7. 删除内容 → 校验失败
        cache.SaveWithMeta(contentPath, content, etag, version);
        File.Delete(contentPath);
        Assert(!cache.VerifyWithMeta(contentPath), "缺失内容 → 校验失败");

        Console.WriteLine();
    }

    // ================================================================
    //  旧明文格式兼容
    // ================================================================

    private static void TestLegacyPlaintext(SecureCacheService cache, string dir)
    {
        Console.WriteLine("--- 旧明文格式兼容 ---");

        // 旧 .meta/.txt 等明文文件作为密文读取必然失败
        var legacyPath = Path.Combine(dir, "legacy.enc");
        File.WriteAllText(legacyPath, "{\"etag\":\"abc\",\"contentBase64\":\"aGVsbG8=\"}");
        var ok = cache.TryReadEnvelope(legacyPath, out _, out _, out _);
        Assert(!ok, "旧明文文件（无加密）→ 解密失败 → 视为无缓存重新下载");

        // 旧 templates.json 明文
        var legacyJsonPath = Path.Combine(dir, "templates.json");
        File.WriteAllText(legacyJsonPath, "[{\"id\":\"abc\"}]");
        ok = cache.TryReadEnvelope(legacyJsonPath, out _, out _, out _);
        Assert(!ok, "旧 templates.json 明文 → 解密失败");

        // 空文件
        var emptyPath = Path.Combine(dir, "empty.enc");
        File.WriteAllText(emptyPath, "");
        ok = cache.TryReadEnvelope(emptyPath, out _, out _, out _);
        Assert(!ok, "空文件 → 解密失败");

        Console.WriteLine();
    }

    // ================================================================
    //  临时明文文件
    // ================================================================

    private static async Task TestTempFilesAsync(SecureCacheService cache, string dir)
    {
        Console.WriteLine("--- 临时明文文件 ---");
        var encPath = Path.Combine(dir, "avatar.enc");
        var content = "AVATAR_DATA"u8.ToArray();
        cache.SaveEnvelope(encPath, content);

        // 1. 解密到临时明文文件
        var tempPath = cache.DecryptToTempFile(encPath, "self_test_avatar.png");
        Assert(tempPath != null && File.Exists(tempPath), "解密到临时明文文件成功");
        if (tempPath != null)
        {
            var readBack = await File.ReadAllBytesAsync(tempPath);
            Assert(readBack.SequenceEqual(content), "临时文件内容与原始一致");
        }

        // 2. 篡改加密文件后无法解密到临时文件
        var raw = File.ReadAllBytes(encPath);
        raw[0] ^= 0xFF;
        File.WriteAllBytes(encPath, raw);
        var badTemp = cache.DecryptToTempFile(encPath, "self_test_avatar2.png");
        Assert(badTemp == null, "篡改后 DecryptToTempFile 返回 null");

        // 3. WriteTempFile 直接写入
        var directPath = cache.WriteTempFile("self_test_direct.bin", content);
        Assert(File.Exists(directPath), "WriteTempFile 直接写入成功");
        var directRead = await File.ReadAllBytesAsync(directPath);
        Assert(directRead.SequenceEqual(content), "WriteTempFile 内容一致");

        // 4. CleanupTempDirectory 清理生效
        // ⚠️ 会清理 %APPDATA%/Kirara/tmp/ 下所有文件（与 App 启动时行为一致），运行前请关闭应用
        SecureCacheService.CleanupTempDirectory();
        Assert(!File.Exists(tempPath!), "CleanupTempDirectory 后临时文件已删除");
        Assert(!File.Exists(directPath), "CleanupTempDirectory 后直接写入文件已删除");

        Console.WriteLine();
    }
}
