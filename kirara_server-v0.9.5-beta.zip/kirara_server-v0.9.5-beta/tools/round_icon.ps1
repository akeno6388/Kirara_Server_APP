# ============================================================
# 给 Assets 下所有 .ico 添加高精度圆角（四角透明）
# 用法: powershell -ExecutionPolicy Bypass -File tools\round_icon.ps1
#
# 抗锯齿原理（超采样 Supersampling）:
#   Graphics.SetClip() 的裁剪边界是硬边，不受 SmoothingMode.AntiAlias 影响，
#   直接裁剪会产生严重锯齿。因此先在 ScaleFactor 倍画布上裁剪圆角，
#   再用 HighQualityBicubic 缩回原始尺寸 —— 圆角边缘像素由 NxN 区域平均采样，
#   自然产生平滑的半透明过渡，彻底消除锯齿。
# ============================================================
param(
    [string]$AssetDir = "D:\works\kirara_server\Assets",
    [int]$ScaleFactor = 4,        # 超采样倍率（4 = 每边 4 倍采样，推荐）
    [double]$RadiusRatio = 0.22,  # 圆角半径占尺寸比例（Windows 11 风格）
    [int]$MinRadius = 4           # 圆角半径下限（px）
)
Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = "Stop"

# ---------- 工具函数: 从 ICO 提取各尺寸 PNG ----------
function Get-IcoSizes($bytes) {
    $count = [BitConverter]::ToUInt16($bytes, 4)
    $sizes = New-Object System.Collections.Generic.List[int]
    $pngList = New-Object System.Collections.Generic.List[byte[]]
    for ($i = 0; $i -lt $count; $i++) {
        $entry = 6 + ($i * 16)
        $w = $bytes[$entry]; $h = $bytes[$entry + 1]
        $size = if ($w -eq 0) { 256 } else { $w }
        $dataLen = [BitConverter]::ToUInt32($bytes, $entry + 8)
        $offset = [BitConverter]::ToUInt32($bytes, $entry + 12)
        $pngBytes = New-Object byte[] $dataLen
        [System.Array]::Copy($bytes, $offset, $pngBytes, 0, $dataLen)
        $sizes.Add($size)
        $pngList.Add($pngBytes)
    }
    return , @($sizes, $pngList)
}

# ---------- 工具函数: 高精度圆角处理单张 PNG ----------
function Add-RoundedCorner($pngBytes, $size) {
    $ms = New-Object System.IO.MemoryStream(,$pngBytes)
    $bmp = [System.Drawing.Bitmap]::new($ms)

    # 圆角半径：约尺寸的 22%（Windows 11 风格），最小 4px
    $radius = [Math]::Max($MinRadius, [int]($size * $RadiusRatio))
    $canvas = $size * $ScaleFactor            # 超采样画布边长
    $bigRadius = $radius * $ScaleFactor       # 超采样圆角半径

    # 1) 超采样画布（透明背景）
    $canvasBmp = New-Object System.Drawing.Bitmap($canvas, $canvas, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($canvasBmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.Clear([System.Drawing.Color]::Transparent)

    # 2) 圆角路径（超采样坐标）
    $path2 = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = [float]($bigRadius * 2)
    $path2.AddArc(0, 0, $d, $d, 180, 90)
    $path2.AddArc($canvas - $d, 0, $d, $d, 270, 90)
    $path2.AddArc($canvas - $d, $canvas - $d, $d, $d, 0, 90)
    $path2.AddArc(0, $canvas - $d, $d, $d, 90, 90)
    $path2.CloseFigure()

    # 3) 在超采样画布上裁剪并绘制原图（铺满）
    $g.SetClip($path2)
    $g.DrawImage($bmp, 0, 0, $canvas, $canvas)

    # 4) 高质量缩回原始尺寸 —— 边缘像素被 NxN 平均采样，形成平滑过渡
    $newBmp = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g2 = [System.Drawing.Graphics]::FromImage($newBmp)
    $g2.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g2.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g2.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
    $g2.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g2.Clear([System.Drawing.Color]::Transparent)
    $g2.DrawImage($canvasBmp, 0, 0, $size, $size)

    # 5) 保存为 PNG
    $outMs = New-Object System.IO.MemoryStream
    $newBmp.Save($outMs, [System.Drawing.Imaging.ImageFormat]::Png)
    $result = $outMs.ToArray()

    $g2.Dispose(); $g.Dispose()
    $newBmp.Dispose(); $canvasBmp.Dispose(); $bmp.Dispose(); $ms.Dispose(); $outMs.Dispose()
    $path2.Dispose()
    return $result
}

# ---------- 工具函数: 打包 ICO ----------
function New-IcoBytes($sizes, $pngList) {
    $newCount = $pngList.Count
    $headerSize = 6 + (16 * $newCount)
    $icoMs = New-Object System.IO.MemoryStream
    $bw = New-Object System.IO.BinaryWriter($icoMs)
    $bw.Write([UInt16]0); $bw.Write([UInt16]1); $bw.Write([UInt16]$newCount)
    $offset = $headerSize
    for ($i = 0; $i -lt $newCount; $i++) {
        $size = $sizes[$i]
        $dataLen = $pngList[$i].Length
        $w = if ($size -ge 256) { 0 } else { $size }
        $bw.Write([Byte]$w); $bw.Write([Byte]$w)
        $bw.Write([Byte]0); $bw.Write([Byte]0)
        # PNG 编码的 ICO entry: planes=1, bitcount=32
        $bw.Write([UInt16]1); $bw.Write([UInt16]32)
        $bw.Write([UInt32]$dataLen); $bw.Write([UInt32]$offset)
        $offset += $dataLen
    }
    foreach ($img in $pngList) { $bw.Write($img) }
    $bw.Flush()
    $result = $icoMs.ToArray()
    $bw.Dispose(); $icoMs.Dispose()
    return $result
}

# ---------- 主流程 ----------
# 备份原始文件（安全第一）
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDir = Join-Path $AssetDir "_ico_backup_$stamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

$icoFiles = Get-ChildItem -Path (Join-Path $AssetDir "*.ico")
Write-Host "Found $($icoFiles.Count) ico files, ScaleFactor=$ScaleFactor, RadiusRatio=$RadiusRatio"
Write-Host "Backup -> $backupDir"
Write-Host ""

foreach ($file in $icoFiles) {
    # 备份
    Copy-Item $file.FullName (Join-Path $backupDir $file.Name)

    $bytes = [System.IO.File]::ReadAllBytes($file.FullName)
    $info = Get-IcoSizes $bytes
    $sizes = $info[0]; $pngList = $info[1]

    $roundedList = New-Object System.Collections.Generic.List[byte[]]
    for ($n = 0; $n -lt $pngList.Count; $n++) {
        $size = $sizes[$n]
        $rounded = Add-RoundedCorner $pngList[$n] $size
        $roundedList.Add($rounded)
        $radius = [Math]::Max($MinRadius, [int]($size * $RadiusRatio))
        Write-Host ("  {0} {1}x{1}: radius={2}px (supersampled x{3})" -f $file.Name, $size, $radius, $ScaleFactor)
    }

    $newIco = New-IcoBytes $sizes $roundedList
    [System.IO.File]::WriteAllBytes($file.FullName, $newIco)
    Write-Host ("  -> saved {0} ({1:N0} bytes)" -f $file.Name, $newIco.Length)
    Write-Host ""
}

Write-Host "Done. All icons rounded with anti-aliased corners."