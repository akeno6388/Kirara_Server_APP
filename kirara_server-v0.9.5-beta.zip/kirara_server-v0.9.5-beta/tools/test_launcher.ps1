# ============================================================
# Launcher single-instance E2E test
# Verifies:
#   1. First launch of launcher starts exactly one Core process
#   2. Second launch of launcher does NOT spawn another Core
#   3. Launcher process exits immediately (<1s, no residue)
#   4. Restore signal: second launch while Core running wakes window
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File tools\test_launcher.ps1
# ============================================================

$ErrorActionPreference = "Stop"
$bin = "D:\works\kirara_server\bin\x64\Debug\net10.0-windows10.0.19041.0\win-x64"
$launcher = Join-Path $bin "KiraraServerAPP.exe"
$coreName = "KiraraServerAPP.Core"
$launcherName = "KiraraServerAPP"

if (-not (Test-Path $launcher)) { throw "Launcher not found: $launcher" }
if (-not (Test-Path (Join-Path $bin "KiraraServerAPP.Core.exe"))) { throw "Core exe not found in $bin" }

Write-Host "=== Launcher E2E Test ===" -ForegroundColor Cyan
Write-Host "Launcher: $launcher"

# ---- Cleanup any existing instances ----
Write-Host "`n[1/4] Cleaning existing processes..." -ForegroundColor Yellow
# taskkill exits non-zero when no matching process; tolerate that
$oldEAP = $ErrorActionPreference
$ErrorActionPreference = "Continue"
taskkill /F /IM "$coreName.exe" 2>&1 | Out-Null
taskkill /F /IM "$launcherName.exe" 2>&1 | Out-Null
$ErrorActionPreference = $oldEAP
Start-Sleep -Milliseconds 500

function Get-ProcCount([string]$name) {
    return @(Get-Process -Name $name -ErrorAction SilentlyContinue).Count
}

# ---- Test 1: first launch starts Core ----
Write-Host "`n[2/4] First launch (should start Core)..." -ForegroundColor Yellow
Start-Process $launcher
Start-Sleep -Seconds 4
$coreCount = Get-ProcCount $coreName
Write-Host "Core processes after first launch: $coreCount"
if ($coreCount -ne 1) {
    Write-Host "[FAIL] Expected exactly 1 Core process" -ForegroundColor Red
    exit 1
}
Write-Host "[PASS] First launch started exactly 1 Core" -ForegroundColor Green

# ---- Test 2: second launch does not spawn another Core ----
Write-Host "`n[3/4] Second launch (should NOT spawn Core)..." -ForegroundColor Yellow
Start-Process $launcher
Start-Sleep -Seconds 2
$coreCountAfter = Get-ProcCount $coreName
Write-Host "Core processes after second launch: $coreCountAfter"
if ($coreCountAfter -ne 1) {
    Write-Host "[FAIL] Second launch spawned extra Core!" -ForegroundColor Red
    exit 1
}

# Launcher itself must have exited (transient process)
$launcherCount = Get-ProcCount $launcherName
Write-Host "Launcher processes remaining: $launcherCount"
if ($launcherCount -ne 0) {
    Write-Host "[FAIL] Launcher process did not exit!" -ForegroundColor Red
    exit 1
}
Write-Host "[PASS] Second launch: no extra Core, launcher exited instantly" -ForegroundColor Green

# ---- Test 3: wake signal reachable (window state) ----
Write-Host "`n[4/4] Sending wake signal (window should restore/foreground)..." -ForegroundColor Yellow
Start-Process $launcher
Start-Sleep -Seconds 1
Write-Host "[INFO] Wake signal sent. Check the main window is restored/foreground." -ForegroundColor Green

Write-Host "`n=== ALL TESTS PASSED ===" -ForegroundColor Green

# ---- Cleanup (kill Core to leave clean state) ----
Write-Host "`nCleaning up test instance..." -ForegroundColor Yellow
$ErrorActionPreference = "Continue"
taskkill /F /IM "$coreName.exe" 2>&1 | Out-Null
$ErrorActionPreference = $oldEAP
Write-Host "Done." -ForegroundColor Green
