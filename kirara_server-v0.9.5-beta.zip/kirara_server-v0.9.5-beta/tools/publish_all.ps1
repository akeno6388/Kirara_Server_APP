# ============================================================
# Kirara Server APP - One-click Publish + Package Script
# Usage:
#   powershell -ExecutionPolicy Bypass -File tools\publish_all.ps1
#
# Steps:
#   1. Publish main app (FolderProfile -> bin\Release\publish)
#   2. Publish VPN helper service (-> bin\Release\publish\KiraraVpnHelper)
#   3. Verify publish artifacts (pri / R2R / language dirs)
#   4. Compile Inno Setup installer (-> bin\installer)
#   5. Output final installer path
#
# Logging:
#   - Console: timestamped [HH:mm:ss] progress lines
#   - File:    bin\installer\publish_log_yyyyMMdd_HHmmss.txt (persistent)
# ============================================================

$ErrorActionPreference = "Stop"
$root = "D:\works\kirara_server"
$iscc = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
$pubDir = "$root\bin\Release\publish"
$installerOut = "$root\bin\installer"

$OK = "[OK]"
$FAIL = "[FAIL]"
$WARN = "[WARN]"

# Script start time (for total duration)
$scriptStart = Get-Date

# ============ Logging helpers ============
# Console + file dual logging with timestamp
$logStamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logFile = "$installerOut\publish_log_$logStamp.txt"
if (-not (Test-Path $installerOut)) { New-Item -ItemType Directory -Path $installerOut -Force | Out-Null }
New-Item -ItemType File -Path $logFile -Force | Out-Null

function Write-Log {
    param(
        [string]$Message,
        [ConsoleColor]$Color = "Gray"
    )
    $stamp = Get-Date -Format "HH:mm:ss"
    $line = "[$stamp] $Message"
    Write-Host $line -ForegroundColor $Color
    Add-Content -Path $logFile -Value $line
}

function Write-Step {
    param(
        [int]$Step,
        [int]$Total,
        [string]$Title
    )
    Write-Log "----------------------------------------" "DarkCyan"
    Write-Log "[$Step/$Total] $Title" "Yellow"
    Write-Log "----------------------------------------" "DarkCyan"
}

function Write-Result {
    param(
        [string]$Message,
        [bool]$Success
    )
    if ($Success) { Write-Log "$OK $Message" "Green" }
    else { Write-Log "$FAIL $Message" "Red" }
}

Write-Log "==============================================" "Cyan"
Write-Log "  Kirara Server APP - Publish + Package" "Cyan"
Write-Log "  Start time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" "Cyan"
Write-Log "  Log file: $logFile" "Cyan"
Write-Log "==============================================" "Cyan"

# ============ Step 1: Publish main app ============
Write-Step 1 5 "Publishing main app (FolderProfile)..."
$sw = [System.Diagnostics.Stopwatch]::StartNew()
Push-Location $root
try {
    dotnet publish -c Release -p:Platform=x64
    if ($LASTEXITCODE -ne 0) { throw "Main app publish failed (exit=$LASTEXITCODE)" }
}
finally { Pop-Location }
$sw.Stop()
Write-Result "Main app published in $($sw.Elapsed.TotalSeconds.ToString('F1'))s" $true

# ============ Step 1.5: Compile native launcher ============
Write-Step 2 6 "Compiling native launcher (single-instance)..." 
$sw = [System.Diagnostics.Stopwatch]::StartNew()
try {
    & "$root\launcher\build_launcher.ps1" -OutputDir $pubDir
    if ($LASTEXITCODE -ne 0) { throw "Launcher compile failed (exit=$LASTEXITCODE)" }
}
catch {
    throw "Launcher compile failed: $($_.Exception.Message)"
}
$sw.Stop()
Write-Result "Launcher compiled in $($sw.Elapsed.TotalSeconds.ToString('F1'))s" $true

# ============ Step 2: Publish VPN helper service ============
Write-Step 3 6 "Publishing VPN helper service..."
$sw = [System.Diagnostics.Stopwatch]::StartNew()
Push-Location $root
try {
    dotnet publish "$root\KiraraVpnHelper\KiraraVpnHelper.csproj" -c Release -p:Platform=x64 -r win-x64 --self-contained true -p:PublishTrimmed=false -p:PublishDir="..\bin\Release\publish\KiraraVpnHelper\"
    if ($LASTEXITCODE -ne 0) { throw "Service publish failed (exit=$LASTEXITCODE)" }
}
finally { Pop-Location }
$sw.Stop()
Write-Result "Service published in $($sw.Elapsed.TotalSeconds.ToString('F1'))s" $true

# ============ Step 3: Verify publish artifacts ============
Write-Step 4 6 "Verifying publish artifacts..."

# 清理改名前的旧产物文件残留（v0.9.2- 的 KiraraServerAPP.pri/.dll 等垃圾文件）。
# ⚠️ 过滤条件必须精确：
#   - 保留 KiraraServerAPP.exe（刚编译的原生启动器）
#   - 保留 KiraraServerAPP.Core.*（当前版本全部新产物）
#   - 只删旧名文件（不带 .Core. 的）
#   - 必须 -File：KiraraServerAPP.exe.WebView2 是 WebView2 数据目录，
#     不能匹配（Remove-Item 删非空目录会弹确认提示卡住脚本）
Get-ChildItem $pubDir -Filter "KiraraServerAPP.*" -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -notlike "KiraraServerAPP.Core.*" -and $_.Name -ne "KiraraServerAPP.exe" } |
    Remove-Item -Force -ErrorAction SilentlyContinue

# 清理旧名遗留的 WebView2 用户数据目录（KiraraServerAPP.exe.WebView2）：
# 改名后新 Core 使用 KiraraServerAPP.Core.exe.WebView2，旧目录是缓存残留，
# 不清理会被 .iss 的 recursesubdirs 打包进安装包（膨胀体积 + 泄漏 Cookie/登录态）
Get-ChildItem $pubDir -Filter "KiraraServerAPP.exe.WebView2" -Directory -ErrorAction SilentlyContinue |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

$checks = @(
    @{ Name = "Launcher exe (native)";  Path = "$pubDir\KiraraServerAPP.exe" },
    @{ Name = "Main app exe (Core)";    Path = "$pubDir\KiraraServerAPP.Core.exe" },
    @{ Name = "Main app pri";           Path = "$pubDir\KiraraServerAPP.Core.pri" },
    @{ Name = "Service exe";            Path = "$pubDir\KiraraVpnHelper\KiraraVpnHelper.exe" },
    @{ Name = "Service dll";            Path = "$pubDir\KiraraVpnHelper\KiraraVpnHelper.dll" }
)
$allOk = $true
foreach ($c in $checks) {
    $ok = Test-Path $c.Path
    if (-not $ok) { $allOk = $false }
    Write-Result "$($c.Name): $($c.Path)" $ok
}
if (-not $allOk) { throw "Publish artifacts incomplete!" }

# R2R check (should be 0)
$niCount = (Get-ChildItem $pubDir -Recurse -Filter "*.ni.dll" -ErrorAction SilentlyContinue).Count
$niOk = ($niCount -eq 0)
Write-Result "R2R files: $niCount (should be 0)" $niOk
if (-not $niOk) { throw "R2R files found, publish config error!" }

# Language dir check (should be only zh-CN)
$langDirs = Get-ChildItem $pubDir -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match "^[a-z]{2,3}(-[A-Za-z0-9]+){1,2}$" }
$langOk = ($langDirs.Count -eq 1 -and $langDirs[0].Name -eq "zh-CN")
if ($langOk) { Write-Result "Language dirs: $($langDirs.Name -join ', ')" $true }
else { Write-Log "$WARN Language dirs: $($langDirs.Name -join ', ') (should be zh-CN)" "DarkYellow" }

# Total size
$size = (Get-ChildItem $pubDir -Recurse -File | Measure-Object Length -Sum).Sum / 1MB
Write-Log "  Publish total size: $([Math]::Round($size,1)) MB" "Gray"
Write-Result "Artifacts verified" $true

# ============ Step 4: Compile installer ============
Write-Step 5 6 "Compiling Inno Setup installer..."
if (-not (Test-Path $iscc)) { throw "ISCC.exe not found: $iscc" }
$sw = [System.Diagnostics.Stopwatch]::StartNew()
& $iscc "$root\installer\Kirara_Server_Setup.iss"
if ($LASTEXITCODE -ne 0) { throw "Installer compile failed (exit=$LASTEXITCODE)" }
$sw.Stop()
Write-Result "Installer compiled in $($sw.Elapsed.TotalSeconds.ToString('F1'))s" $true

# ============ Step 5: Output result ============
Write-Step 6 6 "Final result"
$setup = Get-ChildItem "$installerOut\Kirara_Server_Setup_x64.exe" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($setup) {
    $setupSize = $setup.Length / 1MB
    Write-Log "Final installer: $($setup.FullName)" "Green"
    Write-Log "Size: $([Math]::Round($setupSize,1)) MB" "Green"
    Write-Log "Time: $($setup.LastWriteTime)" "Green"
} else {
    Write-Log "$WARN Installer output not found!" "DarkYellow"
}

Write-Log ""
Write-Log "==============================================" "Cyan"
Write-Log "  All done! Total: $((Get-Date) - $scriptStart)" "Cyan"
Write-Log "  Log saved to: $logFile" "Cyan"
Write-Log "==============================================" "Cyan"
