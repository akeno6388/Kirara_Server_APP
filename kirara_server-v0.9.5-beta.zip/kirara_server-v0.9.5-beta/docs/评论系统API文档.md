# Kirara 评论系统 API 文档

> **版本**：v1.3  
> **更新日期**：2026-08-07  
> **适用 API 地址**：`https://api.akeno6388.online:1010`（生产） / `http://localhost:5340`（开发）  
> **适用客户端**：Kirara_Server-WinUI（WinUI 3 / .NET 10）

---

## 更新记录

| 版本 | 日期 | 变更内容 |
|------|------|----------|
| v1.3 | 2026-08-07 | Comment/Reply 新增 `ContentTitle`（视频标题）字段；创建评论请求体支持可选 `contentTitle`；创建回复自动从父评论继承标题；新增互动通知（回复/点赞自动通知内容作者） |
| v1.2 | 2026-08-01 | 所有端点统一要求登录认证（原 GET 列表/单条查询不再公开）；新增按资源键全量查询端点 `GET /api/comments/by-resource` |
| v1.1 | 2026-07-27 | `authorAvatarUrl` 改为返回原始对象键，客户端自行拼接 CDN 域名 |
| v1.0 | 2026-07-26 | 初始版本，覆盖评论/回复/点赞完整 API |

---

## 一、API 通用规范

### 1.1 请求规范

| 项目 | 规范 |
|------|------|
| **Base URL** | `https://api.akeno6388.online:1010`（生产） / `http://localhost:5340`（开发） |
| **Content-Type** | `application/json`（读写请求） / `multipart/form-data`（文件上传） |
| **字符编码** | UTF-8 |
| **认证方式** | `Authorization: Bearer {accessToken}`（需要登录的端点） |

### 1.2 统一响应格式

所有端点返回统一格式 `ApiResponse<T>`：

```json
// ✅ 成功响应
{
  "success": true,
  "data": { ... },
  "timestamp": "2026-07-26T10:00:00Z"
}

// ❌ 错误响应
{
  "success": false,
  "data": null,
  "timestamp": "2026-07-26T10:00:00Z",
  "error": {
    "code": "ERROR_CODE",
    "message": "人类可读的错误描述"
  }
}
```

### 1.3 错误码对照表

| Error Code | HTTP 状态码 | 说明 | 处理建议 |
|------------|-------------|------|----------|
| `NOT_AUTHORIZED` | 401 | 未提供 Token 或 Token 无效 | 引导用户登录 |
| `FORBIDDEN` | 403 | 无权限执行此操作 | 提示仅作者可操作 |
| `NOT_FOUND` | 404 | 评论/回复不存在 | 刷新列表 |
| `VALIDATION_ERROR` | 400 | 参数校验失败 | 根据 message 提示用户 |
| `INVALID_CREDENTIALS` | 401 | 用户名或密码错误 | 登录时使用 |
| `USERNAME_TAKEN` | 409 | 用户名已被注册 | 注册时使用 |
| `INTERNAL_ERROR` | 500 | 服务器内部错误 | 联系管理员 |

### 1.4 分页规范

列表查询统一使用以下查询参数：

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `page` | int | 1 | 页码，从 1 开始 |
| `pageSize` | int | 20 | 每页条数，最大 100 |

分页响应结构：

```json
{
  "success": true,
  "data": {
    "items": [ ... ],
    "page": 1,
    "pageSize": 20,
    "totalCount": 42,
    "totalPages": 3
  }
}
```

### 1.5 认证流程概述

```
客户端                               服务端
  │                                     │
  │  POST /api/auth/login               │
  │  { username, password }             │
  │────────────────────────────────────>│
  │  { accessToken, refreshToken, user }│
  │<────────────────────────────────────│
  │                                     │
  │  (后续请求)                         │
  │  Authorization: Bearer {accessToken}│
  │────────────────────────────────────>│
  │  (accessToken 过期)                 │
  │  POST /api/auth/refresh             │
  │  { refreshToken }                   │
  │────────────────────────────────────>│
  │  { accessToken, refreshToken }      │
  │<────────────────────────────────────│
```

**客户端 Token 管理策略**：

1. 登录后存储 `accessToken` 和 `refreshToken`
2. 每次请求使用 `accessToken`，在 `Authorization` 头携带
3. 收到 `401` 时自动调用 `/api/auth/refresh` 续期
4. 刷新失败（refreshToken 过期/吊销）→ 引导用户重新登录

---

## 二、评论系统数据模型

### 2.1 核心实体关系

```
┌──────────┐     ┌──────────────┐     ┌──────────────┐
│   User   │1──N│   Comment    │1──N│    Reply     │
│  (作者)  │     │              │     │              │
└──────────┘     ├──────────────┤     ├──────────────┤
                 │ Id (UUID PK) │     │ Id (UUID PK) │
                 │ ResourceKey  │     │ CommentId FK │
                 │ SchemeId     │     │ UserId    FK │
                 │ UserId    FK │     │ Content      │
                 │ Content      │     │ LikeCount    │
                 │ AuthorName   │     │ CreatedAt    │
                 │ LikeCount    │     └──────┬───────┘
                 │ CreatedAt    │            │
                 │ UpdatedAt    │            │1:N
                 └──────┬───────┘     ┌──────┴───────┐
                        │1:N          │  ReplyLike   │
                 ┌──────┴───────┐     ├──────────────┤
                 │ CommentLike  │     │ UserId + ReplyId (联合PK)
                 ├──────────────┤     │ CreatedAt    │
                 │ UserId + CommentId (联合PK)    │
                 │ CreatedAt    │     └──────────────┘
                 └──────────────┘
```

### 2.2 Comment（评论）

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | UUID | 评论唯一标识 |
| `resourceKey` | string | 资源标识，格式 `{schemeName}://{instanceId:N}{path}`，必须包含 `://` |
| `schemeId` | UUID | 所属方案 ID |
| `userId` | UUID | 作者用户 ID |
| `content` | string | 评论内容，最长 5000 字符 |
| `contentTitle` | string? | 视频标题（创建评论时可选传入，用于互动通知文案） |
| `authorName` | string | 作者显示名称（服务端从 JWT 获取） |
| `authorAvatarUrl` | string? | 作者头像对象键（客户端自行拼接 CDN 域名展示） |
| `likeCount` | int | 点赞数（冗余字段，由点赞操作自动更新） |
| `isLikedByUser` | bool | 当前登录用户是否点赞（未登录时为 false） |
| `replyCount` | int | 回复总数 |
| `replies` | Reply[]? | 回复列表（列表查询时嵌入前 3 条，详情查询时返回全部） |
| `createdAt` | datetime | 创建时间 (UTC) |
| `updatedAt` | datetime? | 最后更新时间 (UTC) |

### 2.3 Reply（回复）

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | UUID | 回复唯一标识 |
| `commentId` | UUID | 所属评论 ID |
| `userId` | UUID | 作者用户 ID |
| `content` | string | 回复内容，最长 2000 字符 |
| `contentTitle` | string? | 视频标题（创建回复时自动从父评论继承） |
| `authorName` | string | 作者显示名称 |
| `authorAvatarUrl` | string? | 作者头像对象键（客户端自行拼接 CDN 域名展示） |
| `likeCount` | int | 点赞数 |
| `isLikedByUser` | bool | 当前用户是否点赞 |
| `createdAt` | datetime | 创建时间 (UTC) |

---

## 三、评论 API 端点

### 3.1 获取评论列表（分页）

获取指定资源下的评论列表，每条评论嵌入前 3 条回复。

```
GET /api/comments
```

#### 请求参数（Query）

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `resourceKey` | string | ✅ | — | 资源标识，格式如 `"media://abc123"` |
| `schemeId` | UUID | ✅ | — | 方案 ID |
| `page` | int | ❌ | 1 | 页码 |
| `pageSize` | int | ❌ | 20 | 每页条数（最大 100） |

#### 是否需要认证

✅ 需要，所有端点均要求携带 `Authorization: Bearer {accessToken}`。

响应中的 `isLikedByUser` 字段会根据当前请求的 Token 正确计算。

#### 请求示例

```http
GET /api/comments?resourceKey=media://abc123&schemeId=a1000001-0000-0000-0000-000000000001&page=1&pageSize=20
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

#### 响应示例（200 OK）

```json
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "dc4c336c-c3a6-496c-a42f-f5420689dd87",
        "resourceKey": "media://abc123",
        "schemeId": "a1000001-0000-0000-0000-000000000001",
        "userId": "4d032410-7487-4528-b11e-2b77b5f5964b",
        "content": "非常好用的服务！",
        "authorName": "测试用户2",
        "authorAvatarUrl": null,
        "likeCount": 3,
        "isLikedByUser": true,
        "replyCount": 2,
        "replies": [
          {
            "id": "e5f6a7b8-...",
            "commentId": "dc4c336c-c3a6-...",
            "userId": "4d032410-...",
            "content": "同意！非常好用 👍",
            "authorName": "测试用户2",
            "authorAvatarUrl": null,
            "likeCount": 1,
            "isLikedByUser": true,
            "createdAt": "2026-07-25T13:00:00Z"
          }
        ],
        "createdAt": "2026-07-25T12:57:59Z",
        "updatedAt": null
      }
    ],
    "page": 1,
    "pageSize": 20,
    "totalCount": 1,
    "totalPages": 1
  }
}
```

#### 客户端对接说明

| 客户端方法 | 对应 API |
|-----------|----------|
| `CommentService.GetCommentsAsync(resourceKey, schemeId)` | `GET /api/comments?resourceKey=&schemeId=` |

---

### 3.2 获取单条评论（含全部回复）

```
GET /api/comments/{id}
```

#### 路径参数

| 参数 | 类型 | 说明 |
|------|------|------|
| `id` | UUID | 评论 ID |

#### 是否需要认证

✅ 需要，携带 `Authorization: Bearer {accessToken}`。

#### 响应示例（200 OK）

返回结构与列表中的单条评论一致，区别在于 `replies` 字段包含该评论的 **全部回复**（而非仅前 3 条）。

#### 响应示例（404 Not Found）

```json
{
  "success": false,
  "error": {
    "code": "NOT_FOUND",
    "message": "评论不存在"
  }
}
```

---

### 3.3 创建评论

```
POST /api/comments
```

#### 请求头

| 头 | 值 |
|----|-----|
| `Authorization` | `Bearer {accessToken}` |
| `Content-Type` | `application/json` |

#### 请求体

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `resourceKey` | string | ✅ | 资源标识，必须包含 `://` 分隔符 |
| `schemeId` | UUID | ✅ | 方案 ID |
| `content` | string | ✅ | 评论内容，1~5000 字符 |
| `contentTitle` | string | ❌ | 视频标题，最长 500，用于互动通知文案 |

#### 请求示例

```json
{
  "resourceKey": "media://abc123",
  "schemeId": "a1000001-0000-0000-0000-000000000001",
  "content": "非常好用的服务！",
  "contentTitle": "测试视频标题"
}
```

#### 响应示例（201 Created）

```json
{
  "success": true,
  "data": {
    "id": "dc4c336c-c3a6-496c-a42f-f5420689dd87",
    "resourceKey": "media://abc123",
    "schemeId": "a1000001-0000-0000-0000-000000000001",
    "userId": "4d032410-7487-4528-b11e-2b77b5f5964b",
    "content": "非常好用的服务！",
    "authorName": "测试用户2",
    "authorAvatarUrl": null,
    "likeCount": 0,
    "isLikedByUser": false,
    "replyCount": 0,
    "createdAt": "2026-07-25T12:57:59Z"
  }
}
```

> **注意**：`authorName` 由服务端从 JWT Token 中自动解析，**不需要客户端传入**。

#### 错误响应（400 Bad Request — ResourceKey 格式无效）

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "ResourceKey 格式无效，必须包含 :// 分隔符"
  }
}
```

#### 错误响应（400 Bad Request — 必填字段缺失）

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "The Content field is required."
  }
}
```

#### 客户端对接说明

| 客户端方法 | 对应 API |
|-----------|----------|
| `CommentService.AddCommentAsync(resourceKey, schemeId, content)` | `POST /api/comments` |
| 服务端自动设置 `AuthorName` | 从 JWT 解析，客户端不再硬编码为 `"当前用户"` |
| 🆕 新增 `authorAvatarUrl` | 服务端拼接，客户端直接展示 |

> **客户端改造要点**：`CommentItem.AuthorName` 不再需要硬编码 `"当前用户"`，创建评论时 `authorName` 由服务端从 Token 自动设置。`authorAvatarUrl` 返回原始对象键，客户端需拼接 CDN 域名后展示。

---

### 3.4 更新评论

```
PUT /api/comments/{id}
```

#### 路径参数

| 参数 | 类型 | 说明 |
|------|------|------|
| `id` | UUID | 要更新的评论 ID |

#### 请求头

| 头 | 值 |
|----|-----|
| `Authorization` | `Bearer {accessToken}` |
| `Content-Type` | `application/json` |

#### 请求体

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `content` | string | ✅ | 新内容，1~5000 字符 |

#### 请求示例

```json
{
  "content": "更新后的评论内容"
}
```

#### 响应示例（200 OK）

```json
{
  "success": true,
  "data": {
    "message": "评论已更新"
  }
}
```

#### 错误场景

| 场景 | 状态码 | error.code | message |
|------|--------|------------|---------|
| 评论不存在 | 404 | `NOT_FOUND` | 评论不存在 |
| 非作者修改 | 403 | `FORBIDDEN` | 服务端返回 Forbid |
| 未认证 | 401 | `NOT_AUTHORIZED` | 未认证 |
| 参数缺失 | 400 | `VALIDATION_ERROR` | Content field is required |

---

### 3.5 删除评论

```
DELETE /api/comments/{id}
```

#### 路径参数

| 参数 | 类型 | 说明 |
|------|------|------|
| `id` | UUID | 要删除的评论 ID |

#### 请求头

| 头 | 值 |
|----|-----|
| `Authorization` | `Bearer {accessToken}` |

#### 请求示例

```http
DELETE /api/comments/dc4c336c-c3a6-496c-a42f-f5420689dd87
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

#### 响应示例（200 OK）

```json
{
  "success": true,
  "data": {
    "message": "评论已删除"
  }
}
```

> **级联删除**：删除评论时，该评论下的 **所有回复和点赞记录也会自动删除**（由数据库外键 `CASCADE` 保证）。

#### 客户端对接说明

| 客户端方法 | 对应 API |
|-----------|----------|
| `CommentService.DeleteCommentAsync(commentId)` | `DELETE /api/comments/{id}` |

---

### 3.6 按资源键全量查询（跨方案）

获取指定资源键下的全部评论，**不限定方案**（普通列表查询需要 `schemeId`，本端点不需要）。

```
GET /api/comments/by-resource
```

#### 请求参数（Query）

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `resourceKey` | string | ✅ | — | 资源标识，格式如 `"media://abc123"` |
| `page` | int | ❌ | 1 | 页码 |
| `pageSize` | int | ❌ | 20 | 每页条数（最大 100） |

#### 是否需要认证

✅ 需要，携带 `Authorization: Bearer {accessToken}`。

#### 请求示例

```http
GET /api/comments/by-resource?resourceKey=media://abc123&page=1&pageSize=20
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

#### 响应示例（200 OK）

返回结构与 [3.1 获取评论列表](#31-获取评论列表分页) 一致（`items/page/pageSize/totalCount/totalPages`）。

#### 客户端对接说明

| 客户端方法 | 对应 API |
|-----------|----------|
| `CommentService.GetCommentsByResourceKeyAsync(resourceKey)` | `GET /api/comments/by-resource?resourceKey=` |

---

## 四、回复 API 端点

### 4.1 创建回复

```
POST /api/comments/{commentId}/replies
```

#### 路径参数

| 参数 | 类型 | 说明 |
|------|------|------|
| `commentId` | UUID | 要回复的评论 ID（必填） |

#### 请求头

| 头 | 值 |
|----|-----|
| `Authorization` | `Bearer {accessToken}` |
| `Content-Type` | `application/json` |

#### 请求体

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `content` | string | ✅ | 回复内容，1~2000 字符 |

#### 请求示例

```http
POST /api/comments/dc4c336c-c3a6-496c-a42f-f5420689dd87/replies
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
Content-Type: application/json

{
  "content": "同意！非常好用 👍"
}
```

#### 响应示例（201 Created — 返回创建的回复）

```json
{
  "success": true,
  "data": {
    "id": "e5f6a7b8-...",
    "commentId": "dc4c336c-c3a6-496c-a42f-f5420689dd87",
    "userId": "4d032410-...",
    "content": "同意！非常好用 👍",
    "authorName": "测试用户2",
    "authorAvatarUrl": null,
    "likeCount": 0,
    "isLikedByUser": false,
    "createdAt": "2026-07-25T13:00:00Z"
  }
}
```

> 响应头中 `Location` 指向父评论的 URL：`/api/comments/{commentId}`，客户端可以用这个 URL 刷新评论详情。

#### 客户端对接说明

| 客户端方法 | 对应 API |
|-----------|----------|
| `CommentService.AddReplyAsync(commentId, content)` | `POST /api/comments/{commentId}/replies` |

---

### 4.2 删除回复

```
DELETE /api/comments/{commentId}/replies/{replyId}
```

#### 路径参数

| 参数 | 类型 | 说明 |
|------|------|------|
| `commentId` | UUID | 父评论 ID |
| `replyId` | UUID | 要删除的回复 ID |

#### 请求头

| 头 | 值 |
|----|-----|
| `Authorization` | `Bearer {accessToken}` |

#### 请求示例

```http
DELETE /api/comments/dc4c336c-c3a6-496c-a42f-f5420689dd87/replies/e5f6a7b8-...
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

#### 响应示例（200 OK）

```json
{
  "success": true,
  "data": {
    "message": "回复已删除"
  }
}
```

#### 错误场景

| 场景 | 状态码 | error.code | message |
|------|--------|------------|---------|
| 回复不存在 | 404 | `NOT_FOUND` | 回复不存在 |
| 非作者删除 | 403 | `FORBIDDEN` | 只能删除自己的回复 |
| 未认证 | 401 | `NOT_AUTHORIZED` | 未认证 |

---

## 五、点赞 API 端点

### 5.1 切换评论点赞

> **设计说明**：这是一个"开关"操作。如果当前用户已点赞则取消点赞，未点赞则添加点赞。客户端无需跟踪当前状态，服务端会判断。

```
POST /api/comments/{id}/toggle-like
```

#### 路径参数

| 参数 | 类型 | 说明 |
|------|------|------|
| `id` | UUID | 评论 ID |

#### 请求头

| 头 | 值 |
|----|-----|
| `Authorization` | `Bearer {accessToken}` |

#### 请求示例

```http
POST /api/comments/dc4c336c-c3a6-496c-a42f-f5420689dd87/toggle-like
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

#### 响应示例（200 OK）

```json
{
  "success": true,
  "data": {
    "liked": true,
    "likeCount": 4
  }
}
```

| 返回字段 | 类型 | 说明 |
|----------|------|------|
| `liked` | bool | `true` = 当前已点赞（刚添加），`false` = 当前未点赞（刚取消） |
| `likeCount` | int | 最新的点赞总数，客户端直接更新 UI 即可 |

#### 客户端对接说明

| 客户端方法 | 对应 API |
|-----------|----------|
| `CommentService.ToggleLikeCommentAsync(commentId)` | `POST /api/comments/{id}/toggle-like` |

> **改造要点**：客户端之前可能自己维护了点赞状态和计数。接入此 API 后，**只需信任服务端返回的 `liked` 和 `likeCount` 直接更新 UI**，不再需要本地状态推断。

---

### 5.2 切换回复点赞

```
POST /api/comments/{commentId}/replies/{replyId}/toggle-like
```

#### 路径参数

| 参数 | 类型 | 说明 |
|------|------|------|
| `commentId` | UUID | 父评论 ID |
| `replyId` | UUID | 回复 ID |

#### 请求头

| 头 | 值 |
|----|-----|
| `Authorization` | `Bearer {accessToken}` |

#### 请求示例

```http
POST /api/comments/dc4c336c-c3a6-496c-a42f-f5420689dd87/replies/e5f6a7b8-.../toggle-like
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

#### 响应示例（200 OK）

```json
{
  "success": true,
  "data": {
    "liked": false,
    "likeCount": 0
  }
}
```

#### 客户端对接说明

| 客户端方法 | 对应 API |
|-----------|----------|
| `CommentService.ToggleLikeReplyAsync(replyId)` | `POST /api/comments/{commentId}/replies/{replyId}/toggle-like` |

---

## 六、认证 API 端点（评论系统前置依赖）

客户端需要先获取 Token，才能调用评论系统中需要认证的端点。

### 6.1 注册

```
POST /api/auth/register
```

**请求体**：

```json
{
  "username": "用户名",
  "password": "密码",
  "nickname": "显示名称（可选）"
}
```

**响应**：`201 Created` 返回用户基本信息（不含 Token）

### 6.2 登录

```
POST /api/auth/login
```

**请求体**：

```json
{
  "username": "用户名",
  "password": "密码"
}
```

**响应**（200 OK）：

```json
{
  "success": true,
  "data": {
    "userId": "4d032410-...",
    "username": "testuser2",
    "nickname": "测试用户2",
    "role": "User",
    "accessToken": "eyJhbGciOiJIUzI1NiIs...",
    "refreshToken": "Uv0FRMmIvT8hiAkY..."
  }
}
```

### 6.3 刷新 Token

```
POST /api/auth/refresh
```

**请求体**：

```json
{
  "refreshToken": "Uv0FRMmIvT8hiAkY..."
}
```

**响应**（200 OK）：

```json
{
  "success": true,
  "data": {
    "accessToken": "新的accessToken...",
    "refreshToken": "新的refreshToken..."
  }
}
```

> **注意**：每次刷新会吊销旧的 refreshToken，返回新的 Token Pair。

---

## 七、客户端改造指南

### 7.1 当前客户端现状

客户端（Kirara_Server-WinUI）的 `CommentService` 当前使用本地 LiteDB 存储，每个方法都有 `// TODO: 远程数据库 — 替换为 API 调用` 注释。

```csharp
// 客户端当前实现（LiteDB）
public class CommentService : ICommentService
{
    public async Task<IReadOnlyList<CommentItem>> GetCommentsAsync(string resourceKey, Guid schemeId)
    {
        // TODO: 远程数据库 — 替换为 API 调用
        // 预期: GET /api/comments?resourceKey={resourceKey}&schemeId={schemeId}
        await Task.CompletedTask;
        return _commentRepo.GetByResource(resourceKey).ToList().AsReadOnly();
    }
}
```

### 7.2 改造方案：RemoteCommentService

创建 `RemoteCommentService` 实现 `ICommentService`，用 `HttpClient` 调用 API：

**文件位置**：`Kirara_Server-WinUI/Services/RemoteCommentService.cs`

```csharp
public class RemoteCommentService : ICommentService
{
    private readonly HttpClient _httpClient;

    public RemoteCommentService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<IReadOnlyList<CommentItem>> GetCommentsAsync(string resourceKey, Guid schemeId)
    {
        var response = await _httpClient.GetAsync(
            $"/api/comments?resourceKey={Uri.EscapeDataString(resourceKey)}&schemeId={schemeId}");
        response.EnsureSuccessStatusCode();
        // 反序列化 ApiResponse<...>
        // ...
    }
    // ... 其他方法类似
}
```

### 7.3 DI 配置替换

```csharp
// App.xaml.cs 中注册：
// 当前（本地）：
services.AddSingleton<ICommentService, CommentService>();

// 替换为（远程）：
services.AddSingleton<ICommentService, RemoteCommentService>();
services.AddHttpClient<ICommentService, RemoteCommentService>(client =>
{
    client.BaseAddress = new Uri("https://api.akeno6388.online:1010");
});
```

> **无需改动任何 ViewModel 或 XAML 文件**。

### 7.4 模型差异对照

| 字段 | 客户端现有模型 (`CommentItem`) | 服务端返回模型 (`CommentResponse`) | 差异 |
|------|-------------------------------|-----------------------------------|------|
| `AuthorName` | 硬编码 `"当前用户"` | 服务端从 JWT 解析 | ✅ 服务端正确处理 |
| `AuthorAvatarUrl` | ❌ 不存在 | ✅ `string?` | 🆕 新增字段 |
| `ContentTitle` | ❌ 不存在 | ✅ `string?` | 🆕 新增字段（创建评论时可选传入，回复自动继承） |
| `LikeCount` | 客户端维护 | 服务端 `int` | 客户端改为信任服务端值 |
| `IsLikedByUser` | 客户端推断 | 服务端动态计算 | ✅ 更准确 |
| `ReplyCount` | ❌ 不存在 | ✅ `int` | 🆕 新增字段 |

### 7.5 调用关系汇总

| 客户端方法 | HTTP 方法 | API 路径 | 认证 | 请求体 | 响应体 |
|-----------|-----------|----------|------|--------|--------|
| `GetCommentsAsync` | GET | `/api/comments?resourceKey=&schemeId=&page=&pageSize=` | ✅ | — | `{ items, page, totalCount }` |
| `GetCommentsByResourceKeyAsync` | GET | `/api/comments/by-resource?resourceKey=&page=&pageSize=` | ✅ | — | `{ items, page, totalCount }` |
| `AddCommentAsync` | POST | `/api/comments` | ✅ | `{ resourceKey, schemeId, content, contentTitle? }` | `{ 单条评论 }` |
| `UpdateCommentAsync` | PUT | `/api/comments/{id}` | ✅ | `{ content }` | `{ message }` |
| `DeleteCommentAsync` | DELETE | `/api/comments/{id}` | ✅ | — | `{ message }` |
| `AddReplyAsync` | POST | `/api/comments/{commentId}/replies` | ✅ | `{ content }` | `{ 单条回复 }` |
| `ToggleLikeCommentAsync` | POST | `/api/comments/{id}/toggle-like` | ✅ | — | `{ liked, likeCount }` |
| `ToggleLikeReplyAsync` | POST | `/api/comments/{commentId}/replies/{replyId}/toggle-like` | ✅ | — | `{ liked, likeCount }` |

---

## 八、测试用例

### 8.1 认证准备

```powershell
# 注册
curl.exe -X POST "http://localhost:5340/api/auth/register" -H "Content-Type: application/json" -d "{\"username\":\"testdev\",\"password\":\"Test123456\",\"nickname\":\"测试开发者\"}"

# 登录（保存返回的 accessToken）
curl.exe -X POST "http://localhost:5340/api/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"testdev\",\"password\":\"Test123456\"}"
```

### 8.2 评论 CRUD

```powershell
# 创建评论
curl.exe -X POST "http://localhost:5340/api/comments" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"resourceKey\":\"media://dev123\",\"schemeId\":\"a1000001-0000-0000-0000-000000000001\",\"content\":\"服务端评论测试\"}"

# 获取评论列表（需 Token）
curl.exe -X GET "http://localhost:5340/api/comments?resourceKey=media://dev123&schemeId=a1000001-0000-0000-0000-000000000001&page=1&pageSize=20" -H "Authorization: Bearer <token>"

# 按资源键全量查询评论（需 Token）
curl.exe -X GET "http://localhost:5340/api/comments/by-resource?resourceKey=media://dev123&page=1&pageSize=20" -H "Authorization: Bearer <token>"

# 更新评论（替换 {id}）
curl.exe -X PUT "http://localhost:5340/api/comments/{id}" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"content\":\"已更新内容\"}"

# 删除评论（替换 {id}）
curl.exe -X DELETE "http://localhost:5340/api/comments/{id}" -H "Authorization: Bearer <token>"
```

### 8.3 回复测试

```powershell
# 创建回复（替换 {commentId}）
curl.exe -X POST "http://localhost:5340/api/comments/{commentId}/replies" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"content\":\"收到，已阅 👍\"}"

# 删除回复（替换 {commentId} 和 {replyId}）
curl.exe -X DELETE "http://localhost:5340/api/comments/{commentId}/replies/{replyId}" -H "Authorization: Bearer <token>"
```

### 8.4 点赞测试

```powershell
# 切换评论点赞（替换 {id}）
curl.exe -X POST "http://localhost:5340/api/comments/{id}/toggle-like" -H "Authorization: Bearer <token>"

# 切换回复点赞（替换 {commentId} 和 {replyId}）
curl.exe -X POST "http://localhost:5340/api/comments/{commentId}/replies/{replyId}/toggle-like" -H "Authorization: Bearer <token>"
```

---

## 九、FAQ

### Q1: 评论列表为什么不返回全部回复？

为了性能。列表页嵌入前 3 条回复可以快速预览，查看全部回复需要调用 `GET /api/comments/{id}` 获取单条评论详情。

### Q2: 如何处理 Token 过期？

客户端应拦截 401 响应 → 调用 `/api/auth/refresh` 续期 → 用新 Token 重试原请求。如果 refreshToken 也过期了，引导用户重新登录。
所有评论端点均要求携带 Token（未携带将返回 401），因此 `isLikedByUser` 始终基于当前用户准确计算
### Q3: `isLikedByUser` 的机制是什么？

服务端根据当前请求的 JWT Token 中的 `userId`，查询 `CommentLikes` 或 `ReplyLikes` 表判断。如果请求未携带 Token，则所有 `isLikedByUser` 返回 `false`。

### Q4: 点赞计数 `likeCount` 客户端是否需要自己推算？

不需要。服务端维护 `LikeCount` 冗余字段，每次 toggle-like 操作都会原子更新。客户端**每次请求后直接使用服务端返回的最新值**覆盖本地计数。

### Q5: 头像 CDN 未配置会怎样？

如果 `Cdn:BaseUrl` 未配置，`authorAvatarUrl` 返回 `null`。客户端应当有兜底方案（如显示默认头像 Glyph）。
