# Kirara_Server 功能扩展技术文档

> **版本**：v0.5（G1 OpenVPN 已并入技术栈文档）
> **适用范围**：内部团队使用
> **更新日期**：2026-08-03

> **✅ 实施状态**：**G1（OpenVPN 方案）已完成**，技术内容已并入 `docs/技术栈文档.md`（4.5e 章节），本文档不再包含 OpenVPN 相关内容。**G2（RDP）/ G3（打包分发）待实施**。

---

## 目录

1. [背景与目标](#一背景与目标)
2. [总体架构](#二总体架构)
3. [功能模块设计](#三功能模块设计)
4. [关键技术决策说明](#四关键技术决策说明)
5. [风险与注意事项](#五风险与注意事项)
6. [落地实施计划](#六落地实施计划)

---

## 一、背景与目标

### 1.1 背景

Kirara_Server 目前以 WinUI 3 实现多类"方案"（Scheme）承载与管理。其中**泵桩（Stub）功能**包含待完善的能力：

- **RDP 桌面**：4 个 Winserver 方案（DC/AC/DL/GN）均为 `RDP` 类型桩，`ShowRdp()` 仅显示占位文本，无真实渲染层。

> **📌 说明**：**OpenVPN 方案（原 G1）已开发完成**，自研管理面板 + `openvpn.exe` 子进程 + management 管理接口（`VpnConnectionService` / `OvpnConfigCacheService` / `OpenVpnControl`），详见技术栈文档 `4.5e OpenVPN 方案系统`。

项目为**闭源内部工具**，采用 MIT 许可证开源分发（WinUI 程序本体）。

### 1.2 目标

| 编号 | 目标 | 验收标准 |
|------|------|---------|
| G1 | ✅ **OpenVPN 方案已实现**（已并入技术栈文档） | ✅ 方案页内可连/断、查看状态、流量与日志 |
| G2 | 实现 RDP 方案，**嵌入远程桌面并自动认证** | 方案页内直接显示远程桌面并完成令牌自动认证 |
| G3 | 完成**单包安装分发**，联动安装外置程序 | 双击一个安装包即可装齐应用 + OpenVPN + 依赖 |

---

## 二、总体架构

```mermaid
graph TB
    subgraph Kirara_Server（WinUI 3）
        A[SchemeHostPage] -->|ShowRdp| C[Winserver*Scheme<br/>RDP]
        C --> G[RdpConnectionService<br/>令牌解密 → 连接参数]
        G --> H[RdpEmbeddedHost<br/>WinForms AxHost 承载 MSTSC]
        H --> I[mstscax.dll<br/>系统内建]
    end
```

**分层约定**：
- **业务逻辑**统一委托给 `Services/` 下的 Service 类，不写入 Helpers 等目录。
- **UI 承载控件**放 `Controls/` 目录。
- 方案类（Scheme）仅做编排：绑定令牌 → 调用 Service → 返回 UI。

---

## 三、功能模块设计

### 3.1 RDP 方案（S2）

#### 3.1.1 设计思路

WinUI 3 的 XAML 元素**没有独立 HWND，也不能直接托管 WinForms/ActiveX 控件**（无 WPF 的 WindowsFormsHost）。因此采用：

**MSTSC ActiveX（`mstscax.dll`） + WinForms `AxHost` 承载 + `SetParent`/`MoveWindow` HWND 挂载**。

- `mstscax.dll` 为 Windows 10/11 系统内建组件，**零第三方依赖**。
- 自动认证通过 MSTSC 的 `AdvancedSettings2.ClearTextPassword` 注入令牌凭据，**无需模拟输入**。

#### 3.1.2 文件改动

| 文件 | 状态 | 说明 |
|------|------|------|
| `Services/IRdpConnectionService.cs`、`RdpConnectionService.cs` | 🆕 | 解密绑定令牌 → 构建连接参数 |
| `Controls/RdpEmbeddedHost.cs` | 🆕 | `MsRdpClientHost : AxHost` 承载 + HWND 挂载与定位 |
| `Kirara_Server-WinUI.csproj` | 改 | 引入 `System.Windows.Forms`（官方运行时包，承载 ActiveX 必需） |
| `SchemeHostPage.xaml(.cs)` | 改 | `ShowRdp()` 接入真实连接；命名宿主 Border + 空状态 |
| `App.xaml.cs` | 改 | `ConfigureServices()` 注册 `IRdpConnectionService` 单例 |

4 个 `Winserver*Scheme` 基本不动（`UIKind = RDP`、`DefaultUrlKey` 自动解析种子 IP 已具备），`Server` 优先取 `token.ServerUrl`，为空时回退注册表地址。

#### 3.1.3 连接挂载流程

```
ShowRdp()
  ├─ BuildOptions(binding, address) → RdpConnectionOptions
  ├─ 创建 AxHost（MsRdpClient9NotSafeForScripting）
  ├─ 注入: Server / UserName / AdvancedSettings2.ClearTextPassword
  ├─ SetParent(axHost.Handle, 主窗口HWND)
  ├─ MoveWindow 按宿主区域定位（DPI 换算）
  ├─ _rdp.Connect()
  └─ _host.SizeChanged → PositionWindow() 动态跟随
```

#### 3.1.4 状态与生命周期

- 第一版**轮询 `ConnectedState`**（Connecting/Connected/Disconnected）驱动 UI（`dynamic` 无法挂 COM 事件，ActiveX 事件走连接点）。
- `RdpEmbeddedHost.Dispose()` 中必须 `Disconnect()` + `SetParent(Handle, IntPtr.Zero)` + `DestroyWindow`，避免残留 mstsc 进程。
- 挂起（`SuspendInstance`）时 `ShowWindow(SW_HIDE)` 隐藏，切回再显示。
- 认证失败走 `OnLogonError`，可后续反射挂事件推送 `INotificationService`。

---

### 3.2 打包与分发（S3）

#### 3.2.1 形态决策

| 形态 | 结论 |
|------|------|
| MSIX（已配 `runFullTrust`） | **不推荐**作为主分发——沙盒化对"捆绑驱动安装"极不友好 |
| **Unpackaged + Inno Setup 单安装包** | ✅ **推荐**：一次提权装完应用 + OpenVPN + WebView2 |

#### 3.2.2 发布配置（csproj）

```xml
<WindowsAppSDKSelfContained>true</WindowsAppSDKSelfContained>
<SelfContained>true</SelfContained>
<RuntimeIdentifier>win-x64</RuntimeIdentifier>
```

> ⚠️ **不要使用 `PublishSingleFile`**（WinUI 3 有资源加载路径问题），改用文件夹发布后交给 Inno Setup 打包。

发布命令：

```bash
dotnet publish -c Release -r win-x64 --self-contained true
```

#### 3.2.3 Inno Setup 关键配置

```ini
[Setup]
PrivilegesRequired=admin        ; 安装提权，可装驱动
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "bin\Release\win-x64\publish\*"; DestDir: "{app}"; Flags: recursesubdirs
Source: "thirdparty\openvpn-install-2.6.x-amd64.exe"; DestDir: "{tmp}"

[Run]
; 链式静默安装 OpenVPN（NSIS /S，禁用 DCO 避免冲突）
; ⚠️ /D= 必须是最后一个参数且不带引号（NSIS 硬性要求，即使路径含空格）
; /D={app}\OpenVPN → 安装到软件目录下的 OpenVPN 文件夹
; 客户端探测顺序已适配：应用目录相对路径（{AppDir}\OpenVPN 或 {AppDir}\..\OpenVPN）→ 固定路径 → PATH → 注册表(HKLM/HKCU)
Filename: "{tmp}\openvpn-install-latest.exe"; Parameters: "/S /select_ovpn_dco=0 /D={app}\OpenVPN"; ...
; WebView2 Evergreen 引导器（已装自动跳过）
```

#### 3.2.4 外置程序捆绑策略

| 策略 | 做法 | 结论 |
|------|------|------|
| **A. 链式静默安装** | 安装器内嵌并静默执行 | ✅ 推荐 |
| B. 应用内检测 + 引导 | 检测 `openvpn.exe` 缺失时提示安装 | 备选 |
| C. 二进制直接随包 | 自管驱动/服务注册 | 工作量大，不推荐 |

#### 3.2.5 卸载联动

Inno Setup 默认卸载仅删应用本体，`[UninstallRun]` 中调用 OpenVPN 卸载器：

```ini
[UninstallRun]
Filename: "{pf}\OpenVPN\Uninstall.exe"; Parameters: "/S"
```

---

## 四、关键技术决策说明

| 决策点 | 选择 | 理由 |
|--------|------|------|
| RDP 渲染 | MSTSC ActiveX 内建 | 系统组件、零依赖、免许可 |
| RDP 认证 | `ClearTextPassword` | 令牌注入点，无需模拟输入 |
| 外置驱动安装 | 官方 NSIS 安装包链式安装 | 驱动/服务/TAP 全自动，最省事 |
| 签名 | 自签名或购买 OV 代码签名 | 规避 SmartScreen/UAC 拦截 |

> **已落地决策**（OpenVPN 阶段，详见技术栈文档 4.5e）：OpenVPN 集成方式 = 进程调用 + `--management`（不合并源码，避免 GPLv2 传染）；界面 = CustomControl 自研；运行时提权 = 应用整体 `requireAdministrator`（已配置）。

---

## 五、风险与注意事项

1. **Z 序问题（RDP 最大坑）**：`SetParent` 的子窗口永远盖在 XAML 之上。RDP 方案内不显示评论区；挂起时隐藏窗口。
2. **DPI**：`MoveWindow` 用物理像素，需乘 `GetDpiForWindow / 96.0`，否则高分屏错位。
3. **`ClearTextPassword` 一次性**：连接一次后被 MSTSC 清空，重连必须重新赋值。
4. **MSIX vs Unpackaged**：若未来要 App Installer 增量更新，需换真实签名证书 + 侧载配置；但 MSIX 下做不到干净捆绑驱动安装，需退回"检测 + 引导手动装"。
5. **进程生命周期**：实例切走/关闭/应用退出时，必须在 `DeinitializeAsync` / `Dispose()` 中释放 RDP 连接（`Disconnect` + `SetParent` 还原 + `DestroyWindow`），避免残留 mstsc 进程。
6. **失败通知**：通过 `INotificationService.Publish(Service, Error)` 推送连接失败（认证失败/连接超时），用户可在通知中心看到。

---

## 六、落地实施计划

| 阶段 | 任务 | 验收 |
|------|------|------|
| ① RDP service | `RdpConnectionService` + csproj 加包 | 编译通过 |
| ② RDP 承载 | `RdpEmbeddedHost` + `ShowRdp()` 接入 | 方案页显示远程桌面并自动认证 |
| ③ 打包分发 | 自包含发布 + Inno Setup 单包 + 链式装 OpenVPN/WebView2 | 双击一个安装包全部装齐 |
| ④ 签名与打磨 | 自签名/OV 签名；断线重连、多实例并发（4 个 Winserver 并发连接） | 内网一键部署可复现 |

> **✅ 已完成**（OpenVPN 阶段 ①-③，详见技术栈文档 4.5e）：环境验证 → `VpnConnectionService` → `OpenVpnControl` 已全部实现并接入。

---

*文档依据前期技术调研整理，落地时以实际代码结构调整为准。*
