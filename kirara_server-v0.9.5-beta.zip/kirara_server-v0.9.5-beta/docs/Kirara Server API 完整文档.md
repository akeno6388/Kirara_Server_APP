# Kirara Server API 完整文档

> **版本**：v1.10
> **更新日期**：2026-08-07
> **适用 API 地址**：`http://localhost:5340`（开发） / `https://api.akeno6388.online:1010`（生产）
> **适用客户端**：Kirara_Server-WinUI（WinUI 3 / .NET 10）/ 第三方集成
> **Base URL**：所有端点以 `/api` 为前缀

---

## 更新记录

| 版本 | 日期 | 变更内容 |
|------|------|----------|
| v1.10 | 2026-08-07 | 新增互动通知系统 — 评论/回复/首页分享的回复与点赞自动向内容作者推送通知（SignalR 实时 + REST 补拉）：Comment/Reply/HomepageComment 新增 `ContentTitle`（视频标题）字段，Notification 新增 7 个定位字段（ActionType/ActorUserId/ActorName/TargetId/ResourceKey/ContentTitle/SourceUrl），通知文案模板、自操作排除、取消点赞不通知、同目标去重（未读） |
| v1.9 | 2026-08-06 | 新增应用更新 API — 公开版本校对 `GET /api/app/updates/latest`（语义化版本比对，非法 current 按 0.0.0）+ 管理端发布登记/列表/更新/撤销（`/api/admin/app-releases`，版本唯一索引，登记自动停用旧记录，安装包托管 Alist 直链，服务端不接收文件） |
| v1.8 | 2026-08-01 | 新增 OpenVPN 配置 API（`/api/openvpn`）— 查看/下载需登录认证，上传（覆盖更新 Version++）/删除仅管理员，配置文件存储于 MinIO `openvpn/` 文件夹 |
| v1.7 | 2026-08-01 | 评论系统所有端点统一要求登录认证；新增按资源键全量查询评论端点 `GET /api/comments/by-resource`；新增首页评论系统（`/api/homepage-comments`，含独立实体 HomepageComment / HomepageCommentLike、完整 CRUD + 点赞 API） |
| v1.6 | 2026-07-31 | 补充信息流卡片主媒体和缩略图预签名 URL 获取端点；补充注册功能开关管理端点；逐条比对 .http 测试文件确保 59 条 API 完整覆盖 |
| v1.5 | 2026-07-30 | 修正架构概览中的接口计数（16→17）和服务计数（9→10）；补充 `GET /api/resources/home-background` 的 `X-Resource-Version` 响应头信息；补充 `PUT /api/resources/home-background` 响应中的 `version` 字段；补充信息流卡片管理端点的 curl 示例 |
| v1.4 | 2026-07-28 | 新增文件上传规范章节（支持的 Content-Type / 扩展名 / 各端点大小限制）；新增模板封面图片公开获取端点 `GET /api/templates/{id}/cover`（302 重定向到 MinIO 预签名 URL） |
| v1.2 | 2026-07-27 | 信息流资源存储路径优化（平铺至 `information/`）；新增视频/HTML 文件类型支持；`GetFileExtension` 替代 `GetImageExtension` |
| v1.1 | 2026-07-27 | 新增信息流通知 API、SignalR 实时通知推送 |

---

## 目录

- [一、通用规范](#一通用规范)
  - [1.1 请求规范](#11-请求规范)
  - [1.2 统一响应格式](#12-统一响应格式)
  - [1.3 HTTP 状态码约定](#13-http-状态码约定)
  - [1.4 错误码对照表](#14-错误码对照表)
  - [1.5 分页规范](#15-分页规范)
  - [1.6 Token 生命周期管理](#16-token-生命周期管理)
  - [1.7 文件上传规范](#17-文件上传规范)
- [二、认证 API (`/api/auth`)](#二认证-api-api-auth)
  - [2.1 注册用户](#21-注册用户)
  - [2.2 登录](#22-登录)
  - [2.3 刷新 Token](#23-刷新-token)
  - [2.4 退出登录](#24-退出登录)
  - [2.5 获取当前用户信息](#25-获取当前用户信息)
- [三、评论系统 API (`/api/comments`)](#三评论系统-api-api-comments)
  - [3.1 数据模型](#31-数据模型)
  - [3.2 CommentResponse 字段](#32-commentresponse-字段)
  - [3.3 ReplyResponse 字段](#33-replyresponse-字段)
  - [3.4 获取评论列表（分页）](#34-获取评论列表分页)
  - [3.5 获取单条评论](#35-获取单条评论)
  - [3.6 创建评论](#36-创建评论)
  - [3.7 更新评论](#37-更新评论)
  - [3.8 删除评论](#38-删除评论)
  - [3.9 创建回复](#39-创建回复)
  - [3.10 删除回复](#310-删除回复)
  - [3.11 切换评论点赞](#311-切换评论点赞)
  - [3.12 切换回复点赞](#312-切换回复点赞)
  - [3.13 按资源键全量查询](#313-按资源键全量查询)
- [四、模板 API (`/api/templates`)](#四模板-api-apitemplates)
  - [4.1 获取所有模板列表](#41-获取所有模板列表)
  - [4.2 获取单个模板详情](#42-获取单个模板详情)
  - [4.3 获取模板封面图片](#43-获取模板封面图片)
- [五、方案 URL API (`/api/scheme-urls`)](#五方案-url-api-apischeme-urls)
  - [5.1 获取全部方案 URL](#51-获取全部方案-url)
  - [5.2 获取方案封面图片](#52-获取方案封面图片)
  - [5.3 增量同步方案 URL](#53-增量同步方案-url)
- [六、资源管理 API (`/api/resources`)](#六资源管理-api-apiresources)
  - [6.1 上传当前用户头像](#61-上传当前用户头像)
  - [6.2 获取用户头像](#62-获取用户头像)
  - [6.3 获取首页背景图](#63-获取首页背景图)
  - [6.4 上传首页背景图（仅管理员）](#64-上传首页背景图仅管理员)
- [七、通知系统 API (`/api/notifications`)](#七通知系统-api-apinotifications)
  - [7.1 获取通知列表（分页）](#71-获取通知列表分页)
  - [7.2 获取未读通知数](#72-获取未读通知数)
  - [7.3 标记单条通知已读](#73-标记单条通知已读)
  - [7.4 标记全部通知已读](#74-标记全部通知已读)
  - [7.5 互动通知（回复/点赞自动推送）](#75-互动通知回复点赞自动推送)
- [八、管理功能 API (`/api/admin`)](#八管理功能-api-apiadmin)
  - [8.1 获取用户列表](#81-获取用户列表)
  - [8.2 修改用户角色](#82-修改用户角色)
  - [8.3 删除用户](#83-删除用户)
  - [8.4 更新方案 URL](#84-更新方案-url)
  - [8.5 上传方案图片](#85-上传方案图片)
  - [8.6 广播通知](#86-广播通知)
  - [8.7 新增模板](#87-新增模板)
  - [8.8 更新模板](#88-更新模板)
  - [8.9 删除模板](#89-删除模板)
  - [8.10 上传模板封面图片](#810-上传模板封面图片)
  - [8.11 注册功能开关](#811-注册功能开关)
- [九、健康检查 API (`/api/health`)](#九健康检查-api-apihealth)
  - [9.1 综合健康检查](#91-综合健康检查)
  - [9.2 Aspire 内置健康检查](#92-aspire-内置健康检查)
- [十、信息流通知 API (`/api/info-cards`)](#十信息流通知-api-apiinfo-cards)
  - [10.1 设计说明](#101-设计说明)
  - [10.2 获取所有活跃卡片](#102-获取所有活跃卡片)
  - [10.3 获取单张信息流卡片详情](#103-获取单张信息流卡片详情)
  - [10.4 获取信息流卡片主媒体](#104-获取信息流卡片主媒体)
  - [10.5 获取信息流卡片缩略图](#105-获取信息流卡片缩略图)
  - [10.6 增量同步](#106-增量同步)
  - [10.7 管理端点（Admin）](#107-管理端点admin)
    - [新增卡片](#新增卡片)
    - [更新卡片](#更新卡片)
    - [删除卡片](#删除卡片)
    - [上传媒体](#上传媒体)
  - [10.8 客户端接入建议](#108-客户端接入建议)
- [十一、首页评论 API (`/api/homepage-comments`)](#十一首页评论-api-apihomepage-comments)
  - [11.1 数据模型](#111-数据模型)
  - [11.2 获取首页评论列表](#112-获取首页评论列表)
  - [11.3 获取单条首页评论](#113-获取单条首页评论)
  - [11.4 创建首页评论](#114-创建首页评论)
  - [11.5 更新首页评论](#115-更新首页评论)
  - [11.6 删除首页评论](#116-删除首页评论)
  - [11.7 切换首页评论点赞](#117-切换首页评论点赞)
- [十二、OpenVPN 配置 API (`/api/openvpn`)](#十二openvpn-配置-api-apiopenvpn)
  - [12.1 获取配置信息](#121-获取配置信息)
  - [12.2 获取配置文件下载 URL](#122-获取配置文件下载-url)
  - [12.3 上传 / 覆盖配置文件（仅管理员）](#123-上传--覆盖配置文件仅管理员)
  - [12.4 删除配置文件（仅管理员）](#124-删除配置文件仅管理员)
- [十三、应用更新 API (`/api/app/updates`)](#十三应用更新-api-apiappupdates)
  - [13.1 版本校对（公开）](#131-版本校对公开)
  - [13.2 登记发布（仅管理员）](#132-登记发布仅管理员)
  - [13.3 发布列表（仅管理员）](#133-发布列表仅管理员)
  - [13.4 更新发布（仅管理员）](#134-更新发布仅管理员)
  - [13.5 撤销发布（仅管理员）](#135-撤销发布仅管理员)
- [十四、计划与展望](#十四计划与展望)
- [十五、附录](#十五附录)
  - [14.1 客户端接入指南](#141-客户端接入指南)
  - [14.2 测试用 curl 命令](#142-测试用-curl-命令)
  - [14.3 SignalR 实时通知推送](#143-signalr-实时通知推送)
  - [14.4 项目架构概览](#144-项目架构概览)
  - [14.5 环境配置参考](#145-环境配置参考)
  - [14.6 参考文档](#146-参考文档)

---

## 一、通用规范

### 1.1 请求规范

| 项目 | 规范 |
|------|------|
| **Content-Type** | `application/json`（读写请求） / `multipart/form-data`（文件上传） |
| **字符编码** | UTF-8 |
| **认证方式** | `Authorization: Bearer {accessToken}` |
| **JWT Claims** | `nameidentifier` = 用户 ID, `name` = 用户名, `role` = User/Admin |

### 1.2 统一响应格式

```json
// ✅ 成功响应
{
  "success": true,
  "data": { ... },
  "timestamp": "2026-07-26T10:00:00Z"
}

// ❌ 错误响应
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "人类可读的错误描述"
  },
  "timestamp": "2026-07-26T10:00:00Z"
}
```

### 1.3 HTTP 状态码约定

| 状态码 | 说明 |
|--------|------|
| 200 OK | 请求成功 |
| 201 Created | 资源创建成功 |
| 302 Found | 临时重定向到资源 URL（资源管理） |
| 400 Bad Request | 请求参数错误 |
| 401 Unauthorized | 未认证或 Token 过期 |
| 403 Forbidden | 无权限操作资源 |
| 404 Not Found | 资源不存在 |
| 409 Conflict | 资源冲突 |
| 500 Internal Server Error | 服务器内部错误 |

### 1.4 错误码对照表

| Error Code | 状态码 | 说明 |
|-----------|--------|------|
| `INVALID_CREDENTIALS` | 401 | 用户名或密码错误 |
| `USERNAME_TAKEN` | 409 | 用户名已被注册 |
| `INVALID_TOKEN` | 401 | Refresh Token 无效或过期 |
| `TOKEN_EXPIRED` | 401 | Token 已过期 |
| `NOT_AUTHORIZED` | 401 | 未提供 Token 或 Token 无效 |
| `FORBIDDEN` | 403 | 无权限执行此操作 |
| `NOT_FOUND` | 404 | 资源不存在 |
| `VALIDATION_ERROR` | 400 | 参数校验失败 |
| `CONFLICT` | 409 | 资源冲突 |
| `INTERNAL_ERROR` | 500 | 服务器内部错误 |

### 1.5 分页规范

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `page` | int | 1 | 页码，从 1 开始 |
| `pageSize` | int | 20 | 每页条数，最大 100 |

分页响应结构：

```json
{
  "success": true,
  "data": {
    "items": [ ... ],
    "page": 1,
    "pageSize": 20,
    "totalCount": 42,
    "totalPages": 3
  }
}
```

### 1.6 Token 生命周期管理

```
┌──────────┐                    ┌──────────────┐
│ 客户端    │                    │ 服务端        │
└────┬─────┘                    └──────┬───────┘
     │ POST /api/auth/login           │
     │ { username, password }         │
     │────────────────────────────────>│
     │ 200: { accessToken, refreshToken, user }
     │<────────────────────────────────│
     │                                 │
     │ (后续请求) Authorization: Bearer │
     │────────────────────────────────>│ 验证 JWT 签名 + 角色
     │                                 │
     │ (accessToken 过期)              │
     │ POST /api/auth/refresh          │
     │ { refreshToken }               │
     │────────────────────────────────>│ 吊销旧 Token → 签发新 Pair
     │ 200: { accessToken, refreshToken }
     │<────────────────────────────────│
```

### 1.7 文件上传规范

#### 支持的 Content-Type 与文件扩展名

| Content-Type | 扩展名 | 说明 |
|-------------|--------|------|
| `image/png` | `.png` | PNG 图片 |
| `image/jpeg` / `image/jpg` | `.jpg` | JPEG 图片 |
| `image/webp` | `.webp` | WebP 图片 |
| `image/gif` | `.gif` | GIF 图片 |
| `image/bmp` | `.bmp` | BMP 位图 |
| `image/svg+xml` | `.svg` | SVG 矢量图 |
| `image/tiff` | `.tiff` | TIFF 图片 |
| `image/avif` | `.avif` | AVIF 图片 |
| `text/html` | `.html` | HTML 文件 |
| `application/x-openvpn-profile` / `application/octet-stream` / `text/plain` | `.ovpn` | OpenVPN 配置文件 |
| `video/mp4` | `.mp4` | MP4 视频 |
| `video/webm` | `.webm` | WebM 视频 |
| `video/x-msvideo` | `.avi` | AVI 视频 |
| `video/x-matroska` | `.mkv` | MKV 视频 |
| `video/quicktime` | `.mov` | QuickTime 视频 |
| `video/x-ms-wmv` | `.wmv` | WMV 视频 |
| `video/mpeg` | `.mpeg` | MPEG 视频 |
| `video/ogg` | `.ogv` | Ogg 视频 |
| `video/3gpp` | `.3gp` | 3GP 视频 |
| `video/mp2t` | `.ts` | MPEG-TS 视频 |
| `video/x-flv` | `.flv` | Flash 视频 |

> **注意**：不支持的 Content-Type 将回退使用类型名中的末段作为扩展名。头像上传（`/api/resources/user-avatar`）仅支持图片格式（Content-Type 以 `image/` 开头），非图片格式默认使用 `.jpg`。

#### 各端点的文件大小限制

| 端点 | 最大文件大小 | 说明 |
|------|-------------|------|
| `PUT /api/resources/user-avatar` | **10 MB** | 用户头像上传 |
| `PUT /api/admin/scheme-urls/{key}/image` | **10 MB** | 方案封面图片上传 |
| `PUT /api/admin/templates/{id}/cover` | **20 MB** | 模板封面图片上传 |
| `PUT /api/resources/home-background` | **20 MB** | 首页背景图上传 |
| `PUT /api/admin/info-cards/{id}/media` | **50 MB** | 信息流卡片媒体上传 |
| `PUT /api/admin/info-cards/{id}/thumbnail` | **50 MB** | 信息流卡片缩略图上传 |
| `PUT /api/openvpn` | **1 MB** | OpenVPN 配置文件上传（仅管理员） |

> **说明**：超出大小限制的请求将返回 `400 Bad Request`，错误码 `VALIDATION_ERROR`。

**客户端 Token 管理策略**：
1. 登录后存储 `accessToken` 和 `refreshToken`
2. 每次请求使用 `accessToken`，在 `Authorization` 头携带
3. 收到 `401` 时自动调用 `/api/auth/refresh` 续期
4. 刷新失败（refreshToken 过期/吊销）→ 引导用户重新登录

---

## 二、认证 API (`/api/auth`)

认证模块提供用户注册、登录、Token 刷新、用户信息查询、修改用户名/密码及自动登录状态查询。**已完整实现**。

### 2.1 注册用户

```
POST /api/auth/register
```

**认证**：❌ 不需要

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `username` | string | ✅ | 用户名，3~50 字符 |
| `password` | string | ✅ | 密码，6~100 字符 |
| `nickname` | string | ❌ | 显示名称，默认同用户名 |

**请求示例**：
```json
{
  "username": "newuser",
  "password": "SecureP@ss123",
  "nickname": "新用户"
}
```

**响应** `201 Created`：
```json
{
  "success": true,
  "data": {
    "userId": "a1b2c3d4-...",
    "username": "newuser",
    "nickname": "新用户",
    "role": "User"
  }
}
```

**错误** `409 Conflict`：
```json
{
  "success": false,
  "error": { "code": "USERNAME_TAKEN", "message": "用户名已存在" }
}
```

---

### 2.2 登录

```
POST /api/auth/login
```

**认证**：❌ 不需要

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `username` | string | ✅ | 用户名 |
| `password` | string | ✅ | 密码 |

**请求示例**：
```json
{
  "username": "newuser",
  "password": "SecureP@ss123"
}
```

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "userId": "a1b2c3d4-...",
    "username": "newuser",
    "nickname": "新用户",
    "role": "User",
    "accessToken": "eyJhbGciOiJIUzI1NiIs...",
    "refreshToken": "dGhpcyBpcyBh..."
  }
}
```

> **注意**：登录成功后 `accessToken` 有效期为 15 分钟，`refreshToken` 有效期为 7 天。`refreshToken` 仅在登录和刷新时返回。

**错误** `401 Unauthorized`：
```json
{
  "success": false,
  "error": { "code": "INVALID_CREDENTIALS", "message": "用户名或密码错误" }
}
```

**服务端行为**：
- BCrypt 验证密码
- 更新用户 `LastLoginAt` 时间
- 生成 HS256 签名的 AccessToken（15 分钟）
- 生成 64 字节随机 RefreshToken（Base64）
- 存入 `RefreshTokens` 表

---

### 2.3 刷新 Token

```
POST /api/auth/refresh
```

**认证**：❌ 不需要（携带旧的 refreshToken）

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `refreshToken` | string | ✅ | 登录或上次刷新时返回的 refreshToken |

**请求示例**：
```json
{
  "refreshToken": "dGhpcyBpcyBh..."
}
```

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "accessToken": "新的eyJhbGciOiJIUzI1NiIs...",
    "refreshToken": "新的dGhpcyBpcyBh..."
  }
}
```

**服务端行为**：
- 验证 RefreshToken 存在且未被吊销
- 验证未过期
- **吊销旧 Token**
- 签发新的 Token Pair

---

### 2.4 退出登录

```
POST /api/auth/logout
```

**认证**：✅ 需要 `[Authorize]`

**请求示例**：
```http
POST /api/auth/logout
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "message": "已退出登录" }
}
```

**服务端行为**：
- 吊销该用户所有活跃的 RefreshToken（全量吊销）

---

### 2.5 获取当前用户信息

```
GET /api/auth/me
```

**认证**：✅ 需要 `[Authorize]`

**请求示例**：
```http
GET /api/auth/me
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "id": "a1b2c3d4-...",
    "username": "newuser",
    "nickname": "新用户",
    "avatar": "avatars/a1b2c3d4-....png",
    "role": "User",
    "createdAt": "2026-07-25T12:00:00Z",
    "lastLoginAt": "2026-07-26T10:00:00Z"
  }
}
```

---

### 2.6 修改用户名

```
PUT /api/auth/me/username
```

**认证**：✅ 需要 `[Authorize]`

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `newUsername` | string | ✅ | 新用户名，3~50 字符 |

**请求示例**：
```json
{
  "newUsername": "AKENO"
}
```

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "message": "用户名已更新" }
}
```

---

### 2.7 修改密码

```
PUT /api/auth/me/password
```

**认证**：✅ 需要 `[Authorize]`

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `currentPassword` | string | ✅ | 当前密码 |
| `newPassword` | string | ✅ | 新密码，6~100 字符 |

**请求示例**：
```json
{
  "currentPassword": "OldP@ss123",
  "newPassword": "NewP@ss456"
}
```

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "message": "密码已更新，请重新登录" }
}
```

> **服务端行为**：修改密码后自动吊销该用户所有 RefreshToken，强制重新登录。

---

### 2.8 获取自动登录状态

```
GET /api/auth/me/auto-login
```

**认证**：✅ 需要 `[Authorize]`

**请求示例**：
```http
GET /api/auth/me/auto-login
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "autoLoginEnabled": false }
}
```

---

## 三、评论系统 API (`/api/comments`)

评论模块提供完整的评论 CRUD、回复管理、点赞切换。**已完整实现**。

### 3.1 数据模型

```
┌──────────┐     ┌──────────────┐     ┌──────────────┐
│   User   │1──N│   Comment    │1──N│    Reply     │
└──────────┘     │              │     │              │
                 ├──────────────┤     ├──────────────┤
                 │ Id (UUID PK) │     │ Id (UUID PK) │
                 │ ResourceKey  │     │ CommentId FK │
                 │ SchemeId     │     │ UserId    FK │
                 │ UserId    FK │     │ Content      │
                 │ Content      │     │ LikeCount    │
                 │ AuthorName   │     │ CreatedAt    │
                 │ LikeCount    │     └──────┬───────┘
                 │ CreatedAt    │            │
                 │ UpdatedAt    │            │1:N
                 └──────┬───────┘     ┌──────┴───────┐
                        │1:N          │  ReplyLike   │
                 ┌──────┴───────┐     ├──────────────┤
                 │ CommentLike  │     │ UserId+ReplyId│
                 ├──────────────┤     │ CreatedAt    │
                 │ UserId+CommentId   └──────────────┘
                 │ CreatedAt    │
                 └──────────────┘
```

### 3.2 CommentResponse 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | UUID | 评论 ID |
| `resourceKey` | string | 资源标识，格式 `{scheme}://{instanceId}` |
| `schemeId` | UUID | 所属方案 ID |
| `userId` | UUID | 作者 ID |
| `content` | string | 评论内容，最长 5000 |
| `contentTitle` | string? | 视频标题（创建时从客户端传入） |
| `authorName` | string | 作者显示名（服务端从 JWT 解析） |
| `authorAvatarUrl` | string? | 作者头像对象键（客户端自行拼接 CDN 域名） |
| `likeCount` | int | 点赞数 |
| `isLikedByUser` | bool | 当前用户是否点赞 |
| `replyCount` | int | 回复总数 |
| `replies` | ReplyResponse[]? | 回复列表 |
| `createdAt` | datetime | 创建时间 UTC |
| `updatedAt` | datetime? | 更新时间 UTC |

### 3.3 ReplyResponse 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | UUID | 回复 ID |
| `commentId` | UUID | 所属评论 ID |
| `userId` | UUID | 作者 ID |
| `content` | string | 回复内容，最长 2000 |
| `contentTitle` | string? | 视频标题（创建时从父评论继承） |
| `authorName` | string | 作者显示名 |
| `authorAvatarUrl` | string? | 作者头像对象键（客户端自行拼接 CDN 域名） |
| `likeCount` | int | 点赞数 |
| `isLikedByUser` | bool | 当前用户是否点赞 |
| `createdAt` | datetime | 创建时间 UTC |

### 3.4 获取评论列表（分页）

```
GET /api/comments?resourceKey={key}&schemeId={id}&page=1&pageSize=20
```

**认证**：✅ 需要 `[Authorize]`

**查询参数**：

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `resourceKey` | string | ✅ | 资源标识 |
| `schemeId` | UUID | ✅ | 方案 ID |
| `page` | int | ❌ | 默认 1 |
| `pageSize` | int | ❌ | 默认 20，最大 100 |

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "dc4c336c-...",
        "resourceKey": "media://abc123",
        "schemeId": "a1000001-...",
        "userId": "4d032410-...",
        "content": "非常好用的服务！",
        "authorName": "测试用户2",
        "authorAvatarUrl": null,
        "likeCount": 3,
        "isLikedByUser": false,
        "replyCount": 2,
        "replies": [
          {
            "id": "e5f6a7b8-...",
            "commentId": "dc4c336c-...",
            "userId": "4d032410-...",
            "content": "同意！非常好用 👍",
            "authorName": "测试用户2",
            "authorAvatarUrl": null,
            "likeCount": 1,
            "isLikedByUser": false,
            "createdAt": "2026-07-25T13:00:00Z"
          }
        ],
        "createdAt": "2026-07-25T12:57:59Z"
      }
    ],
    "page": 1,
    "pageSize": 20,
    "totalCount": 1,
    "totalPages": 1
  }
}
```

> **设计说明**：列表查询每条嵌入前 3 条回复，全部回复需调用单条查询。

---

### 3.5 获取单条评论

```
GET /api/comments/{id}
```

**认证**：✅ 需要 `[Authorize]`

**路径参数**：`id` — 评论 UUID

**响应** `200 OK`：返回结构与列表项一致，`replies` 包含全部回复。

**响应** `404`：`{ code: "NOT_FOUND", message: "评论不存在" }`

---

### 3.6 创建评论

```
POST /api/comments
```

**认证**：✅ 需要 `[Authorize]`

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `resourceKey` | string | ✅ | 必须包含 `://` 分隔符 |
| `schemeId` | UUID | ✅ | 方案 ID |
| `content` | string | ✅ | 1~5000 字符 |
| `contentTitle` | string | ❌ | 视频标题，最长 500，用于互动通知文案 |

```json
{
  "resourceKey": "media://abc123",
  "schemeId": "a1000001-...",
  "content": "非常好用的服务！",
  "contentTitle": "电影名称"
}
```

**响应** `201 Created`：返回创建的 CommentResponse。

**错误** `400`：
```json
{
  "error": { "code": "VALIDATION_ERROR", "message": "ResourceKey 格式无效，必须包含 :// 分隔符" }
}
```

> **说明**：`authorName` 由服务端从 JWT Token 自动解析，客户端无需传入。

---

### 3.7 更新评论

```
PUT /api/comments/{id}
```

**认证**：✅ 需要 `[Authorize]`（仅作者）

**请求体**：
```json
{
  "content": "更新后的内容"
}
```

**响应** `200 OK`：`{ "data": { "message": "评论已更新" } }`

**错误**：
- `404` — 评论不存在
- `403` — 非作者修改

---

### 3.8 删除评论

```
DELETE /api/comments/{id}
```

**认证**：✅ 需要 `[Authorize]`（仅作者）

**响应** `200 OK`：`{ "data": { "message": "评论已删除" } }`

> **级联删除**：评论下的所有回复和点赞记录由数据库外键 CASCADE 自动删除。

---

### 3.9 创建回复

```
POST /api/comments/{commentId}/replies
```

**认证**：✅ 需要 `[Authorize]`

**请求体**：
```json
{
  "content": "同意！非常好用 👍"
}
```

**响应** `201 Created`：返回创建的 ReplyResponse。`Location` 头指向父评论 URL。

---

### 3.10 删除回复

```
DELETE /api/comments/{commentId}/replies/{replyId}
```

**认证**：✅ 需要 `[Authorize]`（仅作者）

**响应** `200 OK`：`{ "data": { "message": "回复已删除" } }`

---

### 3.11 切换评论点赞

```
POST /api/comments/{id}/toggle-like
```

**认证**：✅ 需要 `[Authorize]`

**设计**：开关操作，已点赞则取消，未点赞则添加。

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "liked": true,
    "likeCount": 4
  }
}
```

| 字段 | 说明 |
|------|------|
| `liked` | `true`=已点赞，`false`=已取消 |
| `likeCount` | 最新点赞总数，直接更新 UI |

---

### 3.12 切换回复点赞

```
POST /api/comments/{commentId}/replies/{replyId}/toggle-like
```

**认证**：✅ 需要 `[Authorize]`

**响应** `200 OK`：同评论点赞结构 `{ liked, likeCount }`

---

### 3.13 按资源键全量查询

```
GET /api/comments/by-resource?resourceKey={key}&page=1&pageSize=20
```

**认证**：✅ 需要 `[Authorize]`

**查询参数**：

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `resourceKey` | string | ✅ | 资源标识 |
| `page` | int | ❌ | 默认 1 |
| `pageSize` | int | ❌ | 默认 20，最大 100 |

**说明**：与普通列表查询不同，此端点不需要 `schemeId`，返回该资源键下所有方案的评论。

**响应** `200 OK`：格式与 [3.4 获取评论列表](#34-获取评论列表分页) 一致。

---

## 四、模板 API (`/api/templates`)

模板模块提供客户端同步实例模板所需的公开只读端点。**已完整实现**。模板的增删改由管理端点（`/api/admin/templates`）操作。

### 4.1 获取所有模板列表

```
GET /api/templates
```

**认证**：❌ 不需要

**响应** `200 OK`：
```json
{
  "success": true,
  "data": [
    {
      "id": "a1000001-...",
      "name": "影音娱乐",
      "description": "Jellyfin 媒体服务 + 议题评论区",
      "category": "media",
      "tags": "影音,媒体,娱乐",
      "screenshotUrl": null,
      "coverImageUrl": null,
      "schemeIds": [ "a1000001-...", "a1000004-..." ],
      "version": 1,
      "createdAt": "2026-07-25T12:00:00Z"
    }
  ]
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | UUID | 模板 ID |
| `name` | string | 模板名称 |
| `description` | string? | 描述 |
| `category` | string? | 分类 |
| `tags` | string? | 标签，逗号分隔 |
| `screenshotUrl` | string? | 截屏 URL（MinIO 对象键或完整 URL） |
| `coverImageUrl` | string? | 封面图 URL（MinIO 对象键或完整 URL） |
| `schemeIds` | UUID[] | 关联的方案 ID 列表 |
| `version` | int | 版本号，用于客户端缓存比对 |
| `createdAt` | datetime | 创建时间 UTC |

---

### 4.2 获取单个模板详情

```
GET /api/templates/{id}
```

**认证**：❌ 不需要

**路径参数**：`id` — 模板 UUID

**响应** `200 OK`：返回结构与列表项一致。

**响应** `404`：`{ code: "NOT_FOUND", message: "模板不存在" }`

---

### 4.3 获取模板封面图片

```
GET /api/templates/{id}/cover
```

**认证**：❌ 不需要

**路径参数**：`id` — 模板 UUID

**响应**：
- `302 Found` — 自动重定向到 MinIO 预签名 URL
- `404` — `{ code: "NOT_FOUND", message: "模板封面图片不存在" }`

> **客户端处理**：使用 `HttpClient` 时设置 `AllowAutoRedirect = false`，手动读取 `Location` 头。

---

## 五、方案 URL API (`/api/scheme-urls`)

方案 URL 模块提供客户端同步各服务方案连接地址（如 media / drive / kmail）的端点。客户端启动时调用增量同步接口比对版本号，仅拉取变更项。**已完整实现**。所有端点需要登录认证。

### 5.1 获取全部方案 URL

```
GET /api/scheme-urls?category={category}
```

**认证**：✅ 需要 `[Authorize]`

**查询参数**：

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `category` | string | ❌ | 按分类过滤（如 `RDP`、`WebView2`），对应 `tags` 字段 |

**响应** `200 OK`：
```json
{
  "success": true,
  "data": [
    {
      "key": "media",
      "displayName": "Jellyfin 媒体服务",
      "url": "https://media.akeno6388.online:1010",
      "category": "WebView2",
      "coverImageUrl": "schemes/media.png",
      "version": 6,
      "isActive": true,
      "createdAt": "2026-07-25T12:00:00Z",
      "updatedAt": "2026-07-26T10:00:00Z"
    }
  ]
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `key` | string | 方案唯一标识，如 `media` / `drive` / `kmail` |
| `displayName` | string? | 显示名称（`Description` 字段） |
| `url` | string? | 服务地址（未配置时为 null） |
| `category` | string? | 分类标签（`Tags` 字段，如 `WebView2` / `RDP`） |
| `coverImageUrl` | string? | 封面图片对象键（客户端自行拼接 CDN 域名） |
| `version` | int | 版本号，客户端缓存用于增量同步 |
| `isActive` | bool | 是否启用 |
| `createdAt` | datetime | 创建时间 UTC |
| `updatedAt` | datetime? | 更新时间 UTC |

---

### 5.2 获取方案封面图片

```
GET /api/scheme-urls/{key}/image
```

**认证**：✅ 需要 `[Authorize]`

**路径参数**：`key` — 方案标识（如 `media`）

**响应**：
- `302 Found` — 自动重定向到 MinIO 预签名 URL
- `404` — `{ code: "NOT_FOUND", message: "方案图片不存在" }`

> **客户端处理**：使用 `HttpClient` 时设置 `AllowAutoRedirect = false`，手动读取 `Location` 头。

---

### 5.3 增量同步方案 URL

```
POST /api/scheme-urls/sync
```

**认证**：✅ 需要 `[Authorize]`

客户端上报本地缓存的各方案版本号，服务端比对后返回变更列表。

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `clientVersion` | string | ❌ | 客户端版本号（预留） |
| `localVersions` | object | ✅ | 本地版本字典，`{ "key": version }` |

**请求示例**：
```json
{
  "clientVersion": "1.0.0",
  "localVersions": {
    "media": 6,
    "drive": 1,
    "kmail": 1
  }
}
```

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "updated": [
      {
        "key": "drive",
        "displayName": "Nextcloud 云盘",
        "url": "https://drive.akeno6388.online:1010",
        "category": "WebView2",
        "coverImageUrl": "schemes/drive.png",
        "version": 2,
        "isActive": true,
        "createdAt": "2026-07-25T12:00:00Z",
        "updatedAt": "2026-07-27T08:00:00Z"
      }
    ],
    "deleted": [ "old-service" ]
  }
}
```

| 字段 | 说明 |
|------|------|
| `updated` | 服务端版本 > 客户端版本的方案列表（含新增） |
| `deleted` | 服务端已删除但客户端仍持有的方案 key 列表 |

---

## 六、资源管理 API (`/api/resources`)

资源模块提供基于 MinIO 对象存储的头像上传/下载和首页背景图管理。**已完整实现**。

### 6.1 上传当前用户头像

```
PUT /api/resources/user-avatar
```

**认证**：✅ 需要 `[Authorize]`

**请求格式**：`multipart/form-data`

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `file` | File | ✅ | 图片文件，最大 10MB |

**存储路径**：`images/avatars/{userId}{ext}`（根据文件类型自动后缀，替换旧头像）

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "avatarUrl": "http://10.10.10.11:9000/kirara-storage/avatars/a1b2...png?X-Amz-Algorithm=..."
  }
}
```

**错误** `400`：
```json
{
  "error": { "code": "VALIDATION_ERROR", "message": "文件大小不能超过 10MB" }
}
```

---

### 6.2 获取用户头像

```
GET /api/resources/user-avatar/{userId}
```

**认证**：❌ 不需要

**响应**：
- `302 Found` — 自动重定向到 MinIO 预签名 URL（1 小时有效）
- `404` — `{ code: "NOT_FOUND", message: "头像不存在" }`

> **客户端处理**：使用 `HttpClient` 时设置 `AllowAutoRedirect = false`，手动读取 `Location` 头，或直接使用浏览器打开端点。

---

### 6.3 获取首页背景图

```
GET /api/resources/home-background
```

**认证**：❌ 不需要

**响应**：
- `302 Found` — 重定向到 MinIO 预签名 URL，**响应头包含 `X-Resource-Version`**（整数版本号，客户端可用于缓存比对新旧）
- `404` — `{ code: "NOT_FOUND", message: "首页背景不存在" }`

**存储路径**：`images/backgrounds/home_background.jpg`

> **客户端建议**：读取 `X-Resource-Version` 响应头，与本地缓存的版本号比对，判断是否需要刷新背景图。

---

### 6.4 上传首页背景图（仅管理员）

```
PUT /api/resources/home-background
```

**认证**：✅ 需要 `[Authorize]` + **Admin 角色**

**请求格式**：`multipart/form-data`

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `file` | File | ✅ | 图片文件，最大 20MB |

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "backgroundUrl": "http://10.10.10.11:9000/kirara-storage/images/backgrounds/...jpg?X-Amz-Algorithm=...",
    "version": 2
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `backgroundUrl` | string | MinIO 预签名 URL |
| `version` | int | 更新后的资源版本号，客户端应缓存用于后续比对 |

> **注意**：虽然端点在 `/api/resources` 下，但上传首页背景图需要 **Admin 权限**，普通用户调用会返回 403 Forbidden。

---

## 七、通知系统 API (`/api/notifications`)

通知模块提供当前登录用户的系统通知查询、未读计数、单条/批量标记已读。与信息流通知（`/api/info-cards`）不同，此 API 面向用户端实时推送消息。**已完整实现**。所有端点需要登录认证。

> **注意**：广播通知（管理员向用户推送）由 [8.6 广播通知](#86-广播通知) 端点触发，推送结果通过 SignalR Hub 实时通知在线客户端。

### 7.1 获取通知列表（分页）

```
GET /api/notifications?page=1&pageSize=20&since={timestamp}
```

**认证**：✅ 需要 `[Authorize]`

**查询参数**：

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `page` | int | ❌ | 默认 1 |
| `pageSize` | int | ❌ | 默认 20，最大 100 |
| `since` | datetime | ❌ | 增量拉取，仅返回此时间之后的通知 |

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "n1c2d3e4-...",
        "title": "系统维护通知",
        "content": "系统将于今晚 23:00-24:00 进行维护",
        "htmlContent": null,
        "category": "Push",
        "isRead": false,
        "createdAt": "2026-07-27T12:00:00Z"
      },
      {
        "id": "n5f6a7b8-...",
        "title": "测试用户2赞了你的评论",
        "content": "[电影名称]下的评论：\"非常好用的服务！\"",
        "htmlContent": null,
        "category": "Service",
        "isRead": false,
        "createdAt": "2026-08-07T10:00:00Z",
        "actionType": 2,
        "actorUserId": "4d032410-...",
        "actorName": "测试用户2",
        "targetId": "dc4c336c-...",
        "resourceKey": "media://abc123",
        "contentTitle": "电影名称",
        "sourceUrl": null
      }
    ],
    "page": 1,
    "pageSize": 20,
    "totalCount": 5,
    "totalPages": 1
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | UUID | 通知 ID |
| `title` | string | 通知标题 |
| `content` | string? | 纯文本内容 |
| `htmlContent` | string? | 富文本 HTML 内容 |
| `category` | string | 通知类别：`Push`、`Service`、`Log`（互动通知为 `Service`） |
| `isRead` | bool | 是否已读 |
| `createdAt` | datetime | 创建时间 UTC |
| `actionType` | int? | 互动动作类型（1=回复评论, 2=点赞评论, 3=点赞回复, 4=点赞首页分享；广播通知为 null） |
| `actorUserId` | UUID? | 触发者 ID（用于去重 + "谁"；广播通知为 null） |
| `actorName` | string? | 触发者显示名（广播通知为 null） |
| `targetId` | UUID? | 被互动对象 ID（CommentId/ReplyId/HomepageCommentId；广播通知为 null） |
| `resourceKey` | string? | 视频资源键（客户端据此定位；广播通知为 null） |
| `contentTitle` | string? | 视频标题（广播通知为 null） |
| `sourceUrl` | string? | 跳转 URL（预留，当前定位信息存于 resourceKey） |

---

### 7.2 获取未读通知数

```
GET /api/notifications/unread-count
```

**认证**：✅ 需要 `[Authorize]`

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "unreadCount": 3 }
}
```

---

### 7.3 标记单条通知已读

```
PATCH /api/notifications/{id}/read
```

**认证**：✅ 需要 `[Authorize]`

**路径参数**：`id` — 通知 UUID

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "message": "已标记为已读" }
}
```

---

### 7.4 标记全部通知已读

```
PUT /api/notifications/read-all
```

**认证**：✅ 需要 `[Authorize]`

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "message": "全部已标记为已读" }
}
```

---

### 7.5 互动通知（回复/点赞自动推送）

用户回复评论、点赞评论/回复/首页分享时，服务端自动向**内容作者**推送一条通知（SignalR 实时推送 `ReceiveNotification` + 落库供 REST 补拉），无需额外调用。

#### 动作类型对照表

| ActionType | 值 | 触发场景 | targetId 指向 |
|-----------|----|----------|--------------|
| `ReplyComment` | 1 | 回复我的评论 | 新 Reply.Id |
| `LikeComment` | 2 | 点赞我的评论 | Comment.Id |
| `LikeReply` | 3 | 点赞我的回复 | Reply.Id |
| `LikeShare` | 4 | 点赞我的首页分享 | HomepageComment.Id |

#### 通知文案模板（Category = `Service`）

| 动作 | Title | Content |
|------|-------|---------|
| 点赞我的评论 | `XXX赞了你的评论` | `[视频标题]下的评论："你的评论内容"` |
| 回复我的评论 | `XXX回复了你的评论` | `[视频标题]下的评论："你的评论内容"` |
| 点赞我的回复 | `XXX赞了你的回复` | `[视频标题]下的回复："你的回复内容"` |
| 点赞我的分享 | `XXX赞了你的分享` | `在社区分享的资源[视频标题]` |

#### 通知规则（服务端内置）

1. **自操作排除**：自己回复/点赞自己的内容不通知
2. **取消点赞不通知**：仅点赞成功（liked=true）时通知
3. **简单去重**：同一 ActionType + TargetId + 同一触发者 + 接收者 + 未读状态下，重复互动不重复创建通知（已读后再次互动会重新通知）
4. **离线补拉**：离线用户通过 `GET /api/notifications` 拉取，`since` 增量参数可用

---

## 八、管理功能 API (`/api/admin`)

管理模块提供用户管理、方案 URL 管理、广播通知、模板管理、信息流卡片管理。**已完整实现**，所有端点需要 Admin 权限。

> **权限说明**：所有端点标注 `[Authorize]` + `[RequireAdmin]`，JWT 中 `role` 必须是 `Admin`。

### 8.1 获取用户列表

```
GET /api/admin/users
```

**认证**：✅ Admin

**响应** `200 OK`：
```json
{
  "success": true,
  "data": [
    {
      "id": "a1b2c3d4-...",
      "username": "admin",
      "nickname": "管理员",
      "role": "Admin",
      "createdAt": "2026-07-25T...",
      "lastLoginAt": "2026-07-26T..."
    }
  ]
}
```

---

### 8.2 修改用户角色

```
PUT /api/admin/users/{id}/role
```

**认证**：✅ Admin

**请求体**：
```json
{
  "role": "Admin"
}
```

**响应** `200 OK`：`{ "data": { "message": "用户角色已更新" } }`

**错误** `400`：`{ code: "VALIDATION_ERROR", message: "无效的角色值，仅支持 User 或 Admin" }`

---

### 8.3 删除用户

```
DELETE /api/admin/users/{id}
```

**认证**：✅ Admin

**路径参数**：`id` — 目标用户 UUID

**响应** `200 OK`：`{ "data": { "message": "用户已删除" } }`

**错误** `400`：`{ code: "VALIDATION_ERROR", message: "不能删除自己的账号" }`

---

### 8.4 更新方案 URL

```
PUT /api/admin/scheme-urls/{key}
```

**认证**：✅ Admin

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `url` | string | ❌ | 新的 URL 地址，最长 2000；不传或为 null 时不更新 |
| `changeReason` | string | ❌ | 变更原因说明，最长 500 |
| `isActive` | bool | ❌ | 是否启用 |
| `imageUrl` | string | ❌ | 封面图片 URL 或 MinIO 对象键 |

```json
{
  "url": "https://media-new.akeno6388.online:1010",
  "changeReason": "服务器迁移",
  "isActive": true,
  "imageUrl": "https://cdn.kiraramoe.me/schemes/media.png"
}
```

**响应** `200 OK`：`{ "data": { "message": "方案 URL 已更新", "key": "media", "newVersion": "Version++" } }`

**错误** `404`：`{ code: "NOT_FOUND", message: "Key 为 'media' 的方案 URL 不存在" }`

> **服务端行为**：更新 `Url`（仅当传入时）→ `Version++` → `UpdatedAt` 更新。客户端下次调用 `POST /api/scheme-urls/sync` 时拉取变更。

---

### 8.5 上传方案图片

```
PUT /api/admin/scheme-urls/{key}/image
```

**认证**：✅ Admin

**请求格式**：`multipart/form-data`

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `file` | File | ✅ | 图片文件，自动检测类型 |

**存储路径**：MinIO `schemes/{key}{ext}`（自动替换旧图片）

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "imageUrl": "schemes/media.png" }
}
```

---

### 8.6 广播通知

```
POST /api/admin/notifications/broadcast
```

**认证**：✅ Admin

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `title` | string | ✅ | 通知标题，最长 500 |
| `content` | string | ❌ | 纯文本内容 |
| `htmlContent` | string | ❌ | 富文本 HTML |
| `targetType` | int | ❌ | 0=全部用户, 1=按组, 2=按用户列表 |
| `targetGroup` | string | ❌ | targetType=1 时: "User" 或 "Admin" |
| `targetUserIds` | Guid[] | ❌ | targetType=2 时: 用户 ID 列表 |

```json
{
  "title": "系统维护通知",
  "content": "系统将于今晚 23:00-24:00 进行维护",
  "targetType": 0
}
```

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "message": "通知已发送给 5 个用户",
    "recipientCount": 5
  }
}
```

---

### 8.7 新增模板

```
POST /api/admin/templates
```

**认证**：✅ Admin

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `name` | string | ✅ | 模板名称，最长 100 |
| `description` | string | ❌ | 描述 |
| `category` | string | ❌ | 分类，最长 50 |
| `tags` | string | ❌ | 标签 |
| `screenshotUrl` | string | ❌ | 截屏 URL |
| `coverImageUrl` | string | ❌ | 封面图 URL |
| `schemeIds` | Guid[] | ❌ | 关联的方案 ID 列表 |

**请求示例**：
```json
{
  "name": "影音娱乐",
  "description": "Jellyfin 媒体服务 + 议题评论区",
  "category": "media",
  "tags": "影音,媒体,娱乐",
  "schemeIds": ["a1000001-...", "a1000004-..."]
}
```

**响应** `201 Created`：`{ "data": { "id": "...", "name": "影音娱乐" } }`

---

### 8.8 更新模板

```
PUT /api/admin/templates/{id}
```

**认证**：✅ Admin

**请求体**：同新增，所有字段可选。

**响应** `200 OK`：`{ "data": { "message": "模板已更新" } }`

---

### 8.9 删除模板

```
DELETE /api/admin/templates/{id}
```

**认证**：✅ Admin

**响应** `200 OK`：`{ "data": { "message": "模板已删除" } }`

---

### 8.10 上传模板封面图片

```
PUT /api/admin/templates/{id}/cover
```

**认证**：✅ Admin

**请求格式**：`multipart/form-data`

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `file` | File | ✅ | 图片文件，自动检测类型 |

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "coverUrl": "templates/{id}_cover.png" }
}
```

---

### 8.11 注册功能开关

```
GET /api/admin/settings/registration
```

**认证**：✅ Admin

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "registrationEnabled": true }
}
```

---

```
PUT /api/admin/settings/registration
```

**认证**：✅ Admin

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `enabled` | bool | ✅ | `true` 开启注册，`false` 关闭注册 |

**请求示例**：
```json
{
  "enabled": false
}
```

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "message": "注册功能已关闭", "registrationEnabled": false }
}
```

> **说明**：关闭注册后，用户调用 `POST /api/auth/register` 将返回 `403 Forbidden`。

---

## 九、健康检查 API (`/api/health`)

### 9.1 综合健康检查

```
GET /api/health
```

**认证**：❌ 不需要

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "status": "Healthy",
    "totalDuration": "00:00:00.0123456",
    "entries": {
      "self": { "status": "Healthy", "description": null, "duration": "00:00:00.0000018" },
      "StackExchange.Redis": { "status": "Unhealthy", "description": null, "duration": "00:00:05.6771085" }
    },
    "isHealthy": false
  }
}
```

| 检查项 | 说明 |
|--------|------|
| `self` | 应用自身健康 |
| `StackExchange.Redis` | Redis 连接状态（未启动 Redis 时为 Unhealthy，不影响业务） |

### 9.2 Aspire 内置健康检查

| 端点 | 说明 |
|------|------|
| `GET /health` | 存活检查（Aspire 内置） |
| `GET /alive` | 就绪检查（Aspire 内置） |

---

## 十、信息流通知 API (`/api/info-cards`)

信息流通知提供非实时的多媒体卡片推送，适用于公告、活动推广等场景。客户端通过 WebView2 渲染，多媒体资源统一平铺存储于 MinIO `information/` 路径。所有端点需要登录认证。

### 10.1 设计说明

- **同步方式**：客户端启动时上报本地版本号（`POST /api/info-cards/sync`），服务端返回增量变更（新增/更新/已下架）
- **多媒体支持**：`mediaType` 可设为 `image` / `video` / `html`，对应 `mediaUrl` 指向 MinIO 对象键
- **版本管理**：每次更新 `Version++`，客户端本地缓存版本号用于下次同步比对

### 10.2 获取所有活跃卡片

```
GET /api/info-cards
```

**认证**：✅ 需要 `[Authorize]`

**响应** `200 OK`：
```json
{
  "success": true,
  "data": [
    {
      "id": "b1c2d3e4-...",
      "title": "系统更新公告",
      "summary": "Kirara Server v2.0 正式发布",
      "mediaType": "image",
      "coverImageUrl": "information/b1c2d3e4_media.png",
      "thumbnailUrl": "information/b1c2d3e4_thumbnail.png",
      "externalUrl": null,
      "sortOrder": 0,
      "version": 1,
      "createdAt": "2026-07-27T12:00:00Z"
    }
  ]
}
```

### 10.3 获取单张信息流卡片详情

```
GET /api/info-cards/{id}
```

**认证**：✅ 需要 `[Authorize]`

**路径参数**：`id` — 信息流卡片 UUID

**响应** `200 OK`：返回结构与列表项一致，额外包含 `updatedAt` 字段。

**响应** `404`：`{ code: "NOT_FOUND", message: "信息流卡片不存在" }`

---

### 10.4 获取信息流卡片主媒体

```
GET /api/info-cards/{id}/media
```

**认证**：✅ 需要 `[Authorize]`

**路径参数**：`id` — 信息流卡片 UUID

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "presignedUrl": "http://minio:9000/kirara-storage/information/...png?X-Amz-Algorithm=..." }
}
```

**响应** `404`：`{ code: "NOT_FOUND", message: "信息流卡片媒体不存在" }`

---

### 10.5 获取信息流卡片缩略图

```
GET /api/info-cards/{id}/thumbnail
```

**认证**：✅ 需要 `[Authorize]`

**路径参数**：`id` — 信息流卡片 UUID

**响应** `200 OK`：同主媒体结构，返回 `presignedUrl` 字段。

**响应** `404`：`{ code: "NOT_FOUND", message: "信息流卡片缩略图不存在" }`

---

### 10.6 增量同步

```
POST /api/info-cards/sync
```

**认证**：✅ 需要 `[Authorize]`

**请求体**：
```json
{
  "localVersions": {
    "b1c2d3e4-...": 1
  }
}
```

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "serverEpoch": 638636256000000000,
    "updated": [ /* 版本更新的卡片 */ ],
    "new": [ /* 客户端没有的新卡片 */ ],
    "deactivated": [ "f1e2d3c4-..." ]
  }
}
```

| 字段 | 说明 |
|------|------|
| `serverEpoch` | 服务端时间戳，可用于下次同步 |
| `updated` | 客户端版本 < 服务端版本的卡片 |
| `new` | 客户端未持有的新卡片 |
| `deactivated` | 服务端已停用但客户端持有的卡片 ID 列表 |

---

### 10.7 管理端点（Admin）

#### 新增卡片

```
POST /api/admin/info-cards
```

**认证**：✅ Admin

**请求体**：
```json
{
  "title": "系统更新公告",
  "summary": "简短描述",
  "mediaType": "image",
  "sortOrder": 0
}
```

**响应** `201 Created`：`{ "data": { "id": "...", "title": "..." } }`

#### 更新卡片

```
PUT /api/admin/info-cards/{id}
```

**认证**：✅ Admin  
所有字段可选，`Version++`

#### 删除卡片

```
DELETE /api/admin/info-cards/{id}
```

**认证**：✅ Admin

#### 上传媒体

```
PUT /api/admin/info-cards/{id}/media
PUT /api/admin/info-cards/{id}/thumbnail
```

**认证**：✅ Admin  
`multipart/form-data`，最大 50MB，自动生成 MinIO 键 `information/{id}_media{ext}` / `information/{id}_thumbnail{ext}`

### 10.8 客户端接入建议

```csharp
// 启动时同步
var localVersions = LoadLocalVersions(); // 从本地缓存读取
var response = await http.PostAsJsonAsync("/api/info-cards/sync", new { localVersions });
var result = await response.Content.ReadFromJsonAsync<ApiResponse<SyncResult>>();

// 更新本地缓存
foreach (var card in result.Data.new.Concat(result.Data.updated))
{
    SaveCardToLocalDb(card);
}

// WebView2 渲染
var html = BuildInfoCardHtml(card); // 根据 mediaType 构建 HTML
webView.CoreWebView2.NavigateToString(html);
```

---

## 十一、首页评论 API (`/api/homepage-comments`)

首页评论是独立的评论系统，用于用户在视频底下评论并分享到首页展示。数据模型与普通评论一致，但存储于独立的 `HomepageComments` 表。**所有端点均需要登录认证**。

### 11.1 数据模型

```
┌──────────┐     ┌──────────────────┐     ┌─────────────────────┐
│   User   │1──N│ HomepageComment  │1──N│ HomepageCommentLike │
└──────────┘     │                  │     │                     │
                 ├──────────────────┤     ├─────────────────────┤
                 │ Id (UUID PK)     │     │ UserId (PK, FK)     │
                 │ ResourceKey      │     │ HomepageCommentId   │
                 │ SchemeId         │     │     (PK, FK)        │
                 │ UserId    FK     │     │ CreatedAt           │
                 │ Content          │     └─────────────────────┘
                 │ AuthorName       │
                 │ LikeCount        │
                 │ CreatedAt        │
                 │ UpdatedAt        │
                 └──────────────────┘
```

### HomepageCommentResponse 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | UUID | 评论 ID |
| `resourceKey` | string | 资源标识，格式 `{scheme}://{instanceId}` |
| `schemeId` | UUID | 所属方案 ID |
| `userId` | UUID | 作者 ID |
| `content` | string | 评论内容，最长 5000 |
| `contentTitle` | string? | 视频标题（创建时从客户端传入） |
| `authorName` | string | 作者显示名 |
| `authorAvatarUrl` | string? | 作者头像对象键 |
| `likeCount` | int | 点赞数 |
| `isLikedByUser` | bool | 当前用户是否点赞 |
| `createdAt` | datetime | 创建时间 UTC |
| `updatedAt` | datetime? | 更新时间 UTC |

### 11.2 获取首页评论列表

```
GET /api/homepage-comments?page=1&pageSize=20
```

**认证**：✅ 需要 `[Authorize]`

**查询参数**：

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `page` | int | ❌ | 默认 1 |
| `pageSize` | int | ❌ | 默认 20，最大 100 |

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "items": [
      {
        "id": "e1f2a3b4-...",
        "resourceKey": "video://homepage123",
        "schemeId": "a1000001-...",
        "userId": "4d032410-...",
        "content": "这个视频太棒了！分享给大家看",
        "authorName": "测试用户",
        "authorAvatarUrl": null,
        "likeCount": 5,
        "isLikedByUser": false,
        "createdAt": "2026-08-01T10:00:00Z"
      }
    ],
    "page": 1,
    "pageSize": 20,
    "totalCount": 1,
    "totalPages": 1
  }
}
```

---

### 11.3 获取单条首页评论

```
GET /api/homepage-comments/{id}
```

**认证**：✅ 需要 `[Authorize]`

**响应** `200 OK`：返回单条 HomepageCommentResponse。

**响应** `404`：`{ code: "NOT_FOUND", message: "评论不存在" }`

---

### 11.4 创建首页评论

```
POST /api/homepage-comments
```

**认证**：✅ 需要 `[Authorize]`

**请求体**：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `resourceKey` | string | ✅ | 必须包含 `://` 分隔符 |
| `schemeId` | UUID | ✅ | 方案 ID |
| `content` | string | ✅ | 1~5000 字符 |
| `contentTitle` | string | ❌ | 视频标题，最长 500，用于互动通知文案 |

```json
{
  "resourceKey": "video://homepage123",
  "schemeId": "a1000001-...",
  "content": "这个视频太棒了！分享给大家看",
  "contentTitle": "分享视频标题"
}
```

**响应** `201 Created`：返回创建的 HomepageCommentResponse。

---

### 11.5 更新首页评论

```
PUT /api/homepage-comments/{id}
```

**认证**：✅ 需要 `[Authorize]`（仅作者或管理员）

**请求体**：
```json
{
  "content": "更新后的内容"
}
```

**响应** `200 OK`：`{ "data": { "message": "评论已更新" } }`

---

### 11.6 删除首页评论

```
DELETE /api/homepage-comments/{id}
```

**认证**：✅ 需要 `[Authorize]`（仅作者或管理员）

**响应** `200 OK`：`{ "data": { "message": "评论已删除" } }`

---

### 11.7 切换首页评论点赞

```
POST /api/homepage-comments/{id}/toggle-like
```

**认证**：✅ 需要 `[Authorize]`

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "liked": true,
    "likeCount": 6
  }
}
```

---

## 十二、OpenVPN 配置 API (`/api/openvpn`)

OpenVPN 配置模块提供 `.ovpn` 格式配置文件的查看、下载、上传（覆盖更新）与删除。配置文件存储于 MinIO 根目录的 `openvpn/` 文件夹下，版本号维护在 `ResourceVersions` 表（每次覆盖上传 `Version++`）。

**权限说明**：
- **查看 / 下载**：需要登录认证（`[Authorize]`）
- **上传（覆盖更新）/ 删除**：需要 Admin 权限（`[RequireAdmin]`）

### 12.1 获取配置信息

```
GET /api/openvpn
```

**认证**：✅ 需要 `[Authorize]`

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "version": 3,
    "configKey": "openvpn/config.ovpn"
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `version` | int | 配置文件版本号，客户端可用于缓存比对 |
| `configKey` | string | 系统键形式的存储地址（MinIO 对象键） |

**响应** `404`：`{ code: "NOT_FOUND", message: "OpenVPN 配置文件不存在" }`

---

### 12.2 获取配置文件下载 URL

```
GET /api/openvpn/download
```

**认证**：✅ 需要 `[Authorize]`

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "downloadUrl": "http://10.10.10.11:9000/kirara-storage/openvpn/config.ovpn?X-Amz-Algorithm=..."
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `downloadUrl` | string | MinIO 预签名下载 URL（1 小时有效），客户端可直接访问下载 |

> **客户端处理**：直接使用返回的预签名 URL 发起下载请求即可，无需额外认证。

**响应** `404`：`{ code: "NOT_FOUND", message: "OpenVPN 配置文件不存在" }`

---

### 12.3 上传 / 覆盖配置文件（仅管理员）

```
PUT /api/openvpn
```

**认证**：✅ Admin

**请求格式**：`multipart/form-data`

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `file` | File | ✅ | `.ovpn` 配置文件，最大 **1MB** |

> **说明**：不设单独的配置文件更新功能，已有配置文件再次上传直接覆盖更新，然后 `Version++`。

**存储路径**：MinIO `openvpn/config.ovpn`

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "message": "OpenVPN 配置文件已更新",
    "version": 4
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `message` | string | 操作提示 |
| `version` | int | 更新后的版本号 |

---

### 12.4 删除配置文件（仅管理员）

```
DELETE /api/openvpn
```

**认证**：✅ Admin

**响应** `200 OK`：
```json
{
  "success": true,
  "data": { "message": "OpenVPN 配置文件已删除" }
}
```

> **服务端行为**：删除 MinIO `openvpn/config.ovpn` 对象，并移除对应的版本记录。

**响应** `404`：`{ code: "NOT_FOUND", message: "OpenVPN 配置文件不存在" }`

---

## 十三、应用更新 API (`/api/app/updates`)

应用更新模块提供客户端软件版本校对与发布管理。安装包托管于 Alist 直链，服务端仅登记版本号 + 下载链接 + 哈希 + 说明（**不接收文件**）。版本号唯一索引；登记新版本时自动停用旧记录。

**权限说明**：
- **版本校对**（`/api/app/updates/latest`）：公开，无需登录，客户端只问"有没有新版本"，比对策略集中在服务端
- **发布管理**（`/api/admin/app-releases`）：仅管理员

### 13.1 版本校对（公开）

```
GET /api/app/updates/latest?current=0.9.1
```

**认证**：❌ 不需要（未登录用户也要能检查更新）

**查询参数**：

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `current` | string | ❌ | 客户端当前版本（语义化版本号；非法格式按 `0.0.0` 处理，不报错） |

**服务端比对逻辑**（策略集中在服务端）：
1. 取 `IsActive=true` 的记录中版本号最高的一条（按语义化版本排序，非字符串排序）
2. `hasUpdate = latest != null && Version.Parse(latest.Version) > Version.Parse(current)`
3. 返回结论 + 下载信息（下载信息仅 `hasUpdate=true` 时填充）

**响应** `200 OK`：
```json
{
  "success": true,
  "data": {
    "hasUpdate": true,
    "latestVersion": "0.9.2",
    "downloadUrl": "https://alist.akeno6388.online/d/kirara-updates/Kirara_Server_Setup_0.9.2_x64.exe",
    "sha256": "6f4b8c...",
    "releaseNotes": "- 修复 OpenVPN 断线重连",
    "isMandatory": false,
    "publishedAt": "2026-08-06T10:00:00Z"
  },
  "timestamp": "2026-08-06T10:00:00Z"
}
```

`hasUpdate=false` 时 `latestVersion` 等字段返回 `null`。

**错误响应**：无业务错误分支（查询失败走全局 `INTERNAL_ERROR`），无需新增错误码。

---

### 13.2 登记发布（仅管理员）

```
POST /api/admin/app-releases
```

**认证**：✅ Admin

**请求体**（纯 JSON，服务端不接收文件）：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `version` | string | ✅ | 语义化版本号，必须可通过 `Version.TryParse`，唯一（非法 → 400 `VALIDATION_ERROR`） |
| `downloadUrl` | string | ✅ | 安装包直链，必须为 `https://` 开头的合法 URL |
| `sha256` | string | ❌ | 安装包 SHA-256（客户端下载后校验） |
| `releaseNotes` | string | ❌ | 版本说明 |
| `isMandatory` | bool | ❌ | 是否强制更新，默认 false |

**请求示例**：
```json
{
  "version": "0.9.2",
  "downloadUrl": "https://alist.akeno6388.online/d/kirara-updates/Kirara_Server_Setup_0.9.2_x64.exe",
  "sha256": "6f4b8c...",
  "releaseNotes": "- 修复 OpenVPN 断线重连\n- 新增 RDP 方案",
  "isMandatory": false
}
```

**服务端行为**：
1. 校验版本号格式 + 下载链接
2. `version` 已存在 → `409 CONFLICT`（错误码 `CONFLICT`，"该版本已登记"）
3. 登记后**自动将旧记录的 `IsActive` 置为 false**（保证 latest 查询只返回最新一条），新记录 `IsActive=true`
4. `PublishedAt = DateTime.UtcNow`

**响应** `201 Created`：
```json
{
  "success": true,
  "data": {
    "id": "guid",
    "version": "0.9.2",
    "downloadUrl": "https://...",
    "sha256": "6f4b8c...",
    "releaseNotes": "...",
    "isMandatory": false,
    "isActive": true,
    "publishedAt": "2026-08-06T10:00:00Z"
  },
  "timestamp": "..."
}
```

**错误响应**：`VALIDATION_ERROR`(400) / `CONFLICT`(409) / `FORBIDDEN`(403，非 Admin)。

---

### 13.3 发布列表（仅管理员）

```
GET /api/admin/app-releases?page=1&pageSize=20
```

**认证**：✅ Admin

**查询参数**：`page`（默认 1）、`pageSize`（默认 20，最大 100），遵循现有分页规范。

**响应** `200 OK`：分页结构 `{ items: [AppReleaseDto...], page, pageSize, totalCount, totalPages }`，按 `PublishedAt` 倒序。

用途：管理端核对已登记的版本、查看当前活跃版本、定位要撤销的记录。

---

### 13.4 更新发布（仅管理员）

```
PUT /api/admin/app-releases/{id}
```

**认证**：✅ Admin

**请求体**（全部可选，部分更新）：

| 字段 | 类型 | 说明 |
|------|------|------|
| `downloadUrl` | string? | 新的直链 |
| `sha256` | string? | 新的哈希 |
| `releaseNotes` | string? | 新的版本说明 |
| `isMandatory` | bool? | 是否强制更新 |
| `isActive` | bool? | 设为 `false` 可**紧急撤回发布**（latest 立即不再返回该版本） |

**响应** `200 OK`：返回更新后的完整记录；`404 NOT_FOUND` 记录不存在。

> **注意**：**版本号本身不可修改**（版本号是唯一索引，改版本应删旧建新）。

---

### 13.5 撤销发布（仅管理员）

```
DELETE /api/admin/app-releases/{id}
```

**认证**：✅ Admin

**响应**：`204 No Content`；`404 NOT_FOUND` 不存在。

**服务端行为**：彻底移除登记错误的版本记录。删除当前活跃版本后，latest 自动回退到下一个最新版本（无需额外逻辑）。

> **计划**：更新日志（`GET /api/app/updates/history`）与升级结果上报（`POST /api/app/updates/report` + 管理端升级统计）为可选 API，暂未开发。

---

## 十四、计划与展望

以下端点为远期规划，当前尚未实现：

| 端点 | 方法 | 说明 | 计划 |
|------|------|------|------|
| `POST /api/sync/instances` | ✅ | 实例配置同步 | 🔮 |
| `GET /api/sync/instances` | ❌ | 实例配置下载 | 🔮 |
| `POST /api/sync/tokens` | ✅ | 令牌配置同步（端到端加密） | 🔮 |
| `GET /api/sync/tokens` | ✅ | 令牌配置下载 | 🔮 |
| `GET /api/resources/{resourceKey}/download` | ❌ | 通用资源下载 | 🔮 |
| `POST /api/resources/sync` | ✅ | 资源批量同步 | 🔮 |

---

## 十五、附录

### 14.1 客户端接入指南

客户端从本地 LiteDB 切换到远程 API 时，遵循 **接口不变 + DI 替换** 原则：

```
客户端当前（本地模式）:                    客户端未来（远程模式）:
ILoginService → LoginService (LiteDB)      ILoginService → RemoteLoginService (HTTP)
ICommentService → CommentService (LiteDB)  ICommentService → RemoteCommentService (HTTP)
IServerUrlService → ServerUrlService (DB)  IServerUrlService → RemoteServerUrlService (HTTP)
```

> 客户端 `Services/` 层已为所有可能远程化的服务预留了 `// TODO: 远程数据库` 桩注释，切换到远程 API 时**无需改动任何 ViewModel 或 XAML 文件**。

### 14.2 测试用 curl 命令

```powershell
# ════════════════════════════════════════════
# 认证
# ════════════════════════════════════════════

# 注册
curl.exe -X POST "http://localhost:5340/api/auth/register" -H "Content-Type: application/json" -d "{\"username\":\"testdev\",\"password\":\"Test123456\",\"nickname\":\"测试开发者\"}"

# 登录（保存返回的 accessToken）
curl.exe -X POST "http://localhost:5340/api/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"testdev\",\"password\":\"Test123456\"}"

# 修改用户名
curl.exe -X PUT "http://localhost:5340/api/auth/me/username" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"newUsername\":\"newuser\"}"

# 修改密码
curl.exe -X PUT "http://localhost:5340/api/auth/me/password" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"currentPassword\":\"OldP@ss\",\"newPassword\":\"NewP@ss123\"}"

# 获取自动登录状态
curl.exe -X GET "http://localhost:5340/api/auth/me/auto-login" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# 评论
# ════════════════════════════════════════════

# 创建评论（替换 <token>，contentTitle 为视频标题，可选）
curl.exe -X POST "http://localhost:5340/api/comments" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"resourceKey\":\"media://dev123\",\"schemeId\":\"a1000001-0000-0000-0000-000000000001\",\"content\":\"测试评论\",\"contentTitle\":\"测试视频标题\"}"

# 获取评论列表
curl.exe -X GET "http://localhost:5340/api/comments?resourceKey=media://dev123&schemeId=a1000001-0000-0000-0000-000000000001" -H "Authorization: Bearer <token>"

# 按资源键全量查询评论（跨方案）
curl.exe -X GET "http://localhost:5340/api/comments/by-resource?resourceKey=media://dev123&page=1&pageSize=20" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# 模板
# ════════════════════════════════════════════

# 获取所有模板
curl.exe -X GET "http://localhost:5340/api/templates"

# 获取单个模板（替换 <templateId>）
curl.exe -X GET "http://localhost:5340/api/templates/<templateId>"

# 获取模板封面图片（302 重定向）
curl.exe -X GET "http://localhost:5340/api/templates/<templateId>/cover"

# ════════════════════════════════════════════
# 方案 URL（需登录，替换 <token>）
# ════════════════════════════════════════════

# 获取全部方案 URL
curl.exe -X GET "http://localhost:5340/api/scheme-urls" -H "Authorization: Bearer <token>"

# 按分类过滤
curl.exe -X GET "http://localhost:5340/api/scheme-urls?category=RDP" -H "Authorization: Bearer <token>"

# 增量同步方案 URL
curl.exe -X POST "http://localhost:5340/api/scheme-urls/sync" -H "Content-Type: application/json" -H "Authorization: Bearer <token>" -d "{\"clientVersion\":\"1.0.1\",\"localVersions\":{\"media\":6,\"drive\":1}}"

# 获取方案封面图片（302 重定向）
curl.exe -X GET "http://localhost:5340/api/scheme-urls/media/image" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# 资源
# ════════════════════════════════════════════

# 上传头像
curl.exe -X PUT "http://localhost:5340/api/resources/user-avatar" -H "Authorization: Bearer <token>" -F "file=@avatar.png"

# 获取头像
curl.exe -X GET "http://localhost:5340/api/resources/user-avatar/<userId>"

# 获取首页背景图
curl.exe -X GET "http://localhost:5340/api/resources/home-background"

# 上传首页背景图（需 Admin Token）
curl.exe -X PUT "http://localhost:5340/api/resources/home-background" -H "Authorization: Bearer <admin_token>" -F "file=@background.jpg"

# ════════════════════════════════════════════
# 通知系统（需登录，替换 <token>）
# ════════════════════════════════════════════

# 获取通知列表
curl.exe -X GET "http://localhost:5340/api/notifications?page=1&pageSize=20" -H "Authorization: Bearer <token>"

# 获取未读通知数
curl.exe -X GET "http://localhost:5340/api/notifications/unread-count" -H "Authorization: Bearer <token>"

# 标记单条已读（替换 <notificationId>）
curl.exe -X PATCH "http://localhost:5340/api/notifications/<notificationId>/read" -H "Authorization: Bearer <token>"

# 标记全部已读
curl.exe -X PUT "http://localhost:5340/api/notifications/read-all" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# 管理（需 Admin Token）
# ════════════════════════════════════════════

# 获取用户列表
curl.exe -X GET "http://localhost:5340/api/admin/users" -H "Authorization: Bearer <admin_token>"

# 修改用户角色
curl.exe -X PUT "http://localhost:5340/api/admin/users/<userId>/role" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"role\":\"Admin\"}"

# 删除用户
curl.exe -X DELETE "http://localhost:5340/api/admin/users/<userId>" -H "Authorization: Bearer <admin_token>"

# 更新方案 URL
curl.exe -X PUT "http://localhost:5340/api/admin/scheme-urls/media" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"url\":\"https://media-new.example.com\",\"changeReason\":\"迁移\",\"isActive\":true}"

# 上传方案图片
curl.exe -X PUT "http://localhost:5340/api/admin/scheme-urls/media/image" -H "Authorization: Bearer <admin_token>" -F "file=@scheme.png"

# 广播通知（全部用户）
curl.exe -X POST "http://localhost:5340/api/admin/notifications/broadcast" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"title\":\"测试通知\",\"content\":\"这是一条测试\",\"targetType\":0}"

# 新增模板
curl.exe -X POST "http://localhost:5340/api/admin/templates" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"name\":\"影音娱乐\",\"description\":\"Jellyfin 媒体服务\",\"category\":\"media\",\"tags\":\"影音,媒体\"}"

# 上传模板封面
curl.exe -X PUT "http://localhost:5340/api/admin/templates/<templateId>/cover" -H "Authorization: Bearer <admin_token>" -F "file=@cover.jpg"

# ════════════════════════════════════════════
# 信息流卡片（Admin，需 Admin Token）
# ════════════════════════════════════════════

# 获取所有活跃信息流卡片（需登录）
curl.exe -X GET "http://localhost:5340/api/info-cards" -H "Authorization: Bearer <token>"

# 获取单张卡片详情（需登录）
curl.exe -X GET "http://localhost:5340/api/info-cards/<cardId>" -H "Authorization: Bearer <token>"

# 增量同步信息流卡片（需登录）
curl.exe -X POST "http://localhost:5340/api/info-cards/sync" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"localVersions\":{}}"

# 新增信息流卡片（Admin）
curl.exe -X POST "http://localhost:5340/api/admin/info-cards" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"title\":\"系统更新公告\",\"summary\":\"简短描述\",\"mediaType\":\"image\",\"sortOrder\":0}"

# 更新信息流卡片（Admin）
curl.exe -X PUT "http://localhost:5340/api/admin/info-cards/<cardId>" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"title\":\"新标题\",\"isActive\":true}"

# 删除信息流卡片（Admin）
curl.exe -X DELETE "http://localhost:5340/api/admin/info-cards/<cardId>" -H "Authorization: Bearer <admin_token>"

# 上传信息流卡片主媒体（Admin）
curl.exe -X PUT "http://localhost:5340/api/admin/info-cards/<cardId>/media" -H "Authorization: Bearer <admin_token>" -F "file=@media.mp4"

# 上传信息流卡片缩略图（Admin）
curl.exe -X PUT "http://localhost:5340/api/admin/info-cards/<cardId>/thumbnail" -H "Authorization: Bearer <admin_token>" -F "file=@thumbnail.jpg"

# ════════════════════════════════════════════
# 信息流卡片媒体获取（需登录）
# ════════════════════════════════════════════

# 获取信息流卡片主媒体预签名 URL
curl.exe -X GET "http://localhost:5340/api/info-cards/<cardId>/media" -H "Authorization: Bearer <token>"

# 获取信息流卡片缩略图预签名 URL
curl.exe -X GET "http://localhost:5340/api/info-cards/<cardId>/thumbnail" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# 注册功能开关（需 Admin Token）
# ════════════════════════════════════════════

# 获取注册功能状态
curl.exe -X GET "http://localhost:5340/api/admin/settings/registration" -H "Authorization: Bearer <admin_token>"

# 关闭注册功能
curl.exe -X PUT "http://localhost:5340/api/admin/settings/registration" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"enabled\":false}"

# 重新开启注册功能
curl.exe -X PUT "http://localhost:5340/api/admin/settings/registration" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"enabled\":true}"

# ════════════════════════════════════════════
# 健康
# ════════════════════════════════════════════

curl.exe -X GET "http://localhost:5340/api/health"

# ════════════════════════════════════════════
# 首页评论
# ════════════════════════════════════════════

# 获取首页评论列表（需认证）
curl.exe -X GET "http://localhost:5340/api/homepage-comments?page=1&pageSize=20" -H "Authorization: Bearer <token>"

# 获取单条首页评论（需认证）
curl.exe -X GET "http://localhost:5340/api/homepage-comments/<id>" -H "Authorization: Bearer <token>"

# 创建首页评论（需登录，contentTitle 为视频标题，可选）
curl.exe -X POST "http://localhost:5340/api/homepage-comments" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"resourceKey\":\"video://homepage123\",\"schemeId\":\"a1000001-0000-0000-0000-000000000001\",\"content\":\"这个视频太棒了！\",\"contentTitle\":\"分享视频标题\"}"

# 切换首页评论点赞（需登录）
curl.exe -X POST "http://localhost:5340/api/homepage-comments/<id>/toggle-like" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# OpenVPN 配置（需登录，上传/删除需 Admin Token）
# ════════════════════════════════════════════

# 获取 OpenVPN 配置信息（版本号 + 系统键形式的存储地址，需登录）
curl.exe -X GET "http://localhost:5340/api/openvpn" -H "Authorization: Bearer <token>"

# 获取 OpenVPN 配置文件预签名下载 URL（需登录）
curl.exe -X GET "http://localhost:5340/api/openvpn/download" -H "Authorization: Bearer <token>"

# 上传/覆盖 OpenVPN 配置文件（Version++，仅管理员）
curl.exe -X PUT "http://localhost:5340/api/openvpn" -H "Authorization: Bearer <admin_token>" -F "file=@client.ovpn"

# 删除 OpenVPN 配置文件（仅管理员）
curl.exe -X DELETE "http://localhost:5340/api/openvpn" -H "Authorization: Bearer <admin_token>"

# ════════════════════════════════════════════
# 应用更新（版本校对公开，管理需 Admin Token）
# ════════════════════════════════════════════

# 版本校对（公开，无需登录）
curl.exe -X GET "http://localhost:5340/api/app/updates/latest?current=0.9.1"

# 登记新发布（Admin）
curl.exe -X POST "http://localhost:5340/api/admin/app-releases" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"version\":\"0.9.2\",\"downloadUrl\":\"https://alist.akeno6388.online/d/kirara-updates/Kirara_Server_Setup_0.9.2_x64.exe\",\"sha256\":\"6f4b8c...\",\"releaseNotes\":\"- 修复 OpenVPN 断线重连\",\"isMandatory\":false}"

# 发布列表（Admin）
curl.exe -X GET "http://localhost:5340/api/admin/app-releases?page=1&pageSize=20" -H "Authorization: Bearer <admin_token>"

# 更新发布（Admin，可撤回 isActive=false）
curl.exe -X PUT "http://localhost:5340/api/admin/app-releases/<releaseId>" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"isActive\":false}"

# 撤销发布（Admin）
curl.exe -X DELETE "http://localhost:5340/api/admin/app-releases/<releaseId>" -H "Authorization: Bearer <admin_token>"
```

> **提示**：以上命令使用开发环境地址 `http://localhost:5340`。生产环境请将地址替换为 `https://api.akeno6388.online:1010`，详见下方生产环境版本。

#### 生产环境 curl 命令

```powershell
# ════════════════════════════════════════════
# 认证（生产环境）
# ════════════════════════════════════════════

# 注册
curl.exe -X POST "https://api.akeno6388.online:1010/api/auth/register" -H "Content-Type: application/json" -d "{\"username\":\"testdev\",\"password\":\"Test123456\",\"nickname\":\"测试开发者\"}"

# 登录（保存返回的 accessToken）
curl.exe -X POST "https://api.akeno6388.online:1010/api/auth/login" -H "Content-Type: application/json" -d "{\"username\":\"testdev\",\"password\":\"Test123456\"}"

# 修改用户名
curl.exe -X PUT "https://api.akeno6388.online:1010/api/auth/me/username" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"newUsername\":\"newuser\"}"

# 修改密码
curl.exe -X PUT "https://api.akeno6388.online:1010/api/auth/me/password" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"currentPassword\":\"OldP@ss\",\"newPassword\":\"NewP@ss123\"}"

# 获取自动登录状态
curl.exe -X GET "https://api.akeno6388.online:1010/api/auth/me/auto-login" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# 评论（生产环境）
# ════════════════════════════════════════════

# 创建评论（替换 <token>，contentTitle 为视频标题，可选）
curl.exe -X POST "https://api.akeno6388.online:1010/api/comments" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"resourceKey\":\"media://dev123\",\"schemeId\":\"a1000001-0000-0000-0000-000000000001\",\"content\":\"测试评论\",\"contentTitle\":\"测试视频标题\"}"

# 获取评论列表（需认证）
curl.exe -X GET "https://api.akeno6388.online:1010/api/comments?resourceKey=media://dev123&schemeId=a1000001-0000-0000-0000-000000000001" -H "Authorization: Bearer <token>"

# 按资源键全量查询评论（需认证）
curl.exe -X GET "https://api.akeno6388.online:1010/api/comments/by-resource?resourceKey=media://dev123&page=1&pageSize=20" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# 模板（生产环境）
# ════════════════════════════════════════════

# 获取所有模板
curl.exe -X GET "https://api.akeno6388.online:1010/api/templates"

# 获取单个模板（替换 <templateId>）
curl.exe -X GET "https://api.akeno6388.online:1010/api/templates/<templateId>"

# 获取模板封面图片（302 重定向）
curl.exe -X GET "https://api.akeno6388.online:1010/api/templates/<templateId>/cover"

# ════════════════════════════════════════════
# 方案 URL（生产环境，需登录）
# ════════════════════════════════════════════

# 获取全部方案 URL
curl.exe -X GET "https://api.akeno6388.online:1010/api/scheme-urls" -H "Authorization: Bearer <token>"

# 按分类过滤
curl.exe -X GET "https://api.akeno6388.online:1010/api/scheme-urls?category=RDP" -H "Authorization: Bearer <token>"

# 增量同步方案 URL
curl.exe -X POST "https://api.akeno6388.online:1010/api/scheme-urls/sync" -H "Content-Type: application/json" -H "Authorization: Bearer <token>" -d "{\"clientVersion\":\"1.0.1\",\"localVersions\":{\"media\":6,\"drive\":1}}"

# 获取方案封面图片（302 重定向）
curl.exe -X GET "https://api.akeno6388.online:1010/api/scheme-urls/media/image" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# 资源（生产环境）
# ════════════════════════════════════════════

# 上传头像
curl.exe -X PUT "https://api.akeno6388.online:1010/api/resources/user-avatar" -H "Authorization: Bearer <token>" -F "file=@avatar.png"

# 获取头像
curl.exe -X GET "https://api.akeno6388.online:1010/api/resources/user-avatar/<userId>"

# 获取首页背景图
curl.exe -X GET "https://api.akeno6388.online:1010/api/resources/home-background"

# 上传首页背景图（需 Admin Token）
curl.exe -X PUT "https://api.akeno6388.online:1010/api/resources/home-background" -H "Authorization: Bearer <admin_token>" -F "file=@background.jpg"

# ════════════════════════════════════════════
# 通知系统（生产环境，需登录）
# ════════════════════════════════════════════

# 获取通知列表
curl.exe -X GET "https://api.akeno6388.online:1010/api/notifications?page=1&pageSize=20" -H "Authorization: Bearer <token>"

# 获取未读通知数
curl.exe -X GET "https://api.akeno6388.online:1010/api/notifications/unread-count" -H "Authorization: Bearer <token>"

# 标记单条已读（替换 <notificationId>）
curl.exe -X PATCH "https://api.akeno6388.online:1010/api/notifications/<notificationId>/read" -H "Authorization: Bearer <token>"

# 标记全部已读
curl.exe -X PUT "https://api.akeno6388.online:1010/api/notifications/read-all" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# 管理（生产环境，需 Admin Token）
# ════════════════════════════════════════════

# 获取用户列表
curl.exe -X GET "https://api.akeno6388.online:1010/api/admin/users" -H "Authorization: Bearer <admin_token>"

# 修改用户角色
curl.exe -X PUT "https://api.akeno6388.online:1010/api/admin/users/<userId>/role" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"role\":\"Admin\"}"

# 删除用户
curl.exe -X DELETE "https://api.akeno6388.online:1010/api/admin/users/<userId>" -H "Authorization: Bearer <admin_token>"

# 更新方案 URL
curl.exe -X PUT "https://api.akeno6388.online:1010/api/admin/scheme-urls/media" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"url\":\"https://media-new.example.com\",\"changeReason\":\"迁移\",\"isActive\":true}"

# 上传方案图片
curl.exe -X PUT "https://api.akeno6388.online:1010/api/admin/scheme-urls/media/image" -H "Authorization: Bearer <admin_token>" -F "file=@scheme.png"

# 广播通知（全部用户）
curl.exe -X POST "https://api.akeno6388.online:1010/api/admin/notifications/broadcast" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"title\":\"测试通知\",\"content\":\"这是一条测试\",\"targetType\":0}"

# 新增模板
curl.exe -X POST "https://api.akeno6388.online:1010/api/admin/templates" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"name\":\"影音娱乐\",\"description\":\"Jellyfin 媒体服务\",\"category\":\"media\",\"tags\":\"影音,媒体\"}"

# 上传模板封面
curl.exe -X PUT "https://api.akeno6388.online:1010/api/admin/templates/<templateId>/cover" -H "Authorization: Bearer <admin_token>" -F "file=@cover.jpg"

# ════════════════════════════════════════════
# 信息流卡片（生产环境，需登录）
# ════════════════════════════════════════════

# 获取所有活跃信息流卡片（需登录）
curl.exe -X GET "https://api.akeno6388.online:1010/api/info-cards" -H "Authorization: Bearer <token>"

# 获取单张卡片详情（需登录）
curl.exe -X GET "https://api.akeno6388.online:1010/api/info-cards/<cardId>" -H "Authorization: Bearer <token>"

# 增量同步信息流卡片（需登录）
curl.exe -X POST "https://api.akeno6388.online:1010/api/info-cards/sync" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"localVersions\":{}}"

# 新增信息流卡片（Admin）
curl.exe -X POST "https://api.akeno6388.online:1010/api/admin/info-cards" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"title\":\"系统更新公告\",\"summary\":\"简短描述\",\"mediaType\":\"image\",\"sortOrder\":0}"

# 更新信息流卡片（Admin）
curl.exe -X PUT "https://api.akeno6388.online:1010/api/admin/info-cards/<cardId>" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"title\":\"新标题\",\"isActive\":true}"

# 删除信息流卡片（Admin）
curl.exe -X DELETE "https://api.akeno6388.online:1010/api/admin/info-cards/<cardId>" -H "Authorization: Bearer <admin_token>"

# 上传信息流卡片主媒体（Admin）
curl.exe -X PUT "https://api.akeno6388.online:1010/api/admin/info-cards/<cardId>/media" -H "Authorization: Bearer <admin_token>" -F "file=@media.mp4"

# 上传信息流卡片缩略图（Admin）
curl.exe -X PUT "https://api.akeno6388.online:1010/api/admin/info-cards/<cardId>/thumbnail" -H "Authorization: Bearer <admin_token>" -F "file=@thumbnail.jpg"

# ════════════════════════════════════════════
# 信息流卡片媒体获取（生产环境，需登录）
# ════════════════════════════════════════════

# 获取信息流卡片主媒体预签名 URL
curl.exe -X GET "https://api.akeno6388.online:1010/api/info-cards/<cardId>/media" -H "Authorization: Bearer <token>"

# 获取信息流卡片缩略图预签名 URL
curl.exe -X GET "https://api.akeno6388.online:1010/api/info-cards/<cardId>/thumbnail" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# 注册功能开关（生产环境，需 Admin Token）
# ════════════════════════════════════════════

# 获取注册功能状态
curl.exe -X GET "https://api.akeno6388.online:1010/api/admin/settings/registration" -H "Authorization: Bearer <admin_token>"

# 关闭注册功能
curl.exe -X PUT "https://api.akeno6388.online:1010/api/admin/settings/registration" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"enabled\":false}"

# 重新开启注册功能
curl.exe -X PUT "https://api.akeno6388.online:1010/api/admin/settings/registration" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"enabled\":true}"

# ════════════════════════════════════════════
# 健康检查（生产环境）
# ════════════════════════════════════════════

curl.exe -X GET "https://api.akeno6388.online:1010/api/health"

# ════════════════════════════════════════════
# 首页评论（生产环境）
# ════════════════════════════════════════════

# 获取首页评论列表（需认证）
curl.exe -X GET "https://api.akeno6388.online:1010/api/homepage-comments?page=1&pageSize=20" -H "Authorization: Bearer <token>"

# 获取单条首页评论（需认证）
curl.exe -X GET "https://api.akeno6388.online:1010/api/homepage-comments/<id>" -H "Authorization: Bearer <token>"

# 创建首页评论（需登录，contentTitle 为视频标题，可选）
curl.exe -X POST "https://api.akeno6388.online:1010/api/homepage-comments" -H "Authorization: Bearer <token>" -H "Content-Type: application/json" -d "{\"resourceKey\":\"video://homepage123\",\"schemeId\":\"a1000001-0000-0000-0000-000000000001\",\"content\":\"这个视频太棒了！\",\"contentTitle\":\"分享视频标题\"}"

# 切换首页评论点赞（需登录）
curl.exe -X POST "https://api.akeno6388.online:1010/api/homepage-comments/<id>/toggle-like" -H "Authorization: Bearer <token>"

# ════════════════════════════════════════════
# OpenVPN 配置（生产环境，需登录，上传/删除需 Admin Token）
# ════════════════════════════════════════════

# 获取 OpenVPN 配置信息（版本号 + 系统键形式的存储地址，需登录）
curl.exe -X GET "https://api.akeno6388.online:1010/api/openvpn" -H "Authorization: Bearer <token>"

# 获取 OpenVPN 配置文件预签名下载 URL（需登录）
curl.exe -X GET "https://api.akeno6388.online:1010/api/openvpn/download" -H "Authorization: Bearer <token>"

# 上传/覆盖 OpenVPN 配置文件（Version++，仅管理员）
curl.exe -X PUT "https://api.akeno6388.online:1010/api/openvpn" -H "Authorization: Bearer <admin_token>" -F "file=@client.ovpn"

# 删除 OpenVPN 配置文件（仅管理员）
curl.exe -X DELETE "https://api.akeno6388.online:1010/api/openvpn" -H "Authorization: Bearer <admin_token>"

# ════════════════════════════════════════════
# 应用更新（生产环境，版本校对公开，管理需 Admin Token）
# ════════════════════════════════════════════

# 版本校对（公开，无需登录）
curl.exe -X GET "https://api.akeno6388.online:1010/api/app/updates/latest?current=0.9.1"

# 登记新发布（Admin）
curl.exe -X POST "https://api.akeno6388.online:1010/api/admin/app-releases" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"version\":\"0.9.2\",\"downloadUrl\":\"https://alist.akeno6388.online/d/kirara-updates/Kirara_Server_Setup_0.9.2_x64.exe\",\"sha256\":\"6f4b8c...\",\"releaseNotes\":\"- 修复 OpenVPN 断线重连\",\"isMandatory\":false}"

# 发布列表（Admin）
curl.exe -X GET "https://api.akeno6388.online:1010/api/admin/app-releases?page=1&pageSize=20" -H "Authorization: Bearer <admin_token>"

# 更新发布（Admin，可撤回 isActive=false）
curl.exe -X PUT "https://api.akeno6388.online:1010/api/admin/app-releases/<releaseId>" -H "Authorization: Bearer <admin_token>" -H "Content-Type: application/json" -d "{\"isActive\":false}"

# 撤销发布（Admin）
curl.exe -X DELETE "https://api.akeno6388.online:1010/api/admin/app-releases/<releaseId>" -H "Authorization: Bearer <admin_token>"
```

### 14.3 SignalR 实时通知推送

**端点**：`/hubs/notifications`（WebSocket，需要 JWT 认证）

| 项目 | 说明 |
|------|------|
| **传输协议** | WebSocket（降级到 Server-Sent Events / Long Polling） |
| **认证方式** | `?access_token={jwt}` 查询参数传递 JWT |
| **推送事件** | `ReceiveNotification` — 新通知到达时服务端推送 |
| **分组策略** | 每个客户端连接后自动加入 `UserId.ToString()` 命名的 Group |

**客户端连接示例**（WinUI）：
```csharp
var connection = new HubConnectionBuilder()
    .WithUrl("https://localhost:5340/hubs/notifications?access_token={jwt}")
    .Build();

connection.On<JsonElement>("ReceiveNotification", notification =>
{
    // UI 线程更新通知列表
});

await connection.StartAsync();
```

**触发时机**：
- **广播通知**：管理员调用 `POST /api/admin/notifications/broadcast` 后，服务端自动遍历目标用户列表，通过 SignalR 推送给每个在线的目标用户
- **互动通知**：用户回复评论 / 点赞评论 / 点赞回复 / 点赞首页分享时，服务端自动推送给**内容作者**（见 [7.5 互动通知](#75-互动通知回复点赞自动推送)），推送载荷与 REST 列表一致（含 `actionType` / `actorUserId` / `actorName` / `targetId` / `resourceKey` / `contentTitle` 定位字段）

---

### 14.4 项目架构概览

```
Kirara_Server-API/（5 个项目，45+ 代码文件）
│
├── Kirara_Server-API.Core/           ← 领域层
│   ├── 14 个实体（User, RefreshToken, Comment, Reply, CommentLike,
│   │           ReplyLike, Notification, Template, SchemeUrl,
│   │           ResourceVersion, InformationCard, HomepageComment,
│   │           HomepageCommentLike, AppRelease）
│   ├── 21 个接口（仓储基类 + 各实体 + Auth + Jwt + Comment +
│   │            Admin + FileStorage + Resource + Notification +
│   │            Template + SchemeUrl + InformationCard +
│   │            HomepageComment + OpenVpn + User Repository +
│   │            AppRelease Repository + AppUpdate Service）
│   └── 4 个枚举（UserRole, NotificationCategory, SyncStatus, InteractionActionType）
│
├── Kirara_Server-API.Infrastructure/ ← 基础设施层
│   ├── AppDbContext（14 个 DbSet，含 HomepageComments/HomepageCommentLikes/AppReleases）
│   ├── Hubs/NotificationHub.cs（SignalR 实时推送，含互动通知）
│   ├── Services/InteractionNotifier.cs（互动通知统一组件）
│   ├── 8 个仓储实现（含 AppReleaseRepository）
│   └── 14 个服务实现（含 OpenVpnService/AppUpdateService/InteractionNotifier）
│
├── Kirara_Server-API.Server/         ← API 层
│   ├── 14 个 Controller（全部完整实现，含 OpenVpnController/
│   │            AppUpdatesController/AppReleasesAdminController）
│   ├── 21 个 DTO 文件（含 DTOs/AppUpdates/）
│   ├── GlobalExceptionMiddleware
│   └── RequireAdminAttribute
│
├── Kirara_Server-API.Shared/         ← 共享层
│   ├── ApiResponse<T> 统一响应格式
│   └── ErrorCodes 常量
│
└── Kirara_Server-API.AppHost/        ← Aspire 编排
```

### 14.5 环境配置参考

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=10.10.10.11;Port=5888;Database=kiraradatabase;Username=kirara;Password=***"
  },
  "Jwt": {
    "Secret": "*** 32位以上字符串 ***",
    "Issuer": "KiraraServer",
    "Audience": "KiraraClient",
    "AccessTokenExpiryMinutes": "15",
    "RefreshTokenExpiryDays": "7"
  },
  "Minio": {
    "Endpoint": "10.10.10.11:9000",
    "AccessKey": "***",
    "SecretKey": "***",
    "BucketName": "kirara-storage",
    "PublicUrl": "https://cdn.akeno6388.online:1010"
  },
  "Cdn": {
    "BaseUrl": "https://cdn.akeno6388.online:1010"
  }
}
```

### 14.6 参考文档

| 文档 | 位置 | 内容 |
|------|------|------|
| 评论系统 API 文档 | `docs/评论系统API文档.md` | 评论系统详细 API 说明 |
| 服务端后端系统技术栈 | `docs/服务端后端系统技术栈.md` | 技术栈、ER 图、部署架构 |
| 客户端技术栈文档 | `d:\works\kirara_server\docs\技术栈文档.md` | WinUI 客户端完整技术栈 |
