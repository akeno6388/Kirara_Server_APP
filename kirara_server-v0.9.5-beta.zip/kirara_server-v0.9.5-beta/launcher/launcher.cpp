// ============================================================
//  Kirara Server APP - Native Win32 Launcher (single-instance)
//
//  Responsibilities:
//   1. Single-instance detection: when the user double-clicks the
//      desktop icon while the main app (KiraraServerAPP.Core.exe)
//      is already running (visible / minimized / tray-hidden),
//      signal the main instance via a named event to restore the
//      window, then exit immediately.
//   2. If no instance is running, launch the main app.
//      Process is <1MB, pure Win32 with no .NET runtime.
//
//  Shares the SAME named Mutex / named Event with the .NET side
//  (Helpers/SingleInstanceHelper.cs):
//    - Mutex is held by the main app for its lifetime
//    - Launcher only does an instant check (WaitForSingleObject 0ms)
//    - Event is Set by the launcher; the main instance's listener
//      thread waits on it and restores the window
//
//  Build: see build_launcher.ps1 (vcvars64 + cl.exe, static /MT)
//  NOTE: ASCII-only source (cl.exe on GBK codepage cannot read
//        UTF-8 Chinese comments without BOM).
// ============================================================

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <tlhelp32.h>

// ---- Named objects, MUST match C# SingleInstanceHelper ----
static const wchar_t* MUTEX_NAME =
    L"Kirara_Server_WinUI_SingleInstance_6F3A9C2E-8D41-4B7A-9E05-2C7B1F4A8D63";
static const wchar_t* WAKEUP_EVENT_NAME =
    L"Kirara_Server_WinUI_SingleInstance_6F3A9C2E-8D41-4B7A-9E05-2C7B1F4A8D63_Wakeup";

/// <summary>Main app process file name (matches csproj AssemblyName)</summary>
static const wchar_t* CORE_EXE_NAME = L"KiraraServerAPP.Core.exe";

/// <summary>
/// Checks whether a process with the given exe name is running
/// (CreateToolhelp32Snapshot, case-insensitive).
/// </summary>
static bool IsProcessRunning(const wchar_t* exeName)
{
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE)
        return false;

    PROCESSENTRY32W entry;
    entry.dwSize = sizeof(entry);
    bool found = false;

    if (Process32FirstW(snapshot, &entry))
    {
        do
        {
            if (lstrcmpiW(entry.szExeFile, exeName) == 0)
            {
                found = true;
                break;
            }
        } while (Process32NextW(snapshot, &entry));
    }

    CloseHandle(snapshot);
    return found;
}

/// <summary>
/// Entry point (GUI subsystem, no console window).
///
/// Flow:
///   1. Open named Mutex and try to acquire ownership immediately (0ms);
///   2. Acquire failed (main instance holds it) -> Set wakeup event -> exit;
///   3. Acquire succeeded but main app process is already running
///      (still initializing) -> release -> exit (prevent double-launch);
///   4. Acquire succeeded and no main process -> launch Core exe ->
///      release Mutex -> exit.
/// </summary>
int WINAPI wWinMain(HINSTANCE, HINSTANCE, LPWSTR, int)
{
    // Get this launcher exe's directory
    wchar_t selfPath[MAX_PATH];
    GetModuleFileNameW(NULL, selfPath, MAX_PATH);
    wchar_t* slash = wcsrchr(selfPath, L'\\');
    if (slash != NULL)
        *slash = L'\0'; // truncate to directory

    // 1. Open/create named Mutex
    HANDLE mutex = CreateMutexW(NULL, FALSE, MUTEX_NAME);
    if (mutex == NULL)
        return 0; // extreme case, exit silently

    // 2. Try to acquire ownership (0ms timeout)
    //    WAIT_OBJECT_0   -> success (newly created, or previous crashed)
    //    WAIT_ABANDONED  -> previous instance crashed, take over
    //    WAIT_TIMEOUT    -> main instance holds the Mutex
    DWORD waitResult = WaitForSingleObject(mutex, 0);

    if (waitResult == WAIT_OBJECT_0 || waitResult == WAIT_ABANDONED)
    {
        // ---- We own the Mutex: no main instance running ----
        // 3. Defensive race check: if Core is still initializing
        //    (CLR loading, hasn't acquired the Mutex yet), do NOT
        //    launch a second Core.
        if (!IsProcessRunning(CORE_EXE_NAME))
        {
            // 4. Launch main app (working dir = launcher dir so
            //    relative resource paths resolve)
            wchar_t corePath[MAX_PATH];
            lstrcpyW(corePath, selfPath);
            lstrcatW(corePath, L"\\");
            lstrcatW(corePath, CORE_EXE_NAME);

            // Fire-and-forget, no window (Core creates its own)
            SHELLEXECUTEINFOW sei = { 0 };
            sei.cbSize = sizeof(sei);
            sei.fMask = SEE_MASK_NOASYNC | SEE_MASK_FLAG_NO_UI;
            sei.lpVerb = NULL;
            sei.lpFile = corePath;
            sei.lpParameters = NULL;
            sei.lpDirectory = selfPath;
            sei.nShow = SW_SHOWNORMAL;
            ShellExecuteExW(&sei);
        }

        // Release ownership (so Core can acquire it once started)
        ReleaseMutex(mutex);
    }
    else
    {
        // ---- Main instance is running -> send wakeup signal ----
        HANDLE wakeEvent = CreateEventW(NULL, FALSE, FALSE, WAKEUP_EVENT_NAME);
        if (wakeEvent != NULL)
        {
            SetEvent(wakeEvent); // AutoReset: signal persists, not lost
            CloseHandle(wakeEvent);
        }
    }

    CloseHandle(mutex);
    return 0; // native process: <1MB, exits within milliseconds
}
