# ============================================================
# Kirara Server APP - Native Launcher Build Script
# Output: launcher\bin\KiraraServerAPP.exe (<1MB pure Win32, no .NET)
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File launcher\build_launcher.ps1
#   powershell -ExecutionPolicy Bypass -File launcher\build_launcher.ps1 -OutputDir "D:\works\kirara_server\bin\x64\Debug\net10.0-windows10.0.19041.0\win-x64"
#
# Dependency: Visual Studio with C++ desktop workload (MSVC x64 toolchain)
# Notes: Uses vcvars64.bat to configure MSVC + Windows SDK env.
#        Static CRT (/MT) -> no vcruntime140.dll dependency on target machine.
#        Script is ASCII-only for PowerShell 5.1 compatibility.
# ============================================================

param(
    # Output directory (default: launcher\bin\; publish_all.ps1 copies to publish dir)
    [string]$OutputDir = ""
)

$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
if ([string]::IsNullOrWhiteSpace($OutputDir)) {
    $OutputDir = Join-Path $PSScriptRoot "bin"
}
New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null

# ---- Locate Visual Studio via vswhere ----
$vswhere = "C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"
if (-not (Test-Path $vswhere)) {
    throw "vswhere.exe not found: $vswhere (install Visual Studio)"
}
# Note: -requires VC.Tools may fail on newer VS versions (component ID drift),
# so just take latest VS and verify vcvars64.bat existence below.
$vsPath = & $vswhere -latest -property installationPath
if ([string]::IsNullOrWhiteSpace($vsPath)) {
    throw "No Visual Studio found"
}
$vcvars = Join-Path $vsPath "VC\Auxiliary\Build\vcvars64.bat"
if (-not (Test-Path $vcvars)) {
    throw "vcvars64.bat not found: $vcvars (install 'Desktop development with C++' workload)"
}

Write-Host "Visual Studio: $vsPath" -ForegroundColor Cyan

# ---- Compile: rc (embed icon) + cl (static CRT /MT, GUI subsystem) ----
Push-Location $PSScriptRoot
try {
    $outExe = Join-Path $OutputDir "KiraraServerAPP.exe"
    # ASCII-only command; cmd /c handles the && chaining
    $cmd = "`"$vcvars`" >nul 2>&1 && rc.exe /nologo /fo launcher.res launcher.rc && cl.exe /nologo /O1 /MT /EHsc /DUNICODE /D_UNICODE /W4 launcher.cpp launcher.res /Fe:`"$outExe`" /link /SUBSYSTEM:WINDOWS kernel32.lib user32.lib shell32.lib"
    Write-Host "Compiling launcher..." -ForegroundColor Yellow
    cmd /c $cmd
    if ($LASTEXITCODE -ne 0) {
        throw "Launcher compile failed (exit=$LASTEXITCODE)"
    }
}
finally {
    Pop-Location
}

# ---- Cleanup intermediate files ----
Remove-Item (Join-Path $PSScriptRoot "launcher.obj") -ErrorAction SilentlyContinue
Remove-Item (Join-Path $PSScriptRoot "launcher.res") -ErrorAction SilentlyContinue

$exe = Get-Item $outExe
$sizeKb = [Math]::Round($exe.Length / 1KB, 1)
Write-Host "[OK] Launcher: $($exe.FullName) ($sizeKb KB)" -ForegroundColor Green
if ($sizeKb -gt 2048) {
    Write-Warning "Launcher exceeds 2MB - check for accidental .NET/dynamic CRT linkage"
}
