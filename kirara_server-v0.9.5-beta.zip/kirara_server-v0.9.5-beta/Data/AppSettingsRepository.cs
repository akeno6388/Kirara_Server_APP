using LiteDB;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

/// <summary>
/// 应用设置仓库 — LiteDB 实现（app_settings 集合）
/// 索引：Key（唯一）
/// </summary>
public class AppSettingsRepository : IAppSettingsRepository
{
    private readonly ILiteCollection<AppSettingsRecord> _collection;

    public AppSettingsRepository(AppDatabase database)
    {
        _collection = database.AppSettings;
        _collection.EnsureIndex(x => x.Key, true); // 唯一索引
    }

    /// <inheritdoc />
    public string? Get(string key) =>
        _collection.FindOne(x => x.Key == key)?.Value;

    /// <inheritdoc />
    public void Set(string key, string? value)
    {
        var existing = _collection.FindOne(x => x.Key == key);
        if (value is null)
        {
            // 删除该键
            if (existing != null)
                _collection.Delete(existing.Id);
            return;
        }

        if (existing != null)
        {
            existing.Value = value;
            existing.UpdatedAt = DateTime.UtcNow;
            _collection.Update(existing);
        }
        else
        {
            _collection.Insert(new AppSettingsRecord
            {
                Key = key,
                Value = value,
                UpdatedAt = DateTime.UtcNow,
            });
        }
    }
}
