using LiteDB;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

/// <summary>
/// 评论仓储实现 — 基于 LiteDB comments 集合
/// 回复以内嵌文档形式存储于 CommentItem.Replies
/// </summary>
public class CommentRepository : ICommentRepository
{
    private readonly ILiteCollection<CommentItem> _collection;

    public CommentRepository(AppDatabase database)
    {
        _collection = database.Comments;

        // 主查询路径索引：按资源键检索
        _collection.EnsureIndex(x => x.ResourceKey);
        // 排序索引
        _collection.EnsureIndex(x => x.CreatedAt);
    }

    public IEnumerable<CommentItem> GetByResource(string resourceKey) =>
        _collection.Find(x => x.ResourceKey == resourceKey)
                   .OrderByDescending(x => x.CreatedAt);

    public CommentItem? GetById(Guid id) =>
        _collection.FindById(id);

    public void Insert(CommentItem comment) =>
        _collection.Insert(comment);

    public void Update(CommentItem comment) =>
        _collection.Update(comment);

    public void Delete(Guid id) =>
        _collection.Delete(id);

    public void DeleteByResource(string resourceKey) =>
        _collection.DeleteMany(x => x.ResourceKey == resourceKey);
}
