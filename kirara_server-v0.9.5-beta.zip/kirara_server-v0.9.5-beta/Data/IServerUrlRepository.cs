using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

/// <summary>
/// 服务器 URL 注册表仓库接口
/// </summary>
public interface IServerUrlRepository
{
    ServerUrlRecord? GetById(Guid id);
    ServerUrlRecord? GetByKey(string key);
    IEnumerable<ServerUrlRecord> GetAll();
    IEnumerable<ServerUrlRecord> GetBySchemeId(Guid schemeId);
    void Insert(ServerUrlRecord record);
    void Update(ServerUrlRecord record);
    void Upsert(ServerUrlRecord record);
    void Delete(Guid id);
    void InsertBulk(IEnumerable<ServerUrlRecord> records);
    bool Exists(string key);
}
