namespace Kirara_Server_WinUI.Data;

/// <summary>
/// 应用设置仓库接口 — 轻量键值存储
/// </summary>
public interface IAppSettingsRepository
{
    /// <summary>
    /// 按键读取设置值；不存在时返回 null
    /// </summary>
    string? Get(string key);

    /// <summary>
    /// 写入或更新设置值；value 为 null 时删除该键
    /// </summary>
    void Set(string key, string? value);
}
