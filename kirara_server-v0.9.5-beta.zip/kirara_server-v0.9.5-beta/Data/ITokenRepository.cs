using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

public interface ITokenRepository
{
    IEnumerable<Token> GetAll();
    Token? GetById(Guid id);
    void Insert(Token token);
    void Update(Token token);
    void Delete(Guid id);
}
