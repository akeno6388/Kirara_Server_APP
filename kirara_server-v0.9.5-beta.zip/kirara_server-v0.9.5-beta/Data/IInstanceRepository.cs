using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

public interface IInstanceRepository
{
    IEnumerable<Instance> GetAll();
    IEnumerable<Instance> GetByType(InstanceType type);
    Instance? GetById(Guid id);
    void Insert(Instance instance);
    void Update(Instance instance);
    void Delete(Guid id);
    IEnumerable<Instance> Search(string keyword);
}
