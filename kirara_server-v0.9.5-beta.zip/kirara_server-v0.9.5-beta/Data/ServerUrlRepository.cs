using LiteDB;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

/// <summary>
/// 服务器 URL 注册表仓库 — LiteDB 实现
/// 索引：Key（唯一）、SchemeId、Category
/// </summary>
public class ServerUrlRepository : IServerUrlRepository
{
    private readonly ILiteCollection<ServerUrlRecord> _collection;

    public ServerUrlRepository(AppDatabase database)
    {
        _collection = database.ServerUrlRecords;
        _collection.EnsureIndex(x => x.Key, true); // 唯一索引
        _collection.EnsureIndex(x => x.SchemeId);
        _collection.EnsureIndex(x => x.Category);
    }

    public ServerUrlRecord? GetById(Guid id) =>
        _collection.FindById(id);

    public ServerUrlRecord? GetByKey(string key) =>
        _collection.FindOne(x => x.Key == key);

    public IEnumerable<ServerUrlRecord> GetAll() =>
        _collection.FindAll().OrderBy(x => x.Key);

    public IEnumerable<ServerUrlRecord> GetBySchemeId(Guid schemeId) =>
        _collection.Find(x => x.SchemeId == schemeId);

    public void Insert(ServerUrlRecord record)
    {
        record.CreatedAt = DateTime.UtcNow;
        record.UpdatedAt = DateTime.UtcNow;
        _collection.Insert(record);
    }

    public void Update(ServerUrlRecord record)
    {
        record.UpdatedAt = DateTime.UtcNow;
        _collection.Update(record);
    }

    public void Upsert(ServerUrlRecord record)
    {
        var existing = _collection.FindOne(x => x.Key == record.Key);
        if (existing != null)
        {
            record.Id = existing.Id;
            record.CreatedAt = existing.CreatedAt;
            record.UpdatedAt = DateTime.UtcNow;
            _collection.Update(record);
        }
        else
        {
            record.CreatedAt = DateTime.UtcNow;
            record.UpdatedAt = DateTime.UtcNow;
            _collection.Insert(record);
        }
    }

    public void Delete(Guid id) =>
        _collection.Delete(id);

    public void InsertBulk(IEnumerable<ServerUrlRecord> records)
    {
        var now = DateTime.UtcNow;
        foreach (var r in records)
        {
            r.CreatedAt = now;
            r.UpdatedAt = now;
        }
        _collection.InsertBulk(records);
    }

    public bool Exists(string key) =>
        _collection.Exists(x => x.Key == key);
}
