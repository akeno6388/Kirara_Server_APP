using LiteDB;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

public class TokenRepository : ITokenRepository
{
    private readonly ILiteCollection<Token> _collection;

    public TokenRepository(AppDatabase database)
    {
        _collection = database.Tokens;
        _collection.EnsureIndex(x => x.Name);
    }

    public IEnumerable<Token> GetAll() =>
        _collection.FindAll().OrderByDescending(x => x.UpdatedAt);

    public Token? GetById(Guid id) =>
        _collection.FindById(id);

    public void Insert(Token token)
    {
        token.CreatedAt = DateTime.UtcNow;
        token.UpdatedAt = DateTime.UtcNow;
        _collection.Insert(token);
    }

    public void Update(Token token)
    {
        token.UpdatedAt = DateTime.UtcNow;
        _collection.Update(token);
    }

    public void Delete(Guid id)
    {
        // 默认令牌（IsSystem=true）允许删除：其 Id 固定为 TokenService.DefaultTokenId
        // （非空 Guid；LiteDB 会把 Guid.Empty 主键自动替换为新 Guid，不能用作固定 Id），
        // 删除后下次登录时 PopulateDefaultToken 会自动重建，
        // 悬空的 SchemeBinding.TokenId 也会因 Id 复用而自动恢复链接。
        _collection.Delete(id);
    }
}
