using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

public interface ISchemeRepository
{
    IEnumerable<Scheme> GetAll();
    IEnumerable<Scheme> GetByInstanceType(InstanceType type);
    Scheme? GetById(Guid id);
    Scheme? GetByName(string name);
    void Insert(Scheme scheme);
    bool Update(Scheme scheme);
}
