using LiteDB;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

public class SchemeRepository : ISchemeRepository
{
    private readonly ILiteCollection<Scheme> _collection;

    public SchemeRepository(AppDatabase database)
    {
        _collection = database.Schemes;
        _collection.EnsureIndex(x => x.Name);
        _collection.EnsureIndex(x => x.InstanceType);
    }

    public IEnumerable<Scheme> GetAll() =>
        _collection.FindAll().OrderBy(x => x.SortOrder);

    public IEnumerable<Scheme> GetByInstanceType(InstanceType type) =>
        _collection.Find(x => x.InstanceType == type).OrderBy(x => x.SortOrder);

    public Scheme? GetById(Guid id) =>
        _collection.FindById(id);

    public Scheme? GetByName(string name) =>
        _collection.FindOne(x => x.Name == name);

    public void Insert(Scheme scheme) =>
        _collection.Insert(scheme);

    public bool Update(Scheme scheme) =>
        _collection.Update(scheme);
}
