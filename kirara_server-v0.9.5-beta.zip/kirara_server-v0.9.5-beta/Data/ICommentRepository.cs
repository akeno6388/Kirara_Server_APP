using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

/// <summary>
/// 评论仓储接口 — 管理评论和回复的持久化操作
/// </summary>
public interface ICommentRepository
{
    /// <summary>按资源键获取评论列表（按创建时间降序）</summary>
    IEnumerable<CommentItem> GetByResource(string resourceKey);

    /// <summary>按 ID 获取单条评论</summary>
    CommentItem? GetById(Guid id);

    /// <summary>插入新评论</summary>
    void Insert(CommentItem comment);

    /// <summary>更新评论（点赞等）</summary>
    void Update(CommentItem comment);

    /// <summary>删除评论</summary>
    void Delete(Guid id);

    /// <summary>按资源键删除所有评论（实例删除时级联清理）</summary>
    void DeleteByResource(string resourceKey);
}
