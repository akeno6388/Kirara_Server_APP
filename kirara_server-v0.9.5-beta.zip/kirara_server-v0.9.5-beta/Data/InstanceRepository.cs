using LiteDB;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Data;

public class InstanceRepository : IInstanceRepository
{
    private readonly ILiteCollection<Instance> _collection;

    public InstanceRepository(AppDatabase database)
    {
        _collection = database.Instances;
        _collection.EnsureIndex(x => x.Name);
        _collection.EnsureIndex(x => x.InstanceType);
        _collection.EnsureIndex(x => x.OwnerUserId);
    }

    public IEnumerable<Instance> GetAll() =>
        _collection.FindAll().OrderByDescending(x => x.UpdatedAt);

    public IEnumerable<Instance> GetByType(InstanceType type) =>
        _collection.Find(x => x.InstanceType == type).OrderByDescending(x => x.UpdatedAt);

    public Instance? GetById(Guid id) =>
        _collection.FindById(id);

    public void Insert(Instance instance)
    {
        instance.CreatedAt = DateTime.UtcNow;
        instance.UpdatedAt = DateTime.UtcNow;
        _collection.Insert(instance);
    }

    public void Update(Instance instance)
    {
        instance.UpdatedAt = DateTime.UtcNow;
        _collection.Update(instance);
    }

    public void Delete(Guid id) =>
        _collection.Delete(id);

    public IEnumerable<Instance> Search(string keyword) =>
        _collection.Find(x => x.Name.Contains(keyword, StringComparison.OrdinalIgnoreCase));
}
