using System.IO.Pipes;
using System.Security.AccessControl;
using System.Security.Principal;

namespace KiraraVpnHelper;

/// <summary>
/// 命名管道服务端（\\.\pipe\kirara-vpn）。
/// 接收应用侧命令，转发给 VpnProcessManager 执行。
/// 
/// 协议（每行一条命令，| 分隔，路径不允许包含 |）：
///   CONNECT|&lt;exePath&gt;|&lt;configPath&gt;|&lt;authPath&gt;|&lt;managementPort&gt;|&lt;logPath&gt;
///   DISCONNECT
///   STATUS
///   PING
/// 响应：
///   OK
///   ERROR|&lt;message&gt;
///   STATUS|RUNNING|&lt;pid&gt;|&lt;config&gt;
///   STATUS|STOPPED
/// </summary>
public class PipeServer
{
    /// <summary>管道名称（全局命名空间，服务端 LocalSystem 可被普通用户连接）</summary>
    public const string PipeName = "kirara-vpn";

    private readonly VpnProcessManager _manager;
    private CancellationTokenSource? _cts;
    private Task? _acceptLoopTask;

    public PipeServer(VpnProcessManager manager)
    {
        _manager = manager;
    }

    /// <summary>
    /// 启动管道服务端（后台接受循环）
    /// </summary>
    public void Start()
    {
        _cts = new CancellationTokenSource();
        _acceptLoopTask = Task.Run(AcceptLoopAsync);
    }

    /// <summary>
    /// 停止管道服务端
    /// </summary>
    public void Stop()
    {
        try { _cts?.Cancel(); } catch { }
        try { _acceptLoopTask?.Wait(2000); } catch { }
        _cts?.Dispose();
        _cts = null;
    }

    /// <summary>
    /// 接受连接循环：每次接受一个客户端，独立任务处理
    /// </summary>
    private async Task AcceptLoopAsync()
    {
        while (!_cts!.IsCancellationRequested)
        {
            try
            {
                // ⚠️ 必须显式设置 PipeSecurity：服务以 LocalSystem 运行，默认安全描述符
                //    只允许 LocalSystem/Administrators 访问管道 → 普通权限应用连接被拒
                //    （"Access to the path is denied"）。显式授予 Everyone 读写权限。
                var pipeSecurity = CreatePipeSecurity();

                // ⚠️ 使用 NamedPipeServerStreamAcl.Create（.NET Core 专用 API）：
                //    NamedPipeServerStream 本身没有带 PipeSecurity 的构造函数（那是 .NET Framework API）
                var server = NamedPipeServerStreamAcl.Create(
                    PipeName,
                    PipeDirection.InOut,
                    maxNumberOfServerInstances: 4,
                    PipeTransmissionMode.Byte,
                    PipeOptions.Asynchronous,
                    inBufferSize: 0,
                    outBufferSize: 0,
                    pipeSecurity);

                await server.WaitForConnectionAsync(_cts.Token);
                _ = HandleClientAsync(server);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch
            {
                // 瞬时错误（连接竞争等）→ 短暂延迟后继续接受
                await Task.Delay(100);
            }
        }
    }

    /// <summary>
    /// 创建允许 Everyone 读写的管道安全描述符。
    /// 服务（LocalSystem）创建的管道默认仅 LocalSystem/Admin 可访问，
    /// 必须显式授予普通用户（Everyone）读写权限，应用侧才能连接。
    /// </summary>
    private static PipeSecurity CreatePipeSecurity()
    {
        var security = new PipeSecurity();

        // Everyone：读写（应用以普通权限连接）
        security.AddAccessRule(new PipeAccessRule(
            new SecurityIdentifier(WellKnownSidType.WorldSid, null),
            PipeAccessRights.ReadWrite,
            AccessControlType.Allow));

        // 当前用户（LocalSystem）：完全控制
        security.AddAccessRule(new PipeAccessRule(
            WindowsIdentity.GetCurrent().User!,
            PipeAccessRights.FullControl,
            AccessControlType.Allow));

        // Administrators：完全控制（提权调试用）
        security.AddAccessRule(new PipeAccessRule(
            new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null),
            PipeAccessRights.FullControl,
            AccessControlType.Allow));

        return security;
    }

    /// <summary>
    /// 处理单个客户端连接：读一行命令 → 执行 → 写响应 → 关闭
    /// </summary>
    private async Task HandleClientAsync(NamedPipeServerStream stream)
    {
        try
        {
            using var reader = new StreamReader(stream);
            using var writer = new StreamWriter(stream) { AutoFlush = true };

            var line = await reader.ReadLineAsync();
            if (string.IsNullOrEmpty(line))
            {
                return;
            }

            var parts = line.Split('|');
            var command = parts[0].ToUpperInvariant();

            string response;
            switch (command)
            {
                case "CONNECT":
                    // CONNECT|exePath|configPath|authPath|managementPort|logPath
                    if (parts.Length < 6 ||
                        !int.TryParse(parts[4], out var port))
                    {
                        response = "ERROR|CONNECT 参数错误";
                    }
                    else
                    {
                        var error = _manager.Start(
                            parts[1], parts[2], parts[3], port, parts[5]);
                        response = error == null ? "OK" : $"ERROR|{error}";
                    }
                    break;

                case "DISCONNECT":
                    _manager.Stop();
                    response = "OK";
                    break;

                case "STATUS":
                    response = "STATUS|" + _manager.Status();
                    break;

                case "PING":
                    response = "OK";
                    break;

                default:
                    response = "ERROR|未知命令";
                    break;
            }

            await writer.WriteLineAsync(response);
        }
        catch
        {
            // 客户端异常断开：忽略
        }
        finally
        {
            try { stream.Dispose(); } catch { }
        }
    }
}
