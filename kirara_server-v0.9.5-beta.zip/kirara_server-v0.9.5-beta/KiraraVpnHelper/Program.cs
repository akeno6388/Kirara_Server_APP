using System.ServiceProcess;

namespace KiraraVpnHelper;

/// <summary>
/// Kirara VPN Helper 服务入口。
/// 以 LocalSystem 权限运行，通过命名管道接收应用命令，
/// 代应用启动/停止 openvpn.exe（网卡/路由操作需要系统权限）。
/// </summary>
internal static class Program
{
    /// <summary>
    /// 服务入口
    /// </summary>
    private static void Main()
    {
        ServiceBase.Run(new VpnHelperService());
    }
}

/// <summary>
/// Windows 服务宿主：启动命名管道服务端，管理 openvpn 子进程。
/// </summary>
public class VpnHelperService : ServiceBase
{
    private PipeServer? _pipeServer;
    private VpnProcessManager? _processManager;

    public VpnHelperService()
    {
        ServiceName = "KiraraVpnHelper";
        CanStop = true;
        CanShutdown = true;
        AutoLog = true;
    }

    protected override void OnStart(string[] args)
    {
        _processManager = new VpnProcessManager();
        _pipeServer = new PipeServer(_processManager);
        _pipeServer.Start();
    }

    protected override void OnStop()
    {
        try { _pipeServer?.Stop(); } catch { }
        try { _processManager?.StopAll(); } catch { }
    }

    protected override void OnShutdown()
    {
        OnStop();
    }
}
