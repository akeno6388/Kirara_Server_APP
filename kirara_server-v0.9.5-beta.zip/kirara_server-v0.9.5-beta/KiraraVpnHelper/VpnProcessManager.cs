using System.Diagnostics;

namespace KiraraVpnHelper;

/// <summary>
/// openvpn.exe 进程管理器。
/// 以服务（LocalSystem）权限启动/停止 openvpn 子进程，
/// 使虚拟网卡创建/路由配置等高权限操作无需应用侧提权。
/// 
/// 单实例：同一时刻只允许一个活动连接。
/// </summary>
public class VpnProcessManager
{
    /// <summary>进程锁</summary>
    private readonly object _lock = new();

    /// <summary>当前 openvpn 子进程</summary>
    private Process? _process;

    /// <summary>当前 .ovpn 配置路径（状态查询用）</summary>
    private string? _configPath;

    /// <summary>
    /// 启动 openvpn 子进程（SYSTEM 上下文）。
    /// </summary>
    /// <param name="exePath">openvpn.exe 完整路径</param>
    /// <param name="configPath">.ovpn 配置路径</param>
    /// <param name="authFilePath">auth.txt 认证文件路径</param>
    /// <param name="managementPort">management 端口（应用侧 TcpListener）</param>
    /// <param name="logPath">日志文件路径（--log）</param>
    /// <returns>null = 成功；否则返回错误信息</returns>
    public string? Start(string exePath, string configPath, string authFilePath, int managementPort, string logPath)
    {
        lock (_lock)
        {
            if (_process is { HasExited: false })
            {
                return "已有活动连接，请先断开";
            }

            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = exePath,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    // 重定向 stdout/stderr：防止管道缓冲区填满导致 openvpn 永久阻塞
                    // （与 VpnConnectionService 原实现一致的经验教训）
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                };
                psi.ArgumentList.Add("--config");
                psi.ArgumentList.Add(configPath);
                psi.ArgumentList.Add("--auth-user-pass");
                psi.ArgumentList.Add(authFilePath);
                psi.ArgumentList.Add("--auth-nocache");
                psi.ArgumentList.Add("--management");
                psi.ArgumentList.Add("127.0.0.1");
                psi.ArgumentList.Add(managementPort.ToString());
                psi.ArgumentList.Add("--management-client");
                // 日志写入文件：应用侧通过 management "log on" 订阅完整日志，
                // stdout 重定向仅用于防阻塞，内容丢弃（与 --log 重复）
                psi.ArgumentList.Add("--log");
                psi.ArgumentList.Add(logPath);

                _process = Process.Start(psi);
                if (_process == null)
                {
                    return "openvpn 进程创建失败";
                }

                // ⚠️ 必须异步读取 stdout/stderr：不读取则管道缓冲区（4KB）填满后
                //    openvpn 进程永久阻塞（典型症状：管理接口连接超时）
                _process.OutputDataReceived += (_, _) => { };
                _process.ErrorDataReceived += (_, _) => { };
                _process.BeginOutputReadLine();
                _process.BeginErrorReadLine();

                _configPath = configPath;
                return null;
            }
            catch (Exception ex)
            {
                return $"启动 openvpn.exe 失败: {ex.Message}";
            }
        }
    }

    /// <summary>
    /// 停止当前 openvpn 子进程（强制终止 + 进程树）。
    /// </summary>
    public void Stop()
    {
        lock (_lock)
        {
            var p = _process;
            _process = null;
            _configPath = null;
            if (p == null) return;

            try { p.Kill(entireProcessTree: true); } catch { }
            try { p.WaitForExit(3000); } catch { }
            try { p.Dispose(); } catch { }
        }
    }

    /// <summary>
    /// 查询当前连接状态。
    /// </summary>
    /// <returns>RUNNING|&lt;pid&gt;|&lt;config&gt; 或 STOPPED</returns>
    public string Status()
    {
        lock (_lock)
        {
            if (_process is { HasExited: false })
            {
                return $"RUNNING|{_process.Id}|{_configPath ?? string.Empty}";
            }
            return "STOPPED";
        }
    }

    /// <summary>
    /// 停止所有子进程（服务停止时调用）
    /// </summary>
    public void StopAll() => Stop();
}
