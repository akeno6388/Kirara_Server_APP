using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// 状态后缀文字 → 颜色转换器
/// "(令牌异常)" → 红色，"其他后缀" → 橙色
/// </summary>
public class StatusSuffixToBrushConverter : IValueConverter
{
    private static readonly SolidColorBrush RedBrush = new(Color.FromArgb(255, 244, 67, 54));
    private static readonly SolidColorBrush OrangeBrush = new(Color.FromArgb(255, 255, 152, 0));

    public object Convert(object? value, Type targetType, object? parameter, string language)
    {
        var suffix = value as string;
        if (string.IsNullOrEmpty(suffix)) return OrangeBrush;
        return suffix.Contains("令牌异常", StringComparison.Ordinal) ? RedBrush : OrangeBrush;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, string language)
        => throw new NotImplementedException();
}
