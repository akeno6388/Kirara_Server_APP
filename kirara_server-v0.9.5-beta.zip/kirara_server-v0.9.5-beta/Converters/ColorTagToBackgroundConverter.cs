using Microsoft.UI;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// 颜色标签字符串 → 半透明背景色 SolidColorBrush 转换器
/// 用于在实例标签框中用颜色填充背景
/// 空字符串或 null 返回透明
/// </summary>
public class ColorTagToBackgroundConverter : IValueConverter
{
    /// <summary>
    /// 背景填充的不透明度 (0-255)，默认 0x50 ≈ 31% 不透明度
    /// （提高鲜艳度）
    /// </summary>
    public static byte Alpha { get; set; } = 0x50;

    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is string colorHex && !string.IsNullOrEmpty(colorHex))
        {
            try
            {
                var hex = colorHex.TrimStart('#');
                var r = System.Convert.ToByte(hex[..2], 16);
                var g = System.Convert.ToByte(hex[2..4], 16);
                var b = System.Convert.ToByte(hex[4..6], 16);
                return new SolidColorBrush(Color.FromArgb(Alpha, r, g, b));
            }
            catch { }
        }

        // 空 / 无颜色标签时返回半透明白色（默认实例标签色）
        return new SolidColorBrush(Color.FromArgb(Alpha, 255, 255, 255));
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        throw new NotImplementedException();
    }
}
