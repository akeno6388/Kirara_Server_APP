using Microsoft.UI.Xaml.Data;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// bool → dot size（展开 12px / 折叠 8px）
/// </summary>
public class BoolToCollapsedDotSizeConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is bool isExpanded)
            return isExpanded ? 12.0 : 8.0;
        return 12.0;
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
        => throw new NotImplementedException();
}
