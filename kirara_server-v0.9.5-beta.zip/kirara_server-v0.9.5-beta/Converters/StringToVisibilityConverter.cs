using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Data;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// string → Visibility 转换器
/// 非空/非空白 → Visible, null/空/空白 → Collapsed
/// </summary>
public class StringToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        try
        {
            if (value is string s && !string.IsNullOrWhiteSpace(s))
                return Visibility.Visible;
        }
        catch { /* 防止绑定失败导致 XAML Hot Reload 崩溃 */ }
        return Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        throw new NotSupportedException();
    }
}
