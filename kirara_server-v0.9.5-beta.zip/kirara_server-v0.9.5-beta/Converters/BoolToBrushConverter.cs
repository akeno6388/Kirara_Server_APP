using Microsoft.UI;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// bool → SolidColorBrush 转换器
/// true  → 强调色半透明背景（高亮）
/// false → Transparent
/// </summary>
public class BoolToHighlightBrushConverter : IValueConverter
{
    private static SolidColorBrush? _highlightBrush;

    /// <summary>获取主题色半透明画刷（懒加载，跟随系统主题）</summary>
    private static SolidColorBrush HighlightBrush
    {
        get
        {
            if (_highlightBrush == null)
            {
                var accent = (Color)Microsoft.UI.Xaml.Application.Current.Resources["SystemAccentColor"];
                _highlightBrush = new SolidColorBrush(Color.FromArgb(0xAA, accent.R, accent.G, accent.B));
            }
            return _highlightBrush;
        }
    }

    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is bool isActive && isActive)
            return HighlightBrush;

        return new SolidColorBrush(Colors.Transparent);
    }

    /// <summary>
    /// 主题切换时调用：直接更新已缓存画刷实例的颜色。
    /// 所有引用方（x:Bind 绑定）共享同一 brush 实例，改色即时全局生效，
    /// 无需等待绑定值变化重新调用 Convert。
    /// 画刷尚未创建时跳过 —— 下次 Convert 懒加载会读取最新 SystemAccentColor。
    /// </summary>
    public static void InvalidateCache()
    {
        if (_highlightBrush == null) return;
        try
        {
            var accent = (Color)Microsoft.UI.Xaml.Application.Current.Resources["SystemAccentColor"];
            _highlightBrush.Color = Color.FromArgb(0xAA, accent.R, accent.G, accent.B);
        }
        catch { /* 资源不可用时保持原色 */ }
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        if (value is SolidColorBrush brush)
            return brush.Color.A > 0;
        return false;
    }
}
