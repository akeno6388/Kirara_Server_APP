using Microsoft.UI.Xaml.Data;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// 实例工作区状态文字 → 设置按钮可用性转换器。
/// 红灯状态（正在初始化实例... / 正在关闭实例...）→ false（禁用设置按钮，锁定动画不可点击），
/// 其他状态 → true。用于实例标签右侧的设置按钮在初始化/关闭期间变灰并禁止点击。
/// </summary>
public class InstanceWorkStatusToEnabledConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, string language)
    {
        return value is string status
            && status is "正在初始化实例..." or "正在关闭实例..."
            ? false
            : true;
    }

    public object ConvertBack(object value, Type targetType, object? parameter, string language)
        => throw new NotImplementedException();
}
