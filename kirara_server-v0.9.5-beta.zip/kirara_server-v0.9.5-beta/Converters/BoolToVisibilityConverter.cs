using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Data;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// bool → Visibility 转换器
/// true → Visible, false → Collapsed
/// 支持反向转换，内置异常保护防止绑定失败时抛出异常
/// </summary>
public class BoolToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        try
        {
            if (value is bool b)
                return b ? Visibility.Visible : Visibility.Collapsed;
        }
        catch { /* 防止绑定失败导致 XAML Hot Reload 崩溃 */ }
        return Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        try
        {
            if (value is Visibility v)
                return v == Visibility.Visible;
        }
        catch { /* 防止绑定失败导致 XAML Hot Reload 崩溃 */ }
        return false;
    }
}
