using Kirara_Server_WinUI.Models;
using Microsoft.UI.Xaml.Data;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// TokenType 枚举 → 中文显示文本
/// </summary>
public class TokenTypeToDisplayConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is TokenType type)
        {
            return type switch
            {
                TokenType.Default => "默认令牌",
                TokenType.Application => "应用令牌",
                TokenType.ADDomain => "AD 域账户",
                _ => "未知"
            };
        }
        return "未知";
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
        => throw new NotImplementedException();
}
