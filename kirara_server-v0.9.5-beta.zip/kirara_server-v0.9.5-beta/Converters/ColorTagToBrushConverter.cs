using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// 颜色标签字符串 → SolidColorBrush 转换器
/// 支持 #RRGGBB 格式
/// </summary>
public class ColorTagToBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is string colorHex && !string.IsNullOrEmpty(colorHex))
        {
            try
            {
                var hex = colorHex.TrimStart('#');
                var r = System.Convert.ToByte(hex[..2], 16);
                var g = System.Convert.ToByte(hex[2..4], 16);
                var b = System.Convert.ToByte(hex[4..6], 16);
                return new SolidColorBrush(Color.FromArgb(255, r, g, b));
            }
            catch { }
        }

        // 空 / 无颜色标签时返回白色（默认实例标签色）
        return new SolidColorBrush(Color.FromArgb(255, 255, 255, 255));
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        if (value is SolidColorBrush brush)
        {
            var c = brush.Color;
            return $"#{c.R:X2}{c.G:X2}{c.B:X2}";
        }
        return string.Empty;
    }
}
