using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// 令牌链接状态文字 → 颜色转换器
/// 终端状态（成功/失败/通知）返回固定颜色，过程状态返回主题色（SystemAccentColor）
/// </summary>
public class StatusToBrushConverter : IValueConverter
{
    private static readonly SolidColorBrush GreenBrush = new(Color.FromArgb(255, 76, 175, 80));
    private static readonly SolidColorBrush RedBrush = new(Color.FromArgb(255, 244, 67, 54));
    private static readonly SolidColorBrush OrangeBrush = new(Color.FromArgb(255, 255, 152, 0));

    private static SolidColorBrush? _accentBrush;

    /// <summary>获取主题色画刷（懒加载）</summary>
    private static SolidColorBrush AccentBrush
    {
        get
        {
            if (_accentBrush == null)
            {
                var accentColor = (Windows.UI.Color)Microsoft.UI.Xaml.Application.Current.Resources["SystemAccentColor"];
                _accentBrush = new SolidColorBrush(accentColor);
            }
            return _accentBrush;
        }
    }

    public object Convert(object? value, Type targetType, object? parameter, string language)
    {
        var status = value as string;
        if (string.IsNullOrEmpty(status)) return AccentBrush;

        // 提取主文字（去掉括号后缀）
        var mainText = status;
        var parenIdx = status.IndexOf('(');
        if (parenIdx > 0)
            mainText = status[..parenIdx];

        return mainText switch
        {
            "令牌已链接" => GreenBrush,
            "界面加载完成" => GreenBrush,
            "方案已加载" => GreenBrush,
            "令牌链接失败" => RedBrush,
            "预加载失败" => RedBrush,
            "有通知，令牌链接已中断" => OrangeBrush,
            _ => AccentBrush, // "方案加载中..."、"正在链接令牌..."、"加载界面中..."等过程状态 → 主题蓝
        };
    }

    public object ConvertBack(object value, Type targetType, object? parameter, string language)
        => throw new NotImplementedException();

    /// <summary>
    /// 主题切换时调用：直接更新已缓存画刷实例的颜色。
    /// 所有引用方共享同一 brush 实例，改色即时全局生效，
    /// 无需等待绑定值变化重新调用 Convert。
    /// 画刷尚未创建时跳过 —— 下次 Convert 懒加载会读取最新 SystemAccentColor。
    /// </summary>
    public static void InvalidateCache()
    {
        if (_accentBrush == null) return;
        try
        {
            var accentColor = (Windows.UI.Color)Microsoft.UI.Xaml.Application.Current.Resources["SystemAccentColor"];
            _accentBrush.Color = accentColor;
        }
        catch { /* 资源不可用时保持原色 */ }
    }
}