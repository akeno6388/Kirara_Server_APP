using Microsoft.UI.Xaml.Data;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// 将 bool 值映射为 FontWeight。
/// true → SemiBold（激活态），false → Normal（非激活态）
/// </summary>
public class BoolToWeightConverter : IValueConverter
{
    public object Convert(object? value, System.Type targetType, object? parameter, string language)
    {
        if (value is bool b && b)
            return Microsoft.UI.Text.FontWeights.SemiBold;
        return Microsoft.UI.Text.FontWeights.Normal;
    }

    public object ConvertBack(object? value, System.Type targetType, object? parameter, string language)
    {
        if (value is Windows.UI.Text.FontWeight fw)
            return fw.Weight == Microsoft.UI.Text.FontWeights.SemiBold.Weight;
        return false;
    }
}
