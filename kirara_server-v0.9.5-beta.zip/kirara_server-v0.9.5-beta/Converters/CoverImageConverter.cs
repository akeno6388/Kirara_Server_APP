using Kirara_Server_WinUI.Helpers;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media.Imaging;
using System;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// 将模板封面图 URL（CoverImageUrl）转换为 ImageSource。
///
/// ## 处理逻辑
/// - 完整 HTTP/HTTPS URL → 直接作为 BitmapImage 源
/// - 本地文件路径（如 "C:\Users\...\template_covers\{id}.png?v=1"）→
///   自动添加 file:/// 前缀后加载
/// - null / 空 → 回退到内置默认图片 Assets/template_default.png
///
/// ## 说明
/// RemoteQuickStartService 负责封面图下载和本地缓存：
///   1. 获取模板列表后立即加载本地缓存（秒显）
///   2. 后台并行同步服务端封面图（302 → 预签名 URL → 下载 → ETag 比对）
///   3. CoverImageUrl 最终值为本地文件路径（带 ?v= 版本号使 WinUI 缓存失效）
/// 若同步失败且无本地缓存，则回退到默认图片。
/// </summary>
public class CoverImageConverter : IValueConverter
{
    /// <summary>
    /// 内置默认模板图片 URI（Unpackaged 模式下 ms-appx 协议不可用，
    /// 通过 AssetPathHelper 解析为输出目录文件路径）
    /// </summary>
    private static readonly Uri DefaultTemplateImageUri =
        new(AssetPathHelper.Resolve("Assets/template_default.png"));

    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is string url && !string.IsNullOrEmpty(url))
        {
            try
            {
                // 情况 1：HTTP(S) 完整 URL → 直接使用
                if (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                    url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                {
                    return new BitmapImage(new Uri(url));
                }

                // 情况 2：本地文件路径（无 scheme）→ 添加 file:/// 前缀
                // 移除 ?v= 版本号后缀，Uri 构造函数自动处理
                var cleanPath = url.Contains('?')
                    ? url[..url.IndexOf('?')]
                    : url;

                if (!string.IsNullOrEmpty(cleanPath) && File.Exists(cleanPath))
                {
                    return new BitmapImage(new Uri("file:///" + cleanPath));
                }

                System.Diagnostics.Debug.WriteLine(
                    $"[CoverImageConverter] 本地路径无效或文件不存在: {cleanPath}");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(
                    $"[CoverImageConverter] 封面图处理失败: {url} - {ex.Message}");
            }
        }

        // 回退到内置默认图片
        return new BitmapImage(DefaultTemplateImageUri);
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        throw new NotImplementedException();
    }
}
