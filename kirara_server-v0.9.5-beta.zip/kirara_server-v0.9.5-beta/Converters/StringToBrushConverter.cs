using Microsoft.UI;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;
using System;
using System.Diagnostics;
using Windows.UI;

namespace Kirara_Server_WinUI.Converters
{
    /// <summary>
    /// 将十六进制颜色字符串（如 "#2ECC71"）或主题资源键（如 "SystemAccentColor"）转换为 SolidColorBrush
    /// 也支持 "Transparent" 关键字
    /// </summary>
    public class StringToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            try
            {
                if (value is string str && !string.IsNullOrEmpty(str))
                {
                    // 主题资源键（如 SystemAccentColor）
                    if (!str.StartsWith("#") && !str.Equals("Transparent", StringComparison.OrdinalIgnoreCase))
                    {
                        if (Microsoft.UI.Xaml.Application.Current.Resources.TryGetValue(str, out var resourceVal))
                        {
                            if (resourceVal is Color c)
                                return new SolidColorBrush(c);
                            if (resourceVal is SolidColorBrush brush)
                                return brush;
                        }
                        // 回退：尝试作为颜色名解析
                        return new SolidColorBrush(Colors.Transparent);
                    }

                    if (str.Equals("Transparent", StringComparison.OrdinalIgnoreCase))
                        return new SolidColorBrush(Colors.Transparent);

                    var hex = str.TrimStart('#');
                    if (hex.Length < 6)
                        return new SolidColorBrush(Colors.Transparent);

                    byte r = System.Convert.ToByte(hex.Substring(0, 2), 16);
                    byte g = System.Convert.ToByte(hex.Substring(2, 2), 16);
                    byte b = System.Convert.ToByte(hex.Substring(4, 2), 16);
                    return new SolidColorBrush(Color.FromArgb(255, r, g, b));
                }
                if (value is Color color)
                    return new SolidColorBrush(color);
                if (value is SolidColorBrush existingBrush)
                    return existingBrush;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"[StringToBrushConverter] Convert error: {ex.Message}");
            }
            return new SolidColorBrush(Colors.Transparent);
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
}