using Kirara_Server_WinUI.Models;
using Microsoft.UI.Xaml.Data;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// InstanceType 枚举 → 中文显示文本
/// </summary>
public class InstanceTypeToDisplayConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is InstanceType type)
        {
            return type switch
            {
                InstanceType.UserInstance => "用户实例",
                InstanceType.ServiceInstance => "服务实例",
                _ => "未知"
            };
        }
        return "未知";
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
        => throw new NotImplementedException();
}
