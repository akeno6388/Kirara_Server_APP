using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Data;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// bool 取反 → Visibility（true → Collapsed, false → Visible）
/// </summary>
public class NegatedBoolToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is bool b)
            return b ? Visibility.Collapsed : Visibility.Visible;
        return Visibility.Visible;
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
        => throw new NotImplementedException();
}
