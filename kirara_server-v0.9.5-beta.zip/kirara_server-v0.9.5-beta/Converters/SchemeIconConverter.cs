using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media.Imaging;
using System;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// 将方案封面图标本地缓存路径（CoverImageUrl）转换为 ImageSource。
///
/// ## 处理逻辑
/// - 本地文件路径（如 "C:\...\scheme_icons\media.png?v=1"）→ 自动添加 file:/// 前缀后加载
/// - null / 空 → 返回 null（UI 层通过 Visibility 切换自动降级到 IconGlyph）
/// - 文件不存在 → 返回 null
/// </summary>
public class SchemeIconConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is string url && !string.IsNullOrEmpty(url))
        {
            // 移除 ?v= 版本号后缀
            var cleanPath = url.Contains('?')
                ? url[..url.IndexOf('?')]
                : url;

            if (!string.IsNullOrEmpty(cleanPath) && File.Exists(cleanPath))
            {
                try
                {
                    return new BitmapImage(new Uri("file:///" + cleanPath));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"[SchemeIconConverter] 图标加载失败: {cleanPath} - {ex.Message}");
                }
            }
        }

        // 返回 null 使 Image 显示为空，由 XAML 的 Visibility 切换控制 IconGlyph 降级
        return null!;
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        throw new NotImplementedException();
    }
}
