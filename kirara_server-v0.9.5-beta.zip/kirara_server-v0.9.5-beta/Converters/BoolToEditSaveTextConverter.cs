using Microsoft.UI.Xaml.Data;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// bool → 按钮文本转换器（是否编辑模式）
/// true → "保存更改", false → "创建令牌"
/// </summary>
public class BoolToEditSaveTextConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is bool isEdit)
            return isEdit ? "保存更改" : "创建令牌";
        return "保存";
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
        => throw new NotImplementedException();
}
