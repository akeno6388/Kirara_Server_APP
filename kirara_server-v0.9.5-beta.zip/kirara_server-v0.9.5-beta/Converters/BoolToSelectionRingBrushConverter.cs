using Microsoft.UI;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// bool → 选中预选框画刷转换器（主题色色块选中指示）
/// true → 绿色描边（#4CAF50，与实例标签色盘同款）；false → Transparent
/// </summary>
public class BoolToSelectionRingBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language) =>
        value is true
            ? new SolidColorBrush(Color.FromArgb(0xCC, 0x4C, 0xAF, 0x50))
            : new SolidColorBrush(Colors.Transparent);

    public object ConvertBack(object value, Type targetType, object parameter, string language) =>
        throw new NotSupportedException();
}
