using Microsoft.UI.Xaml.Data;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// InstanceType → 图标字符 转换器
/// </summary>
public class InstanceTypeToIconConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is InstanceType type)
        {
            return type switch
            {
                InstanceType.UserInstance => "\uE77B",    // 用户图标
                InstanceType.ServiceInstance => "\uE753", // 服务器图标
                _ => "\uE7C3"
            };
        }
        return "\uE7C3";
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        if (value is string glyph)
        {
            return glyph switch
            {
                "\uE77B" => InstanceType.UserInstance,
                "\uE7B8" => InstanceType.ServiceInstance,
                _ => InstanceType.UserInstance
            };
        }
        return InstanceType.UserInstance;
    }
}
