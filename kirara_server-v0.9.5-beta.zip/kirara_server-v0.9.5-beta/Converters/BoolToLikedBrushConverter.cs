using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// [评论区功能] 布尔值转画笔颜色转换器
/// true → 强调色（已点赞），false → 次要文字色（未点赞）
/// </summary>
public class BoolToLikedBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        if (value is bool isLiked && isLiked)
        {
            return new SolidColorBrush(Microsoft.UI.Colors.Red);
        }
        return new SolidColorBrush(Microsoft.UI.Colors.Gray);
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        throw new NotImplementedException();
    }
}
