using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Media;

namespace Kirara_Server_WinUI.Converters;

/// <summary>
/// 实例工作区状态文字 → 圆点颜色转换器
/// 灰=待部署/null, 橙=部署中, 绿=已就绪, 红=初始化中
/// </summary>
public class InstanceWorkStatusToBrushConverter : IValueConverter
{
    private static readonly SolidColorBrush GrayBrush = new(Microsoft.UI.Colors.Gray);
    private static readonly SolidColorBrush OrangeBrush = new(Microsoft.UI.Colors.Orange);
    private static readonly SolidColorBrush GreenBrush = new(Microsoft.UI.Colors.LimeGreen);
    private static readonly SolidColorBrush RedBrush = new(Microsoft.UI.Colors.Red);

    public object Convert(object? value, Type targetType, object? parameter, string language)
    {
        var status = value as string;
        return status switch
        {
            "正在加载方案..." or "正在链接令牌..." => OrangeBrush,
            "工作区已就绪" => GreenBrush,
            "正在初始化实例..." or "正在关闭实例..." => RedBrush,
            _ => GrayBrush
        };
    }

    public object ConvertBack(object value, Type targetType, object? parameter, string language)
        => throw new NotImplementedException();
}
