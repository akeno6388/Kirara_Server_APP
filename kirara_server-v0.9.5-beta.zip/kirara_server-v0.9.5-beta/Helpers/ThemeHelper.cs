using Microsoft.UI.Xaml;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 主题辅助工具
/// </summary>
public static class ThemeHelper
{
    /// <summary>
    /// 设置应用程序主题
    /// </summary>
    public static void SetTheme(ApplicationTheme theme)
    {
        if (Application.Current is App app)
        {
            app.RequestedTheme = theme;
        }
    }

    /// <summary>
    /// 切换深色/浅色模式
    /// </summary>
    public static void ToggleTheme()
    {
        if (Application.Current.RequestedTheme == ApplicationTheme.Dark)
            SetTheme(ApplicationTheme.Light);
        else
            SetTheme(ApplicationTheme.Dark);
    }

    /// <summary>
    /// 获取当前主题
    /// </summary>
    public static ApplicationTheme CurrentTheme => Application.Current.RequestedTheme;
}
