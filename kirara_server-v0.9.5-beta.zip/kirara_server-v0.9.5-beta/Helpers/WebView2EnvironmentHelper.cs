using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 共享 WebView2 环境辅助类 — 为「信息流 HTML 卡片」等非方案页面提供统一的环境。
///
/// ## 为什么需要
/// WebView2 在 unpackaged 模式下，若不显式指定环境，默认用户数据目录为
/// 可执行文件所在目录（%EXEDIR%\{exeName}.exe.WebView2\EBWebView）。
/// 应用安装到 Program Files 后该目录只读 → WebView2 报错
/// 「无法创建数据目录：MS Edge 无法读取和写入其数据目录」。
///
/// ## 方案
/// 用户数据目录固定到 %LOCALAPPDATA%\Kirara\webview2\shared（用户可写），
/// 与 SchemeHostPage 的实例级目录（%LOCALAPPDATA%\Kirara\webview2\{instanceId}\{schemeId}）隔离。
/// 同一进程内多个 WebView2 控件共享同一环境（缓存 Task 防止重复创建）。
/// </summary>
public static class WebView2EnvironmentHelper
{
    private static readonly object SyncLock = new();
    private static Task<CoreWebView2Environment>? _sharedEnvTask;

    /// <summary>
    /// 获取共享的 WebView2 环境（线程安全，首次调用创建并缓存）。
    /// 必须在 UI 线程调用（EnsureCoreWebView2Async 要求）。
    /// </summary>
    public static Task<CoreWebView2Environment> GetSharedEnvironmentAsync()
    {
        lock (SyncLock)
        {
            return _sharedEnvTask ??= CreateSharedEnvironmentAsync();
        }
    }

    /// <summary>
    /// 创建共享环境 — 用户数据目录 %LOCALAPPDATA%\Kirara\webview2\shared。
    /// </summary>
    private static async Task<CoreWebView2Environment> CreateSharedEnvironmentAsync()
    {
        var userDataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Kirara", "webview2", "shared");
        Directory.CreateDirectory(userDataFolder);

        var options = new CoreWebView2EnvironmentOptions { Language = "zh-CN" };
        return await CoreWebView2Environment.CreateWithOptionsAsync(null, userDataFolder, options);
    }
}
