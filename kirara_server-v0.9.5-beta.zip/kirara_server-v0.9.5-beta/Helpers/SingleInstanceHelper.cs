using System;
using System.Threading;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 单实例辅助类 — 确保应用只有一个实例运行。
///
/// ## 使用场景
/// 程序在「窗体显示 / 最小化到任务栏 / 隐藏到系统托盘角标」状态下，
/// 用户再次双击桌面图标启动应用时：
///   1. 二次启动的实例在 <c>App</c> 构造函数最早阶段（XAML 初始化之前）
///      通过命名 Mutex 检测到已有实例；
///   2. 通过命名 EventWaitHandle 发出唤醒信号；
///   3. 二次实例立即 <c>Environment.Exit(0)</c> 退出 —— 此时 XAML 尚未初始化，
///      进程只消耗 CLR 最小内存且能立即终止，不会产生挂起的残留进程；
///   4. 主实例的侦听线程收到信号，经 <see cref="SetRestoreCallback"/> 注册的回调
///      调度到 UI 线程执行 <see cref="WindowAnimationHelper.RestoreFromTray()"/>
///      恢复窗口（兼容 ①托盘隐藏 SW_HIDE ②最小化 ③正常显示 三种状态）。
///
/// ## 为什么必须在 App 构造函数（而非 OnLaunched）检测
/// WinUI 3 应用执行到 OnLaunched 时 XAML 运行时已初始化（进程内存约 20MB），
/// 此时调用 Environment.Exit 可能与 XAML 启动管线竞争导致进程挂起无法关闭
/// （实测：产生 20MB 左右的残留僵尸进程）。构造函数阶段 XAML 未初始化，
/// Environment.Exit 可立即终止进程。
///
/// ## 线程模型
/// 侦听线程为后台线程，收到信号后仅触发回调（或置 pending 标志）；
/// 实际 UI 操作由回调内部通过 DispatcherQueue 调度到 UI 线程执行。
/// </summary>
public static class SingleInstanceHelper
{
    /// <summary>单实例命名前缀（应用名 + 固定 GUID，避免与其它应用冲突）</summary>
    private const string InstanceName = "Kirara_Server_WinUI_SingleInstance_6F3A9C2E-8D41-4B7A-9E05-2C7B1F4A8D63";

    /// <summary>
    /// 主应用进程名（不含 .exe）。
    /// 与 csproj 的 AssemblyName 保持一致：进程名 = KiraraServerAPP.Core。
    /// （原生启动器 KiraraServerAPP.exe 是瞬时进程，不在此清理范围）
    /// 用于自动清理残留的二次实例（见 <see cref="KillOtherInstances"/>）。
    /// </summary>
    private const string MainProcessName = "KiraraServerAPP.Core";

    /// <summary>命名 Mutex — 检测是否已有实例在运行</summary>
    private static Mutex? _mutex;

    /// <summary>命名事件 — 主实例等待、二次启动实例发信号</summary>
    private static EventWaitHandle? _wakeupEvent;

    /// <summary>事件侦听线程（后台线程）</summary>
    private static Thread? _listenerThread;

    /// <summary>退出标志（侦听线程循环退出条件）</summary>
    private static volatile bool _shutdown;

    /// <summary>恢复请求回调（由 App 包装为 DispatcherQueue 调度执行）</summary>
    private static Action? _restoreRequested;

    /// <summary>
    /// 已收到唤醒信号但回调尚未注册（App 构造函数 → OnLaunched 之间的极短窗口）。
    /// 回调注册时检查此标志补触发，确保信号不丢失。
    /// </summary>
    private static volatile bool _pendingWakeup;

    /// <summary>
    /// 尝试成为唯一实例（必须在 <c>App</c> 构造函数、XAML 初始化之前调用）。
    /// </summary>
    /// <returns>
    /// true = 当前进程为主实例（已持有 Mutex 所有权，侦听线程已启动）；
    /// false = 已有实例在运行（已发出唤醒信号），调用方应立即退出进程。
    /// </returns>
    public static bool TryAcquire()
    {
        try
        {
            // ① 打开/创建命名 Mutex（初始不持有所有权）
            bool createdNew;
            _mutex = new Mutex(false, InstanceName, out createdNew);

            // ② 尝试获取所有权：
            //    - 成功 → 我们是唯一实例（含 createdNew=true 刚创建的情况）
            //    - AbandonedMutexException → 前一个实例崩溃/被杀，接管其所有权继续运行
            //    - 超时(返回 false) → 已有实例正常持有 Mutex → 二次实例
            bool owned = false;
            try
            {
                _mutex.WaitOne(0);
                owned = true;
            }
            catch (AbandonedMutexException)
            {
                // 前一个实例异常退出（abandoned）→ 接管所有权，成为主实例
                System.Diagnostics.Debug.WriteLine("[SingleInstance] 接管异常退出的前实例");
                owned = true;
            }
            catch (Exception)
            {
                // 其它异常按未持有处理
            }

            if (!owned)
            {
                // ③ 二次实例：发出唤醒信号（AutoReset 信号持久保留，主实例不会丢失）
                SignalWakeup();
                return false;
            }

            // ④ 主实例：打开命名事件并启动侦听线程等待唤醒信号
            _wakeupEvent = new EventWaitHandle(false, EventResetMode.AutoReset, InstanceName + "_Wakeup");
            _shutdown = false;
            _pendingWakeup = false;

            _listenerThread = new Thread(ListenerLoop)
            {
                IsBackground = true,
                Name = "SingleInstanceListener"
            };
            _listenerThread.Start();

            // ★ [自动清理] 启动窗口期兜底：主实例从进程创建到持有 Mutex 需
            //   CLR 初始化（自包含 .NET 约数百毫秒），期间用户再次双击启动的
            //   二次实例即使检测失败也会短暂存活（~20MB 可见进程）。
            //   此处延迟扫描并强制终止所有同名残留进程（排除自身），
            //   确保任务管理器中看不到任何残留的二次实例。
            //   执行前检查 _shutdown：主实例已退出（Dispose 置位）时不再清理，
            //   避免误杀用户随后新启动的实例。
            _ = Task.Run(async () =>
            {
                await Task.Delay(TimeSpan.FromMilliseconds(1500));
                if (_shutdown || _mutex == null) return; // 主实例已退出，放弃清理
                KillOtherInstances();
            });

            System.Diagnostics.Debug.WriteLine("[SingleInstance] 主实例就绪，侦听二次启动唤醒信号");
            return true;
        }
        catch (Exception ex)
        {
            // 单实例限制失败时不阻塞启动（降级为允许多实例）
            System.Diagnostics.Debug.WriteLine($"[SingleInstance] 初始化失败（降级为多实例）: {ex.Message}");
            return true;
        }
    }

    /// <summary>
    /// 注册恢复窗口回调（App.OnLaunched 中捕获 UI 线程 DispatcherQueue 后调用）。
    /// 若在注册前已收到唤醒信号（构造函数 → OnLaunched 窗口期），此处立即补触发。
    /// </summary>
    /// <param name="callback">
    /// 收到二次启动唤醒信号时执行的回调（调用方已包装为 UI 线程调度）。
    /// </param>
    public static void SetRestoreCallback(Action callback)
    {
        _restoreRequested = callback;

        // 补触发：构造函数阶段收到的信号（回调未注册时置 pending 标志）
        if (_pendingWakeup)
        {
            _pendingWakeup = false;
            try { callback(); }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[SingleInstance] 补触发恢复回调失败: {ex.Message}");
            }
        }
    }

    /// <summary>
    /// 二次实例发出唤醒信号 — 通知主实例恢复窗口。
    /// 即使事件由本实例先创建，也与主实例后续打开的同名事件共享同一个
    /// 内核对象（AutoReset Set 后状态持久保留，主实例 WaitOne 立即返回）。
    /// </summary>
    private static void SignalWakeup()
    {
        try
        {
            using (var signal = new EventWaitHandle(false, EventResetMode.AutoReset, InstanceName + "_Wakeup"))
            {
                signal.Set();
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SingleInstance] 发出唤醒信号失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 侦听线程主循环 — 阻塞等待二次启动实例发出的唤醒信号。
    /// 收到信号后顺手清理可能挂起的残留二次实例（它发出信号后应已退出，
    /// 若因任何原因挂起，此处强制终止）。
    /// </summary>
    private static void ListenerLoop()
    {
        while (!_shutdown)
        {
            try
            {
                _wakeupEvent?.WaitOne();
                if (_shutdown) break;

                // ★ [自动清理] 二次实例已发出信号，理论上即将退出；
                //   若其退出路径被阻塞（CLR 挂起），强制终止，不留残留进程
                KillOtherInstances();

                // 收到信号 → 触发恢复回调；回调未注册（启动窗口期）→ 置 pending 标志
                var callback = _restoreRequested;
                if (callback != null)
                {
                    callback();
                }
                else
                {
                    _pendingWakeup = true;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[SingleInstance] 侦听异常: {ex.Message}");
            }
        }
    }

    /// <summary>
    /// [自动清理] 强制终止所有同名残留进程（排除当前进程）。
    /// 适用场景：
    ///   1. 启动窗口期：二次实例 CLR 初始化慢/退出路径挂起，主实例兜底清理；
    ///   2. 二次启动：发出唤醒信号后未及时退出的实例；
    ///   3. 历史遗留：旧版本 bug 产生的僵尸进程（主实例启动时顺带清掉）。
    /// </summary>
    private static void KillOtherInstances()
    {
        try
        {
            int currentId = Environment.ProcessId;
            var processes = System.Diagnostics.Process.GetProcessesByName(MainProcessName);
            foreach (var proc in processes)
            {
                try
                {
                    if (proc.Id == currentId) continue; // 绝不杀自己
                    proc.Kill();
                    System.Diagnostics.Debug.WriteLine($"[SingleInstance] 已终止残留二次实例 PID={proc.Id}");
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"[SingleInstance] 终止残留实例失败 PID={proc.Id}: {ex.Message}");
                }
                finally
                {
                    proc.Dispose();
                }
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SingleInstance] 清理残留实例异常: {ex.Message}");
        }
    }

    /// <summary>
    /// 释放单实例资源（应用退出时调用）。
    /// 释放 Mutex 所有权后，后续双击桌面图标可正常启动新实例。
    /// </summary>
    public static void Dispose()
    {
        _shutdown = true;
        // 唤醒侦听线程使其退出阻塞等待
        try { _wakeupEvent?.Set(); } catch { }
        try { _listenerThread?.Join(1000); } catch { }
        try { _wakeupEvent?.Dispose(); } catch { }
        // 仅持有所有权时释放（二次实例路径不持有，ReleaseMutex 会抛异常）
        try { _mutex?.ReleaseMutex(); } catch { }
        try { _mutex?.Dispose(); } catch { }
        _wakeupEvent = null;
        _mutex = null;
        _listenerThread = null;
        _restoreRequested = null;
        _pendingWakeup = false;
        System.Diagnostics.Debug.WriteLine("[SingleInstance] 单实例资源已释放");
    }
}
