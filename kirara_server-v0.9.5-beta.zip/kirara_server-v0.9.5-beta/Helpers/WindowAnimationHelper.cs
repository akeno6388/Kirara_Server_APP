using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using WinRT.Interop;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 窗口行为辅助 — Win11 原生窗口动画。
///
/// WinUI3 unpackaged + asInvoker + self-contained：
/// - 最大化 / 还原 / 最小化 / 关闭的过渡动画全部交由 Windows DWM / OverlappedPresenter
///   原生处理（Win11 自带平滑缩放与任务栏动效），不再自行设计 Composition/Win32 动画。
/// - 本类仅保留两件事：
///   ① DWM Mica 材质过渡属性（系统级，无害且增强原生观感）。
///   ② 「关闭软件行为 = 最小化」时拦截 SC_CLOSE → SW_HIDE + 显示系统托盘角标；
///      以及从托盘恢复窗口（ShowWindow + presenter.Restore，走系统原生还原动画）。
/// </summary>
public static class WindowAnimationHelper
{
    // 保持所有 WindowMessageHandler 实例的强引用，防止 GC 回收 WndProc 委托
    private static readonly List<WindowMessageHandler> _handlerRefs = new();

    /// <summary>
    /// 为指定窗口启用窗口行为辅助（DWM Mica 过渡 + 「关闭→托盘」拦截）。
    /// </summary>
    public static void EnableResizeAnimation(Window window)
    {
        try
        {
            // DWM Mica 材质过渡动画（Windows 11 build 22523+；旧版静默忽略）
            EnableDwmAnimation(window);

            // Win32 WndProc hook：拦截 SC_CLOSE（「关闭→最小化」时隐藏到托盘）。
            // ⚠️ 需先于 App.OnLaunched 中已有的 WindowSizeLimiter 挂载，形成 WndProc 链。
            EnableWindowMessageHook(window);
        }
        catch (Exception ex)
        {
            // 窗口行为辅助失败不应阻止应用启动，静默降级
            System.Diagnostics.Debug.WriteLine($"[WindowAnimationHelper] Failed to enable: {ex.Message}");
        }
    }

    // ────────────────────────────────────────────
    //  DWM Mica 过渡属性
    // ────────────────────────────────────────────

    /// <summary>
    /// DWMWA_MICA_ANIMATION = 37 (Windows 11 build 22523+)：
    /// Mica 材质在窗口缩放/最大化时的过渡动画由 DWM 原生提供。
    /// </summary>
    private static void EnableDwmAnimation(Window window)
    {
        try
        {
            var hwnd = WindowNative.GetWindowHandle(window);

            // Win32 BOOL 是 4 字节，必须用 int 而非 bool
            var enableMicaAnimation = 1;
            DwmSetWindowAttribute(hwnd, DWMWA_MICA_ANIMATION, ref enableMicaAnimation, sizeof(int));
        }
        catch (EntryPointNotFoundException)
        {
            // 旧版 Windows 不支持此属性，静默忽略
        }
        catch (DllNotFoundException)
        {
            // 没有 dwmapi.dll（极端情况），忽略
        }
    }

    // ────────────────────────────────────────────
    //  托盘隐藏 / 恢复
    // ────────────────────────────────────────────

    /// <summary>
    /// [托盘] 隐藏主窗口到系统托盘角标（SW_HIDE + 显示托盘图标）。
    /// </summary>
    public static void HideToTray()
    {
        var handler = WindowMessageHandler.Current;
        if (handler == null || handler.IsHiddenToTray) return;

        try
        {
            ShowWindow(handler.Hwnd, SW_HIDE);
            handler.IsHiddenToTray = true;
            Services.TrayIconService.Current?.Show();
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[WindowAnimationHelper] 隐藏到托盘失败: {ex.Message}");
        }
    }

    /// <summary>
    /// [托盘] 从系统托盘角标恢复主窗口（左键单击托盘角标 / 「打开」菜单项触发）。
    /// ShowWindow + presenter.Restore() → Windows DWM/OverlappedPresenter 播放原生还原动画。
    /// </summary>
    public static void RestoreFromTray()
    {
        WindowMessageHandler.Current?.RestoreFromTray();
    }

    // ────────────────────────────────────────────
    //  托盘 WndProc hook
    // ────────────────────────────────────────────

    /// <summary>
    /// Win32 WndProc hook — 仅拦截 SC_CLOSE（「关闭→最小化」时隐藏到托盘）。
    /// SC_MINIMIZE / SC_RESTORE / SC_MAXIMIZE / SC_CLOSE(直接关闭)全部走默认，
    /// Windows DWM / OverlappedPresenter 提供原生过渡动画。
    /// </summary>
    private static void EnableWindowMessageHook(Window window)
    {
        var hwnd = WindowNative.GetWindowHandle(window);
        var handler = new WindowMessageHandler(hwnd, window);
        // 保持强引用！否则 GC 会回收 handler 及其 WndProc 委托，
        // 导致 unmanaged 代码调用已释放的函数指针 → ExecutionEngineException
        _handlerRefs.Add(handler);
    }

    /// <summary>
    /// WndProc hook — 「关闭→最小化」拦截与托盘恢复。
    /// </summary>
    private sealed class WindowMessageHandler
    {
        private const int GWLP_WNDPROC = -4;
        private const int WM_SYSCOMMAND = 0x0112;
        private const int SC_CLOSE = 0xF060;

        private readonly IntPtr _hwnd;
        private readonly Window _window;
        private readonly WndProcDelegate _wndProcDelegate;
        private readonly IntPtr _oldWndProc;
        private volatile bool _isClosing;

        // [托盘] 当前 handler（供 WindowAnimationHelper.HideToTray / RestoreFromTray 静态入口访问）
        internal static WindowMessageHandler? Current;

        // [托盘] 窗口是否已隐藏到系统托盘角标（SW_HIDE）
        internal volatile bool IsHiddenToTray;

        /// <summary>窗口句柄（供静态入口访问）</summary>
        internal IntPtr Hwnd => _hwnd;

        private delegate IntPtr WndProcDelegate(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

        public WindowMessageHandler(IntPtr hwnd, Window window)
        {
            _hwnd = hwnd;
            _window = window;

            // ⚠️ WndProc hook：插入到已有的 WndProc 链中（WindowSizeLimiter → DefWindowProc）。
            //    注意：TrayIconService.Initialize()（App.OnLaunched）会在本 hook **之后**挂载，
            //    因此本 hook → TrayIconService hook → WindowSizeLimiter → DefWindowProc。
            _wndProcDelegate = WndProcCore;
            _oldWndProc = SetWindowLongPtr(hwnd, GWLP_WNDPROC,
                Marshal.GetFunctionPointerForDelegate(_wndProcDelegate));

            Current = this;
        }

        /// <summary>
        /// [托盘] WndProc — SC_CLOSE：
        /// - 「关闭行为 = 最小化」→ SW_HIDE + Show tray（不退出应用）。
        /// - 「关闭行为 = 直接关闭」→ CallWindowProc（Windows DWM/OverlappedPresenter
        ///   播放原生关闭动画并销毁窗口）。
        /// </summary>
        private IntPtr WndProcCore(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam)
        {
            if (msg == WM_SYSCOMMAND)
            {
                var cmd = wParam.ToInt32() & 0xFFF0;

                // ── [软件行为] 「关闭→最小化」：隐藏到系统托盘角标 ──
                if (cmd == SC_CLOSE && !_isClosing &&
                    Services.AppBehaviorService.Current?.CloseToMinimize == true)
                {
                    _isClosing = true;

                    try
                    {
                        // SW_HIDE → 任务栏图标消失
                        ShowWindow(_hwnd, SW_HIDE);
                        IsHiddenToTray = true;

                        // 显示系统托盘角标（幂等）
                        Services.TrayIconService.Current?.Show();
                    }
                    finally
                    {
                        _isClosing = false;
                    }
                    return IntPtr.Zero;
                }

                // ── SC_MINIMIZE / SC_RESTORE / SC_MAXIMIZE / SC_CLOSE(直接关闭) ──
                // 全部走默认：Windows DWM / OverlappedPresenter 提供原生过渡动画
                return CallWindowProc(_oldWndProc, hWnd, msg, wParam, lParam);
            }

            return CallWindowProc(_oldWndProc, hWnd, msg, wParam, lParam);
        }

        /// <summary>
        /// [托盘] RestoreFromTray — 点击托盘角标恢复主窗口。
        /// 角标常驻（启动即显示），因此需兼容三种窗口状态：
        /// ① 已隐藏到托盘（SW_HIDE）→ ShowWindow + presenter.Restore()（原生还原动画）；
        /// ② 最小化（Minimized）→ presenter.Restore()（原生还原动画）；
        /// ③ 正常显示 → 前置窗口。
        /// </summary>
        internal void RestoreFromTray()
        {
            try
            {
                // ① 窗口已隐藏到托盘 → 先显示再还原
                if (IsHiddenToTray)
                {
                    IsHiddenToTray = false;
                    ShowWindow(_hwnd, SW_SHOWNORMAL);
                }

                var windowId = Microsoft.UI.Win32Interop.GetWindowIdFromWindow(_hwnd);
                var appWindow = AppWindow.GetFromWindowId(windowId);

                // ② 最小化 → presenter.Restore()（Windows DWM/OverlappedPresenter 原生还原动画）
                if (appWindow.Presenter is OverlappedPresenter presenter)
                {
                    if (presenter.State == OverlappedPresenterState.Minimized)
                        presenter.Restore();
                }

                // ③ 正常显示 → 前置窗口（点击托盘角标回到主界面）
                appWindow.Show();
                SetForegroundWindow(_hwnd);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[WindowAnimationHelper] 从托盘恢复失败: {ex.Message}");
            }
        }
    }

    // ──────────────────────────────
    //  常量与 P/Invoke
    // ──────────────────────────────

    private const uint DWMWA_MICA_ANIMATION = 37;

    private const int SW_HIDE = 0;
    private const int SW_SHOWNORMAL = 1;

    [DllImport("dwmapi.dll", PreserveSig = true)]
    private static extern int DwmSetWindowAttribute(
        nint hwnd,
        uint attr,
        [In] ref int attrValue,
        int attrSize);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll", SetLastError = true, EntryPoint = "SetWindowLongPtr")]
    private static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr CallWindowProc(IntPtr lpPrevWndFunc, IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
}