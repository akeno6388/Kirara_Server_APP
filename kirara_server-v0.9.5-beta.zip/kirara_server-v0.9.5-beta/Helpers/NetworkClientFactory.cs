using System;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 双栈（IPv4/IPv6）网络客户端工厂 — 解决 .NET HttpClient 在 IPv6 线路不稳定时的黑洞超时问题。
///
/// ## 背景
/// 当域名同时解析出 A（IPv4）与 AAAA（IPv6）记录时，.NET 的 SocketsHttpHandler 默认
/// **优先尝试 IPv6**。若本机有 IPv6 默认路由但公网 IPv6 出口不可达（宽带 IPv6 租约失效、
/// 前缀漂移、运营商黑洞等），连接会卡死直到 HttpClient.Timeout 超时，而不会快速回退到 IPv4。
/// 症状：Postman/curl（Chromium/curl 网络栈，Happy Eyeballs 更激进）正常，但软件所有
/// HTTP 请求全部超时。
///
/// ## 方案
/// 通过自定义 <see cref="SocketsHttpHandler.ConnectCallback"/> 实现 **Happy Eyeballs**：
/// - 解析域名得到全部地址后，**IPv4 与 IPv6 并行发起连接**，先连通者胜出；
/// - IPv6 可用时走 IPv6（不牺牲性能），IPv6 不可达时自动回退 IPv4（不再黑洞）；
/// - 对每个地址族内部按顺序尝试（多 A/AAAA 记录）。
///
/// ## 用法
/// <code>
/// var client = NetworkClientFactory.Create(allowAutoRedirect: true);
/// client.Timeout = TimeSpan.FromSeconds(15);
/// client.DefaultRequestHeaders.UserAgent.ParseAdd("Kirara_Server/1.0");
/// </code>
/// </summary>
public static class NetworkClientFactory
{
    /// <summary>
    /// 创建带双栈 Happy Eyeballs 连接策略的 HttpClient。
    /// </summary>
    /// <param name="allowAutoRedirect">是否自动跟随重定向（获取预签名 URL 时传 false）。</param>
    public static HttpClient Create(bool allowAutoRedirect = true)
        => new(CreateHandler(allowAutoRedirect));

    /// <summary>
    /// 创建带双栈 Happy Eyeballs 连接策略的 HttpMessageHandler。
    /// 供需要直接使用 handler 的场景（如 SignalR 的 <c>HttpMessageHandlerFactory</c>）。
    /// </summary>
    /// <param name="allowAutoRedirect">是否自动跟随重定向。</param>
    public static HttpMessageHandler CreateHandler(bool allowAutoRedirect = true)
    {
        return new SocketsHttpHandler
        {
            AllowAutoRedirect = allowAutoRedirect,
            ConnectCallback = HappyEyeballsConnectAsync,
        };
    }

    /// <summary>
    /// Happy Eyeballs 连接回调 — IPv4/IPv6 并行尝试，先连通者胜出。
    /// </summary>
    private static async ValueTask<System.IO.Stream> HappyEyeballsConnectAsync(
        SocketsHttpConnectionContext context, CancellationToken cancellationToken)
    {
        var host = context.DnsEndPoint.Host;
        var port = context.DnsEndPoint.Port;

        // 解析域名全部地址（A + AAAA）
        var addresses = await Dns.GetHostAddressesAsync(host).ConfigureAwait(false);
        if (addresses.Length == 0)
            throw new SocketException((int)SocketError.HostNotFound);

        // 按地址族分组：IPv4 / IPv6
        var v4 = new List<IPAddress>();
        var v6 = new List<IPAddress>();
        foreach (var addr in addresses)
        {
            if (addr.AddressFamily == AddressFamily.InterNetwork) v4.Add(addr);
            else if (addr.AddressFamily == AddressFamily.InterNetworkV6) v6.Add(addr);
        }

        // 并行发起两个地址族的连接任务；若某族无地址则直接视为失败。
        var tasks = new List<Task<System.IO.Stream>>();
        if (v4.Count > 0) tasks.Add(TryConnectFamilyAsync(v4, port, cancellationToken));
        if (v6.Count > 0) tasks.Add(TryConnectFamilyAsync(v6, port, cancellationToken));

        if (tasks.Count == 0)
            throw new SocketException((int)SocketError.HostNotFound);

        // 等待第一个成功；全部失败则抛出最后一个异常。
        while (tasks.Count > 0)
        {
            var completed = await Task.WhenAny(tasks).ConfigureAwait(false);
            if (completed.IsCompletedSuccessfully)
                return await completed.ConfigureAwait(false);

            tasks.Remove(completed);
            if (tasks.Count == 0)
                await completed.ConfigureAwait(false); // 抛出最后一个异常
        }

        throw new SocketException((int)SocketError.HostUnreachable);
    }

    /// <summary>
    /// 按顺序尝试同一地址族内的多个地址，返回第一个成功建立的流。
    /// </summary>
    private static async Task<System.IO.Stream> TryConnectFamilyAsync(
        IReadOnlyList<IPAddress> addresses, int port, CancellationToken cancellationToken)
    {
        Exception? lastException = null;
        foreach (var addr in addresses)
        {
            var socket = new Socket(addr.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                await socket.ConnectAsync(new IPEndPoint(addr, port), cancellationToken).ConfigureAwait(false);
                return new NetworkStream(socket, ownsSocket: true);
            }
            catch (Exception ex) when (ex is SocketException or OperationCanceledException)
            {
                lastException = ex;
                socket.Dispose();
                if (ex is OperationCanceledException)
                    throw; // 取消应向上传播，不继续尝试
            }
        }
        throw lastException ?? new SocketException((int)SocketError.HostUnreachable);
    }
}