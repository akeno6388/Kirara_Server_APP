using Microsoft.UI.Xaml;
using Microsoft.Web.WebView2.Core;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// WebView2 附加属性 — 将 HTML 字符串直接渲染到 WebView2 中
/// 用法：&lt;WebView2 helpers:HtmlContentHelper.HtmlContent="{Binding HtmlContent}" /&gt;
/// </summary>
public static class HtmlContentHelper
{
    /// <summary>
    /// HTML 内容附加属性
    /// </summary>
    public static readonly DependencyProperty HtmlContentProperty =
        DependencyProperty.RegisterAttached(
            "HtmlContent",
            typeof(string),
            typeof(HtmlContentHelper),
            new PropertyMetadata(null, OnHtmlContentChanged));

    public static string? GetHtmlContent(DependencyObject obj) =>
        (string?)obj.GetValue(HtmlContentProperty);

    public static void SetHtmlContent(DependencyObject obj, string? value) =>
        obj.SetValue(HtmlContentProperty, value);

    private static async void OnHtmlContentChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not Microsoft.UI.Xaml.Controls.WebView2 wv)
            return;

        var html = e.NewValue as string;
        if (string.IsNullOrEmpty(html))
            return;

        try
        {
            // ★ [Program Files 只读修复] 显式使用共享环境（数据目录固定到
            //   %LOCALAPPDATA%\Kirara\webview2\shared），避免 unpackaged 模式下
            //   默认数据目录（exe 所在目录）不可写导致「无法创建数据目录」报错
            var sharedEnv = await WebView2EnvironmentHelper.GetSharedEnvironmentAsync();
            await wv.EnsureCoreWebView2Async(sharedEnv);
            wv.CoreWebView2!.NavigateToString(html);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[HtmlContentHelper] WebView2 渲染失败: {ex.Message}");
        }
    }
}