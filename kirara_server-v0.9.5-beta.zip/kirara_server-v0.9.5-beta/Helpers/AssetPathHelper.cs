using System;
using System.IO;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// Assets 内置资源路径解析工具 — 统一处理 Packaged / Unpackaged 两种运行模式。
///
/// ## 背景
/// WinUI 3 项目中 Assets 下的内置资源（如默认背景图、默认模板封面图）在
/// Unpackaged（非 MSIX）运行模式下存在两个问题：
/// 1. `ms-appx:///` 协议依赖包身份，Unpackaged 模式下 BitmapImage 无法解析该 URI
/// 2. Content 文件若未设置 CopyToOutputDirectory，不会复制到应用输出目录
///
/// 本工具将相对资源路径解析为当前运行模式可加载的路径：
/// - MSIX 打包模式 → ms-appx:/// URI（包内资源协议）
/// - Unpackaged 模式 → 应用目录下的文件系统绝对路径
/// </summary>
public static class AssetPathHelper
{
    /// <summary>
    /// 当前是否处于 MSIX 打包运行模式。
    /// Unpackaged 模式下访问 Package.Current 会抛出 InvalidOperationException。
    /// </summary>
    public static bool IsPackaged
    {
        get
        {
            try
            {
                // Windows SDK 投影的 Package API（Unpackaged 模式下访问 Current 会抛异常）
                return Windows.ApplicationModel.Package.Current != null;
            }
            catch
            {
                // Unpackaged（自包含）模式：无包身份，Package.Current 访问失败
                return false;
            }
        }
    }

    /// <summary>
    /// 将 Assets 下的相对资源路径（如 "Assets/background_default.jpg"）解析为可加载路径。
    /// </summary>
    /// <param name="relativePath">相对路径，如 "Assets/background_default.jpg"</param>
    /// <returns>Packaged 模式返回 ms-appx:/// URI；Unpackaged 模式返回文件系统绝对路径</returns>
    public static string Resolve(string relativePath)
    {
        var normalized = relativePath.Replace('\\', '/').TrimStart('/');
        if (IsPackaged)
        {
            return "ms-appx:///" + normalized;
        }
        return Path.Combine(AppContext.BaseDirectory, normalized.Replace('/', Path.DirectorySeparatorChar));
    }
}
