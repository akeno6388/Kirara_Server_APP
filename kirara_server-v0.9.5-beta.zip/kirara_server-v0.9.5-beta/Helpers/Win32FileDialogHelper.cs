using System.Runtime.InteropServices;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// Win32 文件打开对话框辅助 — 不依赖 Windows Runtime，任何打包模式（含 WindowsAppSDKSelfContained Unpackaged）下 100% 可靠。
///
/// 背景：Windows.Storage.Pickers.FileOpenPicker（UWP）与 Microsoft.Windows.Storage.Pickers.FileOpenPicker（WinAppSDK 实验版）
/// 在 Unpackaged 自包含模式下均可能激活失败（0x80040154）或不可靠（头像选择器实测失效）。
/// 本类使用 Win32 原生 GetOpenFileNameW（comdlg32.dll），为桌面应用最可靠的方案。
/// </summary>
public static class Win32FileDialogHelper
{
    /// <summary>
    /// 使用 Win32 GetOpenFileNameW 打开文件选择对话框。
    /// </summary>
    /// <param name="filter">文件过滤器（如 "OpenVPN 配置文件 (*.ovpn;*.conf)|*.ovpn;*.conf|所有文件 (*.*)|*.*"）</param>
    /// <param name="title">对话框标题</param>
    /// <param name="ownerHwnd">父窗口句柄（可为 0）</param>
    /// <returns>选中文件的完整路径；用户取消返回 null</returns>
    public static string? ShowOpenFileDialog(string filter, string title, IntPtr ownerHwnd = default)
    {
        var ofn = new OpenFileName
        {
            lStructSize = Marshal.SizeOf<OpenFileName>(),
            hwndOwner = ownerHwnd,
            lpstrFilter = filter.Replace('|', '\0') + "\0\0",
            lpstrFile = new string('\0', 4096),
            nMaxFile = 4096,
            lpstrTitle = title,
            Flags = OFN_FILEMUSTEXIST | OFN_HIDEREADONLY,
        };

        if (!GetOpenFileNameW(ref ofn))
        {
            // 用户取消（commdlg 错误码 0）或失败 → 返回 null
            return null;
        }

        return ofn.lpstrFile;
    }

    /// <summary>
    /// 使用 Win32 GetSaveFileNameW 打开文件保存对话框。
    /// </summary>
    /// <param name="filter">文件过滤器（如 "Kirara 令牌文件 (*.kirara)|*.kirara|所有文件 (*.*)|*.*"）</param>
    /// <param name="title">对话框标题</param>
    /// <param name="defaultFileName">默认文件名（含建议名与扩展名）</param>
    /// <param name="defaultExtension">默认扩展名（不带点，如 "kirara"；用户未输入扩展名时自动追加）</param>
    /// <param name="ownerHwnd">父窗口句柄（可为 0）</param>
    /// <returns>用户选择的完整路径；取消返回 null</returns>
    public static string? ShowSaveFileDialog(
        string filter, string title, string defaultFileName, string defaultExtension, IntPtr ownerHwnd = default)
    {
        // ⚠️ lpstrFile 是 LPWSTR 输出缓冲区：GetSaveFileNameW 会把用户输入的文件名【写入】该缓冲区。
        //    若直接传 defaultFileName 字符串，marshaller 只分配其长度+1 的缓冲区，
        //    用户输入更长文件名时发生缓冲区溢出 → 内存损坏 → System.ExecutionEngineException。
        //    因此必须分配 4096 长度的可写大缓冲区，并把默认文件名预填到开头。
        var fileNameBuffer = new string('\0', 4096);
        if (!string.IsNullOrEmpty(defaultFileName))
        {
            var chars = fileNameBuffer.ToCharArray();
            defaultFileName.CopyTo(0, chars, 0, Math.Min(defaultFileName.Length, 4095));
            fileNameBuffer = new string(chars);
        }

        var ofn = new OpenFileName
        {
            lStructSize = Marshal.SizeOf<OpenFileName>(),
            hwndOwner = ownerHwnd,
            lpstrFilter = filter.Replace('|', '\0') + "\0\0",
            lpstrFile = fileNameBuffer,
            nMaxFile = 4096,
            lpstrDefExt = defaultExtension,
            lpstrTitle = title,
            Flags = OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY,
        };

        if (!GetSaveFileNameW(ref ofn))
        {
            return null;
        }

        return ofn.lpstrFile;
    }

    // ===== Win32 结构 =====

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct OpenFileName
    {
        public int lStructSize;
        public IntPtr hwndOwner;
        public IntPtr hInstance;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpstrFilter;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpstrCustomFilter;
        public int nMaxCustFilter;
        public int nFilterIndex;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpstrFile;
        public int nMaxFile;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpstrFileTitle;
        public int nMaxFileTitle;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpstrInitialDir;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpstrTitle;
        public int Flags;
        public short nFileOffset;
        public short nFileExtension;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpstrDefExt;
        public IntPtr lCustData;
        public IntPtr lpfnHook;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string lpTemplateName;
        public IntPtr pvReserved;
        public int dwReserved;
        public int flagsEx;
    }

    private const int OFN_FILEMUSTEXIST = 0x00001000;
    private const int OFN_HIDEREADONLY = 0x00000004;
    private const int OFN_OVERWRITEPROMPT = 0x00000002;

    [DllImport("comdlg32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool GetOpenFileNameW(ref OpenFileName lpofn);

    [DllImport("comdlg32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool GetSaveFileNameW(ref OpenFileName lpofn);
}
