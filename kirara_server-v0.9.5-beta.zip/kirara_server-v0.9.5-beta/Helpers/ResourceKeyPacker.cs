namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 首页分享 resourceKey 打包/解包工具。
/// 服务端 HomepageComment 数据模型仅存储 resourceKey/schemeId/content 等有限字段，
/// 客户端将 instanceId、contentTitle、sourceUrl 编码进 resourceKey 字符串中，
/// 读取时再解析还原。格式：{actualResourceKey}||{instanceId}||{encodedTitle}||{encodedSourceUrl}
/// </summary>
public static class ResourceKeyPacker
{
    private const string Separator = "||";

    /// <summary>
    /// 将实际资源键与附加字段打包为单个字符串，用于存入服务端 resourceKey 列
    /// </summary>
    public static string Pack(string resourceKey, Guid instanceId, string contentTitle, string sourceUrl)
    {
        var encodedTitle = Uri.EscapeDataString(contentTitle ?? string.Empty);
        var encodedUrl = Uri.EscapeDataString(sourceUrl ?? string.Empty);
        return $"{resourceKey}{Separator}{instanceId}{Separator}{encodedTitle}{Separator}{encodedUrl}";
    }

    /// <summary>
    /// 从打包的 resourceKey 中解包出各字段。
    /// 兼容旧数据（不含分隔符时返回原始 resourceKey，其余字段为默认值）
    /// </summary>
    public static UnpackedResourceKey Unpack(string packedKey)
    {
        if (string.IsNullOrWhiteSpace(packedKey))
            return new UnpackedResourceKey();

        var parts = packedKey.Split(new[] { Separator }, 4, StringSplitOptions.None);
        if (parts.Length < 4)
        {
            // 旧数据：未打包，直接返回原始 resourceKey
            return new UnpackedResourceKey
            {
                ResourceKey = packedKey,
                InstanceId = Guid.Empty,
                ContentTitle = string.Empty,
                SourceUrl = string.Empty
            };
        }

        return new UnpackedResourceKey
        {
            ResourceKey = parts[0],
            InstanceId = Guid.TryParse(parts[1], out var id) ? id : Guid.Empty,
            ContentTitle = SafeUnescape(parts[2]),
            SourceUrl = SafeUnescape(parts[3])
        };
    }

    private static string SafeUnescape(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return string.Empty;
        try { return Uri.UnescapeDataString(value); }
        catch { return value; }
    }
}

/// <summary>
/// 解包后的资源键字段
/// </summary>
public class UnpackedResourceKey
{
    public string ResourceKey { get; set; } = string.Empty;
    public Guid InstanceId { get; set; }
    public string ContentTitle { get; set; } = string.Empty;
    public string SourceUrl { get; set; } = string.Empty;
}
