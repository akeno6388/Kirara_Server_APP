using System;
using System.Globalization;
using Windows.UI;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 颜色工具类 — 十六进制颜色解析与格式化
/// </summary>
public static class ColorHelper
{
    /// <summary>
    /// Color → #RRGGBB（忽略透明度）
    /// </summary>
    public static string ToHex(Color color) =>
        $"#{color.R:X2}{color.G:X2}{color.B:X2}";

    /// <summary>
    /// 解析 #RRGGBB / #AARRGGBB 十六进制颜色；失败返回 null
    /// </summary>
    public static Color? TryParseHex(string? hex)
    {
        if (string.IsNullOrWhiteSpace(hex))
            return null;
        hex = hex.Trim();
        if (hex.Length is not (7 or 9) || hex[0] != '#')
            return null;
        if (uint.TryParse(hex.AsSpan(1), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var value))
        {
            if (hex.Length == 7)
                return Color.FromArgb(0xFF, (byte)(value >> 16), (byte)(value >> 8), (byte)value);
            return Color.FromArgb((byte)(value >> 24), (byte)(value >> 16), (byte)(value >> 8), (byte)value);
        }
        return null;
    }
}
