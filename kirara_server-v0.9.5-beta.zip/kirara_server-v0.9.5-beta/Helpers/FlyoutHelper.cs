using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 全局飞入菜单（Flyout）辅助类。
/// 统一管理应用中所有确认/提示飞入菜单的创建与交互，
/// 确保布局、样式、交互行为完全一致。
/// </summary>
public static class FlyoutHelper
{
    /// <summary>
    /// 读取当前生效的主题色（跟随系统时来自 XamlControlsResources；手动覆盖时来自自定义值）。
    /// 用于全局飞入菜单的默认确认按钮颜色 —— 调用方未显式指定 confirmColor 时跟随主题色。
    /// </summary>
    private static Color ReadCurrentAccent()
    {
        try
        {
            if (Microsoft.UI.Xaml.Application.Current.Resources.TryGetValue("SystemAccentColor", out var value) &&
                value is Color color)
            {
                return color;
            }
        }
        catch { /* 资源不可用时使用默认蓝 */ }
        return Color.FromArgb(255, 0, 103, 192);
    }

    /// <summary>
    /// 获取主题色共享画刷实例（严格遵循 5.11.2 C# 动态创建 UI 规范）：
    /// 从 <c>Application.Current.Resources["KiraraAccentColorBrush"]</c> 取共享画刷，
    /// AppThemeService 改色时直接更新其 Color 实例 → 引用方即时跟随，无需重建 UI。
    /// 资源未加载时返回 null，调用方回退 <see cref="ReadCurrentAccent"/> 快照。
    /// </summary>
    private static SolidColorBrush? TryGetAccentBrush()
    {
        try
        {
            if (Microsoft.UI.Xaml.Application.Current.Resources.TryGetValue(
                    "KiraraAccentColorBrush", out var value) &&
                value is SolidColorBrush brush)
            {
                return brush;
            }
        }
        catch { /* 资源不可用时返回 null */ }
        return null;
    }

    /// <summary>
    /// 显示一个确认飞入菜单（图标 + 标题/描述 + 取消/确认按钮）。
    /// 返回 true 表示用户点击了确认按钮，false 表示取消或关闭。
    /// </summary>
    /// <param name="anchor">锚点元素</param>
    /// <param name="placement">弹出位置</param>
    /// <param name="iconGlyph">图标 Glyph（Segoe MDL2 Assets）</param>
    /// <param name="iconColor">图标颜色</param>
    /// <param name="title">标题文本（粗体 18px）</param>
    /// <param name="description">描述文本（可选，14px 半透明）</param>
    /// <param name="confirmText">确认按钮文本</param>
    /// <param name="confirmColor">确认按钮背景色</param>
    /// <param name="cancelText">取消按钮文本（默认"取消"）</param>
    /// <param name="isMandatory">true=强制模式，仅显示确认按钮（无取消按钮）；false=显示确认+取消</param>
    /// <param name="allowLightDismiss">
    /// true=允许点击外部关闭弹窗（默认）；false=禁止点击外部关闭（含 Esc 键），
    /// 弹窗不会超时消失，只能通过按钮关闭 —— 用于更新提示等需要用户明确选择的场景
    /// </param>
    /// <param name="iconBrush">图标画刷（可选，5.11.2 共享画刷通道：传主题色共享画刷时改色即时生效）</param>
    /// <param name="confirmBrush">确认按钮画刷（可选，5.11.2 共享画刷通道；优先于 confirmColor）</param>
    /// <returns>用户是否点击了确认按钮</returns>
    public static Task<bool> ShowConfirmAsync(
        FrameworkElement anchor,
        FlyoutPlacementMode placement,
        string iconGlyph,
        Color iconColor,
        string title,
        string? description = null,
        string confirmText = "确定",
        Color? confirmColor = null,
        string cancelText = "取消",
        bool isMandatory = false,
        bool allowLightDismiss = true,
        Brush? iconBrush = null,
        Brush? confirmBrush = null)
    {
        var tcs = new TaskCompletionSource<bool>();

        var flyout = new Flyout { Placement = placement };
        // 宽度自适应：MinWidth 保证基础宽度，不设小 MaxWidth —— 面板宽度按内容（描述单行）自动扩展；
        // MaxWidth 960 防御上限：描述 TextWrapping=Wrap，超宽时换行完整显示（不省略号截断、不撑出屏幕）
        var root = new StackPanel { Spacing = 16, MinWidth = 240, MaxWidth = 960, Padding = new Thickness(4) };

        if (!allowLightDismiss)
        {
            // 禁止点击外部关闭弹窗：仅当点击弹窗内按钮（或窗口销毁等极端情况）才会关闭。
            // ⚠️ WinUI 3 的 Flyout 本身没有 IsLightDismissEnabled 属性，
            //    需在 Opened 后通过视觉树找到其内部 Popup 再禁用 light dismiss；
            //    且 Esc 键默认仍会关闭 Flyout，因此下方另行拦截 Esc 键（见 root.KeyDown）。
            flyout.Opened += (_, _) =>
            {
                var current = (DependencyObject)root;
                while (current != null)
                {
                    if (current is Popup popup)
                    {
                        popup.IsLightDismissEnabled = false;
                        break;
                    }
                    current = VisualTreeHelper.GetParent(current);
                }
            };
        }

        // 图标（iconBrush 优先——共享画刷实例改色即时生效，5.11.2；未传时 iconColor 快照）
        root.Children.Add(new FontIcon
        {
            Glyph = iconGlyph,
            FontSize = 45,
            Foreground = iconBrush ?? new SolidColorBrush(iconColor),
            HorizontalAlignment = HorizontalAlignment.Center,
        });

        // 标题
        root.Children.Add(new TextBlock
        {
            Text = title,
            FontSize = 18,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -5, 0, 0),
        });

        // 描述（可选）—— Wrap 换行：短文本单行自适应宽度，超长文本到 MaxWidth 后换行完整显示
        if (!string.IsNullOrEmpty(description))
        {
            root.Children.Add(new TextBlock
            {
                Text = description,
                FontSize = 16,
                Opacity = 0.7,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, -5, 0, 12),
            });
        }
        else
        {
            // 无描述时给底部留白
            root.Children.Add(new Microsoft.UI.Xaml.Shapes.Rectangle
            {
                Height = 10,
                Fill = new SolidColorBrush(Color.FromArgb(0, 0, 0, 0)),
            });
        }

        // 按钮面板
        var buttonPanel = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Center,
            Spacing = 12,
        };

        // 非强制模式才显示取消按钮
        if (!isMandatory)
        {
            var cancelBtn = new Button
            {
                Content = cancelText,
                Style = (Style)Application.Current.Resources["GrayButtonStyle"],
                MinWidth = 100,
            };
            cancelBtn.Click += (_, _) => { flyout.Hide(); tcs.TrySetResult(false); };
            buttonPanel.Children.Add(cancelBtn);
        }

        var confirmBtn = new Button
        {
            Content = confirmText,
            MinWidth = 100,
            Style = (Style)Application.Current.Resources["PrimaryButtonStyle"],
            // 确认按钮颜色优先级：confirmBrush（共享画刷）> confirmColor（显式语义色）
            // > 主题色共享画刷（5.11.2，默认跟随主题色且改色即时生效）> SystemAccentColor 快照
            Background = confirmBrush
                ?? (confirmColor.HasValue ? new SolidColorBrush(confirmColor.Value) : null)
                ?? TryGetAccentBrush()
                ?? new SolidColorBrush(ReadCurrentAccent()),
            Foreground = new SolidColorBrush(Microsoft.UI.Colors.White),
        };
        confirmBtn.Click += (_, _) => { flyout.Hide(); tcs.TrySetResult(true); };
        buttonPanel.Children.Add(confirmBtn);

        root.Children.Add(buttonPanel);
        flyout.Content = root;

        // Flyout 关闭时（点外部关闭）也视为取消。
        // ⚠️ 强制模式 / allowLightDismiss=false 下点击外部不会触发关闭（IsLightDismissEnabled=false），
        //    仅当点击按钮（Hide）或窗口销毁等极端情况触发 Closed 时才会走到这里。
        flyout.Closed += (_, _) => tcs.TrySetResult(false);

        if (!allowLightDismiss)
        {
            // 拦截 Esc 键：IsLightDismissEnabled=false 时 Esc 默认仍会关闭 Flyout，
            // 这里在内容根元素上拦截并标记为已处理，使弹窗只能通过按钮关闭。
            root.KeyDown += (_, e) =>
            {
                if (e.Key == Windows.System.VirtualKey.Escape)
                    e.Handled = true;
            };
        }

        flyout.ShowAt(anchor);
        return tcs.Task;
    }

    /// <summary>
    /// 显示一个纯提示飞入菜单（图标 + 标题 + 描述 + 确定按钮）。
    /// </summary>
    public static void ShowInfo(
        FrameworkElement anchor,
        FlyoutPlacementMode placement,
        string iconGlyph,
        Color iconColor,
        string title,
        string? description = null,
        string confirmText = "确定",
        Color? confirmColor = null,
        Action? onConfirmed = null,
        Brush? iconBrush = null,
        Brush? confirmBrush = null)
    {
        var flyout = new Flyout { Placement = placement };
        // 宽度自适应：MinWidth 保证基础宽度，不设小 MaxWidth —— 面板宽度按内容（描述单行）自动扩展；
        // MaxWidth 960 防御上限：描述 TextWrapping=Wrap，超宽时换行完整显示（不省略号截断、不撑出屏幕）
        var root = new StackPanel { Spacing = 12, MinWidth = 200, MaxWidth = 960, Padding = new Thickness(4) };

        // 图标（iconBrush 优先——共享画刷实例改色即时生效，5.11.2；未传时 iconColor 快照）
        root.Children.Add(new FontIcon
        {
            Glyph = iconGlyph,
            FontSize = 45,
            Foreground = iconBrush ?? new SolidColorBrush(iconColor),
            HorizontalAlignment = HorizontalAlignment.Center,
        });

        // 标题
        root.Children.Add(new TextBlock
        {
            Text = title,
            FontSize = 18,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -3, 0, 4),
        });

        // 描述（可选）—— Wrap 换行：短文本单行自适应宽度，超长文本到 MaxWidth 后换行完整显示
        if (!string.IsNullOrEmpty(description))
        {
            root.Children.Add(new TextBlock
            {
                Text = description,
                FontSize = 16,
                Opacity = 0.7,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, -5, 0, 20),
            });
        }

        // 确定按钮（居中）—— confirmBrush（共享画刷）> confirmColor > iconColor 快照
        var confirmBtn = new Button
        {
            Content = confirmText,
            MinWidth = 100,
            HorizontalAlignment = HorizontalAlignment.Center,
            Style = (Style)Application.Current.Resources["PrimaryButtonStyle"],
            Background = confirmBrush
                ?? (confirmColor.HasValue ? new SolidColorBrush(confirmColor.Value) : null)
                ?? new SolidColorBrush(iconColor),
            Foreground = new SolidColorBrush(Microsoft.UI.Colors.White),
        };
        confirmBtn.Click += (_, _) => flyout.Hide();
        root.Children.Add(confirmBtn);

        // Flyout 关闭时触发回调（点"确定"、点外部均可）
        flyout.Closed += (_, _) => onConfirmed?.Invoke();

        flyout.Content = root;
        flyout.ShowAt(anchor);
    }

    /// <summary>
    /// 显示一个"删除确认"飞入菜单 — 删除类操作的统一方案（含同款图标）。
    /// 图标固定为警示符号 \uE783 + 红色主题（图标/确认按钮均为删除红 #E57373），
    /// 与实例删除飞入提示框完全一致。
    /// </summary>
    /// <param name="anchor">锚点元素</param>
    /// <param name="placement">弹出位置</param>
    /// <param name="title">标题文本（如"确定要删除此配置文件吗？"）</param>
    /// <param name="description">描述文本（可选，14px 半透明）</param>
    /// <param name="confirmText">确认按钮文本（默认"删除"）</param>
    /// <returns>用户是否点击了确认按钮</returns>
    public static Task<bool> ShowDeleteConfirmAsync(
        FrameworkElement anchor,
        FlyoutPlacementMode placement,
        string title,
        string? description = null,
        string confirmText = "删除")
    {
        // 删除红（与实例删除确认飞入一致：229,115,115）
        var deleteRed = Color.FromArgb(255, 229, 115, 115);
        return ShowConfirmAsync(
            anchor,
            placement,
            "\uE783",          // 同款警示图标
            deleteRed,         // 红色图标
            title,
            description,
            confirmText: confirmText,
            confirmColor: deleteRed);  // 红色确认按钮
    }

    /// <summary>
    /// 橙色警告语义色 — 与 AppNotification.SeverityColor 的 Warning 分支一致（#F39C12）。
    /// 全局"橙色警告设计语言"的统一色值：图标 + 确认按钮均使用此色。
    /// 警告类提示（无法跳转/多实例警告/无实例警告等）专用 —— 固定语义色不跟随主题色（5.11.2）。
    /// </summary>
    private static readonly Color WarningOrange = Color.FromArgb(255, 243, 156, 18);

    /// <summary>
    /// 显示一个"主题色确认"飞入菜单 — 普通确认框的统一方案（非警告语义）。
    /// 图标为警示符号 \uE783 + **主题色**（图标/确认按钮均使用主题色共享画刷，
    /// 严格遵循 5.11.2 规范：改色即时生效，不硬编码语义色）。
    /// 用于"是否继续？"类需要用户确认的普通场景（如通知跳转"实例未打开，是否立即打开并跳转？"）。
    /// </summary>
    /// <param name="anchor">锚点元素</param>
    /// <param name="placement">弹出位置</param>
    /// <param name="title">标题文本</param>
    /// <param name="description">描述文本（可选，14px 半透明）</param>
    /// <param name="confirmText">确认按钮文本（默认"确定"）</param>
    /// <param name="cancelText">取消按钮文本（默认"取消"）</param>
    /// <returns>用户是否点击了确认按钮</returns>
    public static Task<bool> ShowWarningConfirmAsync(
        FrameworkElement anchor,
        FlyoutPlacementMode placement,
        string title,
        string? description = null,
        string confirmText = "确定",
        string cancelText = "取消")
    {
        // 主题色：图标用共享画刷（5.11.2），确认按钮不传 confirmColor → 走默认主题色共享画刷
        return ShowConfirmAsync(
            anchor,
            placement,
            "\uE783",              // 警示图标
            ReadCurrentAccent(),   // 图标回退色（无共享画刷时）
            title,
            description,
            confirmText: confirmText,
            cancelText: cancelText,
            iconBrush: TryGetAccentBrush(),
            confirmBrush: TryGetAccentBrush());
    }

    /// <summary>
    /// 显示一个"橙色警告提示"飞入菜单 — 警告类纯提示的统一方案。
    /// 图标固定为警示符号 \uE7BA + 橙色主题（图标/确定按钮均为警告橙 #F39C12），
    /// 用于无法执行操作等需要醒目提示的警告场景（无法跳转 / 多实例警告 / 无实例警告）。
    /// ⚠️ 警告类固定橙色语义色（5.11.2：固定语义色不跟随主题色）；仅确认类（ShowWarningConfirmAsync）为主题色。
    /// </summary>
    /// <param name="anchor">锚点元素</param>
    /// <param name="placement">弹出位置</param>
    /// <param name="title">标题文本</param>
    /// <param name="description">描述文本（可选，14px 半透明）</param>
    /// <param name="confirmText">确定按钮文本（默认"确定"）</param>
    public static void ShowWarningNoticeAsync(
        FrameworkElement anchor,
        FlyoutPlacementMode placement,
        string title,
        string? description = null,
        string confirmText = "确定")
    {
        ShowInfo(
            anchor,
            placement,
            "\uE7BA",          // ⚠ 警告图标（与 NotificationSeverity.Warning 一致）
            WarningOrange,     // 橙色图标
            title,
            description,
            confirmText: confirmText,
            confirmColor: WarningOrange);  // 橙色确定按钮
    }

    /// <summary>
    /// 显示一个带进度条的提示飞入菜单（图标 + 标题 + 描述 + 进度条 + 状态文字）。
    /// 用于下载/长耗时操作的进度反馈；返回 <see cref="ProgressFlyoutController"/> 供更新进度与关闭。
    /// 样式与全局飞入提示一致（Flyout 弹出、居中布局）。
    /// </summary>
    /// <param name="anchor">锚点元素</param>
    /// <param name="placement">弹出位置</param>
    /// <param name="iconGlyph">图标 Glyph（Segoe MDL2 Assets）</param>
    /// <param name="iconColor">图标颜色</param>
    /// <param name="title">标题文本（粗体 18px）</param>
    /// <param name="description">描述文本（可选，14px 半透明）</param>
    /// <returns>进度控制器（Update / SetIndeterminate / Close，线程安全，内部自动切 UI 线程）</returns>
    public static ProgressFlyoutController ShowProgress(
        FrameworkElement anchor,
        FlyoutPlacementMode placement,
        string iconGlyph,
        Color iconColor,
        string title,
        string? description = null)
    {
        var flyout = new Flyout { Placement = placement };
        // 宽度自适应：MinWidth 保证基础宽度，不设小 MaxWidth —— 面板宽度按内容（描述单行）自动扩展；
        // MaxWidth 960 防御上限：描述 TextWrapping=Wrap，超宽时换行完整显示（不省略号截断、不撑出屏幕）
        var root = new StackPanel { Spacing = 12, MinWidth = 240, MaxWidth = 960, Padding = new Thickness(4) };

        // 图标
        root.Children.Add(new FontIcon
        {
            Glyph = iconGlyph,
            FontSize = 45,
            Foreground = new SolidColorBrush(iconColor),
            HorizontalAlignment = HorizontalAlignment.Center,
        });

        // 标题
        root.Children.Add(new TextBlock
        {
            Text = title,
            FontSize = 18,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, -5, 0, 0),
        });

        // 描述（可选）—— Wrap 换行：短文本单行自适应宽度，超长文本到 MaxWidth 后换行完整显示
        if (!string.IsNullOrEmpty(description))
        {
            root.Children.Add(new TextBlock
            {
                Text = description,
                FontSize = 14,
                Opacity = 0.7,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, -3, 0, 0),
            });
        }

        // 进度条（确定进度；总大小未知时由控制器切换为不确定模式）
        var progressBar = new ProgressBar
        {
            Minimum = 0,
            Maximum = 100,
            Value = 0,
            IsIndeterminate = false,
            Margin = new Thickness(0, 8, 0, 0),
        };
        root.Children.Add(progressBar);

        // 状态文字（百分比 / 已下载大小）
        var statusText = new TextBlock
        {
            Text = "准备中...",
            FontSize = 13,
            Opacity = 0.7,
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Center,
        };
        root.Children.Add(statusText);

        flyout.Content = root;
        flyout.ShowAt(anchor);

        return new ProgressFlyoutController(flyout, progressBar, statusText);
    }
}

/// <summary>
/// 进度飞入菜单控制器 — 线程安全地更新进度条 / 状态文字 / 关闭。
/// 由 <see cref="FlyoutHelper.ShowProgress"/> 返回；后台任务可直接调用（内部自动切 UI 线程）。
/// </summary>
public sealed class ProgressFlyoutController
{
    private readonly Flyout _flyout;
    private readonly ProgressBar _progressBar;
    private readonly TextBlock _statusText;
    private readonly DispatcherQueue _dispatcherQueue;

    internal ProgressFlyoutController(Flyout flyout, ProgressBar progressBar, TextBlock statusText)
    {
        _flyout = flyout;
        _progressBar = progressBar;
        _statusText = statusText;
        _dispatcherQueue = DispatcherQueue.GetForCurrentThread();
    }

    /// <summary>更新确定进度（0~100）与状态文字（线程安全）</summary>
    public void Update(double percent, string status)
    {
        void Apply()
        {
            _progressBar.IsIndeterminate = false;
            _progressBar.Value = Math.Clamp(percent, 0, 100);
            _statusText.Text = status;
        }

        RunOnUiThread(Apply);
    }

    /// <summary>切换为不确定进度（总大小未知时）</summary>
    public void SetIndeterminate(string status)
    {
        void Apply()
        {
            _progressBar.IsIndeterminate = true;
            _statusText.Text = status;
        }

        RunOnUiThread(Apply);
    }

    /// <summary>关闭飞入菜单（线程安全；未打开时调用无副作用）</summary>
    public void Close()
    {
        RunOnUiThread(() => _flyout.Hide());
    }

    private void RunOnUiThread(Action action)
    {
        if (_dispatcherQueue.HasThreadAccess)
        {
            action();
        }
        else
        {
            // WinUI 3 的 TryEnqueue 接收 DispatcherQueueHandler（无参委托），
            // 传 Action 需显式转换，否则编译报 CS1503
            _dispatcherQueue.TryEnqueue(new Microsoft.UI.Dispatching.DispatcherQueueHandler(action));
        }
    }
}