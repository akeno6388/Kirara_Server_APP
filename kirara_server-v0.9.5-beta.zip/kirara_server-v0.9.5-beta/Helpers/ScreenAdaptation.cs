using System.Runtime.InteropServices;
using Microsoft.UI.Windowing;
using Windows.Graphics;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 多屏幕自适应 — 根据显示器工作区与 DPI 计算窗口初始尺寸和最小尺寸。
/// 
/// ## 设计原则
/// 
/// - **初始尺寸**：按物理分辨率分级 —— 4K→70%、2K→80%、1K→90%，
///   分辨率越高占比越小（高分辨率屏像素密度高，占比略小仍能完整显示 UI），
///   保证窗口物理尺寸精确占据工作区的对应比例。
/// - **最小尺寸**：1600×900 DIP（用户缩放下限，不干预初始尺寸）。
/// - **降级策略**：若 API 调用失败（远程桌面、无显示器等），回退到 1600×900。
/// - **单位约定**：⚠️ 返回值均为**物理像素**（非 DIP）——
///   `AppWindow.Resize` 与 `WM_GETMINMAXINFO` 均使用物理像素单位，
///   若先转 DIP 再传入会导致高 DPI 缩放下窗口实际占比远小于预期。
/// - **分级依据**：使用物理像素高度判定（4K≥2160、2K≥1440），
///   对超宽屏（如 3440×1440、5120×2160）分级更准确。
/// </summary>
public static class ScreenAdaptation
{
    [DllImport("user32.dll")]
    private static extern int GetDpiForWindow(IntPtr hwnd);

    private const int DefaultDpi = 96;

    // ==== 最小窗口尺寸（DIP）====
    // 这些值在绝大多数屏幕上都能完整显示 UI，且不会超过初始尺寸。
    private const int MinWidthDips = 1600;
    private const int MinHeightDips = 900;

    // ==== 各级别初始尺寸占工作区比例 ====
    private const double InitRatio4K = 0.70;   // 物理高度 ≥ 2160 → 70%
    private const double InitRatio2K = 0.80;   // 物理高度 ≥ 1440 → 80%
    private const double InitRatio1K = 0.90;   // 其余（1080P 等）→ 90%

    // ==== 屏幕级别判定阈值（物理像素高度）====
    private const int PhysicalHeight4K = 2160;
    private const int PhysicalHeight2K = 1440;

    /// <summary>
    /// 根据主显示器工作区和 DPI，计算窗口的初始尺寸和最小尺寸。
    /// 初始尺寸按物理分辨率分级：4K→70%、2K→80%、1K→90%。
    /// </summary>
    /// <param name="windowHandle">窗口句柄（用于获取 DPI）</param>
    /// <returns>(initialWidth, initialHeight, minWidth, minHeight) — 均为物理像素</returns>
    public static (int width, int height, int minWidth, int minHeight) CalculateWindowSizes(IntPtr windowHandle)
    {
        try
        {
            // ---- DPI 缩放比例 ----
            int dpi = GetDpiForWindow(windowHandle);
            double scale = dpi > 0 ? dpi / (double)DefaultDpi : 1.0;

            // ---- 主显示器工作区（物理像素）----
            var primaryArea = DisplayArea.Primary;
            var workArea = primaryArea.WorkArea;

            // ---- 根据物理分辨率高度判定屏幕级别，选择对应比例 ----
            // 用物理高度判定：对超宽屏（3440×1440 / 5120×2160 等）分级更准确
            double ratio = workArea.Height >= PhysicalHeight4K ? InitRatio4K
                         : workArea.Height >= PhysicalHeight2K ? InitRatio2K
                         : InitRatio1K;

            // ---- 初始尺寸：物理工作区 × 分级比例（物理像素）----
            // ⚠️ 不能先除以 scale 转 DIP：AppWindow.Resize 需要物理像素，
            // 直接使用物理像素才能保证任意 DPI 缩放下精确占据对应比例
            int initW = (int)(workArea.Width * ratio);
            int initH = (int)(workArea.Height * ratio);

            // ---- 最小尺寸：1600×900 DIP → 物理像素 ----
            // WM_GETMINMAXINFO 的 ptMinTrackSize 为物理像素单位
            int minW = (int)(MinWidthDips * scale);
            int minH = (int)(MinHeightDips * scale);

            // ---- 防溢出：高缩放/小屏时窗口不超出工作区 ----
            initW = Math.Min(initW, workArea.Width);
            initH = Math.Min(initH, workArea.Height);

            return (initW, initH, minW, minH);
        }
        catch
        {
            // ---- 降级：远程桌面、无显示器等异常场景 ----
            return (1600, 900, MinWidthDips, MinHeightDips);
        }
    }

    /// <summary>
    /// 获取指定窗口所在显示器的 DPI 缩放比例（如 1.0=100%, 1.5=150%, 2.5=250%）
    /// </summary>
    public static double GetScaleFactor(IntPtr windowHandle)
    {
        try
        {
            int dpi = GetDpiForWindow(windowHandle);
            return dpi > 0 ? dpi / (double)DefaultDpi : 1.0;
        }
        catch
        {
            return 1.0;
        }
    }
}