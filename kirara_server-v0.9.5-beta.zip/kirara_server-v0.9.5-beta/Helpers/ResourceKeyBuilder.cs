namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 资源键构建器 — 将 URL 归一化为评论区资源键
/// 格式：{schemeName}://{serverAuthority}{path}
/// 评论按 方案 + 服务器 + 页面路径 隔离，同一服务器的不同实例共享评论
/// </summary>
public static class ResourceKeyBuilder
{
    /// <summary>
    /// 从 WebView2 当前 URL 构建资源键（以服务器主机标识替代实例 ID）
    /// </summary>
    /// <param name="schemeName">方案名称（如 media、drive）</param>
    /// <param name="sourceUrl">WebView2 当前 Source URL</param>
    /// <returns>归一化资源键，如 media://media.akeno6388.online:1010/web#/home.html</returns>
    public static string FromUrl(string schemeName, string sourceUrl)
    {
        if (string.IsNullOrWhiteSpace(sourceUrl) || sourceUrl == "about:blank")
            return $"{schemeName}://unknown/";

        try
        {
            var uri = new Uri(sourceUrl);
            var authority = uri.Authority; // host:port（如 media.akeno6388.online:1010）
            var path = NormalizePath(uri);
            return $"{schemeName}://{authority}{path}";
        }
        catch (UriFormatException)
        {
            // URL 解析失败时直接使用原始字符串
            return $"{schemeName}://unknown/{sourceUrl}";
        }
    }

    /// <summary>
    /// 为议题方案构建资源键（无 WebView2 URL，全局共享）
    /// </summary>
    public static string ForTopic()
    {
        return "topic://global";
    }

    /// <summary>
    /// 归一化 URI 路径部分：
    /// - SPA hash 路由（#/folder/abc）→ 保留 hash
    /// - 传统路径（/video/123）→ 保留 path
    /// - 忽略查询参数（?tab=x），主机名已作为服务器标识嵌入资源键
    /// </summary>
    private static string NormalizePath(Uri uri)
    {
        // SPA hash 路由：hash 部分包含实际路由信息
        if (!string.IsNullOrEmpty(uri.Fragment))
        {
            // 如 #/folder/abc → 保留 path + fragment
            var basePath = uri.AbsolutePath.TrimEnd('/');
            return basePath + uri.Fragment;
        }

        // 传统路径：取 AbsolutePath，去除尾部斜杠（根路径保留 /）
        var path = uri.AbsolutePath;
        if (path.Length > 1)
            path = path.TrimEnd('/');

        return string.IsNullOrEmpty(path) ? "/" : path;
    }
}
