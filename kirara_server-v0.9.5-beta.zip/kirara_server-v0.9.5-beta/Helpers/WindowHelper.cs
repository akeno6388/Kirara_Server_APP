using Microsoft.UI.Xaml;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 窗口辅助工具
/// </summary>
public static class WindowHelper
{
    /// <summary>
    /// 获取当前窗口的句柄
    /// </summary>
    public static nint GetWindowHandle(Window window)
    {
        return WinRT.Interop.WindowNative.GetWindowHandle(window);
    }

    /// <summary>
    /// 设置窗口标题栏为自定义模式
    /// </summary>
    public static void SetCustomTitleBar(Window window, UIElement titleBar)
    {
        window.ExtendsContentIntoTitleBar = true;
        window.SetTitleBar(titleBar);
    }

    /// <summary>
    /// 获取应用窗口
    /// </summary>
    public static Microsoft.UI.Windowing.AppWindow GetAppWindow(Window window)
    {
        var hwnd = GetWindowHandle(window);
        var windowId = Microsoft.UI.Win32Interop.GetWindowIdFromWindow(hwnd);
        return Microsoft.UI.Windowing.AppWindow.GetFromWindowId(windowId);
    }
}
