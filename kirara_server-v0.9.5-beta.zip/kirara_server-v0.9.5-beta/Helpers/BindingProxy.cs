using Microsoft.UI.Xaml;

namespace Kirara_Server_WinUI.Helpers;

/// <summary>
/// 绑定代理 — 用于跨越 DataTemplate 命名作用域访问父级数据上下文
/// </summary>
public class BindingProxy : DependencyObject
{
    public static readonly DependencyProperty DataProperty =
        DependencyProperty.Register(nameof(Data), typeof(object), typeof(BindingProxy), null);

    public object Data
    {
        get => GetValue(DataProperty);
        set => SetValue(DataProperty, value);
    }
}
