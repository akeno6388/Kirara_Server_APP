using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Contracts;

/// <summary>
/// 方案插件接口 — 所有方案必须实现此接口
/// 平台通过此接口加载、初始化、显示和销毁方案
/// </summary>
public interface IScheme
{
    /// <summary>方案唯一标识</summary>
    Guid Id { get; }

    /// <summary>方案名称（内部）</summary>
    string Name { get; }

    /// <summary>方案显示名称</summary>
    string DisplayName { get; }

    /// <summary>方案描述</summary>
    string Description { get; }

    /// <summary>方案类型（用户实例/服务实例）</summary>
    InstanceType InstanceType { get; }

    /// <summary>UI 呈现方式</summary>
    SchemeUIKind UIKind { get; }

    /// <summary>图标（Segoe Fluent Icons 字符）</summary>
    string IconGlyph { get; }

    /// <summary>
    /// 默认 URL 注册表键，方案通过此键从集中式 URL 注册表中获取服务器地址。
    /// 默认与 Name 同名（由 BaseScheme 实现），无需 URL 的方案应返回 null。
    /// </summary>
    string? DefaultUrlKey { get; }

    /// <summary>
    /// 初始化方案（实例激活时调用）
    /// </summary>
    Task<SchemeResult> InitializeAsync(SchemeBinding binding);

    /// <summary>
    /// 获取方案界面 — 平台调用此方法获取要显示的内容
    /// </summary>
    SchemeUI GetUI();

    /// <summary>
    /// 方案被停用时调用
    /// </summary>
    Task<SchemeResult> DeinitializeAsync();

    /// <summary>
    /// 验证令牌是否有效
    /// </summary>
    Task<TokenValidationResult> ValidateTokenAsync(Token token);

    /// <summary>
    /// 获取方案当前状态
    /// </summary>
    SchemeStatus GetStatus();
}
