using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Contracts;

/// <summary>
/// 自动登录提供者接口 — WebView2 方案实现此接口以支持自动填充凭据并提交登录表单。
/// RDP / ExternalProcess / Overlay / CustomControl 方案不需要实现此接口。
/// </summary>
public interface IAutoLoginProvider
{
    /// <summary>
    /// 【页面就绪检测】页面中表示"页面可交互"的 DOM 元素选择器（可选）。
    /// 设置后，WaitForPageReadyAsync 将轮询此选择器直到元素出现，
    /// 确保 SPA 框架已完成渲染。
    /// 例如 Emby/Jellyfin 登录页的"手动登录"按钮：.emby-button
    /// 返回 null 则回退到 document.readyState 检测。
    /// </summary>
    string? PageReadyDomSelector => null;

    /// <summary>
    /// 【登录表单检测】登录页独有的 DOM 元素选择器（可选，推荐设置）。
    /// 用于判定"当前是否仍在登录页"（已登录检测的反向排除）。
    /// 必须与 PageReadyDomSelector 分离的原因：部分方案的就绪元素在登录成功页
    /// 同样存在（如 Jellyfin 的 .emby-button 是通用按钮类，首页也存在），
    /// 若用它做"仍在登录页"判据会把已登录状态误判为未登录，
    /// 导致登录脚本注入后找不到表单而失败（"令牌链接被短路"）。
    /// 应选择仅在登录表单上存在的元素（如用户名输入框的 id/选择器）。
    /// 返回 null 则回退使用 PageReadyDomSelector。
    /// </summary>
    string? LoginFormDomSelector => null;

    /// <summary>
    /// 登录表单在成功页残留（隐藏）时是否视为已登录（可选）。
    /// Jellyfin 登录成功后将登录表单隐藏（display:none）而非从 DOM 移除——
    /// #txtManualName / #txtManualPassword / #loginPage 等仍在成功页 DOM 中，
    /// 仅做"存在性"检测会把成功页误判为"仍在登录页"。
    /// 启用后，检测到登录表单元素存在但不可见（getClientRects 为空）即判定已登录。
    /// 默认 false（仅存在性检测，适用于成功页不残留表单的方案，如 DSM/ESXi）。
    /// </summary>
    bool HiddenLoginFormIndicatesLoggedIn => false;

    /// <summary>
    /// 预登录后密码页的就绪 DOM 选择器（可选）。
    /// 用于分步登录场景——预登录脚本执行后（如填用户名+点击下一步），
    /// 平台会轮询此选择器等待密码输入框出现。
    /// 例如 Synology DSM 密码框：[syno-id="password"]
    /// 返回 null 表示无需额外等待。
    /// </summary>
    string? PasswordPageDomSelector => null;

    /// <summary>
    /// 登录页面延迟到工作区触发（用于加载极慢的方案，如 IMM）。
    /// 设为 true 时，AutoLoginAsync 在预检（已登录/通知页）通过后立即返回"令牌已链接"，
    /// 不执行任何登录脚本；等到用户切换到该方案的工作区页面时才执行实际登录。
    /// 默认 false。
    /// </summary>
    bool DeferLoginToWorkspace => false;

    /// <summary>
    /// 【步骤1】获取预登录 JavaScript 脚本（可选）。
    /// 在主登录脚本之前执行，用于展开登录表单、填入用户名等准备工作。
    /// 例如 Emby 点击"手动登录"按钮展开账密输入框；
    /// Synology DSM 填入用户名并点击"下一步"跳转到密码页。
    /// 返回 null 表示无需预登录步骤，直接执行主登录脚本。
    /// </summary>
    /// <param name="token">已解密的令牌（AccountName/AccountPassword 为明文）</param>
    string? GetPreLoginScript(Token? token) => null;

    /// <summary>
    /// 【步骤2】获取自动登录 JavaScript 脚本。
    /// 在 WebView2 页面 DOMContentLoaded 后注入执行。
    /// 脚本应为同步代码（不使用 Promise），填入凭据并点击提交按钮。
    /// 返回 null 表示该方案不支持自动登录（或凭据不完整）。
    /// </summary>
    /// <param name="token">已解密的令牌（AccountName/AccountPassword 为明文）</param>
    string? GetAutoLoginScript(Token token);

    /// <summary>
    /// 预登录脚本执行后、主登录脚本执行前的等待时间（毫秒）。
    /// 用于等待动画过渡、DOM 出现等。默认 1500ms。
    /// </summary>
    int PreLoginDelayMs => 1500;

    /// <summary>
    /// 登录脚本点击提交后、登录检测前的额外等待时间（毫秒）。
    /// 用于页面加载极慢的方案（如 IMM 需要等待成功页渲染）。
    /// 默认 0（不等待，NavCompleted 触发后立即检测）。
    /// </summary>
    int PostLoginDelayMs => 0;

    /// <summary>
    /// 登录成功后的页面特征 URL 片段（可选）。
    /// 设置后，自动登录将检测页面 URL 是否包含此片段来判断登录是否成功。
    /// 例如 Jellyfin 登录成功后 URL 变为 "/home.html"，可设置为 "home.html"。
    /// 返回 null 表示不检测（默认信任脚本执行成功）。
    /// </summary>
    string? LoginSuccessUrlFragment => null;

    /// <summary>
    /// 登录成功后的页面特征 DOM 选择器（可选）。
    /// 设置后，自动登录将检测页面中是否存在匹配此选择器的元素来判断登录是否成功。
    /// 例如 Jellyfin 登录成功后页面中有 ".dashboardSection"，可设置为 ".dashboardSection"。
    /// 返回 null 表示不通过 DOM 检测。
    /// </summary>
    string? LoginSuccessDomSelector => null;

    /// <summary>
    /// 通知/维护页面的特征 URL 片段（可选）。
    /// 设置后，自动登录将检测当前 URL 是否包含此片段，
    /// 若命中则跳过自动登录并显示"有通知，令牌链接已中断"。
    /// 例如 Emby/Jellyfin 维护通知页 /notice，可设置为 "notice"。
    /// 返回 null 表示不检测。
    /// </summary>
    string? NoticeUrlFragment => null;

    /// <summary>
    /// 登录页面的特征 URL 片段（可选，用于反向排除）。
    /// 设置后，DetectLoginSuccessAsync 会优先检查当前 URL 是否包含此片段，
    /// 若命中则直接判定为未登录（即使 LoginSuccessUrlFragment 也匹配）。
    /// 例如 Jellyfin 登录页 URL 含 "login"，可设置为 "login"。
    /// 返回 null 表示不做反向排除，直接按正向特征检测。
    /// </summary>
    string? LoginPageUrlFragment => null;
}
