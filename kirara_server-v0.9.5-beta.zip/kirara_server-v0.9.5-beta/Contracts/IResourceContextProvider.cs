namespace Kirara_Server_WinUI.Contracts;

/// <summary>
/// [评论区功能] 资源上下文提供者接口 — 方案可选实现
/// 实现此接口可自定义评论区的资源键和显示标题。
/// 默认使用 WebView2 当前 URL 路径作为资源键。
/// </summary>
public interface IResourceContextProvider
{
    /// <summary>
    /// 获取当前资源的标识键（用于关联评论）。
    /// 返回 null 则使用默认的 WebView2 URL 路径。
    /// </summary>
    string? GetResourceKey();

    /// <summary>
    /// 获取当前资源的显示标题（用于评论区标题栏）。
    /// 返回 null 则使用方案的 DisplayName。
    /// </summary>
    string? GetResourceTitle();
}
