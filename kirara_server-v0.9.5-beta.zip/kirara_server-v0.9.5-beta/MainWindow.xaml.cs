using Kirara_Server_WinUI.Helpers;
using Microsoft.UI.Xaml;

namespace Kirara_Server_WinUI
{
    public sealed partial class MainWindow : Window
    {
        /// <summary>
        /// 当前窗口实例（隐藏 Window.Current）
        /// </summary>
        public new static MainWindow? Current { get; private set; }

        public MainWindow()
        {
            InitializeComponent();
            Current = this;
        }

        /// <summary>
        /// 启用窗口动画（由 App.OnLaunched 在内容加载后调用）
        /// </summary>
        internal void EnableAnimations()
        {
            WindowAnimationHelper.EnableResizeAnimation(this);
        }
    }
}
