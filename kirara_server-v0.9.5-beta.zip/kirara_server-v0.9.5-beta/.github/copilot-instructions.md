---

# AGENTS.md — Kirara_Server 项目 AI 代理指令文件

---

## 一、项目概览

**Kirara_Server** 是一款基于 **WinUI 3 + .NET 10** 的 Windows 桌面应用程序。用户通过 **创建实例 → 选择方案 → 链接令牌** 的方式使用和管理内置的多种服务（媒体、直播、云存储、邮件、虚拟化、远程桌面等），实现"一次配置，多服务直达"。

- 代码完成度：约 **95%**（基础架构层完整，UI 交互层基本完成；Phase 1-3 首页功能已全部实现，含全屏背景板、通知中心、快速开始向导；**登录认证系统已完整实现**，含登录/注册/自动登录/忙状态遮罩/表单动画/全局遮罩覆盖标题栏；**账号设置系统已完整实现**，含头像上传/用户名修改/密码修改/名片信息/三方绑定桩；**远程 API 接入**：远程登录认证（JWT+RefreshToken）和远程模板获取已实现；**实例/令牌管理系统**已完整实现；**设置页面**已实现；**方案图标缓存**已实现；**方案页全局缓存**已实现；**导入导出**已实现；**第三方方案扫描器桩**已就绪；**信息流卡片**✅已在首页通知中心以 FlipView 原生轮播实现（图片/视频/HTML 三类卡片，圆点导航+自动播放）；**OpenVPN 方案**✅已完整实现，含自研管理面板 + openvpn.exe 子进程 + .ovpn 服务端同步，应用整体提权（requireAdministrator））
- 项目路径：`Kirara_Server-WinUI/`
- 主解决方案：`Kirara_Server-WinUI.slnx`
- 目标框架：`net10.0-windows10.0.19041.0`

### 服务器通信现状

> **服务端状态**：Kirara_Server-API（ASP.NET Core 10）**全部 API 已实现**（认证/评论/通知/模板/方案URL/资源/信息流卡片/管理功能），详见 `docs/服务端后端系统技术栈.md`。
> **客户端接入**：以下功能客户端当前为本地模式，通过创建 `Remote*Service` + DI 替换注册即可接入。

| 功能 | 客户端状态 | 服务端 API | 关键代码位置 |
|------|-----------|-----------|-------------|
| 首页背景图片 | ✅ HTTP 下载已实现 | ✅ `GET /api/resources/home-background` | `BackgroundService.cs` |
| 用户头像 | ✅ HTTP 下载+上传已实现 | ✅ `PUT/GET /api/resources/user-avatar` | `UserAvatarService.cs` |
| 账号认证 | ✅ **远程认证已实现**（JWT+RefreshToken） | ✅ `POST /api/auth/*` (BCrypt+JWT) | `RemoteLoginService.cs` |
| 消息推送 (Push) | ✅ **SignalR 实时推送已接入**（断线重连 + HTTP 离线补拉） | ✅ SignalR Hub + REST API | `RemoteNotificationService.cs` |
| 实例模板 | ✅ **远程模板已实现**（含封面图缓存） | ✅ `GET /api/templates` (含封面图) | `RemoteQuickStartService.cs` |
| 议题评论 | ✅ **远程评论已接入**（REST API，DI 替换 CommentService） | ✅ `/api/comments/*` (含回复/点赞) | `RemoteCommentService.cs` |
| 方案 URL 同步 | ✅ **增量同步已实现**（POST /api/scheme-urls/sync） | ✅ `POST /api/scheme-urls/sync` (增量同步) | `ServerUrlService.SyncFromServerAsync()` |
| 方案图标缓存 | ✅ **HTTP 下载+加密缓存已实现**（方案A加密合并） | ✅ `GET /api/scheme-urls/{key}/image` | `SchemeIconCacheService.cs` |
| OpenVPN 配置 | ✅ **已接入**（版本比对+预签名URL下载+方案A加密缓存；openvpn.exe 子进程连接引擎） | ✅ `GET/PUT/DELETE /api/openvpn` | `OvpnConfigCacheService.cs` / `VpnConnectionService.cs` |
| 信息流卡片 | ✅ **信息流页面已实现**（首页通知中心 FlipView 原生轮播，图片/视频/HTML 三类，方案B媒体缓存） | ✅ `GET /api/info-cards`, `/sync` | `MainPage.xaml` / `NotificationCenterViewModel` |
| 管理功能 | 🔴 未接入 | ✅ `/api/admin/*` (用户/URL/通知/模板) | — |

> **关键文档**: 客户端 `docs/技术栈文档.md`（含 OpenVPN 4.5e） | 服务端 `docs/服务端后端系统技术栈.md` | API 完整文档 `docs/Kirara Server API 完整文档.md` | 待实施扩展 `docs/Kirara_Server 功能扩展技术文档.md`（RDP / 打包分发）

---

## 二、技术栈

| 层级 | 技术 | 版本 |
|------|------|------|
| UI 框架 | WinUI 3 (Windows App SDK) | 2.3.1 |
| 目标框架 | .NET 10 | `net10.0-windows10.0.19041.0` |
| 语言 | C# 13 | 全项目统一 |
| MVVM 工具包 | CommunityToolkit.Mvvm | 8.4.0 |
| DI 容器 | Microsoft.Extensions.DependencyInjection + Hosting | 10.* |
| 嵌入式数据库 | LiteDB | 5.* |
| 加密 | DPAPI + AES-256-GCM | `System.Security.Cryptography` |
| XAML 样式 | Fluent 2 Design Language | 自定义 ResourceDictionary `AppStyles.xaml` |
| HTTP 客户端 | System.Net.Http.HttpClient | 内置，用于背景图片/头像/模板/信息流/.ovpn 下载与 API 调用 |
| JSON 序列化 | System.Text.Json | 内置，用于推送通知解析与数据导入导出 |
| 打包分发 | MSIX (可选) / Unpackaged | — |

> **服务端现状**: 后端 **Kirara_Server-API**（ASP.NET Core 10 + PostgreSQL + Redis + MinIO + SignalR）**全部 API 已实现**，详见 `docs/服务端后端系统技术栈.md`。客户端通过实现已有接口的远程版（如 `RemoteCommentService : ICommentService`）接入，DI 替换注册即可，无需改动 ViewModel/UI 层。

---

## 三、项目结构

```
Kirara_Server-WinUI/
├── App.xaml(.cs)              # 应用入口 + DI 容器 + 全局异常捕获
├── MainWindow.xaml(.cs)       # 主窗口
├── Contracts/                 # 接口定义 (IScheme, IAutoLoginProvider 等)
├── Models/                    # 数据模型 (Instance, Scheme, Token, CommentItem 等)
├── Data/                      # 数据访问层 (LiteDB Repository)
├── Services/                  # 业务逻辑层 (20 个接口+实现，共 41 个文件)
│   ├── AuthModels.cs         # 🆕API 统一响应模型 + 认证 DTO
│   ├── SecureCacheService.cs # 🆕安全缓存服务（方案A加密合并/方案B加密meta，防篡改）
│   ├── RemoteLoginService.cs # 🆕远程登录认证（JWT+RefreshToken，已接入服务端 API）
│   ├── RemoteQuickStartService.cs # 🆕远程模板获取（HTTP + 封面图加密缓存）
│   ├── SchemeIconCacheService.cs  # 🆕方案图标缓存（HTTP + 加密缓存）
│   ├── LoggingService.cs     # 日志服务（环形缓冲区+TraceListener重定向）
│   ├── NotificationService.cs# 通知服务（全局总线，Push/Service/Log三类别）
│   ├── NotificationWiringHelper.cs # 🆕通知源连接器
│   ├── BackgroundService.cs  # 背景图片管理（方案A加密缓存/下载/服务器同步/降级）
│   ├── PermissionService.cs  # 权限管理（管理员/用户组权限控制）
│   ├── UserAvatarService.cs  # 头像管理服务（方案A加密缓存/下载/上传/居中裁剪70×70）
│   ├── ExportImportService.cs# 🆕导入导出服务（实例/令牌 JSON 导入导出）
│   ├── SchemePageCache.cs    # 🆕方案宿主页全局缓存管理器
│   ├── AutoLoginService.cs   # 🆕自动登录编排服务
│   ├── NavigationService.cs  # 🆕导航服务
│   ├── TokenService.cs       # 🆕令牌管理服务
│   ├── InstanceService.cs    # 🆕实例管理服务
│   ├── SchemeService.cs      # 🆕方案管理服务
│   ├── ServerUrlService.cs   # 🆕服务器 URL 管理服务
│   ├── CommentService.cs     # 🆕评论服务
│   ├── RemoteCommentService.cs # 🆕远程评论服务（REST API，DI 替换 CommentService）
│   ├── CommentPanelService.cs# 🆕评论面板服务
│   ├── RemoteInfoCardService.cs # 🆕信息流卡片服务（增量版本同步 + CDN 预签名 URL）
│   ├── LocalInfoCardStore.cs # 🆕信息流卡片本地持久化
│   ├── LocalTemplateStore.cs # 🆕模板列表本地持久化（方案A加密存储）
│   ├── RemoteNotificationService.cs # 🆕远程通知服务（SignalR 实时推送 + HTTP 离线补拉）
│   ├── VpnConnectionService.cs # 🆕OpenVPN 连接服务（openvpn.exe 子进程 + management 管理接口）
│   ├── OvpnConfigCacheService.cs # 🆕.ovpn 配置缓存服务（服务端下载 + 方案A加密缓存）
│   ├── DialogService.cs      # 🆕对话框服务
│   └── CryptoService.cs      # 🆕加密服务（DPAPI + AES-256-GCM）
├── tools/                     # 自测工具（不参与主项目构建）
│   └── SecureCacheSelfTest/   # 🆕加密缓存自测（加密/解密/篡改检测 29 项断言）
├── Schemes/                   # 方案插件实现
│   ├── BaseScheme.cs          # IScheme 基类
│   ├── BuiltIn/               # 用户实例方案 (Media, OpenVPN, Alist, Note, Moment 等 11 个)
│   ├── Service/               # 服务实例方案 (AppServer, ESXi, IMM, OpenVPN, BitComet 等 14 个)
│   └── ThirdParty/            # 第三方方案扫描器桩
├── ViewModels/                # ViewModel 层 (17 个文件)
│   ├── MainWindowViewModel.cs               # 主窗口 VM（全局状态）
│   ├── Pages/
│   │   ├── MainPageViewModel.cs             # 首页 VM（登录状态/模板/通知概览/问候语定时刷新）
│   │   ├── LoginPageViewModel.cs            # 登录页 VM（登录/注册/密码强度/实时校验/自动登录）
│   │   ├── QuickStartWizardViewModel.cs     # 快速开始向导 VM
│   │   ├── AccountSettingsViewModel.cs      # 账号设置 VM（头像/用户名/密码/三方绑定桩）
│   │   ├── SettingsViewModel.cs             # 🆕设置页面 VM（主题切换/导入导出）
│   │   ├── TokenEditorViewModel.cs          # 🆕令牌编辑器 VM（三步向导）
│   │   ├── TokenManagerViewModel.cs         # 🆕令牌管理器 VM（列表/搜索/导入导出）
│   │   └── InstanceEditorViewModel.cs       # 🆕实例编辑器 VM（四步向导）
│   ├── Controls/
│   │   ├── NotificationCenterViewModel.cs   # 通知中心 VM（三标签页+实时订阅）
│   │   ├── LeftFunctionBarViewModel.cs      # 🆕左侧功能栏 VM
│   │   ├── InstanceCardViewModel.cs         # 🆕实例卡片 VM
│   │   ├── NotificationBadgeViewModel.cs    # 🆕通知徽章 VM
│   │   ├── SchemeTabBarViewModel.cs         # 🆕方案标签栏 VM
│   │   └── StatusBarViewModel.cs            # 🆕状态栏 VM
│   ├── Comment/
│   │   ├── CommentItemViewModel.cs          # 🆕评论项 VM
│   │   ├── CommentWindowViewModel.cs        # 🆕评论窗口 VM
│   │   └── ReplyItemViewModel.cs            # 🆕回复项 VM
│   └── Instance/
│       ├── InstanceWorkspaceViewModel.cs    # 🆕实例工作区 VM
│       └── SchemeHostViewModel.cs           # 🆕方案宿主 VM
├── Views/                     # XAML 视图层 (28 个文件，全部完整)
│   ├── ShellPage.xaml(.cs)                 # 主框架（标题栏/功能栏/内容区/全局遮罩）
│   ├── Pages/
│   │   ├── MainPage.xaml(.cs)              # 首页（登录面板/快速开始/通知中心三标签页动画+账号设置面板叠加）
│   │   ├── LoginPage.xaml(.cs)             # 登录页（登录/注册表单切换动画+密码强度+自动登录）
│   │   ├── QuickStartWizardPage.xaml(.cs)  # 快速开始向导页
│   │   ├── SettingsPage.xaml(.cs)          # 🆕设置页面（主题切换/导入导出）
│   │   ├── TokenEditorPage.xaml(.cs)       # 🆕令牌编辑器页（三步向导）
│   │   ├── TokenManagerPage.xaml(.cs)      # 🆕令牌管理器页（列表/搜索/导入导出）
│   │   ├── InstanceEditorPage.xaml(.cs)    # 🆕实例编辑器页（四步向导）
│   │   └── InstanceSummaryPage.xaml(.cs)   # 🆕实例概览页
│   ├── Controls/
│   │   ├── LeftFunctionBar.xaml(.cs)       # 🆕左侧功能栏
│   │   ├── TopTitleBar.xaml(.cs)           # 🆕自定义标题栏
│   │   ├── InstanceCard.xaml(.cs)          # 🆕实例卡片
│   │   ├── NotificationBadge.xaml(.cs)     # 🆕通知徽章
│   │   ├── SchemeTabBar.xaml(.cs)          # 🆕方案标签栏
│   │   ├── StatusBar.xaml(.cs)             # 🆕状态栏
│   │   └── OpenVpnControl.xaml(.cs)        # 🆕OpenVPN 自研管理面板（状态/流量/日志/连断）
│   ├── Comment/
│   │   ├── CommentPanel.xaml(.cs)          # 🆕评论面板
│   │   └── CommentWindow.xaml(.cs)         # 🆕评论窗口
│   └── Instance/
│       ├── InstanceWorkspace.xaml(.cs)     # 🆕实例工作区
│       └── SchemeHostPage.xaml(.cs)        # 🆕方案宿主页（WebView2/RDP 容器）
├── Converters/                # XAML 值转换器 (22 个)
├── Helpers/                   # 工具类 (BindingProxy, ThemeHelper, HtmlContentHelper, ResourceKeyBuilder, ScreenAdaptation 等 8 个)
├── Styles/                    # Fluent2 样式资源字典 AppStyles.xaml
├── Assets/                    # MSIX 图标/启动画面资源
├── docs/                      # 📘 项目文档（开发前必读）
│   ├── 技术栈文档.md           # 客户端完整架构与技术栈（含 OpenVPN 4.5e）
│   ├── 服务端后端系统技术栈.md   # 服务端搭建规划（API/数据库/部署）
│   ├── 需求文档.md
│   ├── 首页开发计划.md
│   ├── Kirara Server API 完整文档.md
│   └── Kirara_Server 功能扩展技术文档.md # 待实施扩展（RDP / 打包分发）
└── .github/
    └── copilot-instructions.md # 本文件
```

**⚠️ 重要目录约束：**
- **`Contracts/`、`Models/`、`Data/`、`Services/`** — 基础架构层，非必要勿改动，新增全新的功能可以增加，但是请仔细阅读docs/下的技术栈文件再开发
- **`Schemes/`** — 方案业务逻辑层，**仍可扩展**（如补充 IAutoLoginProvider 实现）
- **`Views/`** — UI 交互层，**28/28 个文件已完成**，新增视图遵循现有布局模式
- **`ViewModels/`** — 逻辑层，新增功能须先在此层添加 VM

---

## 四、构建与运行

```bash
# Debug (Unpackaged 模式 — 推荐开发调试)
dotnet build -c Debug

# Release (MSIX 打包发布)
dotnet publish -c Release -p:Platform=x64

# Visual Studio 启动配置:
# "Kirara_Server-WinUI (Package)"      — MSIX 打包运行
# "Kirara_Server-WinUI (Unpackaged)"   — 直接运行 (推荐调试)
```

**注意事项：**
- TFM 为 `net10.0-windows10.0.19041.0`，需要 .NET 10 SDK + Windows App SDK 运行时
- WebView2 的 `EnsureCoreWebView2Async()` **必须在 UI 线程调用**
- WinUI3 的 PasswordBox **不支持直接绑定 MVVM**，需通过 code-behind 中转

---

## 五、架构约束与设计原则

### 5.1 MVVM + DI 架构
- 所有依赖通过 DI 容器管理生命周期（Singleton / Transient）
- ViewModel 使用 `[ObservableProperty]` 和 `[RelayCommand]` 特性
- Repository 为 Singleton，Service 为 Singleton，ViewModel 按作用域选择
- **禁止**在 View 中直接操作业务逻辑；所有业务逻辑应委托给 Service

### 5.2 数据层规范
- 数据库路径：`%APPDATA%/Kirara/data.db`（LiteDB 单文件）
- 集合清单：`instances`、`schemes`、`tokens`、`server_urls`、`users`、`comments`
- 种子数据写入 `AppDatabase.SeedBuiltInSchemes()`，启动同步在 `SchemeService.SyncBuiltInSchemas()`
- 所有新集合须在 `AppDatabase.cs` 中注册索引

### 5.3 加密规范
- 令牌敏感字段（AccountName, AccountPassword, ApiKey, ServerUrl）**必须** AES-256-GCM 加密存储
- 加密前缀格式：`"KIRARA_ENC:" + Base64(密文)`
- AES 密钥由 DPAPI（`DataProtectionScope.CurrentUser`）保护，存于 `%APPDATA%/Kirara/.key`
- **服务器资源缓存必须经 `SecureCacheService` 加密存储（v1.7+）**：
  - 方案A（小文件）：头像/背景图/模板封面/方案图标/.ovpn/模板列表 JSON → 内容+ETag 合并加密单文件 `.enc`
  - 方案B（大媒体）：信息流图片/视频/HTML → 内容明文 + 加密 meta（SHA256 校验防篡改）
  - **禁止**再新增明文缓存 + 独立 meta 文件的方式（旧格式解密失败自动重下，无需迁移）
  - 解密后的临时明文统一放 `%APPDATA%/Kirara/tmp/`（启动时 `CleanupTempDirectory()` 清理）
  - 新增缓存服务后运行自测：`dotnet run --project tools/SecureCacheSelfTest -c Debug -p:Platform=x64`

### 5.4 方案插件系统
- 所有方案必须实现 `IScheme` 接口（位于 `Contracts/IScheme.cs`）
- 新方案建议继承 `BaseScheme`（提供虚默认实现）
- 5 种 UI 呈现方式按需选择：`CustomControl` / `WebView2` / `RDP` / `ExternalProcess` / `Overlay`
- `DefaultUrlKey` 默认返回方案 `Name`，由 `BaseScheme` 自动处理，无需在每个方案中显式重写
- 无需 URL 的方案（Topic / GameServer）需显式重写 `DefaultUrlKey => null`；**OpenVpn 显式返回 `"openvpn"`**（服务器地址回退来源，主来源为令牌 ServerUrl，连接实际使用 .ovpn 内配置）
- **OpenVPN 方案（CustomControl）已实现**：`VpnConnectionService`（子进程 + management 管理接口）+ `OvpnConfigCacheService`（.ovpn 服务端同步）+ `OpenVpnControl`（自研面板），详见 `docs/技术栈文档.md` 4.5e

### 5.5 自动登录系统（IAutoLoginProvider）
- 已实现三层架构：`IAutoLoginService`（编排层）→ `SchemeHostViewModel`（状态管理层）→ `SchemeHostPage`（UI 渲染层）
- 新增 WebView2 方案的自动登录适配时，**实现 `IAutoLoginProvider`** 接口即可，共 13 个可配置项（v2.1 起新增 `LoginFormDomSelector` 登录表单判据元素；v2.2 起新增 `HiddenLoginFormIndicatesLoggedIn`——Jellyfin 成功页残留 display:none 隐藏表单时需设为 true）
- **登录状态检测优先级（v2.4 实测校准）**：① 登录表单 DOM **可见**（显式 `LoginFormDomSelector`）→ 未登录（**先于 URL 正向**，修复 Jellyfin 未登录访问 #/home.html 时 SPA 先渲染登录视图、hash 未重定向的竞态短路）；② URL 正向特征命中（成功 URL 精确片段）→ 已登录（**显式表单 DOM 未渲染 not_found 时 URL 不可信，不短路**——SPA 加载早期 URL 已是成功路由而 DOM 未渲染）；③ 登录表单可见（回退 PageReadyDomSelector，仅未显式设置时）→ 未登录（兼容 Alist @manage 页有可见 username 输入框）；④ URL 反向排除 → 未登录；⑤ 登录表单 DOM 隐藏且方案声明 → 已登录（成功页残留隐藏表单=成功特征）；⑥ 成功 DOM 存在 → 已登录（最弱，最后）
- **Jellyfin 必须放弃 URL 正向判据**（Media LoginSuccessUrlFragment=null）：Jellyfin 的 URL 无法区分登录状态——未登录访问 #/home.html 路由会停在 home.html（先渲染登录视图再异步重定向），完全依赖 DOM 可见性判据
- **登录表单判据必须用可见性而非存在性**：Jellyfin 登录成功只隐藏表单不移除 DOM（#txtManualName/#loginPage 在成功页仍存在），存在性检测会把成功页误判为"仍在登录页"
- **成功 DOM 选择器必须与登录页 DOM 严格互斥**：实测 .homePage 登录页 not_found/成功页 FOUND 可用；.libraryPage 成功页 home 视图也有、.dashboardSection 本版本不存在，均不可用
- **Alist 例外**：@manage 个人资料页有可见的 username/password 输入框，**不要**为 Alist 设置 LoginFormDomSelector（否则已登录被误判未登录且脚本误填充个人资料），其登录判据完全依赖 URL 正反向
- 使用 `DeferToWorkspace` + `PostLoginDelayMs` 处理极慢页面（如 IMM 需 20s 缓冲）

### 5.6 登录认证系统
- **ILoginService/LoginService**：基于本地数据库（SHA256+盐）的登录认证，支持登录/注册/自动登录
- **自动登录**：通过 `UserAccount.AutoLoginEnabled` 标记持久化，`TryAutoLoginAsync()` 从默认令牌读取加密凭据自动登录
- **忙状态遮罩**：全局 `GlobalBusyOverlay`（`ShellPage` 最顶层，覆盖标题栏），登录/注册操作中自动显示，最低 1s 显示时间
- **表单切换动画**：登录/注册表单通过 Grid 叠加实现交叉淡入淡出（卡片微缩 280ms → 弹性恢复 420ms），字段重置在旧表单隐藏后执行
- **PasswordBox 处理**：不支持直接 MVVM 绑定，需通过 `PasswordChanged` 事件 + code-behind 中转
- **退出登录抑制**：`_isLoggingOut` 标记防止导航回登录页时触发自动登录重入

### 5.7 通知与日志系统
- **INotificationService/NotificationService**：全局通知总线，支持 Push/Service/Log 三类别，每类别环形缓冲区 500 条
- **ILoggingService/LoggingService**：环形缓冲区日志（2000 条），通过 `ObservableTraceListener` 捕获 `Debug.WriteLine` 输出
- **通知语义**：服务项仅接收**方案级别通知**（如 OpenVPN 连接失败）与**开发者广播**（SignalR 服务端推送 / AppUpdate 下载失败）；事件（对话框、全局异常）与日志级别内容**不进入**服务项，日志统一走日志项
- Push 类别数据模型（`HtmlContent` 字段）和 UI 渲染已就绪，**客户端轮询拉取尚未实现**（服务端 SignalR Hub + REST API ✅ 已实现）

### 5.8 首页背景系统
- **IBackgroundService/BackgroundService**：本地加密缓存（方案A）→ 远程下载 → 降级内置默认图片
- 缓存路径：`%APPDATA%/Kirara/backgrounds/background_cache.enc`（ETag 内嵌加密信封，旧 jpg/txt 启动自动清理）
- 解密临时明文：`%APPDATA%/Kirara/tmp/background_cache.jpg`（UI 按路径加载）
- URL 注册表 Key：`home_background`（通过 `IServerUrlService` 管理）
- ShellPage 监听 `BackgroundChanged` 事件自动更新 `Image.Source`

### 5.9 ShellPage 层级结构
```
ShellPage Grid（从底到顶）:
├── [1] HomeBackgroundImage       — 首页全屏背景图片
├── [2] HomeOverlay (Rectangle)   — 抽屉动画暗色遮罩
├── [3] TopTitleBar               — 自定义标题栏
├── [4] LeftFunctionBar            — 左侧功能栏
├── [5] ContentFrame               — 页面导航（LoginPage / MainPage 等）
└── [6] GlobalBusyOverlay (Grid)  — 全局忙状态遮罩（覆盖标题栏）
```

### 5.10 账号设置系统
- **AccountSettingsViewModel**：由 MainPage 持有，管理头像/用户名/密码/三方绑定
- **头像资源链**（与 BackgroundService 一致）：本地缓存 → 服务器下载 → Glyph 降级
- **头像上传**：FileOpenPicker → 居中裁剪 70×70（BitmapTransform）→ 本地缓存 → 服务器上传
- **用户名修改**：校验规则与登录页注册一致（非法字符/长度/重复/新旧相同检测）
- **密码修改**：强度评估与登录页一致 + 当前密码验证 + 新旧密码相同检测
- **结果通知**：通过 `OnResultNotification` 事件 → MainPage 弹出 Flyout（锚定在触发按钮旁）
- **表单重置**：离开设置面板时调用 `ResetFormFields()` + PasswordBox code-behind 清空
- **设置面板动画**：打开时主页退场 → 面板从右侧滑入；关闭时面板滑出 → 主页入场
- **侧栏导航切出**：先关闭设置面板（跳过主页入场动画）→ 直接背景淡出 → 导航

### 5.11 外观主题系统（★ 新页面/新控件必读）

> **核心服务**：`AppThemeService`（Singleton，`Services/AppThemeService.cs`），存储于 LiteDB `app_settings`。
> 支持三组设置：**跟随系统开关**、**明暗主题**、**主题色（Win11 色盘）**。设置变化**立即全局生效，无需刷新页面**。

```
三种模式:
├── 跟随系统 (FollowSystem=true)   → root.RequestedTheme=Default + 不覆盖 SystemAccentColor（随 Windows 自动）
├── 手动明暗 (FollowSystem=false)  → root.RequestedTheme=Dark/Light
└── 手动主题色 (+AccentColor)      → Application.Resources 覆盖 SystemAccentColor/Light1-3/Dark1-3
                                   （衍生色=白/黑线性插值 20%/40%/60%）
```

**⚠️ 核心陷阱：`{ThemeResource SystemAccentColor}` 是"固化引用"**
- ThemeResource 在 XAML **加载时解析一次**，之后运行时改 `SystemAccentColor` 顶层键**不会刷新**
- `AppThemeService.ApplyAccentResources()` 通过「共享画刷实例改色 + 顶层键覆盖 + 强制主题重建」三管齐下，让全 UI 即时跟随

#### 5.11.1 XAML 静态引用规范（★ 新页面必须遵守）

| 用途 | 正确写法 | 错误写法 |
|------|---------|---------|
| 前景/背景/图标 | `{StaticResource KiraraAccentColorBrush}` | ❌ `{ThemeResource SystemAccentColor}` |
| 提亮变体 | `{StaticResource KiraraAccentLight2Brush}` | ❌ `{ThemeResource SystemAccentColorLight2}` |
| 压暗变体 | `{StaticResource KiraraAccentDark2Brush}` | ❌ `{ThemeResource SystemAccentColorDark2}` |
| 渐变 | `{StaticResource KiraraAccentGradientBrush}` | ❌ 自建 LinearGradientBrush |
| 步骤指示器 | `{StaticResource StepCompletedFill}` 等 9 键 | ❌ 页面内自建 SolidColorBrush |
| 令牌徽章 | `{StaticResource AppTokenBadgeBrush}` | ❌ 页面内自建 |

- 共享画刷定义在 `Styles/AppStyles.xaml`，`AppThemeService` 实时更新其 `Color` 实例 → StaticResource 引用方**即时跟随，无需刷新**
- **禁止**在页面/控件局部 Resources 中定义 `Color="{ThemeResource SystemAccentColor}"` 的画刷（加载时固化，不刷新）
- **禁止**在 XAML 中直接写 `{ThemeResource SystemAccentColor}`（除非是 AppStyles.xaml 桥接定义）

#### 5.11.2 C# 动态创建 UI 规范（code-behind / DialogService / FlyoutHelper）

- **推荐**：从 `Application.Current.Resources["KiraraAccentColorBrush"]` 取共享画刷实例（改色即时生效）
- **禁止**：`new SolidColorBrush((Color)Application.Current.Resources["SystemAccentColor"])`（快照拷贝，不跟随后续变化）
- 固定语义色（红/橙/绿等状态色、删除红、成功绿）设计上不跟随主题色，可硬编码

#### 5.11.3 新增控件类型的统一接入流程（防止遗漏）

```
1. 找出控件模板引用的主题色资源键（如 ToggleSwitchFillOn*、PivotHeaderItemSelectedPipeFill）
   ⚠️ 这些键在 XamlControlsResources 加载时已从 SystemAccentColor 解析固化
2. 在 AppThemeService.cs 定义键组（8 键状态组用 ApplyControlResourceKeys，单键直接 Set）
3. 加入 ControlAccentKeyGroups 注册表（覆盖/移除分支自动同步，只需登记一处）
4. 新增全局共享画刷（若 XAML 需要引用）→ AppStyles.xaml 定义 + ApplyAccentResources() 末尾 SetBrushColor 更新
5. 构建测试: dotnet build -c Debug -p:Platform=x64
```

**已有键组清单**（`ControlAccentKeyGroups` + 单键）：ToggleSwitch 开关轨道 / RadioButton 选中外圈 / CheckBox 勾选框选中态 / ContentDialog 默认按钮(AccentButtonStyle) / Pivot 标签选中短线（`PivotHeaderItemSelectedPipeFill`+`FocusPipeFill`）/ RadioButtonCheckGlyphStroke。

#### 5.11.4 主题变化刷新机制（已实现，勿重复造轮子）

- **共享画刷改色**：`SetBrushColor()` 更新 AppStyles.xaml 共享 SolidColorBrush 实例 → StaticResource 引用方即时变
- **控件模板键覆盖**：顶层 Set/Remove `ToggleSwitchFillOn*` 等固化键
- **强制主题重建**：`ForceThemeRebuildIfAccentChanged()` — RequestedTheme 往返切换（基于 ActualTheme 切相反值，触发 ActualThemeChanged → 全树 ThemeResource 重新解析）
- **转换器缓存刷新**：`BoolToHighlightBrushConverter/InstanceActiveToBrushConverter/StatusToBrushConverter.InvalidateCache()` 直接更新已缓存画刷实例的 Color（不能只置 null！x:Bind 绑定值不变时 Convert 不会被重新调用）
- **独立窗口同步**：`AppThemeService.ThemeChanged` 事件 → `CommentWindow` 订阅同步 `RequestedTheme`（独立窗口不在 MainWindow 内容树）
- **服务通知默认图标**：`AppNotification.SeverityColor` Info 分支返回 `"KiraraAccentColorBrush"` 资源键字符串（StringToBrushConverter 返回共享实例）；Error/Warning 保持固定红/橙

---

## 六、编码规范

### 6.1 C# 代码规范
- 使用 C# 13 语法，全项目统一文件范围命名空间
- 文件名与类名一致（PascalCase）
- **禁止**使用 `var` 替代内置类型（如 `int`、`string`、`bool`）
- **禁止**引入新的第三方 NuGet 依赖；如有需要须先说明理由

### 6.2 XAML 规范
- 所有新建控件使用 `AppStyles.xaml` 中定义的样式键（`CardStyle`、`AcrylicPanelStyle`、`PrimaryButtonStyle`）
- 颜色引用使用 `ThemeResource` 实现深色/浅色自适应，**禁止**硬编码颜色值
- **主题色引用必须用 `{StaticResource KiraraAccentColorBrush}` 系列共享画刷**（详见 5.11.1），**禁止**直接写 `{ThemeResource SystemAccentColor}`（加载时固化，主题色切换不刷新）
- **禁止**在页面局部 Resources 定义 `Color="{ThemeResource SystemAccentColor}"` 的画刷（同固化问题）
- 自定义标题栏的 `ExtendsContentIntoTitleBar = true` 模式不要改动

### 6.3 注释与文档
- 所有公开接口方法须有 XML 文档注释
- 敏感/复杂逻辑须添加行内注释说明意图
- 方案的 `IAutoLoginProvider` 实现须标注适配的登录步骤和 DOM 选择器

---

## 七、边界约束与安全规则

### ❌ 禁止操作
1. **禁止**修改 `%APPDATA%/Kirara/` 下的数据库和密钥文件
2. **禁止**在未说明的情况下改变既定目录结构和架构分层
3. **禁止**在 `Schemes/` 之外新建功能目录（如把业务逻辑放到 `Helpers/`）
4. **禁止**在不通知的情况下删除或重命名已有 Repository 接口方法
5. **禁止**在非 UI 线程调用 WebView2 操作（`EnsureCoreWebView2Async` 等）

### ⚠️ 高敏感操作（需二次确认）
- 改动 DI 容器注册策略（Singleton ↔ Transient 变更）
- 修改 LiteDB 集合索引或数据模型字段定义
- 变更加密/解密流程（`CryptoService`）
- 删文件、改 Git 配置、改 CI/CD

### ✅ 安全第一原则
> **安全性 = 正确性 > 最小变更 > 可读性 > 一致性**[^23]

遇到阻塞点（动机不清、前置假设不成立、信息不足、方案存在冲突点）时，**立即停下报告，不要凭猜测继续推进**。

---

## 八、常见开发任务

### 8.1 新建一个 WebView2 方案
```
1. 在 Schemes/BuiltIn/ 或 Schemes/Service/ 下新建 XxxScheme.cs
2. 继承 BaseScheme，设置 Name / DisplayName / UIKind = WebView2 / IconGlyph + 指定唯一的 Guid Id
3. 如果该页面需要自动登录，实现 IAutoLoginProvider 接口
4. 确保 URL 注册表中有对应 Key（或让用户通过 ServerUrlService 注册）
5. 在 SchemeService.cs 的 BuiltInSchemeMap 中添加 Guid → Type 映射
   （SeedBuiltInSchemes() 通过反射自动扫描 BaseScheme 子类，无需手动修改）
6. 构建测试: dotnet build -c Debug
```

### 8.2 为已有方案添加自动登录
```
1. 在方案类上实现 IAutoLoginProvider 接口
2. 设置 PageReadyDomSelector（SPA 就绪选择器）
3. 实现 GetPreLoginScript / GetAutoLoginScript
4. 设置 LoginSuccessDomSelector 和 LoginPageUrlFragment
5. 如果页面加载慢，使用 DeferToWorkspace + PostLoginDelayMs
```

### 8.3 首页开发（Phase 1-3）
首页功能已全部实现，参照 `docs/` 目录下的技术栈文档和首页开发计划：
- **Phase 1**：核心骨架（LoggingService + NotificationService + ShellPage 背景层）✅已实现
- **Phase 2**：功能填充（QuickStartWizardPage + NotificationCenter + BackgroundService）✅已实现
- **Phase 3**：增强完善（登录面板 ✅ + SignalR 推送 ✅已接入（断线重连+离线补拉） + 方案 URL 服务器同步 ✅已实现）

**复用原则**：优先复用 `InstanceEditorViewModel.SchemeTokenBinding`、`IQuickStartService`、`IInstanceService` 等现有组件，而不是重新造轮子。

### 8.4 首页/登录页面 UI 动画
- **首页入场动画**：三个一级容器按序（登录面板 → 快速开始 → 通知中心）逐个淡入 + 微上浮（Y: 20→0 + BackEase），通知中心带缩放弹出效果（Scale: 0.85→1.0）
- **通知中心标签切换**：Pivot 标签切换带动画（旧面板淡出+滑出 → 新面板从反方向滑入+淡入，300ms CircleEase）
- **登录表单切换**：登录/注册表单通过 Grid 叠加 + 交叉淡入淡出 + 卡片弹性缩放（280ms 收缩 → 420ms 弹性恢复）
- **登录→首页过渡**：登录成功 → 忙状态遮罩消失 → 卡片退出动画 → 暗色遮罩抽屉式拉入 → 导航到首页（900ms QuinticEase）
- **退出登录过渡**：左侧栏淡出 + 首页退出动画 → 暗色遮罩抽屉式拉出 → 导航到登录页

### 8.5 登录页面开发注意事项
- 登录成功后 `IsBusy` 保持 `true`（遮罩保持显示），由 ShellPage 的 `LoginStateChanged` 回调处理后续动画
- 字段重置必须在表单切换动画的淡出完成后调用（`CompleteFormSwitch()`），防止子控件绑定提前消失
- 自动登录时跳过入场动画（`LoginCard.Opacity = 0`），防止卡片穿过遮罩层闪现
- 退出登录时通过 `_isLoggingOut` + `SuppressAutoLogin` 双重抑制，防止导航回登录页后触发自动登录重入

### 8.6 接入服务端 API（通用流程）
```
1. 阅读 docs/服务端后端系统技术栈.md 了解目标 API 端点
2. 在 Services/ 下新建 RemoteXxxService.cs，实现已有 I*Service 接口
3. 内部使用 HttpClient 调用 REST API，System.Text.Json 序列化/反序列化
4. 在 App.xaml.cs 的 ConfigureServices() 中替换 DI 注册:
   services.AddSingleton<ICommentService, RemoteCommentService>();  // 替换 CommentService
5. 构建测试: dotnet build -c Debug
```
**注意**：不需要新建接口，不需要改动 ViewModel 或 XAML 文件。

### 8.7 服务端项目（已全部实现）
> **服务端 Kirara_Server-API 已全部实现**，详见 `docs/服务端后端系统技术栈.md`。包含：
> - Auth / Comments / Notifications / Templates / SchemeUrls / Resources / InfoCards / Admin 全部 Controller
> - SignalR Hub `/hubs/notifications` 实时推送
> - MinIO 对象存储（头像/背景/封面/信息流媒体）
> - PostgreSQL + EF Core + Redis 输出缓存
> - Aspire 13 编排（Server + Redis + Frontend）
> - OpenAPI 文档生成

### 8.8 方案 URL 同步（✅ 已实现）

方案 URL 增量同步已在 `ServerUrlService.SyncFromServerAsync()` 中完整实现：

```
Step 1: 构建本地 Version 字典（从 server_urls 集合读取 SchemeName 非空的记录）
Step 2: POST /api/scheme-urls/sync → { localVersions }
Step 3: 处理 updated 列表 → UpsertBatch() 更新本地 DB（自动加密）
Step 4: 处理 deleted 列表 → 标记 SyncStatus="Removed" + Version++
Step 5: 触发 OnSchemeUrlChanged 事件（通知已打开方案的页面）
```

**调用链路**：`App.OnLaunched` → `SyncSchemeUrlsAsync()` (fire-and-forget) → `ServerUrlService.SyncFromServerAsync()`

**错误处理**：网络异常/超时（15s）→ 静默降级，仅输出 Debug 日志，不影响本地已有数据。

**事件订阅**：`OnSchemeUrlChanged` 事件已定义，`SchemeHostPage` 可订阅此事件检测当前方案 URL 变更后提示用户刷新或自动重载（当前尚未接入）。

### 8.9 信息流页面开发注意事项

**信息流卡片**直接在首页通知中心「信息流」标签中通过 **FlipView 原生轮播**渲染，一次显示一张卡片，圆点导航 + 自动播放切换（图片/视频/HTML 三类卡片）。

```
信息流卡片数据流:
RemoteInfoCardService (HTTP 拉取 GET /api/info-cards / POST /api/info-cards/sync 增量同步)
  → _cachedCards (原始 API DTO) → LocalInfoCardStore 本地持久化
  → CardsRefreshed 事件
    → NotificationCenterViewModel.ReloadCardsAsync()
      → 构建 InfoCardViewModel 集合（本地媒体缓存秒显 → 后台下载媒体）
        → 绑定 CardFlipView (NoWheelFlipView) / CardVideoPlayer / CardHtmlView
```

**关键文件**：
- `Services/RemoteInfoCardService.cs` — 远程拉取、增量版本同步、CDN 预签名 URL、本地持久化
- `ViewModels/Controls/NotificationCenterViewModel.cs` — 轮播切换（AutoPlayNext/PrevCard/NextCard）、HTML 生成、媒体缓存、圆点导航
- `Views/Pages/MainPage.xaml` — PushContentPanel 内嵌 NoWheelFlipView + MediaPlayerElement + WebView2
- `Controls/NoWheelFlipView.cs` — 禁用滚轮/触控滑动的 FlipView 变体

**设计要点**：
- 一次只渲染一张卡片，通过 `CurrentCardIndex` 与 `FlipView.SelectedIndex` 双向绑定切换
- 媒体加载优先级：本地文件缓存（方案B校验通过）→ CDN 预签名 URL
- **方案B防篡改**：内容明文 + 加密 meta（AES-GCM `{sha256, etag, version}`）；读取时解密 meta + SHA256 校验，任一失败删除重新下载
- 半透明遮罩（`#C7101010` + 圆角）覆盖在媒体左上角，显示标题/摘要/时间
- 缓存路径：`%APPDATA%/Kirara/info_cards_media/{cardId:N}_v{n}_{field}.{ext}` + `{path}.meta`（加密）
- 空状态时不显示轮播与圆点，显示"暂无信息流内容"

### 8.10 OpenVPN 方案开发注意事项

> **OpenVPN 方案已完整实现**（详见 `docs/技术栈文档.md` 4.5e），以下是开发/维护时的关键约束：

```
架构: OpenVpnScheme (CustomControl) → OpenVpnControl (纯 UI) → VpnConnectionService (子进程+management) + OvpnConfigCacheService (.ovpn 同步)
```

- **分层约束**：`OpenVpnControl` 是纯 UI 渲染层，所有业务逻辑委托 `VpnConnectionService`（Singleton）；禁止在控件内直接启动/管理进程
- **management 通信**：使用 `--management-client` 反向连接 + TcpListener 动态端口（**禁止**改回固定端口，避免多实例冲突）；`StreamWriter` 必须用无 BOM UTF-8（否则首条命令带 BOM 前缀导致 `state on` 失效）
- **stdout 必须异步读取**：不读取 stdout/stderr 会因管道缓冲区（4KB）填满导致 openvpn 进程永久阻塞（典型症状：15s"管理接口连接超时"）
- **连接成功判定**：`ConnectAsync` 返回只代表进程拉起 + 管理接口接入，连接成功需等状态机进入确定态（`Connected` / `Failed` / `Disconnected`）；stdout 中 `Initialization Sequence Completed` 是兜底铁证
- **.ovpn 配置无降级链路**：本地无缓存且服务端同步失败时连接直接中断（返回失败）；服务端不可达时保留本地缓存（可用性优先）
- **.ovpn 加密缓存（方案A）**：内容+版本号+ETag 合并加密单文件 `openvpn/ovpn_config.enc`（AES-256-GCM）；openvpn.exe 加载的是解密后的临时明文 `tmp/ovpn_config.ovpn`；篡改任意字节 → GCM 认证失败 → 重新下载（禁止改回明文 .ovpn + 独立 meta 方式）
- **硬重载/初始化语义**：硬重载 = 断开 + `ClearCacheAndResyncAsync()`（强制重新下载，不自动令牌链接）；初始化实例 = `ClearCacheOnlyAsync()`（清缓存不下载，下次部署时全新下载）；关闭实例 = 仅断开保留缓存
- **凭据安全**：账密运行时从绑定令牌解密（AES-256-GCM），经 auth.txt 临时文件注入，断开时清理；`--auth-nocache` 防止内存残留
- **提权**：应用整体 `requireAdministrator`（TAP/Wintun 网卡需要管理员权限），**不要移除** `app.manifest` 中的提权声明
- **进程清理**：应用退出（`MainWindow.Closed` → `VpnConnectionService.Dispose()`）、实例销毁（`SchemePageCache.DestroyInstance`）必须断开连接，防止残留 openvpn.exe

---

## 九、议题（评论区）开发注意事项

- 评论数据已持久化到 LiteDB `comments` 集合，通过 `ICommentRepository` / `CommentService` 操作
- 资源键格式：`"{schemeName}://{instanceId:N}{path}"`
- 评论面板的打开/关闭由 `ICommentPanelService` 管理，在 `ShellPage.OnContentNavigated` 中触发
- 远程 API 接入只需新建 `RemoteCommentService : ICommentService`，DI 替换注册即可，**无需改动 ViewModel / UI 层**
- **服务端搭建**: 详见 `docs/服务端后端系统技术栈.md`（整体架构）

---

## 十、服务器通信架构与接入指引

### 10.1 整体通信模型

```
┌────────────────────────────────────────────────┐
│  客户端 (WinUI 3)                              │
│                                                │
│  ┌──────────────────────────────────────────┐  │
│  │ 已实现 HTTP 通信:                         │  │
│  │  ✅ BackgroundService   → GET 下载背景图  │  │
│  │  ✅ UserAvatarService   → GET/POST 头像   │  │
│  │  ✅ RemoteLoginService  → POST /api/auth/*│  │
│  │  ✅ RemoteQuickStartService→GET /api/templates││
│  │  ✅ SchemeIconCacheService→GET /api/scheme-urls/{key}/image││
│  │  ✅ ServerUrlService    → POST /api/scheme-urls/sync ││
│  │  ✅ RemoteCommentService→ /api/comments/* │  │
│  │  ✅ RemoteInfoCardService→/api/info-cards │  │
│  │  ✅ OvpnConfigCacheService→/api/openvpn/* │  │
│  │  ✅ RemoteNotificationService → SignalR   │  │
│  │                                          │  │
│  │ 🔴 待接入（服务端 ✅ 已实现）:             │  │
│  │  🔴 Admin               → /api/admin/*    │  │
│  └──────────────────────────────────────────┘  │
│                                                │
│  关键设计: 接口抽象 + DI 替换注册               │
│  所有待接入功能都有 I*Service 接口，新建远程     │
│  实现类，DI 替换注册即可，不需改 ViewModel/UI   │
└────────────────────────────────────────────────┘
```

### 10.2 接入模式

客户端对接服务端 API 遵循**统一模式**，以评论系统为例：

```
Step 1: 新建 RemoteCommentService : ICommentService
        实现 HTTP 调用 (HttpClient + System.Text.Json)
Step 2: App.xaml.cs DI 容器替换注册
        services.AddSingleton<ICommentService, RemoteCommentService>();
Step 3: 可选离线降级
        在线 → RemoteCommentService；离线 → CommentService (LiteDB)
```

**当前接入状态**：

| 文件 | 状态 | 目标服务端 API |
|------|------|---------------|
| `Services/RemoteCommentService.cs` | ✅ 已接入（DI 已替换 CommentService） | `GET/POST/PUT/DELETE /api/comments`, `/replies` |
| `Services/QuickStartService.cs` | ✅ 已由 `RemoteQuickStartService` 替换（本地硬编码作离线降级） | `GET /api/templates` |
| `Services/RemoteNotificationService.cs` | ✅ SignalR 已接入（断线重连 + HTTP 离线补拉） | SignalR Hub + `GET /api/notifications` |
| `Services/UserAvatarService.cs` | ✅ 下载/上传已实现（上传 fire-and-forget，无重试/确认） | `PUT /api/resources/user_avatar` |
| `Services/OvpnConfigCacheService.cs` | ✅ 已接入（版本比对 + 预签名 URL + 方案A加密缓存） | `GET /api/openvpn`, `/download` |
| — | 🔴 未接入 | `/api/admin/*` (用户/URL/通知/模板) |

> **已实现远程服务**（无需再接入）：
> - ✅ `RemoteLoginService.cs` — JWT+RefreshToken 远程认证（替换 LoginService）
> - ✅ `RemoteQuickStartService.cs` — HTTP 模板获取 + 封面图加密缓存（替换 QuickStartService）
> - ✅ `SchemeIconCacheService.cs` — HTTP 方案图标下载 + 加密缓存
> - ✅ `ServerUrlService.SyncFromServerAsync()` — 方案 URL 增量同步（POST /api/scheme-urls/sync）
> - ✅ **信息流卡片** — 首页通知中心 FlipView 原生轮播 + 方案B媒体缓存（加密 meta 校验）

### 10.3 关键参考文档

| 文档 | 用途 | 核心内容 |
|------|------|----------|
| `docs/服务端后端系统技术栈.md` | **服务端搭建总纲** | 技术选型、数据库 DDL、REST API 设计、部署方案、客户端改造清单 |
| `docs/技术栈文档.md` | 客户端架构参考 | 全部 Service 接口定义、DI 注册表、数据模型 |
| `docs/Kirara Server API 完整文档.md` | API 完整参考 | 全部 API 端点、请求/响应示例、状态码 |

### 10.4 方案 URL 集中管理链路

> 理解此链路对于**接入服务端 URL 推送**和**新建 WebView2 方案**至关重要。

```
方案 Name (=DefaultUrlKey)
  → BaseScheme.GetUI()
    → ServerUrlService.GetDecryptedUrl(key)
      → LiteDB server_urls 集合 (AES-256-GCM 加密)
        → 解密返回明文 URL
          → SchemeUI.WebViewUrl
            → SchemeHostPage.ShowWebViewAsync(url) → WebView2 导航

✅ 当前: `ServerUrlService.SyncFromServerAsync()` → POST /api/scheme-urls/sync → 增量同步 URL 变更
（App.OnLaunched 中 fire-and-forget 调用，15s 超时，静默降级）
```

### 10.5 新增服务器通信功能的核心原则

1. **接口不变原则**：所有待接入功能已有 `I*Service` 接口，新建 `Remote*Service` 实现即可
2. **DI 替换原则**：在 `App.xaml.cs` 的 `ConfigureServices()` 中替换注册，不改 ViewModel/UI
3. **增量同步原则**：资源/URL/模板使用 `Version` 字段，客户端上报本地版本，服务端仅返回变更
4. **降级兜底原则**：所有远程 API 调用应有本地降级路径（LiteDB / 硬编码默认值 / null）
5. **加密不变原则**：敏感字段（密码、API Key）由客户端 AES-256-GCM 加密后传输，服务端不解密（端到端加密）

---
