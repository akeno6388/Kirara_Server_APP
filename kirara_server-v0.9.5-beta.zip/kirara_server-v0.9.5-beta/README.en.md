# Kirara_Server Application Project Documentation

### Introduction
The Kirara application allows users to utilize and manage applications on Kirara_Server by creating new **Instances**, selecting **Profiles**, and linking **Tokens**. Users can create and save instances based on their needs. Kirara automatically negotiates communication methods with the server, reducing the learning curve for Kirara_Server, simplifying operations, and enabling configuration once for multiple runs.

### Software Architecture

1.   **Program Architecture Overview**
- Multiple applications on Kirara_Server or their usage combinations are referred to as Service Groups. The Kirara application distinguishes between different service groups using Instances. A service group is composed of one or more Profiles, each of which can be linked to a specific account. Once a user creates an instance, they can access the application with one click without manually configuring each service. The Kirara application manages all user accounts registered on Kirara_Server and the certificates required for application services through the Token Manager. Users can link these to various Profiles to achieve automatic login and authentication.

2.   **Instance Function Overview**
- **User Instance:** To use specific applications on Kirara_Server, a User Instance must be created. After creating a User Instance, a Profile must be selected. Multiple User Instances can be created and saved. User Instances support renaming, importing, and exporting. Instances can be favorited and assigned color labels.
- **Service Instance:** To perform maintenance on Kirara_Server, a Service Instance must be created. After creating a Service Instance, a Profile must be selected. Multiple Service Instances can be created and saved. Service Instances support renaming, importing, and exporting. Instances can be favorited and assigned color labels.
- **Note:** Only one instance can be applied at a time. If multiple profiles need to be used simultaneously, please create a new Instance and select all the required Profiles. To successfully apply an Instance, the user must have permissions for all Profiles contained within that Instance; otherwise, only the Instance creation is possible.

3.   **Profile Function Overview**
- A Profile describes a service group. One Profile is responsible for invoking one or more corresponding modules on Kirara_Server. For example, the Jellyfin media application Profile invokes Kirara_MediaServer, and the OpenVPN Profile invokes OpenVPN Server and OpenVPN Server(AD).
- Each Profile can be linked to different or the same accounts that have access permissions for that Profile.
- One Profile can only be linked to one account that has access permissions for that Profile.
- Support for Third-party Profiles: Users can import executable files as Profiles for selection and support adding launch parameters. If multiple third-party Profiles are selected, the startup order can be configured.

4.   **Token Manager Function Overview**
- The Token Manager is responsible for storing all user accounts registered on Kirara_Server and the certificates required for application services. It can automatically pass account information or certificates to achieve seamless authentication for applications.
- The Token Manager's data directory is stored locally on the user's side and requires encryption. (Future consideration: open up cloud storage, allowing users to choose whether to store token data in the cloud for cross-device synchronization).
- The Token Manager supports users in naming token data and supports exporting and importing tokens.

5.   **Service Group & Instance Interface Function Overview**
- Users create an Instance via **Create New Instance → Select Profiles to form Instance Profile Groups → Link Profile Tokens**. After applying the Instance, the program attempts to negotiate communication methods for the included Profiles with the server. Upon successful communication, it automatically passes information based on the user's linked tokens and attempts login. After success, the service group becomes usable.
- If errors other than permission types occur during communication or authentication, the Instance can be allowed not to use this Profile, causing the Instance to be applied in a degraded state. If permission errors occur, regardless of whether other Profiles in the Instance have permissions, this Instance cannot be applied.
- **Instance Interface:** After an Instance is applied, an Instance Main Window is created within the main application window. Profiles contained within the Instance are presented as tabs on the title bar of its main window. Users can click tabs to switch between different Profile interfaces. If a Profile provides an application interface, users can utilize the application services offered by that Profile within that interface.

### Profile Function Development

1.   **Belonging to User Instances**
- **Jellyfin Media Application Profile:** Currently, only front-end development is planned for this Profile. Front-end: Jellyfin Web client is developed in JavaScript; Back-end: Jellyfin Server is developed in C#. Back-end development is temporarily on hold due to database migration issues. The original back-end can be used. Focus on adapting the front-end to the program's Profile interface.
- **OpenVPN Profile:** Currently, only front-end development is planned for this Profile. Front-end: OpenVPN GUI is developed in C; Back-end: OpenVPN Server is developed in C. Back-end development is temporarily on hold due to deployment issues. The original back-end can be used. Focus on adapting the original front-end settings interface to the program's Profile interface and supporting silent connections.
- **SRS Live Streaming Profile:** This Profile does not strictly separate front-end and back-end. SRS is an efficient live streaming server solution developed in C++. On the User Instance side, it needs to implement launching the OBS process based on user requirements and automatically configuring OBS streaming parameters via OBS configuration files, enabling click-to-start streaming. Viewers can also directly select and watch live streams through this Profile's interface.
- **Discussion Board Profile:** This Profile is designed by ourselves. It is a transparent overlay window always located in the bottom-right corner of the Instance Main Window. In media application Profiles, it can serve as a long-term video comment section; in the SRS Live Streaming Profile, it can serve as an interactive area.
- **Kirara Team Shared Cloud Profile:** This Profile only requires embedding the existing application into the Profile interface using the WebView2 control.
- **Kmail Email Service Profile:** This Profile only requires embedding the existing application into the Profile interface using the WebView2 control.
- **Chat Team Collaboration Profile:** This Profile only requires embedding the existing application into the Profile interface using the WebView2 control.
- **Virtualization Platform Profile:** This Profile only requires embedding the existing application into the Profile interface using the WebView2 control.
- **Game Server Profile:** This Profile supports scanning user-installed games that can utilize this multiplayer server and displaying them within the Profile interface. For each game application, users can view running service threads and join the game with one click (automatically launching the game process and displaying a notification in the bottom-right corner with the connection address for the service thread).

2.   **Belonging to Service Instances**
- **APP Server Management Profile:** This Profile only requires embedding the existing application into the Profile interface using the WebView2 control.
- **Backup Server Management Profile:** This Profile only requires embedding the existing application into the Profile interface using the WebView2 control.
- **ESXi Management Profile:** This Profile only requires embedding the existing application into the Profile interface using the WebView2 control.
- **ikuai Management Profile:** This Profile only requires embedding the existing application into the Profile interface using the WebView2 control.
- **OpenWrt Management Profile:** This Profile only requires embedding the existing application into the Profile interface using the WebView2 control.
- **IMM Management Profile:** This Profile only requires embedding the existing application into the Profile interface using the WebView2 control.
- **Winserver-DC Management Profile:** This Profile only requires invoking the Windows Remote Desktop Connection, automatically passing login information based on the user's linked token, and embedding the remote desktop into the Profile interface.
- **Winserver-AC Management Profile:** This Profile only requires invoking the Windows Remote Desktop Connection, automatically passing login information based on the user's linked token, and embedding the remote desktop into the Profile interface.
- **Self-Signed Certificate Profile:** This Profile only requires embedding the existing application into the Profile interface using the WebView2 control.
- **Winserver-DL Management Profile:** This Profile only requires invoking the Windows Remote Desktop Connection, automatically passing login information based on the user's linked token, and embedding the remote desktop into the Profile interface.
- **Winserver-GN Management Profile:** This Profile only requires invoking the Windows Remote Desktop Connection, automatically passing login information based on the user's linked token, and embedding the remote desktop into the Profile interface.

### Interface Development
- The interface is divided into the Left Function Bar, Top Title Bar, and Bottom-Right Notification Thumbnail Corner Marker. The remaining area is reserved for the Instance Main Window area. The top part of the Instance Main Window area is the Profile Tab Bar.
- **Left Function Bar (Explicit Menu Interface):** The upper part contains Quick Start, Create New User Instance, Create New Service Instance; the middle part contains the Instance Manager; the lower part contains the Token Manager and Settings.
- **Top Title Bar:** To the left of the three main window operation buttons is the background project area.
- **Bottom-Right Notification Thumbnail Corner Marker:** Can be collapsed and expanded.

### About Quick Start
Quick Start provides pre-configured common User Instances and Service Instances. Users can directly apply these templates. Quick Start can directly launch applications that support official clients, such as Synology Drive, Potplayer, OBS Studio, etc. Third-party profiles imported by users will also be displayed here.

### Usage Instructions

### Contributing