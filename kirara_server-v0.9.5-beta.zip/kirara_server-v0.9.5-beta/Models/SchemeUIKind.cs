namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 方案 UI 呈现方式
/// </summary>
public enum SchemeUIKind
{
    /// <summary>自定义 XAML 控件</summary>
    CustomControl = 0,

    /// <summary>WebView2 嵌入网页</summary>
    WebView2 = 1,

    /// <summary>远程桌面嵌入</summary>
    RDP = 2,

    /// <summary>外部进程（拉起独立窗口）</summary>
    ExternalProcess = 3,

    /// <summary>透明遮罩（议题方案）</summary>
    Overlay = 4
}
