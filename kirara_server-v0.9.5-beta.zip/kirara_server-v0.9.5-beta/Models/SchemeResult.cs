namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 方案操作结果
/// </summary>
public class SchemeResult
{
    public bool IsSuccess { get; set; }
    public string? ErrorMessage { get; set; }
    public string? Message { get; set; }

    public static SchemeResult Success(string? message = null) =>
        new() { IsSuccess = true, Message = message };

    public static SchemeResult Fail(string error) =>
        new() { IsSuccess = false, ErrorMessage = error };
}

/// <summary>
/// 令牌验证结果
/// </summary>
public class TokenValidationResult
{
    public bool IsValid { get; set; }
    public string? ErrorMessage { get; set; }
    public string? ServerVersion { get; set; }

    public static TokenValidationResult Valid(string? version = null) =>
        new() { IsValid = true, ServerVersion = version };

    public static TokenValidationResult Invalid(string error) =>
        new() { IsValid = false, ErrorMessage = error };
}

/// <summary>
/// 方案状态
/// </summary>
public enum SchemeStatus
{
    Idle,
    Initializing,
    Running,
    Degraded,
    Error,
    Stopped
}

/// <summary>
/// 方案 UI 描述 — 平台根据此信息渲染方案界面
/// </summary>
public class SchemeUI
{
    public SchemeUIKind Kind { get; set; }

    /// <summary>自定义控件时：承载方案的 FrameworkElement</summary>
    public object? CustomControl { get; set; }

    /// <summary>WebView2 导航 URL</summary>
    public string? WebViewUrl { get; set; }

    /// <summary>RDP 连接地址</summary>
    public string? RdpAddress { get; set; }

    /// <summary>外部进程路径</summary>
    public string? ExternalProcessPath { get; set; }

    /// <summary>外部进程参数</summary>
    public string? ExternalProcessArgs { get; set; }

    /// <summary>是否为透明遮罩</summary>
    public bool IsOverlay { get; set; }
}
