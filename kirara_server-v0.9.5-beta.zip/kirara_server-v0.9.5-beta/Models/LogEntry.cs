namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 日志级别
/// </summary>
public enum LogLevel
{
    /// <summary>调试信息</summary>
    Debug = 0,

    /// <summary>常规信息</summary>
    Info = 1,

    /// <summary>警告</summary>
    Warning = 2,

    /// <summary>错误</summary>
    Error = 3,

    /// <summary>致命错误</summary>
    Fatal = 4,
}

/// <summary>
/// 日志条目 — 表示一条日志记录，由 ILoggingService 生成
/// </summary>
public class LogEntry
{
    /// <summary>时间戳</summary>
    public DateTime Timestamp { get; set; } = DateTime.Now;

    /// <summary>日志级别</summary>
    public LogLevel Level { get; set; }

    /// <summary>来源模块名</summary>
    public string Source { get; set; } = string.Empty;

    /// <summary>日志消息</summary>
    public string Message { get; set; } = string.Empty;

    /// <summary>异常详情（可选）</summary>
    public string? Exception { get; set; }
}
