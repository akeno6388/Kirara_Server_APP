namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 方案绑定 — 连接实例与方案及其令牌的关联关系
/// </summary>
public class SchemeBinding
{
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>所属实例 ID</summary>
    public Guid InstanceId { get; set; }

    /// <summary>绑定的方案 ID</summary>
    public Guid SchemeId { get; set; }

    /// <summary>绑定的令牌 ID（可为空）</summary>
    public Guid? TokenId { get; set; }

    /// <summary>启用状态（降级时为 false）</summary>
    public bool IsEnabled { get; set; } = true;

    /// <summary>在标签栏中的顺序</summary>
    public int Order { get; set; }

    /// <summary>自定义参数</summary>
    public Dictionary<string, string>? CustomParameters { get; set; }
}
