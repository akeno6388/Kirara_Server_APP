namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 集中式服务器 URL 注册记录 — 统一管理所有服务端地址
/// 所有 URL 均加密存储，支持未来在线同步功能
/// </summary>
public class ServerUrlRecord
{
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>URL 标识键（唯一，如 "media", "kmail", "drive"）</summary>
    public string Key { get; set; } = string.Empty;

    /// <summary>显示名称（如 "Kirara Media", "Kmail 邮件服务"）</summary>
    public string DisplayName { get; set; } = string.Empty;

    /// <summary>服务器 URL（AES-256-GCM 加密存储）</summary>
    public string Url { get; set; } = string.Empty;

    /// <summary>关联的方案 ID（可选）</summary>
    public Guid? SchemeId { get; set; }

    /// <summary>关联的方案 Name（冗余字段，便于查询）</summary>
    public string? SchemeName { get; set; }

    /// <summary>URL 所属分类（如 "WebView2", "RDP", "API"）</summary>
    public string? Category { get; set; }

    /// <summary>是否启用（false 表示服务端已停用此 URL）</summary>
    public bool IsActive { get; set; } = true;

    /// <summary>是否启用自动同步</summary>
    public bool AutoSync { get; set; }

    /// <summary>同步源端点 URL（加密存储）</summary>
    public string? SyncEndpoint { get; set; }

    /// <summary>最后同步时间（UTC）</summary>
    public DateTime? LastSyncedAt { get; set; }

    /// <summary>同步状态：Idle / Syncing / Failed / UpToDate</summary>
    public string? SyncStatus { get; set; }

    /// <summary>同步失败时的错误信息</summary>
    public string? SyncErrorMessage { get; set; }

    /// <summary>URL 版本号（用于同步冲突检测）</summary>
    public int Version { get; set; } = 1;

    /// <summary>创建时间</summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>更新时间</summary>
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>扩展元数据</summary>
    public Dictionary<string, string>? Metadata { get; set; }
}
