namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 评论数据模型 — 表示评论区中的一条评论
/// 评论通过 ResourceKey（默认 URL 路径）与当前查看的资源关联
/// </summary>
public class CommentItem
{
    /// <summary>评论唯一标识</summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>关联的资源标识键（默认为 WebView2 当前 URL 路径）</summary>
    public string ResourceKey { get; set; } = string.Empty;

    /// <summary>所属方案 ID</summary>
    public Guid SchemeId { get; set; }

    /// <summary>评论作者名称</summary>
    public string AuthorName { get; set; } = string.Empty;

    /// <summary>作者用户 ID（头像缓存键，经 API 6.2 获取头像）</summary>
    public Guid AuthorUserId { get; set; }

    /// <summary>作者头像 URL（服务端拼接，可能为 null）</summary>
    public string? AuthorAvatarUrl { get; set; }

    /// <summary>评论内容</summary>
    public string Content { get; set; } = string.Empty;

    /// <summary>视频标题（v1.10，创建时从客户端传入，用于互动通知文案）</summary>
    public string? ContentTitle { get; set; }

    /// <summary>创建时间</summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>点赞数</summary>
    public int LikeCount { get; set; }

    /// <summary>当前用户是否已点赞</summary>
    public bool IsLikedByUser { get; set; }

    /// <summary>回复总数</summary>
    public int ReplyCount { get; set; }

    /// <summary>回复列表</summary>
    public List<ReplyItem> Replies { get; set; } = new();
}
