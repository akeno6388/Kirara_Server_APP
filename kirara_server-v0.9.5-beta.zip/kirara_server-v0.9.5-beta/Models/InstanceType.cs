namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 实例类型：用户实例 vs 服务实例
/// </summary>
public enum InstanceType
{
    /// <summary>用户实例 — 使用 Kirara_Server 具体应用</summary>
    UserInstance = 0,

    /// <summary>服务实例 — 对 Kirara_Server 进行维护</summary>
    ServiceInstance = 1
}
