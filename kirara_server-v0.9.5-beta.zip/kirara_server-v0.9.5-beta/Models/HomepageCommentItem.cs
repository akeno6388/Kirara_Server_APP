namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 首页分享数据模型 — 表示用户分享到首页的资源卡片
/// 通过 /api/homepage-comments 端点与服务端交互
/// </summary>
public class HomepageCommentItem
{
    /// <summary>分享唯一标识</summary>
    public Guid Id { get; set; }

    /// <summary>关联的资源标识键（如 media://host:port/path）</summary>
    public string ResourceKey { get; set; } = string.Empty;

    /// <summary>所属方案 ID（用于跳转定位）</summary>
    public Guid SchemeId { get; set; }

    /// <summary>所属实例 ID（用于导航跳转）</summary>
    public Guid InstanceId { get; set; }

    /// <summary>资源内容标题（分享时从评论区标题获取）</summary>
    public string ContentTitle { get; set; } = string.Empty;

    /// <summary>分享时的页面 URL（用于“查看”时跳转回对应页面）</summary>
    public string SourceUrl { get; set; } = string.Empty;

    /// <summary>分享用户评语</summary>
    public string Content { get; set; } = string.Empty;

    /// <summary>分享用户显示名</summary>
    public string AuthorName { get; set; } = string.Empty;

    /// <summary>分享作者用户 ID（头像缓存键，经 API 6.2 获取头像）</summary>
    public Guid AuthorUserId { get; set; }

    /// <summary>分享用户头像 URL（可能为 null）</summary>
    public string? AuthorAvatarUrl { get; set; }

    /// <summary>点赞数</summary>
    public int LikeCount { get; set; }

    /// <summary>当前用户是否已点赞</summary>
    public bool IsLikedByUser { get; set; }

    /// <summary>创建时间 UTC</summary>
    public DateTime CreatedAt { get; set; }
}
