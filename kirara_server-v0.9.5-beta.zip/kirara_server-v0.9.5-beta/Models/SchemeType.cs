namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 方案类型
/// </summary>
public enum SchemeType
{
    /// <summary>系统内置方案（用户实例）</summary>
    BuiltIn = 0,

    /// <summary>用户导入的第三方方案</summary>
    ThirdParty = 1,

    /// <summary>服务实例方案（管理员维护 Kirara_Server 用）</summary>
    Server = 2
}
