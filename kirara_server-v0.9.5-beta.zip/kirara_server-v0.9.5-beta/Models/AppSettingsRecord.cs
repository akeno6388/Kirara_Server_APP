namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 应用设置记录 — 键值对存储（LiteDB app_settings 集合）
/// 用于持久化外观主题等轻量应用偏好
/// </summary>
public class AppSettingsRecord
{
    /// <summary>记录 ID</summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>设置键（唯一）</summary>
    public string Key { get; set; } = string.Empty;

    /// <summary>设置值（字符串形式，由读取方解析）</summary>
    public string Value { get; set; } = string.Empty;

    /// <summary>更新时间</summary>
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}
