namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 方案 — 对服务组的描述，负责调用 Kirara_Server 的某一个或多个模块
/// </summary>
public class Scheme
{
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>方案名称（内部）</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>显示名称</summary>
    public string DisplayName { get; set; } = string.Empty;

    /// <summary>方案描述</summary>
    public string Description { get; set; } = string.Empty;

    /// <summary>方案来源类型</summary>
    public SchemeType SchemeType { get; set; } = SchemeType.BuiltIn;

    /// <summary>适用实例类型</summary>
    public InstanceType InstanceType { get; set; } = InstanceType.UserInstance;

    /// <summary>UI 呈现方式</summary>
    public SchemeUIKind UIKind { get; set; } = SchemeUIKind.WebView2;

    /// <summary>图标（Segoe Fluent Icons 字符）</summary>
    public string IconGlyph { get; set; } = string.Empty;

    /// <summary>
    /// 封面图片本地缓存路径（运行时填充）。
    /// 由 SchemeIconCacheService 在启动时从服务端下载并缓存，
    /// 无缓存时为 null，UI 层自动降级到 IconGlyph。
    /// </summary>
    public string? CoverImageUrl { get; set; }

    /// <summary>内置方案的程序集名称</summary>
    public string? EntryAssembly { get; set; }

    /// <summary>内置方案的类名（实现 IScheme）</summary>
    public string? EntryTypeName { get; set; }

    /// <summary>第三方方案：可执行文件路径</summary>
    public string? ExecutablePath { get; set; }

    /// <summary>第三方方案：启动参数</summary>
    public string? Arguments { get; set; }

    /// <summary>第三方方案：多方案启动顺序</summary>
    public int? LaunchOrder { get; set; }

    /// <summary>WebView2 方案的 URL</summary>
    public string? WebViewUrl { get; set; }

    /// <summary>是否需要 RDP 嵌入</summary>
    public bool RequiresRdp { get; set; }

    /// <summary>是否系统内置（不可删除）</summary>
    public bool IsSystem { get; set; }

    /// <summary>排序权重</summary>
    public int SortOrder { get; set; }

    /// <summary>UI 选中状态（用于向导多选）</summary>
    public bool IsSelected { get; set; }
}
