using Kirara_Server_WinUI.Services;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Kirara_Server_WinUI.Models;

/// <summary>
/// OpenVPN 服务版配置文件 — 一个导入的 .ovpn 配置 + 其独立账密与自动登录标记。
///
/// 设计要点（服务版 OpenVPN 方案）：
/// - 每个配置文件对应一套独立账密，彼此互不干扰；
/// - 账密字段以 AES-256-GCM 加密字符串存储（由 OpenVpnProfileStore 加密/解密）；
/// - AutoLogin 标记全局唯一（同一实例内同时最多一个配置勾选自动登录），
///   勾选后作为下次启动此方案的令牌自动链接凭据。
/// </summary>
public class OpenVpnProfile : INotifyPropertyChanged
{
    /// <summary>配置文件唯一标识</summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>显示名称（导入时取源文件名，可后续修改）</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>存储的 .ovpn 文件名（{Id:N}.ovpn，位于实例隔离目录内）</summary>
    public string OvpnFileName { get; set; } = string.Empty;

    /// <summary>服务器主机名/IP（从 .ovpn remote 指令解析，仅用于界面展示；连接实际使用 .ovpn 内容）</summary>
    public string? ServerHost { get; set; }

    /// <summary>服务器端口（从 .ovpn remote 指令解析，默认 1195）</summary>
    public int ServerPort { get; set; } = VpnConnectionService.DefaultVpnPort;

    /// <summary>认证账号（AES-256-GCM 加密存储）</summary>
    public string? AccountNameEncrypted { get; set; }

    /// <summary>认证密码（AES-256-GCM 加密存储）</summary>
    public string? AccountPasswordEncrypted { get; set; }

    /// <summary>是否勾选自动登录（同一实例内全局唯一；勾选后作为下次启动的令牌自动链接凭据）</summary>
    public bool AutoLogin { get; set; }

    /// <summary>导入时间</summary>
    public DateTime ImportedAt { get; set; } = DateTime.UtcNow;

    /// <summary>界面展示用服务器地址（"服务器 URL: host:port"；无 remote 时显示占位）</summary>
    public string ServerDisplay =>
        string.IsNullOrEmpty(ServerHost)
            ? "服务器 URL: --"
            : $"服务器 URL: {ServerHost}:{ServerPort}";

    /// <summary>是否在列表中被选中（驱动左侧主题色竖线显示）</summary>
    private bool _isSelected;
    public bool IsSelected
    {
        get => _isSelected;
        set
        {
            if (_isSelected == value) return;
            _isSelected = value;
            OnPropertyChanged();
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
