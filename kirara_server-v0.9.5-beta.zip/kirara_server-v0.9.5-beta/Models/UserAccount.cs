namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 用户组别 — 决定权限范围
/// </summary>
public enum UserGroup
{
    /// <summary>普通用户 — 无法创建/访问服务实例</summary>
    User = 0,

    /// <summary>管理员 — 拥有全部功能权限</summary>
    Admin = 1
}

/// <summary>
/// 用户账户 — 存储在本地数据库中的登录凭据
/// Phase 3 Part 1 使用本地 LiteDB 存储，Part 2 将迁移至服务器数据库
/// </summary>
public class UserAccount
{
    /// <summary>用户唯一标识</summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>用户名（登录用，唯一）</summary>
    public string Username { get; set; } = string.Empty;

    /// <summary>密码哈希（SHA256 + 盐）</summary>
    public string PasswordHash { get; set; } = string.Empty;

    /// <summary>密码盐（Base64）</summary>
    public string PasswordSalt { get; set; } = string.Empty;

    /// <summary>用户组别</summary>
    public UserGroup Group { get; set; } = UserGroup.User;

    /// <summary>创建时间</summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>上次登录时间</summary>
    public DateTime? LastLoginAt { get; set; }

    /// <summary>是否启用自动登录（下次启动跳过登录页）</summary>
    public bool AutoLoginEnabled { get; set; }
}
