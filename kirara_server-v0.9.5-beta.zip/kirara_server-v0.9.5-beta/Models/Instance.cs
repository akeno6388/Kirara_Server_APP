using System.ComponentModel;
using System.Runtime.CompilerServices;
using LiteDB;

namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 实例 — 一组方案的集合，绑定令牌后形成一个可运行的服务组
/// </summary>
public class Instance : INotifyPropertyChanged
{
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>实例名称（用户自定义）</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>实例类型：用户实例 / 服务实例</summary>
    public InstanceType InstanceType { get; set; } = InstanceType.UserInstance;

    /// <summary>是否收藏</summary>
    public bool IsFavorite { get; set; }

    /// <summary>颜色标签（如 #FF0000）</summary>
    public string? ColorTag { get; set; }

    /// <summary>创建时间</summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>更新时间</summary>
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>最后使用时间</summary>
    public DateTime? LastUsedAt { get; set; }

    /// <summary>方案绑定列表</summary>
    public List<SchemeBinding> SchemeBindings { get; set; } = new();

    /// <summary>扩展元数据</summary>
    public Dictionary<string, string>? Metadata { get; set; }

    /// <summary>所属用户 ID</summary>
    public Guid OwnerUserId { get; set; }

    /// <summary>工作区状态（非持久化）：null/空=待部署, 正在加载方案.../正在链接令牌...=部署中, 工作区已就绪=就绪</summary>
    [BsonIgnore]
    public string? WorkStatus
    {
        get => _workStatus;
        set { if (_workStatus != value) { _workStatus = value; OnPropertyChanged(); } }
    }
    private string? _workStatus;

    public event PropertyChangedEventHandler? PropertyChanged;

    protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
