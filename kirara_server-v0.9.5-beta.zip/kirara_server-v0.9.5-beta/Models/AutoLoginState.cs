namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 自动登录状态 — 不可变记录，每次状态变更产生新实例。
/// 消除竞态条件：所有字段通过 with 表达式原子更新。
/// </summary>
public record AutoLoginState
{
    /// <summary>自动登录是否已处理过（成功/失败/跳过均标记）</summary>
    public bool IsHandled { get; init; }

    /// <summary>预加载已完成但工作区登录待执行（密码页方案）</summary>
    public bool WorkspaceLoginPending { get; init; }

    /// <summary>上次自动登录的最终状态文字</summary>
    public string? LastStatus { get; init; }

    /// <summary>初始状态（未登录）</summary>
    public static readonly AutoLoginState Initial = new();

    /// <summary>标记为已处理并记录状态文字</summary>
    public AutoLoginState MarkHandled(string status) =>
        this with { IsHandled = true, LastStatus = status };

    /// <summary>标记为工作区登录待执行</summary>
    public AutoLoginState MarkWorkspacePending() =>
        this with { WorkspaceLoginPending = true, LastStatus = "令牌已链接(需确认)" };

    /// <summary>重置为初始状态</summary>
    public AutoLoginState Reset() => Initial;
}