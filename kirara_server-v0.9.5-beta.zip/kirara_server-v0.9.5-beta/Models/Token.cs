namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 令牌 — 用户在 Kirara_Server 上注册的账户凭据，存储在本地加密
/// </summary>
public class Token
{
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>令牌名称（用户自定义）</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>令牌类型</summary>
    public TokenType TokenType { get; set; } = TokenType.Application;

    /// <summary>账户名（加密存储）</summary>
    public string AccountName { get; set; } = string.Empty;

    /// <summary>密码（加密存储）</summary>
    public string? AccountPassword { get; set; }

    /// <summary>API 密钥（加密存储）</summary>
    public string? ApiKey { get; set; }

    /// <summary>服务器地址（AES-256-GCM 加密存储），可通过集中式 ServerUrlRecord 同步管理</summary>
    public string? ServerUrl { get; set; }

    /// <summary>证书路径</summary>
    public string? CertificatePath { get; set; }

    /// <summary>备注</summary>
    public string? Notes { get; set; }

    /// <summary>颜色标签（如 #FF0000），用于自定义令牌图标颜色</summary>
    public string? ColorTag { get; set; }

    /// <summary>是否系统内置（默认令牌；允许删除，删除后下次登录自动重建）</summary>
    public bool IsSystem { get; set; }

    /// <summary>创建时间</summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>更新时间</summary>
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>扩展字段</summary>
    public Dictionary<string, string>? Metadata { get; set; }

    /// <summary>所属用户 ID（null 表示系统内置令牌，所有用户可见）</summary>
    public Guid? OwnerUserId { get; set; }
}
