namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 回复数据模型 — 表示评论下的一条回复
/// </summary>
public class ReplyItem
{
    /// <summary>回复唯一标识</summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>所属评论 ID</summary>
    public Guid CommentId { get; set; }

    /// <summary>回复作者名称</summary>
    public string AuthorName { get; set; } = string.Empty;

    /// <summary>作者用户 ID（头像缓存键，经 API 6.2 获取头像）</summary>
    public Guid AuthorUserId { get; set; }

    /// <summary>作者头像 URL（服务端拼接，可能为 null）</summary>
    public string? AuthorAvatarUrl { get; set; }

    /// <summary>回复内容</summary>
    public string Content { get; set; } = string.Empty;

    /// <summary>视频标题（v1.10，创建时从父评论继承，用于互动通知文案）</summary>
    public string? ContentTitle { get; set; }

    /// <summary>创建时间</summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>点赞数</summary>
    public int LikeCount { get; set; }

    /// <summary>当前用户是否已点赞</summary>
    public bool IsLikedByUser { get; set; }
}
