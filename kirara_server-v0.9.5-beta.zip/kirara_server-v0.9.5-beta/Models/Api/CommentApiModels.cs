using System.Text.Json.Serialization;

namespace Kirara_Server_WinUI.Models.Api;

/// <summary>
/// 统一 API 响应包装 — 对应服务端 ApiResponse&lt;T&gt;
/// </summary>
public class ApiResponse<T>
{
    [JsonPropertyName("success")]
    public bool Success { get; set; }

    [JsonPropertyName("data")]
    public T? Data { get; set; }

    [JsonPropertyName("timestamp")]
    public DateTime Timestamp { get; set; }

    [JsonPropertyName("error")]
    public ApiError? Error { get; set; }
}

/// <summary>API 错误信息</summary>
public class ApiError
{
    [JsonPropertyName("code")]
    public string Code { get; set; } = string.Empty;

    [JsonPropertyName("message")]
    public string Message { get; set; } = string.Empty;
}

/// <summary>分页数据结构</summary>
public class PagedResult<T>
{
    [JsonPropertyName("items")]
    public List<T> Items { get; set; } = new();

    [JsonPropertyName("page")]
    public int Page { get; set; }

    [JsonPropertyName("pageSize")]
    public int PageSize { get; set; }

    [JsonPropertyName("totalCount")]
    public int TotalCount { get; set; }

    [JsonPropertyName("totalPages")]
    public int TotalPages { get; set; }
}

/// <summary>评论 API 响应 DTO</summary>
public class CommentResponse
{
    [JsonPropertyName("id")]
    public Guid Id { get; set; }

    [JsonPropertyName("resourceKey")]
    public string ResourceKey { get; set; } = string.Empty;

    [JsonPropertyName("schemeId")]
    public Guid SchemeId { get; set; }

    [JsonPropertyName("userId")]
    public Guid UserId { get; set; }

    [JsonPropertyName("content")]
    public string Content { get; set; } = string.Empty;

    [JsonPropertyName("contentTitle")]
    public string? ContentTitle { get; set; }

    [JsonPropertyName("authorName")]
    public string AuthorName { get; set; } = string.Empty;

    [JsonPropertyName("authorAvatarUrl")]
    public string? AuthorAvatarUrl { get; set; }

    [JsonPropertyName("likeCount")]
    public int LikeCount { get; set; }

    [JsonPropertyName("isLikedByUser")]
    public bool IsLikedByUser { get; set; }

    [JsonPropertyName("replyCount")]
    public int ReplyCount { get; set; }

    [JsonPropertyName("replies")]
    public List<ReplyResponse>? Replies { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }

    [JsonPropertyName("updatedAt")]
    public DateTime? UpdatedAt { get; set; }
}

/// <summary>回复 API 响应 DTO</summary>
public class ReplyResponse
{
    [JsonPropertyName("id")]
    public Guid Id { get; set; }

    [JsonPropertyName("commentId")]
    public Guid CommentId { get; set; }

    [JsonPropertyName("userId")]
    public Guid UserId { get; set; }

    [JsonPropertyName("content")]
    public string Content { get; set; } = string.Empty;

    [JsonPropertyName("contentTitle")]
    public string? ContentTitle { get; set; }

    [JsonPropertyName("authorName")]
    public string AuthorName { get; set; } = string.Empty;

    [JsonPropertyName("authorAvatarUrl")]
    public string? AuthorAvatarUrl { get; set; }

    [JsonPropertyName("likeCount")]
    public int LikeCount { get; set; }

    [JsonPropertyName("isLikedByUser")]
    public bool IsLikedByUser { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }
}

/// <summary>点赞切换结果</summary>
public class LikeResult
{
    [JsonPropertyName("liked")]
    public bool Liked { get; set; }

    [JsonPropertyName("likeCount")]
    public int LikeCount { get; set; }
}

/// <summary>消息结果（删除/更新操作返回）</summary>
public class MessageResult
{
    [JsonPropertyName("message")]
    public string Message { get; set; } = string.Empty;
}
