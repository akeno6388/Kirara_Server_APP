using System.Text.Json.Serialization;

namespace Kirara_Server_WinUI.Models.Api;

/// <summary>
/// 首页分享 API 响应 DTO — 映射 /api/homepage-comments 返回的 JSON
/// </summary>
public class HomepageCommentResponse
{
    [JsonPropertyName("id")]
    public Guid Id { get; set; }

    [JsonPropertyName("resourceKey")]
    public string ResourceKey { get; set; } = string.Empty;

    [JsonPropertyName("schemeId")]
    public Guid SchemeId { get; set; }

    [JsonPropertyName("instanceId")]
    public Guid InstanceId { get; set; }

    [JsonPropertyName("contentTitle")]
    public string ContentTitle { get; set; } = string.Empty;

    [JsonPropertyName("sourceUrl")]
    public string SourceUrl { get; set; } = string.Empty;

    [JsonPropertyName("userId")]
    public Guid UserId { get; set; }

    [JsonPropertyName("content")]
    public string Content { get; set; } = string.Empty;

    [JsonPropertyName("authorName")]
    public string AuthorName { get; set; } = string.Empty;

    [JsonPropertyName("authorAvatarUrl")]
    public string? AuthorAvatarUrl { get; set; }

    [JsonPropertyName("likeCount")]
    public int LikeCount { get; set; }

    [JsonPropertyName("isLikedByUser")]
    public bool IsLikedByUser { get; set; }

    [JsonPropertyName("createdAt")]
    public DateTime CreatedAt { get; set; }

    [JsonPropertyName("updatedAt")]
    public DateTime? UpdatedAt { get; set; }
}
