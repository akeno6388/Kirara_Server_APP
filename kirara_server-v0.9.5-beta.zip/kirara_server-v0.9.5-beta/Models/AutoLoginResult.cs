namespace Kirara_Server_WinUI.Models;

/// <summary>
/// 自动登录操作结果 — 封装执行结果和后续动作指示。
/// </summary>
public record AutoLoginResult
{
    /// <summary>登录是否成功</summary>
    public bool Success { get; init; }

    /// <summary>状态文字（直接作为卡片状态文字）</summary>
    public string StatusText { get; init; } = string.Empty;

    /// <summary>是否需要工作区登录阶段（分步/延迟方案）</summary>
    public bool WorkspaceLoginPending { get; init; }

    /// <summary>检测到通知/维护页面，令牌链接中断</summary>
    public bool NoticePageDetected { get; init; }

    public static AutoLoginResult Handled(string status) =>
        new() { Success = true, StatusText = status };

    public static AutoLoginResult WorkspacePending() =>
        new() { Success = true, StatusText = "令牌已链接(需确认)", WorkspaceLoginPending = true };

    public static AutoLoginResult NoticePage() =>
        new() { Success = false, StatusText = "有通知，令牌链接已中断", NoticePageDetected = true };

    public static AutoLoginResult Failed(string status) =>
        new() { Success = false, StatusText = status };
}