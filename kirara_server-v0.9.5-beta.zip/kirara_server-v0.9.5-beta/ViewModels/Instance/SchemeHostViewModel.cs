using CommunityToolkit.Mvvm.ComponentModel;
using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Helpers;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.ViewModels.InstanceSpace;

/// <summary>
/// 方案宿主 ViewModel — 管理单个方案的加载、自动登录、重载、评论区同步等全部业务逻辑。
/// SchemeHostPage 通过此 ViewModel 获取数据和操作命令，自身只负责 UI 渲染。
/// </summary>
public partial class SchemeHostViewModel : ObservableObject
{
    private readonly ISchemeService _schemeService;
    private readonly ITokenService _tokenService;
    private readonly IAutoLoginService _autoLoginService;
    private readonly ICommentPanelService _commentPanelService;

    // ——— 自动登录状态（不可变 record，原子更新） ———
    private AutoLoginState _autoLoginState = AutoLoginState.Initial;

    // ——— WebView2 URL 跟踪 ———
    private string? _lastWebViewUrl;

    // ——— 实例/方案上下文（由 Page.SetContext 传入） ———
    private Guid _instanceId;
    private Guid _schemeId;

    // ——— [ObservableProperty] 生成的属性名避免与类型名冲突 ———

    /// <summary>当前加载的方案定义（来自数据库的 Scheme 模型）</summary>
    [ObservableProperty]
    private Scheme? _hostScheme;

    /// <summary>当前方案绑定（令牌链接、启用状态）</summary>
    [ObservableProperty]
    private SchemeBinding? _hostBinding;

    /// <summary>方案插件实例（IScheme 实现，null 表示无插件）</summary>
    [ObservableProperty]
    private IScheme? _schemeInstance;

    /// <summary>方案 UI 描述对象（由 IScheme.GetUI() 返回或从 Scheme 模型构造）</summary>
    [ObservableProperty]
    private SchemeUI? _schemeUi;

    /// <summary>是否使用 IScheme 插件（true=有插件，false=直接从 Scheme 模型渲染）</summary>
    [ObservableProperty]
    private bool _hasPlugin;

    /// <summary>是否正在加载中</summary>
    [ObservableProperty]
    private bool _isLoading;

    /// <summary>是否出现错误</summary>
    [ObservableProperty]
    private bool _hasError;

    /// <summary>错误消息</summary>
    [ObservableProperty]
    private string? _errorMessage;

    /// <summary>方案当前状态</summary>
    [ObservableProperty]
    private SchemeStatus _status = SchemeStatus.Idle;

    /// <summary>方案名称（用于 XAML 绑定）</summary>
    [ObservableProperty]
    private string _displayName = string.Empty;

    /// <summary>忙状态遮罩文字（空=隐藏）</summary>
    [ObservableProperty]
    private string _busyOverlayText = string.Empty;

    /// <summary>忙状态遮罩是否可见</summary>
    [ObservableProperty]
    private bool _isBusyOverlayVisible;

    /// <summary>当前选中的方案选项卡 ID（由外部 InstanceWorkspace 传入同步）</summary>
    public Guid ActiveSchemeId { get; set; }

    /// <summary>自动登录完成事件。参数：(bindingId, statusText)</summary>
    public event Action<Guid, string>? OnAutoLoginCompleted;

    /// <summary>当前是否处于工作区登录待执行状态</summary>
    public bool IsWorkspaceLoginPending => _autoLoginState.WorkspaceLoginPending;

    /// <summary>上次自动登录的最终状态文字（如"令牌已链接"、"界面加载完成"），用于恢复 UI 状态</summary>
    public string? LastAutoLoginStatus => _autoLoginState.LastStatus;

    /// <summary>最近一次 WebView2 导航 URL（供硬重载重新导航）</summary>
    public string? LastWebViewUrl => _lastWebViewUrl;

    public SchemeHostViewModel(
        ISchemeService schemeService,
        ITokenService tokenService,
        IAutoLoginService autoLoginService,
        ICommentPanelService commentPanelService)
    {
        _schemeService = schemeService;
        _tokenService = tokenService;
        _autoLoginService = autoLoginService;
        _commentPanelService = commentPanelService;
    }

    /// <summary>
    /// 设置实例/方案上下文（由 Page.SetContext 委托调用）
    /// </summary>
    public void SetContext(Guid instanceId, Guid schemeId)
    {
        _instanceId = instanceId;
        _schemeId = schemeId;
    }

    /// <summary>
    /// 加载方案数据
    /// </summary>
    /// <returns>返回 SchemeUI（页面可直接使用），或 null 表示需要回退到 Scheme 模型渲染</returns>
    public async Task<(SchemeUI? ui, bool hasPlugin)> LoadSchemeAsync(Scheme scheme, SchemeBinding binding)
    {
        HostScheme = scheme;
        HostBinding = binding;
        DisplayName = scheme.DisplayName;
        IsLoading = true;
        HasError = false;
        ErrorMessage = null;
        Status = SchemeStatus.Initializing;

        try
        {
            var instance = _schemeService.LoadSchemeInstance(scheme);
            SchemeInstance = instance;

            if (instance != null)
            {
                // ——— 有 IScheme 插件：通过插件获取 UI ———
                HasPlugin = true;
                var result = await instance.InitializeAsync(binding);
                if (result.IsSuccess)
                {
                    SchemeUi = instance.GetUI();
                    Status = SchemeStatus.Running;
                    return (SchemeUi, true);
                }
                else
                {
                    HasError = true;
                    ErrorMessage = result.ErrorMessage ?? "方案初始化失败";
                    Status = SchemeStatus.Error;
                    return (null, true);
                }
            }
            else
            {
                // ——— 无 IScheme 插件：由页面从 Scheme 模型直接渲染 ———
                HasPlugin = false;
                Status = SchemeStatus.Running;
                return (null, false);
            }
        }
        catch (Exception ex)
        {
            HasError = true;
            ErrorMessage = ex.Message;
            Status = SchemeStatus.Error;
            return (null, false);
        }
        finally
        {
            IsLoading = false;
        }
    }

    // ========== 自动令牌登录 ==========

    /// <summary>
    /// 自动令牌登录 — 从令牌中解密凭据，注入到 WebView2 登录表单。
    /// </summary>
    public async Task AutoLoginAsync(Guid tokenId, Func<CoreWebView2Provider?> getWebViewProvider)
    {
        if (HostScheme?.UIKind != Models.SchemeUIKind.WebView2)
            return;

        var webViewProvider = getWebViewProvider();
        if (webViewProvider?.CoreWebView2 == null)
        {
            SetAutoLoginResult("预加载失败");
            return;
        }

        // 已处理过则跳过，但重新推送上次的最终状态文字
        if (_autoLoginState.IsHandled || _autoLoginState.WorkspaceLoginPending)
        {
            if (!string.IsNullOrEmpty(_autoLoginState.LastStatus))
                OnAutoLoginCompleted?.Invoke(HostBinding?.Id ?? Guid.Empty, _autoLoginState.LastStatus);
            return;
        }

        var token = _tokenService.LoadSecureToken(tokenId);
        if (token == null)
        {
            SetAutoLoginResult("令牌链接失败");
            return;
        }

        var schemeInstance = _schemeService.LoadSchemeInstance(HostScheme!);
        if (schemeInstance is not IAutoLoginProvider loginProvider)
        {
            SetAutoLoginResult("预加载失败");
            return;
        }

        var result = await _autoLoginService.ExecuteAutoLoginAsync(
            webViewProvider.CoreWebView2, HostScheme!, HostBinding!, token, loginProvider);

        ApplyAutoLoginResult(result);
    }

    /// <summary>
    /// 工作区登录阶段 — 填入密码并提交（分步/延迟方案）。
    /// </summary>
    public async Task PerformWorkspaceLoginAsync(Func<CoreWebView2Provider?> getWebViewProvider)
    {
        if (_autoLoginState.IsHandled) return;
        if (!_autoLoginState.WorkspaceLoginPending) return;

        // 立即防重入：标记已处理
        _autoLoginState = _autoLoginState.MarkHandled("令牌已链接(需确认)");

        if (HostScheme?.UIKind != Models.SchemeUIKind.WebView2) return;

        var webViewProvider = getWebViewProvider();
        if (webViewProvider?.CoreWebView2 == null) return;

        if (HostBinding?.TokenId == null) return;

        var token = _tokenService.LoadSecureToken(HostBinding.TokenId.Value);
        if (token == null) return;

        var schemeInstance = _schemeService.LoadSchemeInstance(HostScheme!);
        if (schemeInstance is not IAutoLoginProvider loginProvider) return;

        var result = await _autoLoginService.ExecuteWorkspaceLoginAsync(
            webViewProvider.CoreWebView2, HostScheme!, HostBinding!, token, loginProvider);

        ApplyAutoLoginResult(result);
    }

    // ========== 重载操作 ==========

    /// <summary>
    /// 软重载（F5）：WebView2 简单刷新页面，保留 Cookie/缓存。
    /// </summary>
    public async Task SoftReloadAsync(Func<CoreWebView2Provider?> getWebViewProvider, Func<Task> reloadScheme)
    {
        if (HostScheme == null || HostBinding == null) return;

        try
        {
            IsLoading = true;

            if (HostScheme.UIKind == Models.SchemeUIKind.WebView2)
            {
                var wvp = getWebViewProvider();
                if (wvp == null || !wvp.IsOperational)
                {
                    // WebView2 不可操作 → 通知页面重建，然后重新加载
                    System.Diagnostics.Debug.WriteLine(
                        $"[SchemeHost] WebView2 不可操作，需要重建: {HostScheme.Name}");
                    await reloadScheme();
                }
                else
                {
                    wvp.Reload();
                    System.Diagnostics.Debug.WriteLine(
                        $"[SchemeHost] WebView2 软重载（F5）: {HostScheme.Name}");
                }
            }
            else
            {
                await reloadScheme();
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SchemeHost] 软重载失败: {ex.Message}");
            HasError = true;
            ErrorMessage = $"刷新失败: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    /// <summary>
    /// 后退（WebView2 导航历史）：返回上一页。
    /// 适用场景：弹出窗口被拦截转为内部导航后，用户需要回到原页面。
    /// </summary>
    public Task GoBackAsync(Func<CoreWebView2Provider?> getWebViewProvider)
    {
        try
        {
            var wvp = getWebViewProvider();
            var wv = wvp?.CoreWebView2;
            if (wv is { CanGoBack: true })
            {
                wv.GoBack();
                System.Diagnostics.Debug.WriteLine($"[SchemeHost] WebView2 后退: {HostScheme?.Name}");
            }
            else
            {
                System.Diagnostics.Debug.WriteLine($"[SchemeHost] WebView2 无可后退历史: {HostScheme?.Name}");
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SchemeHost] 后退失败: {ex.Message}");
        }
        return Task.CompletedTask;
    }

    /// <summary>
    /// 前进（WebView2 导航历史）：回到后退前的页面。
    /// </summary>
    public Task GoForwardAsync(Func<CoreWebView2Provider?> getWebViewProvider)
    {
        try
        {
            var wvp = getWebViewProvider();
            var wv = wvp?.CoreWebView2;
            if (wv is { CanGoForward: true })
            {
                wv.GoForward();
                System.Diagnostics.Debug.WriteLine($"[SchemeHost] WebView2 前进: {HostScheme?.Name}");
            }
            else
            {
                System.Diagnostics.Debug.WriteLine($"[SchemeHost] WebView2 无可前进历史: {HostScheme?.Name}");
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SchemeHost] 前进失败: {ex.Message}");
        }
        return Task.CompletedTask;
    }

    /// <summary>
    /// 硬重载：清除全部缓存/Cookie，然后重新加载。
    /// </summary>
    public async Task HardReloadAsync(
        Func<CoreWebView2Provider?> getWebViewProvider,
        Func<string?> getUserDataFolder,
        Func<Task> recreateWebView,
        Func<Task> reloadScheme)
    {
        if (HostScheme == null || HostBinding == null) return;

        BusyOverlayText = "正在硬重载方案，请稍候...";
        IsBusyOverlayVisible = true;

        try
        {
            IsLoading = true;

            if (HostScheme.UIKind == Models.SchemeUIKind.WebView2)
            {
                var wvp = getWebViewProvider();
                if (wvp != null && wvp.IsOperational)
                {
                    // 清除全部缓存/Cookie/本地存储
                    await wvp.CoreWebView2!.Profile.ClearBrowsingDataAsync(
                        Microsoft.Web.WebView2.Core.CoreWebView2BrowsingDataKinds.AllDomStorage |
                        Microsoft.Web.WebView2.Core.CoreWebView2BrowsingDataKinds.Cookies |
                        Microsoft.Web.WebView2.Core.CoreWebView2BrowsingDataKinds.DiskCache |
                        Microsoft.Web.WebView2.Core.CoreWebView2BrowsingDataKinds.BrowsingHistory);

                    // 清空磁盘残留文件
                    var folder = getUserDataFolder();
                    if (!string.IsNullOrEmpty(folder) && Directory.Exists(folder))
                    {
                        ClearDirectoryFiles(folder);
                    }

                    // 重置自动登录状态
                    _autoLoginState = AutoLoginState.Initial;

                    // 导航回登录页
                    if (!string.IsNullOrEmpty(_lastWebViewUrl))
                        wvp.CoreWebView2.Navigate(_lastWebViewUrl);
                    else
                        await reloadScheme();
                }
                else
                {
                    // WebView2 不可操作 → 彻底重建
                    _autoLoginState = AutoLoginState.Initial;
                    await recreateWebView();
                    await reloadScheme();
                }

                // 等待页面加载完成
                if (wvp?.CoreWebView2 != null)
                    await _autoLoginService.WaitForPageLoadCompleteAsync(wvp.CoreWebView2);
            }
            else
            {
                await reloadScheme();
                await Task.Delay(1500);
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[SchemeHost] 硬重载失败: {ex.Message}");
            HasError = true;
            ErrorMessage = $"硬重载失败: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
            IsBusyOverlayVisible = false;
            BusyOverlayText = string.Empty;
        }
    }

    /// <summary>
    /// 重链接令牌 — 在当前页面重新执行令牌链接脚本。
    /// </summary>
    public async Task RelinkTokenAsync(Func<CoreWebView2Provider?> getWebViewProvider)
    {
        if (HostScheme == null || HostBinding == null) return;

        // 非 WebView2：代码桩
        if (HostScheme.UIKind != Models.SchemeUIKind.WebView2)
            return;

        var wvp = getWebViewProvider();
        if (wvp == null || !wvp.IsOperational) return;

        var coreWebView = wvp.CoreWebView2;
        if (coreWebView == null) return;

        if (HostBinding.TokenId == null) return;

        var schemeInstance = _schemeService.LoadSchemeInstance(HostScheme);
        if (schemeInstance is not IAutoLoginProvider lp) return;

        var tokenId = HostBinding.TokenId.Value;

        // 重置登录状态
        _autoLoginState = AutoLoginState.Initial;

        BusyOverlayText = "正在重链接令牌，请稍候...";
        IsBusyOverlayVisible = true;

        try
        {
            var token = _tokenService.LoadSecureToken(tokenId);
            if (token == null) return;

            // 阶段一：执行自动登录
            var result = await _autoLoginService.ExecuteAutoLoginAsync(
                coreWebView, HostScheme, HostBinding, token, lp);

            ApplyAutoLoginResult(result);

            // 检测到通知页 → 提示用户
            if (result.NoticePageDetected)
            {
                BusyOverlayText = "请先处理当前页面之后再重试！";
                await Task.Delay(3000);
                return;
            }

            // 阶段二：工作区登录阶段
            if (_autoLoginState.WorkspaceLoginPending)
            {
                var wsResult = await _autoLoginService.ExecuteWorkspaceLoginAsync(
                    coreWebView, HostScheme, HostBinding, token, lp);
                ApplyAutoLoginResult(wsResult);
            }

            // [探针] 遮罩消失：自动登录成功标志已输出（ApplyAutoLoginResult 完成，
            // 卡牌/标签状态已更新为"令牌已链接"/"界面加载完成"/"令牌链接失败"）→ 立即隐藏遮罩，
            // 不再等待下方 DOM 轮询完成（最长 10s），避免用户长时间被遮罩阻塞。
            IsBusyOverlayVisible = false;
            BusyOverlayText = string.Empty;

            // 成功界面 DOM 检测：紧跟自动登录成功标志输出之后立即执行
            // （各方案 LoginSuccessDomSelector 命中后消除评论面板等依赖成功 DOM 的竞态）
            await _autoLoginService.PollLoginSuccessDomAsync(coreWebView, lp);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[RelinkToken] 异常: {ex.Message}");
        }
        finally
        {
            IsBusyOverlayVisible = false;
            BusyOverlayText = string.Empty;
        }
    }

    // ========== [评论区功能] 资源上下文同步 ==========

    /// <summary>
    /// WebView2 导航完成后，将当前 URL 同步到评论面板作为资源键。
    /// </summary>
    public void SyncCommentResourceKey(Func<string?> getCurrentUrl)
    {
        try
        {
            var currentUrl = getCurrentUrl() ?? string.Empty;
            var schemeName = HostScheme?.Name ?? "unknown";
            string resourceKey;
            string? resourceTitle;

            // 尝试加载方案插件实例，检查是否实现了 IResourceContextProvider
            var schemeInstance = HostScheme != null ? _schemeService.LoadSchemeInstance(HostScheme) : null;

            if (schemeInstance is IResourceContextProvider contextProvider)
            {
                var customKey = contextProvider.GetResourceKey();
                resourceKey = customKey != null
                    ? $"{schemeName}://{new Uri(currentUrl).Authority}{customKey}"
                    : ResourceKeyBuilder.FromUrl(schemeName, currentUrl);
                resourceTitle = contextProvider.GetResourceTitle();
            }
            else
            {
                resourceKey = ResourceKeyBuilder.FromUrl(schemeName, currentUrl);
                resourceTitle = HostScheme?.DisplayName;
            }

            _commentPanelService.UpdateResourceContext(resourceKey, HostScheme?.Id ?? Guid.Empty, resourceTitle);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[评论区] 资源上下文同步失败: {ex.Message}");
        }
    }

    // ========== URL 跟踪 ==========

    /// <summary>记录最近一次 WebView2 导航 URL</summary>
    public void TrackNavigationUrl(string url) => _lastWebViewUrl = url;

    // ========== 状态管理 ==========

    /// <summary>重置为空闲状态</summary>
    public void Reset()
    {
        HostScheme = null;
        HostBinding = null;
        SchemeInstance = null;
        SchemeUi = null;
        HasPlugin = false;
        IsLoading = false;
        HasError = false;
        ErrorMessage = null;
        DisplayName = string.Empty;
        Status = SchemeStatus.Idle;
        ActiveSchemeId = Guid.Empty;
        BusyOverlayText = string.Empty;
        IsBusyOverlayVisible = false;
        _autoLoginState = AutoLoginState.Initial;
        _lastWebViewUrl = null;
        // 注意：不清空 OnAutoLoginCompleted，因为 InstanceSummaryPage 在 Reset 之前已订阅。
        // 事件由 SchemeHostPage 的 OnAutoLoginCompleted 属性转发，Page 生命周期结束时自然解绑。
    }

    // ========== 私有辅助方法 ==========

    private void SetAutoLoginResult(string status)
    {
        _autoLoginState = _autoLoginState.MarkHandled(status);
        OnAutoLoginCompleted?.Invoke(HostBinding?.Id ?? Guid.Empty, status);
    }

    private void ApplyAutoLoginResult(AutoLoginResult result)
    {
        if (result.WorkspaceLoginPending)
        {
            _autoLoginState = _autoLoginState.MarkWorkspacePending();
        }
        else
        {
            _autoLoginState = _autoLoginState.MarkHandled(result.StatusText);
        }
        OnAutoLoginCompleted?.Invoke(HostBinding?.Id ?? Guid.Empty, result.StatusText);
    }

    private static void ClearDirectoryFiles(string folder)
    {
        try
        {
            foreach (var f in Directory.GetFiles(folder))
                File.Delete(f);
            foreach (var d in Directory.GetDirectories(folder))
                Directory.Delete(d, true);
        }
        catch { }
    }
}

/// <summary>
/// WebView2 提供者 — 桥接 Page 持有的 WebView2 XAML 控件与 ViewModel/Service。
/// ViewModel/Service 不直接持有 WebView2 XAML 控件引用，通过此提供者访问 CoreWebView2。
/// </summary>
public class CoreWebView2Provider
{
    private readonly Microsoft.UI.Xaml.Controls.WebView2 _webViewControl;

    public CoreWebView2Provider(Microsoft.UI.Xaml.Controls.WebView2 webViewControl)
    {
        _webViewControl = webViewControl;
    }

    /// <summary>CoreWebView2（可能为 null，需先 EnsureCoreWebView2Async）</summary>
    public Microsoft.Web.WebView2.Core.CoreWebView2? CoreWebView2
    {
        get
        {
            try { return _webViewControl.CoreWebView2; }
            catch { return null; }
        }
    }

    /// <summary>WebView2 是否处于可操作状态</summary>
    public bool IsOperational
    {
        get
        {
            try { return _webViewControl.CoreWebView2 != null; }
            catch { return false; }
        }
    }

    /// <summary>执行 Reload()</summary>
    public void Reload()
    {
        try { _webViewControl.Reload(); } catch { }
    }

    /// <summary>执行 GoBack()（WebView2 导航历史后退）</summary>
    public void GoBack()
    {
        try { _webViewControl.CoreWebView2?.GoBack(); } catch { }
    }

    /// <summary>执行 GoForward()（WebView2 导航历史前进）</summary>
    public void GoForward()
    {
        try { _webViewControl.CoreWebView2?.GoForward(); } catch { }
    }

    /// <summary>是否可后退（导航历史中存在上一页）</summary>
    public bool CanGoBack
    {
        get
        {
            try { return _webViewControl.CoreWebView2?.CanGoBack ?? false; }
            catch { return false; }
        }
    }

    /// <summary>是否可前进（导航历史中存在下一页）</summary>
    public bool CanGoForward
    {
        get
        {
            try { return _webViewControl.CoreWebView2?.CanGoForward ?? false; }
            catch { return false; }
        }
    }

    /// <summary>获取 Source URI</summary>
    public string? Source
    {
        get
        {
            try { return _webViewControl.Source?.ToString(); } catch { return null; }
        }
    }
}
