using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.ViewModels.Controls;

namespace Kirara_Server_WinUI.ViewModels.InstanceSpace;

/// <summary>
/// 实例主窗体 ViewModel — 管理激活后的实例工作区
/// 包含方案标签栏数据，以及当前显示的方案
/// </summary>
public partial class InstanceWorkspaceViewModel : ObservableObject
{
    private readonly IInstanceService _instanceService;
    private readonly ISchemeService _schemeService;

    [ObservableProperty]
    private Instance? _currentInstance;

    [ObservableProperty]
    private SchemeTabBarViewModel? _schemeTabBar;

    /// <summary>
    /// 当前选中的方案绑定（标签栏当前选中项对应）
    /// </summary>
    [ObservableProperty]
    private SchemeTabItemViewModel? _activeSchemeTab;

    public InstanceWorkspaceViewModel(
        IInstanceService instanceService,
        ISchemeService schemeService,
        SchemeTabBarViewModel schemeTabBar)
    {
        _instanceService = instanceService;
        _schemeService = schemeService;
        _schemeTabBar = schemeTabBar;
    }

    /// <summary>
    /// 加载指定实例，初始化标签栏
    /// </summary>
    public void LoadInstance(Guid instanceId)
    {
        CurrentInstance = _instanceService.GetInstance(instanceId);
        if (CurrentInstance != null)
        {
            // 激活实例（记录最后使用时间等）
            _instanceService.ActivateInstance(instanceId);

            // 加载标签栏（传入实例 ID，拖拽排序后持久化顺序）
            SchemeTabBar?.LoadTabs(instanceId, CurrentInstance.SchemeBindings);

            // 选中第一个可用方案
            var first = SchemeTabBar?.Tabs.FirstOrDefault();
            if (first != null)
            {
                ActiveSchemeTab = first;
            }
        }
    }

    /// <summary>
    /// 设置为当前活跃的方案标签
    /// </summary>
    public void SetActiveTab(SchemeTabItemViewModel tab)
    {
        ActiveSchemeTab = tab;
    }

    /// <summary>
    /// 停用当前实例，返回实例列表
    /// </summary>
    [RelayCommand]
    private void Deactivate()
    {
        _instanceService.DeactivateInstance();
        SchemeTabBar?.Clear();
        CurrentInstance = null;
        ActiveSchemeTab = null;
    }
}
