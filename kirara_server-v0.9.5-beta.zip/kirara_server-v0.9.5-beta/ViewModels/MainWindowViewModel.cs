using CommunityToolkit.Mvvm.ComponentModel;

namespace Kirara_Server_WinUI.ViewModels;

/// <summary>
/// 主窗口 ViewModel — 承载全局状态
/// </summary>
public partial class MainWindowViewModel : ObservableObject
{
    [ObservableProperty]
    private string _title = "Kirara";

    [ObservableProperty]
    private bool _isInstanceActive;
}
