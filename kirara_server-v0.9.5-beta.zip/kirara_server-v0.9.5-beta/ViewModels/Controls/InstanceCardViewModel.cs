using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.ViewModels.Controls;

/// <summary>
/// 实例卡片控件 ViewModel
/// </summary>
public partial class InstanceCardViewModel : ObservableObject
{
    private readonly IInstanceService _instanceService;

    [ObservableProperty]
    private Instance? _instance;

    public InstanceCardViewModel(IInstanceService instanceService)
    {
        _instanceService = instanceService;
    }

    [RelayCommand]
    private void ToggleFavorite()
    {
        if (Instance != null)
        {
            _instanceService.ToggleFavorite(Instance.Id);
            OnPropertyChanged(nameof(Instance));
        }
    }

    [RelayCommand]
    private void Activate()
    {
        if (Instance != null)
        {
            _instanceService.ActivateInstance(Instance.Id);
        }
    }
}
