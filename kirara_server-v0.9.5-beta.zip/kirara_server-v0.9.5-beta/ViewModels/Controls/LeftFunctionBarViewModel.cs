using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.ViewModels.Comment;

namespace Kirara_Server_WinUI.ViewModels.Controls;

/// <summary>
/// 壳布局 ViewModel — 管理左侧功能栏、导航状态、实例交互逻辑与业务校验。
/// 由原 ShellViewModel 与 LeftFunctionBarViewModel 合并而成，统一收归全局壳层职责。
/// </summary>
public partial class LeftFunctionBarViewModel : ObservableObject
{
    // ================================================================
    //  依赖服务
    // ================================================================
    private readonly INavigationService _navigationService;
    private readonly IInstanceService _instanceService;
    private readonly IDialogService _dialogService;
    private readonly ISchemePageCache _schemePageCache;
    private readonly IPermissionService _permissionService;
    private readonly ILoginService _loginService;

    public LeftFunctionBarViewModel(
        INavigationService navigationService,
        IInstanceService instanceService,
        IDialogService dialogService,
        ISchemePageCache schemePageCache,
        IPermissionService permissionService,
        ILoginService loginService)
    {
        _navigationService = navigationService;
        _instanceService = instanceService;
        _dialogService = dialogService;
        _schemePageCache = schemePageCache;
        _permissionService = permissionService;
        _loginService = loginService;
        LoadInstances();
    }

    // ================================================================
    //  预定义颜色选项（十六进制色值），用于飞入菜单的颜色标签选择
    // ================================================================
    public IReadOnlyList<string> ColorOptions { get; } = new List<string>
    {
        "#FF6B6B",
        "#FFA94D",
        "#FFD43B",
        "#69DB7C",
        "#4DABF7",
        "#9775FA",
        "#F06595",
        "#868E96",
        "#FFFFFF",
    };

    // ================================================================
    //  重命名非法字符集合（业务规则，与 View 无关）
    // ================================================================
    private static readonly HashSet<char> ForbiddenNameChars = new(@"#\/*:?""<>|");

    // ================================================================
    //  实例名称校验（唯一入口，消除重复定义）
    // ================================================================

    /// <summary>
    /// 验证实例名称是否合法。
    /// instance 为 null 时仅做格式校验（适用于新建场景）。
    /// </summary>
    /// <param name="name">待验证的名称</param>
    /// <param name="instance">当前实例（可选，用于跳过自身比较和同名检测）</param>
    /// <returns>(是否合法, 错误描述) — error 为 null 表示没有错误</returns>
    public (bool isValid, string? error) ValidateInstanceName(string name, Instance? instance)
    {
        if (string.IsNullOrWhiteSpace(name))
            return (false, "名称不能为空");

        if (name.Contains(' '))
            return (false, "名称不能包含空格");

        if (name.Any(c => ForbiddenNameChars.Contains(c)))
            return (false, "名称不能包含下列特殊字符：# \\ / : * ? \" < > |");

        // 无实例引用时仅做格式校验（新建等场景）
        if (instance == null)
            return (true, null);

        if (name == instance.Name)
            return (false, null);

        // 同名检测
        if (AllInstances.Any(i =>
            i.Id != instance.Id && i.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
            return (false, "该名称已被其他实例使用，请换一个名称");

        return (true, null);
    }

    // ================================================================
    //  侧栏展开/折叠状态
    // ================================================================
    [ObservableProperty]
    private bool _isLeftPaneOpen = true;

    public double SidebarWidth => IsLeftPaneOpen ? 240.0 : 48.0;
    public bool IsPaneCollapsed => !IsLeftPaneOpen;

    partial void OnIsLeftPaneOpenChanged(bool value)
    {
        OnPropertyChanged(nameof(SidebarWidth));
        OnPropertyChanged(nameof(IsPaneCollapsed));
    }

    /// <summary>
    /// 应用侧栏启动状态（由 App 在 AppBehaviorService.Load() 之后调用）：
    /// 自动折叠开启 → 启动展开（折叠发生在进入工作区时）；
    /// 否则按折叠/展开开关（开 = 展开 / 关 = 折叠）。
    /// </summary>
    public void ApplyStartupPaneState()
    {
        var behavior = AppBehaviorService.Current;
        if (behavior == null) return;
        IsLeftPaneOpen = behavior.AutoCollapseSidebar || behavior.SidebarStartupExpanded;
    }

    /// <summary>自动折叠触发前记录的侧栏状态（null = 未记录，离开工作区时不恢复）</summary>
    private bool? _paneStateBeforeWorkspace;

    /// <summary>
    /// 进入实例主界面（InstanceWorkspace.OnNavigatedTo）时调用：
    /// 自动折叠开启时折叠侧栏；仅首次进入（从工作区外）记录进入前状态，
    /// 工作区 → 工作区（切入另一实例/分享跳转）不覆盖记录，
    /// 最终恢复目标保持为「首次进入工作区前」的状态。
    /// </summary>
    public void PrepareWorkspaceAutoCollapse()
    {
        if (AppBehaviorService.Current?.AutoCollapseSidebar != true) return;
        _paneStateBeforeWorkspace ??= IsLeftPaneOpen;
        IsLeftPaneOpen = false;
    }

    /// <summary>
    /// 离开实例主界面到其他页面（InstanceWorkspace.OnNavigatedFrom）时调用：
    /// 若此前因自动折叠记录过状态，则恢复为首次进入工作区前的展开/折叠状态。
    /// </summary>
    public void RestorePaneStateAfterWorkspace()
    {
        if (_paneStateBeforeWorkspace.HasValue)
        {
            IsLeftPaneOpen = _paneStateBeforeWorkspace.Value;
            _paneStateBeforeWorkspace = null;
        }
    }

    /// <summary>
    /// 关闭「自动折叠」设置时（设置页调用）：
    /// 清除自动折叠状态记录，并立即按折叠/展开开关设置侧栏状态，
    /// 使设置项与左侧栏状态即时一致，无需重启。
    /// </summary>
    public void DisableAutoCollapseAndApplyStartupState()
    {
        _paneStateBeforeWorkspace = null;
        var behavior = AppBehaviorService.Current;
        if (behavior == null) return;
        IsLeftPaneOpen = behavior.SidebarStartupExpanded;
    }

    [ObservableProperty]
    private string? _searchText;

    partial void OnSearchTextChanged(string? value)
    {
        ApplyFilter();
    }

    // ================================================================
    //  导航高亮状态
    // ================================================================
    [ObservableProperty]
    private bool _isQuickStartActive = true;

    [ObservableProperty]
    private bool _isCreateUserActive;

    [ObservableProperty]
    private bool _isCreateServiceActive;

    [ObservableProperty]
    private bool _isTokenManagerActive;

    [ObservableProperty]
    private bool _isSettingsActive;

    /// <summary>实例工作区是否处于活跃状态（对应左侧某个实例被选中进入）</summary>
    [ObservableProperty]
    private bool _isInstanceActive;

    /// <summary>当前激活的实例 ID（用于左侧栏高亮匹配）</summary>
    [ObservableProperty]
    private Guid _activeInstanceId;

    /// <summary>已点击"开始工作"的实例 ID 集合（之后直接进入工作区，不再显示先导页）</summary>
    private static readonly HashSet<Guid> StartedInstances = new();

    partial void OnActiveInstanceIdChanged(Guid value)
    {
        Converters.InstanceActiveToBrushConverter.ActiveInstanceId = value;

        // ★ 高亮刷新统一入口：左侧栏高亮绑定是 x:Bind + 静态转换器（ActiveInstanceId），
        //   其变化不会触发绑定重新求值，必须重建集合（LoadInstances → ApplyFilter →
        //   FilteredInstances 新集合 → ItemsSource 更新 → 容器 x:Bind 重求值）才会刷新。
        //   任何 ActiveInstanceId 变化（手动点击 / 通知跳转 / 切出实例页清空）都立即生效，
        //   不依赖导航回调的巧合。LoadInstances 不修改 ActiveInstanceId，无递归。
        LoadInstances();
    }

    /// <summary>
    /// 设置当前的活跃导航项，其余全部置 false
    /// </summary>
    public void SetActivePage(bool quickStart = false, bool createUser = false,
        bool createService = false, bool tokenManager = false, bool settings = false,
        bool instance = false)
    {
        IsQuickStartActive = quickStart;
        IsCreateUserActive = createUser;
        IsCreateServiceActive = createService;
        IsTokenManagerActive = tokenManager;
        IsSettingsActive = settings;
        IsInstanceActive = instance;
        if (!instance) ActiveInstanceId = Guid.Empty;
    }

    // ================================================================
    //  实例数据管理
    // ================================================================
    [ObservableProperty]
    private ObservableCollection<Instance> _allInstances = new();

    [ObservableProperty]
    private ObservableCollection<Instance> _filteredInstances = new();

    /// <summary>快捷操作上下文——当前选中的实例（用于重命名、改色、删除）</summary>
    [ObservableProperty]
    private Instance? _contextInstance;

    /// <summary>
    /// 实例颜色标签变更时触发。参数：实例 ID, 新颜色标签（null 表示清除）。
    /// InstanceWorkspace 订阅此事件以同步刷新方案标签栏底部颜色线。
    /// </summary>
    public event Action<Guid, string?>? InstanceColorTagChanged;

    /// <summary>当前页面类型（由 ShellPage 在导航时更新）</summary>
    public Type? CurrentPageType { get; set; }

    /// <summary>实例创建向导是否已进入（用户已同意许可协议），用于控制离开确认弹窗</summary>
    public bool IsEditorInProgress { get; set; }

    /// <summary>
    /// 正在初始化中的实例 ID 集合。
    /// 初始化期间：状态灯显示红色，点击实例标签被拦截（显示"正在初始化中"提示），无法进入总结页。
    /// </summary>
    private readonly HashSet<Guid> _initializingInstances = new();

    /// <summary>初始化实例红灯状态文字（转换器映射为红色圆点）</summary>
    private const string InitializingStatusText = "正在初始化实例...";

    /// <summary>初始化实例红灯/拦截最小显示时长（毫秒）— 即使初始化瞬间完成，也让用户看到状态反馈</summary>
    private const int MinInitializingDisplayMs = 5000;

    /// <summary>指定实例是否正处于初始化中（供 UI 层点击拦截判断）</summary>
    public bool IsInstanceInitializing(Guid instanceId) => _initializingInstances.Contains(instanceId);

    /// <summary>
    /// 正在关闭中的实例 ID 集合（与初始化探针对称）。
    /// 关闭期间：状态灯显示红色，点击实例标签被拦截（显示"正在关闭中"提示），无法进入总结页。
    /// </summary>
    private readonly HashSet<Guid> _closingInstances = new();

    /// <summary>关闭实例红灯状态文字（转换器映射为红色圆点）</summary>
    private const string ClosingStatusText = "正在关闭实例...";

    /// <summary>关闭实例红灯/拦截最小显示时长（毫秒）— 即使关闭瞬间完成，也让用户看到状态反馈</summary>
    private const int MinClosingDisplayMs = 3000;

    /// <summary>指定实例是否正处于关闭中（供 UI 层点击拦截判断）</summary>
    public bool IsInstanceClosing(Guid instanceId) => _closingInstances.Contains(instanceId);

    /// <summary>当前用户是否可以创建服务实例（管理员专有权限）</summary>
    public bool CanCreateServiceInstance => _permissionService.CanCreateServiceInstance;

    /// <summary>
    /// 用户登录后刷新数据：重新加载当前用户的实例 + 通知权限变更
    /// </summary>
    public void RefreshAfterLogin()
    {
        LoadInstances();
        OnPropertyChanged(nameof(CanCreateServiceInstance));
    }

    /// <summary>
    /// [账号安全] 退出登录时重置实例会话状态（等同关闭软件再打开）：
    /// 1. 清除"已开始工作"标记 → 下次登录点击实例重新进入实例总结页（先导页），而非直接进工作区
    /// 2. 清除 WorkStatus 缓存与初始化中集合 → 圆点/红灯状态不残留
    /// 3. 重置激活状态与上下文 → 左侧栏高亮不残留
    /// 由 ShellPage 登出分支调用。
    /// </summary>
    public void ResetForLogout()
    {
        StartedInstances.Clear();
        _workStatusCache.Clear();
        _initializingInstances.Clear();
        _closingInstances.Clear();
        ContextInstance = null;
        ActiveInstanceId = Guid.Empty;
        IsInstanceActive = false;
        ApplyStatusToCollectionsAll(null);
    }

    /// <summary>将所有实例的 WorkStatus 置为指定值（登出时清空圆点状态）</summary>
    private void ApplyStatusToCollectionsAll(string? status)
    {
        foreach (var inst in AllInstances)
            inst.WorkStatus = status;
        foreach (var inst in FilteredInstances)
            inst.WorkStatus = status;
    }

    /// <summary>
    /// UI 层注入的委托——当需要确认离开编辑器时调用此委托显示 Flyout 确认菜单。
    /// ViewModel 不依赖 IDialogService，由 UI 层决定展示样式。
    /// </summary>
    public Func<Task<bool>>? ConfirmLeaveEditor { get; set; }

    /// <summary>
    /// 如果当前在实例创建向导页面且已进入向导（同意协议后），弹出确认菜单。
    /// 返回 true 表示可以继续导航，false 表示用户取消。
    /// </summary>
    private async Task<bool> ConfirmLeaveEditorIfNeeded()
    {
        if (CurrentPageType == typeof(Views.Pages.InstanceEditorPage) && IsEditorInProgress)
        {
            if (ConfirmLeaveEditor != null)
                return await ConfirmLeaveEditor();
            return true;
        }
        return true;
    }

    /// <summary>
    /// 从服务加载当前用户实例并刷新过滤列表。
    /// 普通用户只能看到用户实例，管理员可以看到全部。
    /// </summary>

    /// <summary>
    /// WorkStatus 缓存：因为 LoadInstances 每次从 LiteDB 重建 Instance 对象，
    /// 而 WorkStatus 是 [BsonIgnore] 非持久化属性，重建后会丢失。
    /// 此字典在 LoadInstances 前后保存/恢复状态。
    /// </summary>
    private readonly Dictionary<Guid, string?> _workStatusCache = new();

    public void LoadInstances()
    {
        // 保存当前 WorkStatus，防止重建 Instance 对象后状态丢失
        foreach (var inst in AllInstances)
        {
            if (inst.WorkStatus != null)
                _workStatusCache[inst.Id] = inst.WorkStatus;
        }

        var userId = _loginService.CurrentUserId;
        var instances = _instanceService.GetInstancesByUser(userId).ToList();
        // [权限] 根据当前用户组别过滤实例
        instances = _permissionService.FilterAccessibleInstances(instances).ToList();

        // 恢复已缓存的 WorkStatus
        foreach (var inst in instances)
        {
            if (_initializingInstances.Contains(inst.Id))
            {
                // [初始化保护] 正在初始化中的实例强制红灯（缓存意外丢失时也能保持状态）
                inst.WorkStatus = InitializingStatusText;
            }
            else if (_workStatusCache.TryGetValue(inst.Id, out var saved))
            {
                inst.WorkStatus = saved;
            }
        }

        AllInstances = new ObservableCollection<Instance>(instances);
        ApplyFilter();
    }

    private void ApplyFilter()
    {
        var source = AllInstances.AsEnumerable();
        if (!string.IsNullOrWhiteSpace(SearchText))
        {
            var keyword = SearchText.Trim();
            source = source.Where(i =>
                i.Name.Contains(keyword, StringComparison.OrdinalIgnoreCase));
        }
        // 收藏的实例优先显示，其余按名称升序排列（稳定排序，不会因点击而跳动）
        FilteredInstances = new ObservableCollection<Instance>(
            source.OrderByDescending(i => i.IsFavorite)
                  .ThenBy(i => i.Name, StringComparer.OrdinalIgnoreCase));
    }

    // ================================================================
    //  工作区状态管理（侧边栏圆点颜色）
    // ================================================================

    /// <summary>
    /// 设置实例工作区状态（供 InstanceSummaryPage 调用），触发侧边栏圆点变色。
    /// 同时写入缓存以防 LoadInstances 重建对象后丢失。
    /// </summary>
    public void UpdateInstanceWorkStatus(Guid instanceId, string? status)
    {
        if (status == null)
            _workStatusCache.Remove(instanceId);
        else
            _workStatusCache[instanceId] = status;

        ApplyStatusToCollections(instanceId, status);
    }

    /// <summary>
    /// 清除实例工作区状态（关闭/删除/重置时调用），圆点恢复灰色。
    /// </summary>
    private void ClearWorkStatus(Guid instanceId)
    {
        _workStatusCache.Remove(instanceId);
        ApplyStatusToCollections(instanceId, null);
    }

    /// <summary>
    /// 将 WorkStatus 应用到 AllInstances 和 FilteredInstances 中的对应对象。
    /// </summary>
    private void ApplyStatusToCollections(Guid instanceId, string? status)
    {
        ApplyTo(AllInstances);
        ApplyTo(FilteredInstances);

        void ApplyTo(ObservableCollection<Instance> collection)
        {
            for (int i = 0; i < collection.Count; i++)
            {
                if (collection[i].Id == instanceId)
                {
                    collection[i].WorkStatus = status;
                    break;
                }
            }
        }
    }

    // ================================================================
    //  导航命令
    // ================================================================

    [RelayCommand]
    private async Task NavigateToQuickStart()
    {
        // 防重复：如果当前已在首页，不重复导航，仅播放点击动画
        if (CurrentPageType == typeof(Views.Pages.MainPage) && IsQuickStartActive)
            return;

        if (!await ConfirmLeaveEditorIfNeeded()) return;
        _navigationService.NavigateTo(typeof(Views.Pages.MainPage));
        SetActivePage(quickStart: true);
    }

    [RelayCommand]
    private async Task NavigateToTokenManager()
    {
        // 防重复：如果当前已在令牌管理器页面，不重复导航，仅播放点击动画
        if (CurrentPageType == typeof(Views.Pages.TokenManagerPage) && IsTokenManagerActive)
            return;

        if (!await ConfirmLeaveEditorIfNeeded()) return;
        _navigationService.NavigateTo(typeof(Views.Pages.TokenManagerPage));
        SetActivePage(tokenManager: true);
    }

    [RelayCommand]
    private async Task NavigateToSettings()
    {
        // 防重复：如果当前已在设置页面，不重复导航，仅播放点击动画
        if (CurrentPageType == typeof(Views.Pages.SettingsPage) && IsSettingsActive)
            return;

        if (!await ConfirmLeaveEditorIfNeeded()) return;
        _navigationService.NavigateTo(typeof(Views.Pages.SettingsPage));
        SetActivePage(settings: true);
    }

    [RelayCommand]
    private async Task CreateUserInstance()
    {
        // 防重复：如果当前已在创建用户实例页面，不重复导航，仅播放点击动画
        if (CurrentPageType == typeof(Views.Pages.InstanceEditorPage) && IsCreateUserActive)
            return;

        if (!await ConfirmLeaveEditorIfNeeded()) return;

        _navigationService.NavigateTo(typeof(Views.Pages.InstanceEditorPage),
            new Dictionary<string, object> { ["InstanceType"] = InstanceType.UserInstance });
        SetActivePage(createUser: true);
    }

    [RelayCommand]
    private async Task CreateServiceInstance()
    {
        // [权限] 非管理员不能创建服务实例
        if (!_permissionService.CanCreateServiceInstance)
        {
            await _dialogService.ShowMessageAsync("权限不足", "只有管理员组的用户才能创建服务实例。");
            return;
        }

        // 防重复：如果当前已在创建服务实例页面，不重复导航，仅播放点击动画
        if (CurrentPageType == typeof(Views.Pages.InstanceEditorPage) && IsCreateServiceActive)
            return;

        if (!await ConfirmLeaveEditorIfNeeded()) return;

        _navigationService.NavigateTo(typeof(Views.Pages.InstanceEditorPage),
            new Dictionary<string, object> { ["InstanceType"] = InstanceType.ServiceInstance });
        SetActivePage(createService: true);
    }

    [RelayCommand]
    private void ToggleLeftPane()
    {
        IsLeftPaneOpen = !IsLeftPaneOpen;
    }

    // ================================================================
    //  实例选择与启动标记
    // ================================================================

    [RelayCommand]
    private Task SelectInstance(Instance? instance)
    {
        if (instance == null) return Task.CompletedTask;
        return SelectInstanceCoreAsync(instance, jumpTarget: null);
    }

    /// <summary>
    /// 通知跳转入口 — 与手动点击左侧栏实例标签（SelectInstance）**完全共享同一核心路径**：
    /// 拦截检查 / 权限检查 / 编辑器离开确认 / 高亮设置 / 集合刷新 / 状态灯 / 导航。
    /// 差异仅两点：
    /// 1. 导航携带跳转目标（jumpTarget）：已启动 → 工作区跳资源；未启动 → 总结页自动部署模式；
    /// 2. 设置高亮后**立即 LoadInstances() 重建集合**（左侧栏高亮绑定是 x:Bind + 静态转换器，
    ///    必须重建集合才重新求值；手动路径靠导航后的 OnContentNavigated 巧合刷新，通知路径主动执行）。
    /// </summary>
    /// <param name="instance">目标实例</param>
    /// <param name="jumpTarget">通知跳转目标（SharedContentNavigationParameter）；null=普通导航</param>
    public Task SelectInstanceForNotification(Instance instance, SharedContentNavigationParameter? jumpTarget)
        => SelectInstanceCoreAsync(instance, jumpTarget);

    /// <summary>
    /// 实例选择核心路径（手动点击标签与通知跳转共用）。
    /// </summary>
    private async Task SelectInstanceCoreAsync(Instance instance, SharedContentNavigationParameter? jumpTarget)
    {
        if (instance == null) return;

        // [初始化拦截] 该实例正在初始化中 → 阻止进入总结页/工作区
        // （UI 层会先弹出"正在初始化中"飞入提示，此处兜底拦截）
        if (_initializingInstances.Contains(instance.Id))
            return;

        // [关闭拦截] 该实例正在关闭中 → 阻止进入总结页/工作区
        // （UI 层会先弹出"正在关闭中"飞入提示，此处兜底拦截）
        if (_closingInstances.Contains(instance.Id))
            return;

        // [权限] 检查当前用户是否有权访问此实例
        if (!_permissionService.CanAccessInstance(instance))
        {
            await _dialogService.ShowMessageAsync("权限不足",
                $"您没有权限访问服务实例「{instance.Name}」。\n只有管理员组的用户才能访问服务实例。");
            return;
        }

        // 如果点击的是当前已激活的实例，不重复导航，仅保留按钮点击特效
        if (ActiveInstanceId == instance.Id && IsInstanceActive)
            return;

        if (!await ConfirmLeaveEditorIfNeeded()) return;

        // 设置活跃实例（触发 OnActiveInstanceIdChanged → LoadInstances 刷新高亮）
        ActiveInstanceId = instance.Id;
        SetActivePage(instance: true);

        // 注意：此处**不**设置状态灯（点击标签/跳转本身不改变状态灯颜色）——
        // 状态灯由 InstanceSummaryPage 部署流程控制：点击"开始部署"后
        // SyncWorkStatus("正在加载方案...") 才变橙，部署完成"工作区已就绪"变绿。

        if (jumpTarget != null)
        {
            // 通知跳转：已启动 → 工作区跳资源；未启动 → 总结页自动部署模式
            if (StartedInstances.Contains(instance.Id))
            {
                _navigationService.NavigateTo(
                    typeof(Views.Instance.InstanceWorkspace), jumpTarget);
            }
            else
            {
                _navigationService.NavigateTo(
                    typeof(Views.Pages.InstanceSummaryPage),
                    new AutoDeployNavigationParameter(instance.Id, jumpTarget));
            }
        }
        else
        {
            // 手动点击：已启动过的实例直接进入工作区；首次打开则显示先导页
            if (StartedInstances.Contains(instance.Id))
                _navigationService.NavigateTo(typeof(Views.Instance.InstanceWorkspace), instance.Id);
            else
                _navigationService.NavigateTo(typeof(Views.Pages.InstanceSummaryPage), instance.Id);
        }
    }

    /// <summary>标记实例已启动（由先导页“开始工作”调用），之后不再显示先导页</summary>
    public void MarkInstanceStarted(Guid instanceId)
    {
        StartedInstances.Add(instanceId);
    }

    /// <summary>判断实例是否已启动（进入过工作区）。供通知跳转等外部模块判断"实例是否打开"。</summary>
    public bool IsInstanceStarted(Guid instanceId) => StartedInstances.Contains(instanceId);

    /// <summary>
    /// 确保指定实例处于左侧栏激活/高亮状态（幂等）。
    /// 供 InstanceWorkspace 等"进入工作区"的兜底路径调用：
    /// 所有进入工作区的路径（手动点击 / 通知跳转 / 分享跳转）统一在此同步
    /// ActiveInstanceId + IsInstanceActive + 集合重建（x:Bind 高亮重求值），
    /// 防止个别路径未设置高亮导致左侧栏标签无选中状态。
    /// </summary>
    /// <param name="instanceId">目标实例 ID</param>
    public void EnsureInstanceActive(Guid instanceId)
    {
        if (instanceId == Guid.Empty) return;
        if (ActiveInstanceId == instanceId && IsInstanceActive) return;

        // 触发 OnActiveInstanceIdChanged → 静态转换器更新 + LoadInstances 刷新高亮；
        // 若值未变化（已是目标实例但 IsInstanceActive=false），partial method 不触发，
        // 下方 LoadInstances 兜底重建集合（幂等，重复调用无副作用）。
        ActiveInstanceId = instanceId;
        SetActivePage(instance: true);
        LoadInstances();
    }

    // ================================================================
    //  右键 / 飞入菜单快捷操作
    // ================================================================

    /// <summary>设置实例的上下文（供 Flyout 使用）</summary>
    [RelayCommand]
    private void SetContextInstance(Instance? instance)
    {
        ContextInstance = instance;
    }

    [RelayCommand]
    private void RenameContextInstance(string? newName)
    {
        if (ContextInstance == null || string.IsNullOrWhiteSpace(newName)) return;
        _instanceService.RenameInstance(ContextInstance.Id, newName);
        LoadInstances();
    }

    [RelayCommand]
    private async Task DeleteContextInstance()
    {
        if (ContextInstance == null) return;
        var instanceId = ContextInstance.Id;
        var wasActive = IsInstanceActive && ActiveInstanceId == instanceId;

        _instanceService.DeleteInstance(instanceId);
        await _schemePageCache.DestroyInstance(instanceId);
        StartedInstances.Remove(instanceId);
        ClearWorkStatus(instanceId);
        LoadInstances();
        ContextInstance = null;

        // 如果当前正在查看被删实例的工作区，立即关闭并返回快速开始
        if (wasActive)
        {
            _instanceService.DeactivateInstance();
            ActiveInstanceId = Guid.Empty;
            SetActivePage(quickStart: true);
            _navigationService.NavigateTo(typeof(Views.Pages.MainPage));
        }
    }
    
    [RelayCommand]
    private async Task CloseInstance()
    {
        if (ContextInstance == null) return;
        var instanceId = ContextInstance.Id;
        var wasActive = IsInstanceActive && ActiveInstanceId == instanceId;

        // 防重复：同一实例已在关闭中则忽略重复触发
        if (_closingInstances.Contains(instanceId)) return;

        // 0. 标记关闭中：状态灯变红 + 拦截点击进入
        //    记录开始时间，用于确保红灯/拦截至少显示 MinClosingDisplayMs（关闭可能瞬间完成）
        var closeStartTime = DateTime.UtcNow;
        _closingInstances.Add(instanceId);
        UpdateInstanceWorkStatus(instanceId, ClosingStatusText);

        // 1. 先清空上下文，防止关闭期间命令被重复触发
        ContextInstance = null;

        try
        {
            // 2. 停用实例 + 移除已启动标记
            _instanceService.DeactivateInstance();
            StartedInstances.Remove(instanceId);

            // 3. 正在查看该实例时，先导航回首页（UI 立即离开工作区），
            //    避免等待页面关闭（OpenVPN 断开最长 5s）期间停留在已销毁页面白屏。
            //    与 ResetContextInstance（初始化实例）的"先导航后销毁"顺序保持一致。
            if (wasActive)
            {
                ActiveInstanceId = Guid.Empty;
                SetActivePage(quickStart: true);
                _navigationService.NavigateTo(typeof(Views.Pages.MainPage));
            }

            // 4. 关闭所有方案页面（WebView2 进程 + OpenVPN 连接），保留磁盘用户数据
            //    （与"关闭软件再打开"同级语义：Cookie/.ovpn 缓存下次打开可复用）
            await _schemePageCache.ShutdownInstance(instanceId);

            // 4.5 确保红灯/拦截至少显示 MinClosingDisplayMs，避免关闭瞬间完成时
            //     用户看不到任何状态反馈（纯 WebView2 实例 ShutdownInstance 通常 <100ms）
            var elapsedMs = (DateTime.UtcNow - closeStartTime).TotalMilliseconds;
            var remainingMs = MinClosingDisplayMs - elapsedMs;
            if (remainingMs > 0)
                await Task.Delay((int)remainingMs);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[LeftFunctionBar] 关闭实例失败: {ex.Message}");
        }
        finally
        {
            // 5. 关闭完成（成功或失败）：解除点击拦截，状态灯恢复灰色
            _closingInstances.Remove(instanceId);
            ClearWorkStatus(instanceId);
        }
    }

    /// <summary>
    /// 初始化实例：将实例绑定的所有方案重置到初始状态，相当于对每个方案执行一次"硬重载方案"。
    /// 销毁所有缓存的方案页并清除磁盘用户数据（Cookie/缓存/本地存储）。
    /// 下次打开实例时所有方案从零开始创建，等价于每个方案都执行了硬重载。
    /// 非 WebView2 方案同样适用（下次打开时重新加载）。
    /// </summary>
    [RelayCommand]
    private async Task ResetContextInstance()
    {
        if (ContextInstance == null) return;

        var instanceId = ContextInstance.Id;
        var wasActive = IsInstanceActive && ActiveInstanceId == instanceId;

        // 防重复：同一实例已在初始化中则忽略重复触发
        if (_initializingInstances.Contains(instanceId)) return;

        // 0. 标记初始化中：状态灯变红 + 拦截点击进入
        //    记录开始时间，用于确保红灯/拦截至少显示 MinInitializingDisplayMs（初始化可能瞬间完成）
        var resetStartTime = DateTime.UtcNow;
        _initializingInstances.Add(instanceId);
        UpdateInstanceWorkStatus(instanceId, InitializingStatusText);

        try
        {
            // 1. 停用实例 + 移除已启动标记
            _instanceService.DeactivateInstance();
            StartedInstances.Remove(instanceId);

            if (wasActive)
            {
                // 导航回首页，先于 DestroyInstance 确保 UI 已离开
                ActiveInstanceId = Guid.Empty;
                SetActivePage(quickStart: true);
                _navigationService.NavigateTo(typeof(Views.Pages.MainPage));
            }

            // 先清空上下文，防止销毁期间命令被重复触发
            ContextInstance = null;

            // 2.5 重置方案绑定的标签顺序为初始顺序（列表顺序即初始顺序，拖拽只改 Order 值）
            //    ✅ 拖拽排序持久化后，切出/重启均保留；仅此处"初始化实例"还原默认顺序
            var instance = _instanceService.GetInstance(instanceId);
            if (instance != null)
            {
                bool orderChanged = false;
                for (int i = 0; i < instance.SchemeBindings.Count; i++)
                {
                    if (instance.SchemeBindings[i].Order != i)
                    {
                        instance.SchemeBindings[i].Order = i;
                        orderChanged = true;
                    }
                }
                if (orderChanged)
                {
                    instance.UpdatedAt = DateTime.UtcNow;
                    _instanceService.UpdateInstance(instance);
                    System.Diagnostics.Debug.WriteLine(
                        "[LeftFunctionBar] 初始化实例：方案标签顺序已重置为默认顺序");
                }
            }

            // 3. 销毁缓存并清除磁盘用户数据（deleteUserData: true）
            //    DestroyInstance 内部：同步关闭 WebView2 → 代际升代（写入全局缓存）→ 异步删除旧数据目录。
            //    等待销毁完成后再返回：下次打开实例时新建的页面通过全局代际延续到干净数据目录，
            //    等价于每个方案都执行了硬重载（非 WebView2 方案同样适用）。
            await _schemePageCache.DestroyInstance(instanceId);

            // 3.5 确保红灯/拦截至少显示 MinInitializingDisplayMs，避免初始化瞬间完成时
            //     用户看不到任何状态反馈（纯 WebView2 实例 DestroyInstance 通常 <100ms）
            var elapsedMs = (DateTime.UtcNow - resetStartTime).TotalMilliseconds;
            var remainingMs = MinInitializingDisplayMs - elapsedMs;
            if (remainingMs > 0)
                await Task.Delay((int)remainingMs);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[LeftFunctionBar] 初始化实例失败: {ex.Message}");
        }
        finally
        {
            // 4. 初始化完成（成功或失败）：解除点击拦截，状态灯恢复灰色
            _initializingInstances.Remove(instanceId);
            ClearWorkStatus(instanceId);
        }
    }

    [RelayCommand]
    private void SetContextInstanceColor(string? colorHex)
    {
        if (ContextInstance == null) return;
        var instanceId = ContextInstance.Id;
        _instanceService.SetColorTag(instanceId, colorHex);
        LoadInstances();
        InstanceColorTagChanged?.Invoke(instanceId, colorHex);
    }

    [RelayCommand]
    private void ToggleFavoriteContextInstance()
    {
        if (ContextInstance == null) return;
        _instanceService.ToggleFavorite(ContextInstance.Id);
        LoadInstances();
    }

    /// <summary>
    /// 带对话框的重命名 — 校验委托直接调用统一的 ValidateInstanceName，
    /// 不再内联重复逻辑。
    /// </summary>
    [RelayCommand]
    private async Task RenameContextInstanceWithDialog()
    {
        if (ContextInstance == null) return;

        var newName = await _dialogService.ShowRenameInputAsync(
            "重命名实例",
            ContextInstance.Name,
            validate: name => ValidateInstanceName(name, ContextInstance));

        if (newName != null)
        {
            _instanceService.RenameInstance(ContextInstance.Id, newName);
            LoadInstances();
        }
    }

    /// <summary>
    /// 带确认对话框的删除 — 确认后销毁方案缓存并清理状态
    /// </summary>
    [RelayCommand]
    private async Task DeleteContextInstanceWithConfirm()
    {
        if (ContextInstance == null) return;

        var instanceId = ContextInstance.Id;
        var wasActive = IsInstanceActive && ActiveInstanceId == instanceId;

        var confirmed = await _dialogService.ShowConfirmAsync(
            "确认删除",
            $"确定要永久删除实例「{ContextInstance.Name}」吗？");

        if (confirmed)
        {
            _instanceService.DeleteInstance(instanceId);
            await _schemePageCache.DestroyInstance(instanceId);
            StartedInstances.Remove(instanceId);
            ClearWorkStatus(instanceId);
            LoadInstances();
            ContextInstance = null;

            // 如果当前正在查看被删实例的工作区，立即关闭并返回主页
            if (wasActive)
            {
                _instanceService.DeactivateInstance();
                SetActivePage(quickStart: true);
                _navigationService.NavigateTo(typeof(Views.Pages.MainPage));
            }
        }
    }
}
