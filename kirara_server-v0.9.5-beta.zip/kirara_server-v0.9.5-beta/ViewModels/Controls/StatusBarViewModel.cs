using CommunityToolkit.Mvvm.ComponentModel;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.ViewModels.Controls;

/// <summary>
/// 实例工作区状态栏 ViewModel — 监控并显示网络/系统状态信息
/// 内网可达检测（全局共享：状态栏在所有实例下显示同一状态，不随实例切换跳变）：
///   - OpenVPN 已连接（VpnConnectionService.State == Connected）→ 内网可达（0ms，零网络请求）
///   - OpenVPN 未连接 / 断开 / 失败 → 立即"内网不可达"，降级 Ping 网关 10.10.10.3（每 30s 更新一次）
///   - 机器本身处于内网（Ping 通 10.10.10.3）→ 无需连接 OpenVPN 也显示"内网可达"
/// </summary>
public partial class StatusBarViewModel : ObservableObject, IDisposable
{
    // ================================================================
    //  Ping 目标网关
    // ================================================================
    private static readonly string[] VpnGateways = { "10.10.10.3" };

    // ===== 网络状态 =====
    [ObservableProperty]
    private bool _isNetworkAvailable = true;

    [ObservableProperty]
    private double _uploadSpeed;

    [ObservableProperty]
    private double _downloadSpeed;

    [ObservableProperty]
    private string _uploadSpeedText = "0 B/s";

    [ObservableProperty]
    private string _downloadSpeedText = "0 B/s";

    // ===== VPN 状态 =====
    [ObservableProperty]
    private bool _isVpnConnected;

    [ObservableProperty]
    private string _vpnStatusText = "内网不可达";

    // ===== 系统资源 =====
    /// <summary>
    /// CPU 使用率（百分比）。变化时联动通知 CpuUsageText（只读计算属性，
    /// 否则 XAML 绑定 {x:Bind CpuUsageText} 永远收不到更新通知，显示不刷新）。
    /// </summary>
    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(CpuUsageText))]
    private double _cpuUsagePercent;

    /// <summary>
    /// 内存使用率（百分比）。变化时联动通知 MemoryUsageTextFormatted（只读计算属性，
    /// 否则 XAML 绑定 {x:Bind MemoryUsageTextFormatted} 永远收不到更新通知，显示不刷新）。
    /// </summary>
    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(MemoryUsageTextFormatted))]
    private double _memoryUsagePercent;

    [ObservableProperty]
    private string _memoryUsageText = "0 MB / 0 MB";

    // ===== 格式化显示文本 =====
    public string CpuUsageText => $"{CpuUsagePercent:F0}%";
    public string MemoryUsageTextFormatted => $"{MemoryUsagePercent:F0}%";

    // ===== VPN 检测内部状态 =====
    /// <summary>最近一次 VPN 检测结果（OpenVPN 挂钩 / Ping 任一通过即为 true）</summary>
    private bool _lastVpnResult;
    /// <summary>降级 Ping 检测轮询间隔（秒）— 每 30s 更新一次内网可达状态</summary>
    private const int VpnCheckIntervalSeconds = 30;
    private int _vpnCheckTickCounter;
    private readonly object _vpnLock = new();
    /// <summary>检测是否进行中（防 Ping 慢速路径被定时器与 StateChanged 并发触发重入）</summary>
    private bool _detectInProgress;
    /// <summary>检测进行中又有新请求到达（合并请求：完成后立即再跑一次，避免状态刷新丢失）</summary>
    private bool _detectPending;

    // ===== 依赖服务（Initialize 时获取）=====
    private VpnConnectionService? _vpnService;

    // ===== 内部状态 =====
    private PerformanceCounter? _cpuCounter;
    private PerformanceCounter? _memCounter;
    private PerformanceCounter? _memTotalCounter;
    private long _prevBytesReceived;
    private long _prevBytesSent;
    private DateTime _prevNetTime;
    private Timer? _refreshTimer;
    private bool _disposed;
    private List<PerformanceCounter> _netRecvCounters = new();
    private List<PerformanceCounter> _netSentCounters = new();

    private long _memTotalBytes;
    private DispatcherQueue? _dispatcherQueue;
    private bool _isInitialized;

    /// <summary>
    /// 初始化状态栏（需在 UI 线程调用）— 捕获 DispatcherQueue 并将重量级计数器创建放到后台线程
    /// </summary>
    public void Initialize()
    {
        if (_isInitialized) return;
        _isInitialized = true;

        _dispatcherQueue = DispatcherQueue.GetForCurrentThread();

        // 获取依赖服务（OpenVPN 连接状态）
        _vpnService = App.Services.GetRequiredService<VpnConnectionService>();

        // 内网可达直接挂钩 OpenVPN 连接状态（全局共享，不区分当前实例）：
        // 连接成功 → 立即"内网可达"；断开/失败 → 立即"内网不可达"并降级 30s Ping 检测
        _vpnService.StateChanged += OnVpnStateChanged;

        // 主窗口关闭时自动释放资源
        if (MainWindow.Current is not null)
            MainWindow.Current.Closed += (_, _) => Dispose();

        // 将耗时的性能计数器初始化放到后台线程，避免阻塞 UI
        Task.Run(() =>
        {
            try
            {
                _cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
                _cpuCounter.NextValue(); // 首次调用返回 0，需要先采样一次

                // 内存信息
                _memCounter = new PerformanceCounter("Memory", "Available MBytes");
                _memTotalCounter = new PerformanceCounter("Memory", "Committed Bytes");
                _memTotalBytes = GetTotalPhysicalMemoryMB();

                // 网络计数器
                InitNetworkCounters();

                // 网络初始采样
                _prevBytesReceived = ReadTotalBytesReceived();
                _prevBytesSent = ReadTotalBytesSent();
                _prevNetTime = DateTime.UtcNow;

                // 启动定时器
                _refreshTimer = new Timer(OnRefresh, null, TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(1));
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[StatusBar] 性能计数器初始化失败: {ex.Message}");
            }
        });
    }

    /// <summary>
    /// 初始化网络计数器列表（保持存活以便 NextValue 返回有效差值）
    /// </summary>
    private void InitNetworkCounters()
    {
        try
        {
            var category = new PerformanceCounterCategory("Network Interface");
            var instances = category.GetInstanceNames();
            foreach (var inst in instances)
            {
                if (inst.Contains("Loopback") || inst.Contains("Teredo") || inst.Contains("6to4"))
                    continue;
                _netRecvCounters.Add(new PerformanceCounter("Network Interface", "Bytes Received/sec", inst));
                _netSentCounters.Add(new PerformanceCounter("Network Interface", "Bytes Sent/sec", inst));
            }
        }
        catch { }
    }

    private static long GetTotalPhysicalMemoryMB()
    {
        try
        {
            // 使用 Kernel32 GlobalMemoryStatusEx 获取总物理内存
            var memoryStatus = new MEMORYSTATUSEX();
            memoryStatus.dwLength = (uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(MEMORYSTATUSEX));
            if (GlobalMemoryStatusEx(ref memoryStatus))
            {
                return (long)(memoryStatus.ullTotalPhys / (1024 * 1024));
            }
        }
        catch { }
        return 16384; // 兜底：假设 16GB
    }

    [System.Runtime.InteropServices.DllImport("kernel32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto, SetLastError = true)]
    private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);

    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
    private struct MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
    }

    private void OnRefresh(object? state)
    {
        if (_disposed) return;
        try
        {
            // CPU
            if (_cpuCounter != null)
            {
                var cpuVal = _cpuCounter.NextValue();
                SafeSetOnUi(() => CpuUsagePercent = Math.Round(cpuVal, 1));
            }

            // 内存
            if (_memCounter != null && _memTotalBytes > 0)
            {
                var availMB = _memCounter.NextValue();
                var usedMB = _memTotalBytes - availMB;
                var percent = (usedMB / (double)_memTotalBytes) * 100.0;
                SafeSetOnUi(() =>
                {
                    MemoryUsagePercent = Math.Round(percent, 1);
                    MemoryUsageText = $"{usedMB:F0} MB / {_memTotalBytes} MB";
                });
            }

            // 网络速率 — 使用持久化计数器的 NextValue()，返回的就是 bytes/sec
            var now = DateTime.UtcNow;
            var elapsed = (now - _prevNetTime).TotalSeconds;
            if (elapsed >= 0.8)
            {
                double downBytesPerSec = 0, upBytesPerSec = 0;

                // 读取所有网卡计数器的瞬时速率并求和
                foreach (var c in _netRecvCounters) downBytesPerSec += c.NextValue();
                foreach (var c in _netSentCounters) upBytesPerSec += c.NextValue();

                _prevNetTime = now;

                var downBps = Math.Max(0, downBytesPerSec);
                var upBps = Math.Max(0, upBytesPerSec);

                SafeSetOnUi(() =>
                {
                    DownloadSpeed = downBps;
                    UploadSpeed = upBps;
                    DownloadSpeedText = FormatSpeed(downBps);
                    UploadSpeedText = FormatSpeed(upBps);
                });
            }

            // 内网可达检测 — 每 VpnCheckIntervalSeconds 秒执行一次（降级 Ping 方案 30s 更新一次）
            _vpnCheckTickCounter++;
            if (_vpnCheckTickCounter >= VpnCheckIntervalSeconds)
            {
                _vpnCheckTickCounter = 0;
                // OpenVPN 已连接时：状态由 StateChanged 事件驱动（0ms 挂钩，立即响应断开），
                // 无需 30s 定时器轮询（也不执行任何 Ping）；仅未连接时降级 Ping 检测
                if (_vpnService?.State != VpnConnectionState.Connected)
                {
                    _ = DetectVpnAndRefreshAsync();
                }
            }
        }
        catch
        {
            // 采样失败时静默处理
        }
    }

    /// <summary>
    /// 动态格式化速率：< 1 KB/s 显示 B/s，< 1 MB/s 显示 KB/s，否则 MB/s
    /// </summary>
    private static string FormatSpeed(double bytesPerSec)
    {
        if (bytesPerSec < 0) return "0 B/s";
        if (bytesPerSec < 1024)
            return $"{bytesPerSec:F0} B/s";
        if (bytesPerSec < 1024 * 1024)
            return $"{bytesPerSec / 1024:F1} KB/s";
        return $"{bytesPerSec / (1024 * 1024):F1} MB/s";
    }

    /// <summary>
    /// 读取所有网卡总接收字节数（仅用于初始采样）
    /// </summary>
    private long ReadTotalBytesReceived()
    {
        long total = 0;
        foreach (var c in _netRecvCounters)
            total += (long)c.NextValue();
        return total;
    }

    /// <summary>
    /// 读取所有网卡总发送字节数（仅用于初始采样）
    /// </summary>
    private long ReadTotalBytesSent()
    {
        long total = 0;
        foreach (var c in _netSentCounters)
            total += (long)c.NextValue();
        return total;
    }

    // ================================================================
    //  内网可达检测（OpenVPN 挂钩 + Ping 降级）
    // ================================================================

    /// <summary>
    /// 立即执行一次 VPN 检测并刷新状态。
    /// 进入先导页面时调用，不等待定时器。
    /// </summary>
    public void TriggerImmediateVpnCheck()
    {
        _ = DetectVpnAndRefreshAsync();
    }

    /// <summary>
    /// OpenVPN 连接状态变化回调（后台线程触发，全局共享状态不区分实例）。
    /// - 连接成功（Connected）→ 立即检测（挂钩 OpenVPN 状态 → 内网可达）
    /// - 断开 / 失败 → 立即"内网不可达"，并立即触发一次降级 Ping 检测
    ///   （不等 30s 定时器，让内网状态尽快恢复）
    /// </summary>
    private void OnVpnStateChanged(VpnConnectionState state)
    {
        if (_disposed) return;

        if (state == VpnConnectionState.Connected)
        {
            // OpenVPN 连接成功 → 立即刷新为内网可达
            _ = DetectVpnAndRefreshAsync();
        }
        else
        {
            // OpenVPN 断开 / 失败 → 立即"内网不可达"
            lock (_vpnLock)
            {
                _lastVpnResult = false;
            }
            RefreshVpnStatus();

            // 立马触发一次降级方案检测（State 非 Connected → 走 Ping 10.10.10.3 分支，
            // 防重入由 _detectInProgress/_detectPending 合并机制保证）
            _ = DetectVpnAndRefreshAsync();
        }
    }

    /// <summary>
    /// 内网可达检测入口（全局共享，不依赖当前实例，切换实例不会导致状态跳变）：
    /// OpenVPN 已连接 → 直接挂钩连接状态（0ms，无网络请求）；
    /// 否则降级：Ping 网关 10.10.10.3（每 30s 定时器驱动一次）。
    /// </summary>
    private async Task DetectVpnAndRefreshAsync()
    {
        // 防重入：进行中则标记待处理，完成后立即再跑一次（避免状态刷新丢失——
        // 典型场景：OpenVPN 正在连接时走 Ping 降级路径（2s），连接成功的 StateChanged
        // 到达被拦截，若直接丢弃会导致状态栏延迟最多 30s 才显示"内网可达"）
        if (_detectInProgress)
        {
            _detectPending = true;
            return;
        }
        _detectInProgress = true;
        try
        {
            do
            {
                _detectPending = false;

                bool connected;

                // ---- 主路径：OpenVPN 已连接 → 内网可达（全局挂钩） ----
                if (_vpnService?.State == VpnConnectionState.Connected)
                {
                    connected = true;
                }
                else
                {
                    // ---- 降级路径（OpenVPN 未连接 / 断开 / 失败）：仅 Ping 网关 ----
                    connected = await PingGatewaysAsync();
                }

                lock (_vpnLock)
                {
                    _lastVpnResult = connected;
                }
                RefreshVpnStatus();
            }
            while (_detectPending);   // 期间有新请求 → 立即再检测一次
        }
        finally
        {
            _detectInProgress = false;
        }
    }

    /// <summary>
    /// 刷新 VPN 状态文字和图标颜色。
    /// </summary>
    private void RefreshVpnStatus()
    {
        bool connected;
        lock (_vpnLock)
        {
            connected = _lastVpnResult;
        }

        SafeSetOnUi(() =>
        {
            IsVpnConnected = connected;
            VpnStatusText = connected ? "内网可达" : "内网不可达";
        });
    }

    /// <summary>
    /// 异步 ping 所有网关，任一通即返回 true。
    /// </summary>
    private static async Task<bool> PingGatewaysAsync()
    {
        foreach (var gw in VpnGateways)
        {
            if (await PingHostAsync(gw))
                return true;
        }
        return false;
    }

    /// <summary>
    /// 异步 ping 指定 IP，超时 2 秒。
    /// </summary>
    private static async Task<bool> PingHostAsync(string ipAddress)
    {
        try
        {
            using var ping = new Ping();
            var reply = await ping.SendPingAsync(ipAddress, 2000);
            return reply.Status == IPStatus.Success;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// 安全地在 UI 线程上设置属性，捕获因窗口关闭导致的 COMException。
    /// </summary>
    private void SafeSetOnUi(Action action)
    {
        if (_disposed) return;
        _ = _dispatcherQueue?.TryEnqueue(() =>
        {
            if (_disposed) return;
            try
            {
                action();
            }
            catch (COMException ex) when ((uint)ex.HResult == 0x8000FFFF)
            {
                // 窗口已关闭，UI 元素已销毁，静默忽略
            }
            catch (ObjectDisposedException)
            {
                // UI 元素已被释放，静默忽略
            }
        });
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        // 取消 OpenVPN 状态订阅（防泄漏）
        if (_vpnService != null)
            _vpnService.StateChanged -= OnVpnStateChanged;

        // 停止定时器（WaitForPendingTimers = true 确保无待执行回调）
        using var waitHandle = new ManualResetEvent(false);
        _refreshTimer?.Dispose(waitHandle);
        waitHandle.WaitOne(TimeSpan.FromSeconds(1));
        _refreshTimer = null;

        // 释放性能计数器和相关资源
        try { _cpuCounter?.Dispose(); } catch { }
        try { _memCounter?.Dispose(); } catch { }
        try { _memTotalCounter?.Dispose(); } catch { }

        if (_netRecvCounters != null)
        {
            foreach (var c in _netRecvCounters) try { c?.Dispose(); } catch { }
            _netRecvCounters.Clear();
        }

        if (_netSentCounters != null)
        {
            foreach (var c in _netSentCounters) try { c?.Dispose(); } catch { }
            _netSentCounters.Clear();
        }

        // 断开 DispatcherQueue 引用，防止再次 TryEnqueue
        _dispatcherQueue = null;
    }
}