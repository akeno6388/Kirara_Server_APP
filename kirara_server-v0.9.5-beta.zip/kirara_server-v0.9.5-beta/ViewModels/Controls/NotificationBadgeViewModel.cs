using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;

namespace Kirara_Server_WinUI.ViewModels.Controls;

/// <summary>
/// 右下通知缩略角标 ViewModel
/// </summary>
public partial class NotificationBadgeViewModel : ObservableObject
{
    [ObservableProperty]
    private ObservableCollection<NotificationItem> _notifications = new();

    [ObservableProperty]
    private bool _isExpanded;

    [ObservableProperty]
    private int _unreadCount;

    [RelayCommand]
    private void ToggleExpand()
    {
        IsExpanded = !IsExpanded;
    }

    [RelayCommand]
    private void ClearAll()
    {
        Notifications.Clear();
        UnreadCount = 0;
    }

    public void AddNotification(string title, string message)
    {
        Notifications.Add(new NotificationItem
        {
            Title = title,
            Message = message,
            Timestamp = DateTime.Now
        });
        UnreadCount = Notifications.Count;
    }
}

/// <summary>
/// 通知项
/// </summary>
public class NotificationItem
{
    public string Title { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public DateTime Timestamp { get; set; }
}
