using CommunityToolkit.Mvvm.ComponentModel;
using Microsoft.UI.Xaml.Media.Imaging;

namespace Kirara_Server_WinUI.ViewModels.Controls;

/// <summary>
/// 单张信息流卡片的 ViewModel — 封装标题/摘要/媒体路径/类型，
/// 供 FlipView DataTemplate 绑定。
///
/// ## 媒体类型与渲染方式
/// - image: FlipView 内 Image 原生渲染
/// - video: 共享 MediaPlayerElement 覆盖在 FlipView 上方循环静音播放
/// - html:  共享 WebView2 覆盖渲染
/// </summary>
public partial class InfoCardViewModel : ObservableObject
{
    [ObservableProperty]
    private string _title = string.Empty;

    [ObservableProperty]
    private string _summary = string.Empty;

    [ObservableProperty]
    private string _time = string.Empty;

    /// <summary>原始卡片的 Guid Id，供下载回写匹配</summary>
    public Guid CardId { get; set; }

    /// <summary>媒体类型："image", "video", "html"</summary>
    [ObservableProperty]
    private string _mediaType = "image";

    /// <summary>本地缓存的缩略图/封面（供 FlipView Image 绑定）</summary>
    [ObservableProperty]
    private BitmapImage? _imageSource;

    /// <summary>本地缓存的视频文件绝对路径（供 MediaPlayerElement 播放）</summary>
    [ObservableProperty]
    private string? _videoPath;

    /// <summary>HTML 卡片的原始 HTML 内容</summary>
    [ObservableProperty]
    private string? _htmlContent;

    /// <summary>HTML 卡片的外部链接</summary>
    [ObservableProperty]
    private string? _externalUrl;

    // ===== 预计算布尔值（供 XAML x:Bind Visibility 使用） =====

    public bool IsVideo => MediaType == "video";
    public bool IsImage => MediaType != "video" && MediaType != "html";
    public bool IsHtml => MediaType == "html";

    partial void OnMediaTypeChanged(string value)
    {
        OnPropertyChanged(nameof(IsVideo));
        OnPropertyChanged(nameof(IsImage));
        OnPropertyChanged(nameof(IsHtml));
    }
}
