using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.Views.Instance;
using System.Collections.ObjectModel;

namespace Kirara_Server_WinUI.ViewModels.Controls;

/// <summary>
/// 方案标签栏 ViewModel — 管理 InstanceWorkspace 上方的方案标签页。
/// 选中状态由 View 层 ListView.SelectedItem 双向绑定驱动，
/// ViewModel 不做 UI 高亮同步，仅暴露 TabSelectionChanged 事件供外部订阅业务响应。
/// </summary>
public partial class SchemeTabBarViewModel : ObservableObject
{
    private readonly ISchemeService _schemeService;
    private readonly IInstanceService _instanceService;

    /// <summary>当前加载的实例 ID（用于拖拽排序后写回数据库持久化）</summary>
    private Guid _currentInstanceId;

    [ObservableProperty]
    private ObservableCollection<SchemeTabItemViewModel> _tabs = new();

    [ObservableProperty]
    private SchemeTabItemViewModel? _selectedTab;

    /// <summary>
    /// 标签选中变更时触发（供 InstanceWorkspace 订阅以切换方案内容）
    /// </summary>
    public event Action<SchemeTabItemViewModel>? TabSelectionChanged;

    /// <summary>
    /// 标签软重载（F5 刷新）请求时触发 — 供 InstanceWorkspace 订阅
    /// </summary>
    public event Action<SchemeTabItemViewModel>? TabSoftReloadRequested;

    /// <summary>
    /// 标签硬重载（Ctrl+Shift+R）请求时触发 — 供 InstanceWorkspace 订阅
    /// </summary>
    public event Action<SchemeTabItemViewModel>? TabHardReloadRequested;

    /// <summary>
    /// 标签重链接令牌请求时触发 — 供 InstanceWorkspace 订阅
    /// </summary>
    public event Action<SchemeTabItemViewModel>? TabTokenRelinkRequested;

    /// <summary>
    /// 标签后退（WebView2 导航历史）请求时触发 — 供 InstanceWorkspace 订阅
    /// </summary>
    public event Action<SchemeTabItemViewModel>? TabGoBackRequested;

    /// <summary>
    /// 标签前进（WebView2 导航历史）请求时触发 — 供 InstanceWorkspace 订阅
    /// </summary>
    public event Action<SchemeTabItemViewModel>? TabGoForwardRequested;

    public SchemeTabBarViewModel(
        ISchemeService schemeService,
        IInstanceService instanceService)
    {
        _schemeService = schemeService;
        _instanceService = instanceService;
        SchemeIconCacheService.SchemeIconsRefreshed += OnSchemeIconsRefreshed;
    }

    /// <summary>
    /// 方案图标缓存刷新后，更新所有标签的 CoverImageUrl。
    /// SchemeTabItemViewModel.CoverImageUrl 是 [ObservableProperty]，
    /// 设置后自动通知 UI 更新图标显示。
    /// </summary>
    private void OnSchemeIconsRefreshed()
    {
        var iconCache = App.Services.GetRequiredService<SchemeIconCacheService>();
        foreach (var tab in Tabs)
        {
            var scheme = _schemeService.GetScheme(tab.SchemeId);
            if (scheme != null)
                tab.CoverImageUrl = iconCache.GetCachedIconUrl(scheme.Name);
        }
    }

    /// <summary>
    /// 加载实例的方案绑定列表到标签栏
    /// </summary>
    /// <param name="instanceId">所属实例 ID（拖拽排序后持久化用）</param>
    /// <param name="bindings">方案绑定列表（按 Order 排序）</param>
    public void LoadTabs(Guid instanceId, IEnumerable<SchemeBinding> bindings)
    {
        _currentInstanceId = instanceId;
        SchemeIconCacheService? iconCache = null;
        try { iconCache = App.Services.GetRequiredService<SchemeIconCacheService>(); }
        catch { /* 容器未就绪时跳过 */ }

        Tabs.Clear();
        foreach (var binding in bindings.OrderBy(b => b.Order))
        {
            var scheme = _schemeService.GetScheme(binding.SchemeId);

            // 优先从 IScheme 实例获取 UIKind（代码中 override 的值），
            // 回退到数据库中的 Scheme.UIKind，最后默认 WebView2
            var schemeInstance = scheme != null ? _schemeService.LoadSchemeInstance(scheme) : null;
            var uiKind = schemeInstance?.UIKind ?? scheme?.UIKind ?? SchemeUIKind.WebView2;

            var tab = new SchemeTabItemViewModel
            {
                SchemeId = binding.SchemeId,
                BindingId = binding.Id,
                TokenId = binding.TokenId,
                DisplayName = scheme?.DisplayName ?? scheme?.Name ?? "未知方案",
                IconGlyph = schemeInstance?.IconGlyph ?? scheme?.IconGlyph ?? "\uE7C3",
                CoverImageUrl = scheme != null && iconCache != null
                    ? iconCache.GetCachedIconUrl(scheme.Name)
                    : null,
                IsEnabled = binding.IsEnabled,
                Order = binding.Order,
                UiKind = uiKind,
                // 服务版 OpenVPN 使用本地凭据自动登录，不支持重链接令牌 → 菜单隐藏该选项
                SupportsRelinkToken = schemeInstance is not Schemes.Service.OpenVpnServiceScheme,
            };
            tab.SetSoftReloadAction(OnTabSoftReloadRequested);
            tab.SetHardReloadAction(OnTabHardReloadRequested);
            tab.SetRelinkTokenAction(OnTabTokenRelinkRequested);
            tab.SetGoBackAction(OnTabGoBackRequested);
            tab.SetGoForwardAction(OnTabGoForwardRequested);
            Tabs.Add(tab);
        }

        if (Tabs.Count > 0)
        {
            SelectedTab = Tabs[0];
            Tabs[0].IsSelected = true;
        }
    }

    private void OnTabSoftReloadRequested(SchemeTabItemViewModel tab)
    {
        TabSoftReloadRequested?.Invoke(tab);
    }

    private void OnTabHardReloadRequested(SchemeTabItemViewModel tab)
    {
        TabHardReloadRequested?.Invoke(tab);
    }

    private void OnTabTokenRelinkRequested(SchemeTabItemViewModel tab)
    {
        TabTokenRelinkRequested?.Invoke(tab);
    }

    private void OnTabGoBackRequested(SchemeTabItemViewModel tab)
    {
        TabGoBackRequested?.Invoke(tab);
    }

    private void OnTabGoForwardRequested(SchemeTabItemViewModel tab)
    {
        TabGoForwardRequested?.Invoke(tab);
    }

    /// <summary>
    /// 查询标签对应页面能否后退（WebView2 导航历史中存在上一页）。
    /// 页面未创建 / 未初始化 / 非 WebView2 时返回 false（菜单按钮置灰）。
    /// </summary>
    public bool CanNavigateBack(SchemeTabItemViewModel tab)
    {
        if (tab == null || _currentInstanceId == Guid.Empty) return false;
        try
        {
            var pageCache = App.Services.GetRequiredService<ISchemePageCache>();
            return pageCache.GetInstancePages(_currentInstanceId)
                .TryGetValue(tab.SchemeId, out var page) && page.CanGoBack;
        }
        catch { return false; }
    }

    /// <summary>
    /// 查询标签对应页面能否前进（WebView2 导航历史中存在下一页）。
    /// 页面未创建 / 未初始化 / 非 WebView2 时返回 false（菜单按钮置灰）。
    /// </summary>
    public bool CanNavigateForward(SchemeTabItemViewModel tab)
    {
        if (tab == null || _currentInstanceId == Guid.Empty) return false;
        try
        {
            var pageCache = App.Services.GetRequiredService<ISchemePageCache>();
            return pageCache.GetInstancePages(_currentInstanceId)
                .TryGetValue(tab.SchemeId, out var page) && page.CanGoForward;
        }
        catch { return false; }
    }

    /// <summary>
    /// 选中指定标签 — View 层 ListView.SelectedItem 双向绑定自动同步 UI 高亮，
    /// ViewModel 仅负责更新内部状态并通过事件通知外部。
    /// </summary>
    [RelayCommand]
    private void SelectTab(SchemeTabItemViewModel? tab)
    {
        if (tab != null && tab != SelectedTab)
        {
            // 维护每个标签的 IsSelected 状态（驱动模板选中高亮）
            if (SelectedTab != null) SelectedTab.IsSelected = false;
            SelectedTab = tab;
            tab.IsSelected = true;
            TabSelectionChanged?.Invoke(tab);
        }
    }

    /// <summary>
    /// 拖拽排序完成后：更新内存顺序，并**持久化到 LiteDB**。
    /// 切出实例再切回 / 关闭软件重启后，标签顺序保持不变；
    /// 仅重新初始化实例（重建 SchemeBindings）才会还原为默认顺序。
    /// </summary>
    public void SyncTabOrder()
    {
        for (int i = 0; i < Tabs.Count; i++)
        {
            Tabs[i].Order = i;
        }

        // 确保选中项未丢失
        if (SelectedTab == null && Tabs.Count > 0)
        {
            SelectedTab = Tabs[0];
            Tabs[0].IsSelected = true;
        }

        // ── 持久化：按新顺序更新实例的 SchemeBindings[].Order 并写回数据库 ──
        if (_currentInstanceId == Guid.Empty) return;

        var instance = _instanceService.GetInstance(_currentInstanceId);
        if (instance == null) return;

        bool changed = false;
        for (int i = 0; i < Tabs.Count; i++)
        {
            var binding = instance.SchemeBindings
                .FirstOrDefault(b => b.Id == Tabs[i].BindingId);
            if (binding != null && binding.Order != i)
            {
                binding.Order = i;
                changed = true;
            }
        }

        if (changed)
        {
            instance.UpdatedAt = DateTime.UtcNow;
            _instanceService.UpdateInstance(instance);
            System.Diagnostics.Debug.WriteLine(
                $"[SchemeTabBar] 标签顺序已持久化: {string.Join(" > ", Tabs.Select(t => t.DisplayName))}");
        }
    }

    /// <summary>
    /// 清除所有标签
    /// </summary>
    public void Clear()
    {
        Tabs.Clear();
        SelectedTab = null;
        _currentInstanceId = Guid.Empty;
    }
}

/// <summary>
/// 方案标签项 ViewModel — 表示标签栏中的单个方案标签
/// </summary>
public partial class SchemeTabItemViewModel : ObservableObject
{
    private Action<SchemeTabItemViewModel>? _softReloadAction;
    private Action<SchemeTabItemViewModel>? _hardReloadAction;
    private Action<SchemeTabItemViewModel>? _relinkTokenAction;
    private Action<SchemeTabItemViewModel>? _goBackAction;
    private Action<SchemeTabItemViewModel>? _goForwardAction;

    /// <summary>是否选中（驱动模板标签背景高亮；由 ViewModel.SelectTab 维护）</summary>
    [ObservableProperty]
    private bool _isSelected;

    /// <summary>方案 ID</summary>
    [ObservableProperty]
    private Guid _schemeId;

    /// <summary>方案绑定 ID</summary>
    [ObservableProperty]
    private Guid _bindingId;

    /// <summary>绑定的令牌 ID（可为 null）</summary>
    [ObservableProperty]
    private Guid? _tokenId;

    /// <summary>是否已绑定令牌（用于菜单条件显示）</summary>
    public bool HasTokenBinding => TokenId.HasValue;

    /// <summary>TokenId 变更时同步通知 HasTokenBinding</summary>
    partial void OnTokenIdChanged(Guid? value) => OnPropertyChanged(nameof(HasTokenBinding));

    /// <summary>显示名称</summary>
    [ObservableProperty]
    private string _displayName = string.Empty;

    /// <summary>图标字符（Segoe Fluent Icons）</summary>
    [ObservableProperty]
    private string _iconGlyph = "\uE7C3";

    /// <summary>封面图标本地缓存路径（由 SchemeIconCacheService 填充）</summary>
    [ObservableProperty]
    private string? _coverImageUrl;

    /// <summary>是否启用</summary>
    [ObservableProperty]
    private bool _isEnabled = true;

    /// <summary>排序位置（拖拽后更新）</summary>
    [ObservableProperty]
    private int _order;

    /// <summary>方案 UI 类型（用于判断刷新/重载行为）</summary>
    private SchemeUIKind _uIKind = SchemeUIKind.WebView2;

    public SchemeUIKind UiKind
    {
        get => _uIKind;
        set => SetProperty(ref _uIKind, value);
    }

    /// <summary>是否为 WebView2 方案（用于飞入菜单条件显示）</summary>
    public bool IsWebView2 => _uIKind == SchemeUIKind.WebView2;

    /// <summary>
    /// 是否支持"重链接令牌"功能（用于飞入菜单条件显示）。
    /// 默认 true；服务版 OpenVPN 等使用本地凭据、不支持重链接令牌的方案置 false。
    /// </summary>
    public bool SupportsRelinkToken { get; set; } = true;

    /// <summary>软重载命令（F5 刷新）</summary>
    [RelayCommand]
    private void SoftReload()
    {
        _softReloadAction?.Invoke(this);
    }

    /// <summary>硬重载命令（Ctrl+Shift+R）</summary>
    [RelayCommand]
    private void HardReload()
    {
        _hardReloadAction?.Invoke(this);
    }

    /// <summary>重链接令牌命令</summary>
    [RelayCommand]
    private void RelinkToken()
    {
        _relinkTokenAction?.Invoke(this);
    }

    /// <summary>后退命令（WebView2 导航历史）</summary>
    [RelayCommand]
    private void GoBack()
    {
        _goBackAction?.Invoke(this);
    }

    /// <summary>前进命令（WebView2 导航历史）</summary>
    [RelayCommand]
    private void GoForward()
    {
        _goForwardAction?.Invoke(this);
    }

    internal void SetSoftReloadAction(Action<SchemeTabItemViewModel>? action)
    {
        _softReloadAction = action;
    }

    internal void SetHardReloadAction(Action<SchemeTabItemViewModel>? action)
    {
        _hardReloadAction = action;
    }

    internal void SetRelinkTokenAction(Action<SchemeTabItemViewModel>? action)
    {
        _relinkTokenAction = action;
    }

    internal void SetGoBackAction(Action<SchemeTabItemViewModel>? action)
    {
        _goBackAction = action;
    }

    internal void SetGoForwardAction(Action<SchemeTabItemViewModel>? action)
    {
        _goForwardAction = action;
    }
}
