using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.ViewModels.Pages;

/// <summary>
/// 登录页面 ViewModel — 管理用户登录/注册
/// 登录表单和注册表单使用完全独立的字段，切换时丢弃另一方的输入
/// </summary>
public partial class LoginPageViewModel : ObservableObject
{
    private readonly ILoginService _loginService;
    private readonly INavigationService _navigationService;

    private static readonly HashSet<char> ForbiddenChars = new(@"#\/*:?""<>| ");

    /// <summary>注册用户名格式是否通过校验（用于 CanRegister）</summary>
    private bool _isRegUsernameFormatValid;

    // ================================================================
    //  标题
    // ================================================================

    public string ModeTitle => IsRegisterMode ? "注册 KIRARA 通行证" : "欢迎使用 Kirara Server";

    // ================================================================
    //  登录表单字段（独立于注册字段）
    // ================================================================

    [ObservableProperty]
    private string _loginUsername = string.Empty;

    [ObservableProperty]
    private string _loginPassword = string.Empty;

    // ================================================================
    //  注册表单字段（独立于登录字段）
    // ================================================================

    [ObservableProperty]
    private string _regUsername = string.Empty;

    [ObservableProperty]
    private string _regPassword = string.Empty;

    [ObservableProperty]
    private string _regConfirmPassword = string.Empty;

    // ================================================================
    //  UI 状态
    // ================================================================

    [ObservableProperty]
    private bool _isRegisterMode;

    [ObservableProperty]
    private string _errorMessage = string.Empty;

    /// <summary>
    /// 提示框文字/边框色 — 成功消息返回主题绿，错误消息返回红色
    /// </summary>
    public string ErrorMessageBrush
    {
        get
        {
            if (string.IsNullOrEmpty(ErrorMessage))
                return "Transparent";
            if (ErrorMessage.Contains("成功"))
                return "#2ECC71";
            return "#E74856";
        }
    }

    /// <summary>提示框边框色（与文字色一致）</summary>
    public string ErrorMessageBorderBrush => ErrorMessageBrush;

    partial void OnErrorMessageChanged(string value)
    {
        OnPropertyChanged(nameof(ErrorMessageBrush));
        OnPropertyChanged(nameof(ErrorMessageBorderBrush));
    }

    [ObservableProperty]
    private bool _isBusy;

    /// <summary>是否启用自动登录</summary>
    [ObservableProperty]
    private bool _autoLoginEnabled;

    /// <summary>是否显示自动登录复选框（仅登录模式显示）</summary>
    public bool IsAutoLoginVisible => !IsRegisterMode;

    /// <summary>是否抑制自动登录（退出登录后导航到登录页时设置）</summary>
    public bool SuppressAutoLogin { get; set; }

    /// <summary>忙状态开始时间（用于确保最低显示时长）</summary>
    private DateTime _busyStartTime;

    /// <summary>最低忙状态遮罩显示时间（毫秒）</summary>
    private const int MinBusyOverlayMs = 1000;

    /// <summary>
    /// 确保忙状态遮罩至少显示 MinBusyOverlayMs 毫秒
    /// </summary>
    private async Task EnsureMinimumBusyTimeAsync()
    {
        var elapsed = (DateTime.UtcNow - _busyStartTime).TotalMilliseconds;
        var remaining = MinBusyOverlayMs - elapsed;
        if (remaining > 0)
            await Task.Delay((int)remaining);
    }

    /// <summary>是否启用输入框（登录/注册操作中禁用）</summary>
    public bool IsInputEnabled => !IsBusy;

    /// <summary>登录按钮是否可用</summary>
    public bool CanLogin => !IsBusy && !string.IsNullOrWhiteSpace(LoginUsername) && !string.IsNullOrEmpty(LoginPassword);

    /// <summary>注册按钮是否可用</summary>
    public bool CanRegister => !IsBusy
        && !string.IsNullOrWhiteSpace(RegUsername)
        && _isRegUsernameFormatValid
        && !string.IsNullOrEmpty(RegPassword)
        && PasswordStrengthScore >= 2
        && !string.IsNullOrEmpty(RegConfirmPassword)
        && RegPassword == RegConfirmPassword;

    // ================================================================
    //  用户名实时校验提示
    // ================================================================
    public string UsernameHint { get; private set; } = string.Empty;
    public string UsernameHintColor { get; private set; } = "#E74856";

    // ================================================================
    //  密码强度
    // ================================================================
    public int PasswordStrengthScore { get; private set; }
    public double PasswordStrengthRatio { get; private set; }
    [ObservableProperty]
    private double _passwordStrengthWidth;

    public string PasswordStrengthText => PasswordStrengthScore switch
    {
        0 => string.IsNullOrEmpty(RegPassword) ? string.Empty : "密码太弱：至少6个字符",
        1 => "密码强度：弱（建议混合大小写字母、数字和符号）",
        2 => "密码强度：中等",
        3 => "密码强度：强",
        _ => string.Empty
    };

    public string PasswordStrengthColor => PasswordStrengthScore switch
    {
        0 => "#E74856",
        1 => "#E74856",
        2 => "#FF9800",
        3 => "#4CAF50",
        _ => "#E74856"
    };

    public bool PasswordsMatch => string.IsNullOrEmpty(RegConfirmPassword) || RegPassword == RegConfirmPassword;
    public string PasswordMismatchHint => PasswordsMatch ? string.Empty : "两次输入的密码不一致";

    // ================================================================
    //  变更通知链
    // ================================================================

    partial void OnIsRegisterModeChanged(bool value)
    {
        OnPropertyChanged(nameof(ModeTitle));
        ErrorMessage = string.Empty;
        RefreshCanExecute();
    }

    /// <summary>
    /// 在表单切换动画中（旧面板淡出后、新面板淡入前）由 LoginPage 调用，
    /// 清理旧表单的校验状态和字段数据，确保新表单以干净状态入场。
    /// </summary>
    public void CompleteFormSwitch()
    {
        ResetFormFields(IsRegisterMode);
    }

    private void ResetFormFields(bool toRegister)
    {
        if (toRegister)
        {
            // 切换到注册：丢弃登录字段
            LoginUsername = string.Empty;
            LoginPassword = string.Empty;
            // 重置注册校验
            OnRegUsernameChanged(RegUsername);
            OnRegPasswordChanged(RegPassword);
        }
        else
        {
            // 切换回登录：丢弃注册字段
            RegUsername = string.Empty;
            RegPassword = string.Empty;
            RegConfirmPassword = string.Empty;
            UsernameHint = string.Empty;
            OnPropertyChanged(nameof(UsernameHint));
            OnPropertyChanged(nameof(UsernameHintColor));
            PasswordStrengthScore = 0;
            PasswordStrengthWidth = 0;
            OnPropertyChanged(nameof(PasswordStrengthScore));
            OnPropertyChanged(nameof(PasswordStrengthText));
            OnPropertyChanged(nameof(PasswordStrengthColor));
            OnPropertyChanged(nameof(PasswordStrengthWidth));
        }
    }

    partial void OnLoginUsernameChanged(string value) => RefreshCanExecute();
    partial void OnLoginPasswordChanged(string value)
    {
        RefreshCanExecute();
    }

    partial void OnRegUsernameChanged(string value)
    {
        ValidateRegUsername(value);
        RefreshCanExecute();
    }

    partial void OnRegPasswordChanged(string value)
    {
        EvaluatePasswordStrength(value);
        RefreshCanExecute();
        OnPropertyChanged(nameof(PasswordsMatch));
        OnPropertyChanged(nameof(PasswordMismatchHint));
    }

    partial void OnRegConfirmPasswordChanged(string value)
    {
        RefreshCanExecute();
        OnPropertyChanged(nameof(PasswordsMatch));
        OnPropertyChanged(nameof(PasswordMismatchHint));
    }

    partial void OnIsBusyChanged(bool value)
    {
        OnPropertyChanged(nameof(IsInputEnabled));
        RefreshCanExecute();
    }

    private void RefreshCanExecute()
    {
        OnPropertyChanged(nameof(CanLogin));
        OnPropertyChanged(nameof(CanRegister));
    }

    // ================================================================
    //  注册用户名实时校验
    // ================================================================
    private void ValidateRegUsername(string username)
    {
        if (string.IsNullOrWhiteSpace(username))
        {
            UsernameHint = string.Empty;
            _isRegUsernameFormatValid = false;
            OnPropertyChanged(nameof(UsernameHint));
            return;
        }

        var trimmed = username.Trim();

        if (trimmed.Any(c => ForbiddenChars.Contains(c)))
        {
            UsernameHint = "用户名包含非法字符（空格或特殊符号 # \\ / : * ? \" < > |）";
            _isRegUsernameFormatValid = false;
            goto notify;
        }

        if (trimmed.Length < 3)
        {
            UsernameHint = "用户名至少需要 3 个字符";
            _isRegUsernameFormatValid = false;
            goto notify;
        }

        if (trimmed.Length > 20)
        {
            UsernameHint = "用户名不能超过 20 个字符";
            _isRegUsernameFormatValid = false;
            goto notify;
        }

        // 格式校验通过 — 不留提示文字
        UsernameHint = string.Empty;
        _isRegUsernameFormatValid = true;

    notify:
        OnPropertyChanged(nameof(UsernameHint));
    }

    // ================================================================
    //  密码强度评估
    // ================================================================
    private void EvaluatePasswordStrength(string password)
    {
        if (string.IsNullOrEmpty(password))
        {
            PasswordStrengthScore = 0;
            PasswordStrengthRatio = 0;
            PasswordStrengthWidth = 0;
            goto notify;
        }

        if (password.Length < 6)
        {
            PasswordStrengthScore = 0;
            PasswordStrengthRatio = 0;
            PasswordStrengthWidth = 0;
            goto notify;
        }

        bool hasLower = password.Any(char.IsLower);
        bool hasUpper = password.Any(char.IsUpper);
        bool hasDigit = password.Any(char.IsDigit);
        bool hasSpecial = password.Any(c => !char.IsLetterOrDigit(c));
        int length = password.Length;

        bool isSingleType = (hasLower || hasUpper) && !hasDigit && !hasSpecial;
        bool isAllDigits = hasDigit && !hasLower && !hasUpper && !hasSpecial;
        bool isAllSameChar = password.Distinct().Count() == 1;

        bool hasRepeatingPattern = false;
        for (int len = 2; len <= password.Length / 2; len++)
        {
            if (password.Length % len != 0) continue;
            var pattern = password[..len];
            bool matches = true;
            for (int i = len; i < password.Length; i += len)
            {
                if (password.Substring(i, len) != pattern) { matches = false; break; }
            }
            if (matches) { hasRepeatingPattern = true; break; }
        }

        bool hasSequential = false;
        for (int i = 0; i < password.Length - 2; i++)
        {
            if ((password[i] + 1 == password[i + 1] && password[i + 1] + 1 == password[i + 2]) ||
                (password[i] - 1 == password[i + 1] && password[i + 1] - 1 == password[i + 2]))
            { hasSequential = true; break; }
        }

        if (isAllSameChar || isAllDigits || isSingleType)
        {
            PasswordStrengthScore = 1;
            PasswordStrengthRatio = 0.25;
            PasswordStrengthWidth = 100;
            goto notify;
        }

        int score = 0;
        if (length >= 8) score++;
        if (length >= 12) score++;
        if (length >= 16) score++;
        if (hasLower) score++;
        if (hasUpper) score++;
        if (hasDigit) score++;
        if (hasSpecial) score++;
        if (hasRepeatingPattern) score -= 2;
        if (hasSequential) score--;
        score = Math.Max(1, score);

        PasswordStrengthScore = score switch
        {
            <= 2 => 1,
            3 or 4 => 2,
            _ => 3
        };
        PasswordStrengthRatio = PasswordStrengthScore switch { 1 => 0.25, 2 => 0.55, 3 => 0.85, _ => 0 };
        PasswordStrengthWidth = PasswordStrengthScore switch { 1 => 100, 2 => 200, 3 => 370, _ => 0 };

    notify:
        OnPropertyChanged(nameof(PasswordStrengthScore));
        OnPropertyChanged(nameof(PasswordStrengthRatio));
        OnPropertyChanged(nameof(PasswordStrengthWidth));
        OnPropertyChanged(nameof(PasswordStrengthText));
        OnPropertyChanged(nameof(PasswordStrengthColor));
    }

    // ================================================================
    //  构造函数
    // ================================================================

    public LoginPageViewModel(ILoginService loginService, INavigationService navigationService)
    {
        _loginService = loginService;
        _navigationService = navigationService;

        // 检查是否启用了自动登录
        AutoLoginEnabled = _loginService.AutoLoginEnabled;

        // 退出登录后预填上次登录的用户名
        if (!string.IsNullOrEmpty(_loginService.LastLoginUsername))
            LoginUsername = _loginService.LastLoginUsername;
    }

    /// <summary>
    /// 自动登录入口 — 由 LoginPage 在加载完成后调用
    /// </summary>
    public async Task BeginAutoLoginAsync()
    {
        if (!AutoLoginEnabled || SuppressAutoLogin) return;

        // 记录开始时间并显示遮罩
        _busyStartTime = DateTime.UtcNow;
        IsBusy = true;

        try
        {
            var success = await _loginService.TryAutoLoginAsync();
            await EnsureMinimumBusyTimeAsync();

            if (!success)
            {
                // 先收起遮罩，再显示错误（避免错误框在半透明遮罩下提前透出）
                IsBusy = false;
                ErrorMessage = "自动登录失败，请手动登录";
            }
            else
            {
                // 自动登录成功，确保最低显示时长后关闭遮罩，触发 ShellPage 动画
                await EnsureMinimumBusyTimeAsync();
                IsBusy = false;
            }
        }
        catch (Exception ex)
        {
            // 先收起遮罩，再显示错误
            IsBusy = false;
            ErrorMessage = $"自动登录出错: {ex.Message}";
            System.Diagnostics.Debug.WriteLine($"[LoginPageVM] 自动登录异常: {ex}");
        }
    }

    // ================================================================
    //  命令
    // ================================================================

    [RelayCommand]
    private void SwitchToRegister()
    {
        IsRegisterMode = true;
    }

    [RelayCommand]
    private void SwitchToLogin()
    {
        IsRegisterMode = false;
    }

    [RelayCommand]
    private async Task LoginAsync()
    {
        if (!CanLogin) return;

        ErrorMessage = string.Empty;

        // 记录开始时间并显示遮罩
        _busyStartTime = DateTime.UtcNow;
        IsBusy = true;

        try
        {
            var (success, error) = await _loginService.LoginAsync(LoginUsername.Trim(), LoginPassword);

            if (success)
            {
                // 保存自动登录偏好
                _loginService.SetAutoLoginEnabled(AutoLoginEnabled);
                // 确保最低显示时长后关闭遮罩，触发 ShellPage 动画
                await EnsureMinimumBusyTimeAsync();
                IsBusy = false;
            }
            else
            {
                // 确保最低显示时长后先收起遮罩，再显示错误（避免错误框在半透明遮罩下提前透出）
                await EnsureMinimumBusyTimeAsync();
                IsBusy = false;
                ErrorMessage = error ?? "登录失败";
            }
        }
        catch (Exception ex)
        {
            // 先收起遮罩，再显示错误
            await EnsureMinimumBusyTimeAsync();
            IsBusy = false;
            ErrorMessage = $"登录出错: {ex.Message}";
            System.Diagnostics.Debug.WriteLine($"[LoginPageVM] 登录异常: {ex}");
        }
    }

    [RelayCommand]
    private async Task RegisterAsync()
    {
        if (!CanRegister) return;

        if (RegPassword != RegConfirmPassword)
        {
            ErrorMessage = "两次输入的密码不一致";
            return;
        }

        ErrorMessage = string.Empty;

        // 记录开始时间并显示遮罩
        _busyStartTime = DateTime.UtcNow;
        IsBusy = true;

        try
        {
            var (success, error) = await _loginService.RegisterAsync(RegUsername.Trim(), RegPassword);

            if (success)
            {
                // 注册成功后切换到登录界面，预填用户名
                var registeredUsername = RegUsername.Trim();
                await EnsureMinimumBusyTimeAsync();
                IsBusy = false;
                IsRegisterMode = false;
                LoginUsername = registeredUsername;
                return;
            }
            else
            {
                // 确保最低显示时长后先收起遮罩，再显示错误（避免错误框在半透明遮罩下提前透出）
                await EnsureMinimumBusyTimeAsync();
                IsBusy = false;
                ErrorMessage = error ?? "注册失败";
                return;
            }
        }
        catch (Exception ex)
        {
            // 先收起遮罩，再显示错误
            await EnsureMinimumBusyTimeAsync();
            IsBusy = false;
            ErrorMessage = $"注册出错: {ex.Message}";
            System.Diagnostics.Debug.WriteLine($"[LoginPageVM] 注册异常: {ex}");
            return;
        }
    }
}
