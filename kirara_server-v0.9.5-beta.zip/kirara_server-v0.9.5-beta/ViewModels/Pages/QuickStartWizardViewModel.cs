using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.ViewModels.Pages;

/// <summary>
/// 快速开始向导 ViewModel — 从预置模板一键创建实例
/// 复用 InstanceEditorViewModel 的 SchemeTokenBinding 模型和令牌绑定逻辑
/// </summary>
public partial class QuickStartWizardViewModel : ObservableObject
{
    private readonly IInstanceService _instanceService;
    private readonly ITokenService _tokenService;
    private readonly ISchemeService _schemeService;
    private readonly INavigationService _navigationService;
    private readonly ILoginService _loginService;
    private readonly ViewModels.Controls.LeftFunctionBarViewModel _leftFunctionBar;

    // ===== 接收参数 =====

    /// <summary>从主页传入的模板数据</summary>
    [ObservableProperty]
    private QuickStartTemplate _template = null!;

    /// <summary>页面标题</summary>
    public string PageTitle => Template != null ? $"为「{Template.Name}」实例模板绑定令牌" : "快速开始向导";

    /// <summary>
    /// 解析唯一的实例名称。
    /// 如果已有同名实例则自动加 (1)(2)... 后缀。
    /// </summary>
    public string ResolvedInstanceName
    {
        get
        {
            if (Template == null) return string.Empty;

            var baseName = Template.Name;
            var userId = _loginService.CurrentUserId;
            if (_instanceService.GetInstancesByUser(userId).Any(i =>
                i.Name.Equals(baseName, StringComparison.OrdinalIgnoreCase)))
            {
                int suffix = 1;
                string candidate;
                do
                {
                    candidate = $"{baseName}({suffix})";
                    suffix++;
                } while (_instanceService.GetInstancesByUser(userId).Any(i =>
                    i.Name.Equals(candidate, StringComparison.OrdinalIgnoreCase)));
                return candidate;
            }
            return baseName;
        }
    }

    // ===== 令牌绑定（复用 SchemeTokenBinding） =====

    [ObservableProperty]
    private ObservableCollection<SchemeTokenBinding> _selectedSchemeTokenBindings = new();

    [ObservableProperty]
    private ObservableCollection<Token> _availableTokens = new();

    /// <summary>是否使用统一认证模式</summary>
    [ObservableProperty]
    private bool _useDomainAccount;

    /// <summary>AD 域可用令牌</summary>
    [ObservableProperty]
    private ObservableCollection<Token> _domainTokens = new();

    /// <summary>当前选中的 AD 域令牌</summary>
    [ObservableProperty]
    private Token? _selectedDomainToken;

    /// <summary>统一认证状态文字</summary>
    [ObservableProperty]
    private string _domainTokenStatusText = "未选择域账户令牌";

    /// <summary>是否使用普通模式（每个方案单独配令牌）</summary>
    public bool IsNormalTokenMode => !UseDomainAccount;

    /// <summary>是否使用 AD 域账户模式</summary>
    public bool IsDomainAccountMode => UseDomainAccount;

    /// <summary>"完成"按钮是否可点击</summary>
    public bool CanComplete =>
        SelectedSchemeTokenBindings.Count > 0 &&
        (UseDomainAccount
            ? SelectedDomainToken != null
            : SelectedSchemeTokenBindings.All(b => b.SelectedToken != null));

    public QuickStartWizardViewModel(
        IInstanceService instanceService,
        ITokenService tokenService,
        ISchemeService schemeService,
        INavigationService navigationService,
        ILoginService loginService,
        ViewModels.Controls.LeftFunctionBarViewModel leftFunctionBar)
    {
        _instanceService = instanceService;
        _tokenService = tokenService;
        _schemeService = schemeService;
        _navigationService = navigationService;
        _loginService = loginService;
        _leftFunctionBar = leftFunctionBar;
    }

    /// <summary>
    /// 页面导航完成后初始化（接收模板参数）
    /// </summary>
    public void Initialize(QuickStartTemplate template)
    {
        Template = template;
        OnPropertyChanged(nameof(PageTitle));
        OnPropertyChanged(nameof(ResolvedInstanceName));

        LoadData();
    }

    private void LoadData()
    {
        // 加载模板对应的方案
        var schemes = Template.SchemeIds
            .Select(id => _schemeService.GetScheme(id))
            .Where(s => s != null)
            .Cast<Scheme>()
            .ToList();

        // 主动填充封面图标缓存路径
        try
        {
            var iconCache = App.Services.GetRequiredService<SchemeIconCacheService>();
            foreach (var s in schemes)
                s.CoverImageUrl = iconCache.GetCachedIconUrl(s.Name);
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[QuickStartWizardVM] 填充封面图标失败: {ex.Message}");
        }

        // 加载所有可用令牌
        var userId = _loginService.CurrentUserId;
        var tokens = _tokenService.GetTokensByUser(userId).ToList();
        AvailableTokens = new ObservableCollection<Token>(tokens);

        // 默认令牌（系统内置占位符）
        var defaultToken = tokens.FirstOrDefault(t => t.TokenType == TokenType.Default);

        // AD 域令牌列表
        DomainTokens = new ObservableCollection<Token>(
            tokens.Where(t => t.TokenType == TokenType.ADDomain || t.TokenType == TokenType.Default));
        SelectedDomainToken = defaultToken ?? DomainTokens.FirstOrDefault();

        // 为每个方案创建令牌绑定
        SelectedSchemeTokenBindings.Clear();
        foreach (var scheme in schemes)
        {
            var binding = new SchemeTokenBinding
            {
                Scheme = scheme,
                AvailableTokens = AvailableTokens,
                SelectedToken = defaultToken, // 自动预设默认令牌
            };
            binding.PropertyChanged += (_, _) =>
            {
                OnPropertyChanged(nameof(CanComplete));
            };
            SelectedSchemeTokenBindings.Add(binding);
        }

        OnPropertyChanged(nameof(CanComplete));
    }

    /// <summary>
    /// 统一认证模式切换时更新绑定状态
    /// </summary>
    partial void OnUseDomainAccountChanged(bool value)
    {
        OnPropertyChanged(nameof(IsNormalTokenMode));
        OnPropertyChanged(nameof(IsDomainAccountMode));

        if (value)
        {
            foreach (var b in SelectedSchemeTokenBindings)
                b.SelectedToken = null;
        }
        else
        {
            var defaultToken = AvailableTokens.FirstOrDefault(t => t.TokenType == TokenType.Default);
            foreach (var b in SelectedSchemeTokenBindings)
                b.SelectedToken = defaultToken;
        }

        OnPropertyChanged(nameof(CanComplete));
    }

    /// <summary>
    /// AD 域令牌选择变化
    /// </summary>
    partial void OnSelectedDomainTokenChanged(Token? value)
    {
        DomainTokenStatusText = value != null
            ? $"已绑定域账户：{value.Name}"
            : "未选择域账户令牌";
        OnPropertyChanged(nameof(CanComplete));
    }

    /// <summary>
    /// 模式切换命令
    /// </summary>
    [RelayCommand]
    private void SwitchToNormalMode() => UseDomainAccount = false;

    [RelayCommand]
    private void SwitchToDomainMode() => UseDomainAccount = true;

    // ===== 导航命令 =====

    /// <summary>
    /// 取消 — 返回首页
    /// </summary>
    [RelayCommand]
    private void Cancel()
    {
        _navigationService.NavigateTo(typeof(Views.Pages.MainPage));
        _leftFunctionBar.SetActivePage(quickStart: true);
    }

    /// <summary>
    /// 完成 — 创建实例并返回首页
    /// </summary>
    [RelayCommand]
    private void Complete()
    {
        var instanceName = ResolvedInstanceName;

        // 创建实例
        var instance = _instanceService.CreateInstance(instanceName, InstanceType.UserInstance, _loginService.CurrentUserId);

        // 添加方案绑定
        if (UseDomainAccount && SelectedDomainToken != null)
        {
            foreach (var binding in SelectedSchemeTokenBindings)
            {
                _instanceService.AddSchemeToInstance(
                    instance.Id, binding.Scheme.Id, SelectedDomainToken.Id);
            }
        }
        else
        {
            var defaultTokenId = AvailableTokens
                .FirstOrDefault(t => t.TokenType == TokenType.Default)?.Id;
            foreach (var binding in SelectedSchemeTokenBindings)
            {
                _instanceService.AddSchemeToInstance(
                    instance.Id, binding.Scheme.Id,
                    binding.SelectedToken?.Id ?? defaultTokenId);
            }
        }

        var savedInstance = _instanceService.GetInstance(instance.Id);
        if (savedInstance != null)
        {
            System.Diagnostics.Debug.WriteLine(
                $"[QuickStart] 实例「{savedInstance.Name}」创建完成，"
                + $"共绑定 {savedInstance.SchemeBindings.Count} 个方案");
        }

        // 刷新左侧栏实例列表
        _leftFunctionBar.LoadInstances();

        // 返回首页（不调用 MarkInstanceStarted，让模板实例和其他实例一样先走先导页）
        _navigationService.NavigateTo(typeof(Views.Pages.MainPage));
        _leftFunctionBar.SetActivePage(quickStart: true);
    }
}
