using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.ViewModels.Pages;

/// <summary>
/// 首页 ViewModel — 管理背景、登录状态、快速开始模板、通知概览
/// </summary>
public partial class MainPageViewModel : ObservableObject
{
    private readonly IQuickStartService _quickStartService;
    private readonly IInstanceService _instanceService;
    private readonly INotificationService _notificationService;
    private readonly ILoggingService _loggingService;
    private readonly INavigationService _navigationService;
    private readonly ILoginService _loginService;

    private Timer? _greetingTimer;
    private int _lastGreetingPeriod; // 缓存上次时段，0=早上 1=下午 2=晚上
    private Microsoft.UI.Dispatching.DispatcherQueue? _dispatcherQueue;

    public MainPageViewModel(
        IQuickStartService quickStartService,
        IInstanceService instanceService,
        INotificationService notificationService,
        ILoggingService loggingService,
        INavigationService navigationService,
        ILoginService loginService)
    {
        _quickStartService = quickStartService;
        _instanceService = instanceService;
        _notificationService = notificationService;
        _loggingService = loggingService;
        _navigationService = navigationService;
        _loginService = loginService;

        // 必须先获取 UI 线程 DispatcherQueue（供登录状态回调安全调度刷新）
        _dispatcherQueue = Microsoft.UI.Dispatching.DispatcherQueue.GetForCurrentThread();

        // 从登录服务读取当前登录状态
        _isLoggedIn = _loginService.IsLoggedIn;

        // ★ [账户切换同步] 订阅登录状态变化：
        //   首页页面缓存复用（NavigationCacheMode=Required），退出重登后构造函数不会重跑，
        //   必须在此订阅，在登录/登出时刷新问候语用户名与登录状态，避免显示上一账户的用户名。
        //   LoginStateChanged 可能在后台线程触发（自动登录），必须调度到 UI 线程刷新。
        _loginService.LoginStateChanged += _ =>
        {
            _dispatcherQueue?.TryEnqueue(() =>
            {
                IsLoggedIn = _loginService.IsLoggedIn;
                OnPropertyChanged(nameof(GreetingText));
            });
        };

        // 订阅通知实时更新未读计数
        _notificationService.OnNotificationReceived += _ =>
        {
            _dispatcherQueue?.TryEnqueue(UpdateUnreadCounts);
        };
        UpdateUnreadCounts();

        // 触发问候语绑定更新
        OnPropertyChanged(nameof(GreetingText));
        OnPropertyChanged(nameof(SubtitleText));

        // 启动问候语定时刷新（每分钟检查一次时段变化）
        _lastGreetingPeriod = GetCurrentPeriod();
        _greetingTimer = new Timer(OnGreetingTimerTick, null,
            TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(1));
    }

    /// <summary>获取当前时段索引（0=早上 1=中午 2=下午 3=晚上）</summary>
    private static int GetCurrentPeriod()
    {
        var hour = DateTime.Now.Hour;
        if (hour >= 6 && hour < 11) return 0;
        if (hour >= 11 && hour < 13) return 1;
        if (hour >= 13 && hour < 18) return 2;
        return 3;
    }

    // ================================================================
    //  登录状态
    // ================================================================

    /// <summary>是否已登录（从 ILoginService 读取）</summary>
    [ObservableProperty]
    private bool _isLoggedIn;

    /// <summary>问候语（根据时间段生成）</summary>
    public string GreetingText
    {
        get
        {
            var hour = DateTime.Now.Hour;
            string period = hour switch
            {
                >= 6 and < 11 => "早上",
                >= 11 and < 13 => "中午",
                >= 13 and < 18 => "下午",
                _ => "晚上"
            };
            var username = _loginService.CurrentUser?.Username ?? "用户";
            return $"{period}好，{username}！";
        }
    }

    /// <summary>副标题</summary>
    public string SubtitleText => "欢迎使用 Kirara Server 应用程序 ~";

    // ================================================================
    //  快速开始模板
    // ================================================================

    public IEnumerable<QuickStartTemplate> Templates =>
        _quickStartService.GetTemplates();

    public IEnumerable<ExternalClient> ExternalClients =>
        _quickStartService.GetExternalClients();

    /// <summary>
    /// 选择模板 → 打开快速开始向导
    /// </summary>
    [RelayCommand]
    private void SelectTemplate(QuickStartTemplate template)
    {
        _navigationService.NavigateTo(typeof(Views.Pages.QuickStartWizardPage), template);
    }

    // ================================================================
    //  通知概览（右上角角标显示）
    // ================================================================

    [ObservableProperty]
    private int _pushUnreadCount;

    [ObservableProperty]
    private int _serviceUnreadCount;

    [ObservableProperty]
    private bool _hasUnreadNotifications;

    private void UpdateUnreadCounts()
    {
        PushUnreadCount = _notificationService.GetNotifications(NotificationCategory.Push)
            .Count(n => !n.IsRead);
        ServiceUnreadCount = _notificationService.GetNotifications(NotificationCategory.Service)
            .Count(n => !n.IsRead);
        HasUnreadNotifications = PushUnreadCount + ServiceUnreadCount > 0;
    }

    // ================================================================
    //  问候语定时刷新
    // ================================================================

    private void OnGreetingTimerTick(object? state)
    {
        int currentPeriod = GetCurrentPeriod();
        if (currentPeriod != _lastGreetingPeriod)
        {
            _lastGreetingPeriod = currentPeriod;
            _dispatcherQueue?.TryEnqueue(() => OnPropertyChanged(nameof(GreetingText)));
        }
    }

    /// <summary>
    /// 释放定时器资源（由 ShellPage 在页面卸载时调用）
    /// </summary>
    public void StopGreetingTimer()
    {
        _greetingTimer?.Dispose();
        _greetingTimer = null;
    }

    // ================================================================
    //  快捷导航命令
    // ================================================================

    [RelayCommand]
    private void GoToTokenManager()
    {
        _navigationService.NavigateTo(typeof(Views.Pages.TokenManagerPage));
    }

    [RelayCommand]
    private void Logout()
    {
        _loginService.Logout();
        // ShellPage 的 LoginStateChanged 事件会自动导航到登录页面
    }

    [RelayCommand]
    private void GoToSettings()
    {
        _navigationService.NavigateTo(typeof(Views.Pages.SettingsPage));
    }

    // ================================================================
    //  通知操作命令
    // ================================================================

    [RelayCommand]
    private void ClearLogs()
    {
        _loggingService.ClearLogs();
    }
}
