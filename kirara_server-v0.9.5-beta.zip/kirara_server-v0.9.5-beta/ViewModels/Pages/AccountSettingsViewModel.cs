using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.ViewModels.Pages;

/// <summary>
/// 账号设置 ViewModel — 管理头像/用户名/密码修改与三方账号绑定（桩）
/// 校验规则与登录页面注册表单一致
/// </summary>
public partial class AccountSettingsViewModel : ObservableObject
{
    private readonly ILoginService _loginService;
    private readonly IUserAvatarService _avatarService;

    /// <summary>UI 线程调度器（供登录状态回调安全刷新绑定属性）</summary>
    private Microsoft.UI.Dispatching.DispatcherQueue? _dispatcherQueue;

    private static readonly HashSet<char> ForbiddenChars = new(@"#\/*:?""<>| ");

    /// <summary>用户名格式是否通过校验（用于 IsUsernameValid）</summary>
    private bool _isUsernameFormatValid;

    /// <summary>
    /// 结果通知事件 — 由 MainPage 订阅，弹出 Flyout 飞入菜单
    /// 参数：(title, message, isSuccess, onConfirmed)
    /// onConfirmed: 用户点击"确定"后的回调（可选，通常用于密码修改后触发登出）
    /// </summary>
    public event Action<string, string, bool, Action?>? OnResultNotification;

    // ================================================================
    //  头像
    // ================================================================

    /// <summary>当前头像路径（本地文件路径或 null）</summary>
    [ObservableProperty]
    private string? _avatarPath;

    /// <summary>是否正在上传头像</summary>
    [ObservableProperty]
    private bool _isAvatarUploading;

    /// <summary>是否可以上传头像（上传中禁用）</summary>
    public bool CanUploadAvatar => !IsAvatarUploading;

    // ===== 名片信息 =====

    /// <summary>账户显示名</summary>
    public string AccountDisplayName => _loginService.CurrentUser?.Username ?? "用户";

    /// <summary>累计登录时长文本</summary>
    public string TotalLoginDurationText
    {
        get
        {
            var user = _loginService.CurrentUser;
            if (user == null) return "0 天";
            var elapsed = DateTime.UtcNow - user.CreatedAt;
            int days = (int)elapsed.TotalDays;
            if (days < 1) return "不足 1 天";
            if (days < 30) return $"{days} 天";
            int months = days / 30;
            int remainingDays = days % 30;
            return months >= 12
                ? $"{months / 12} 年 {months % 12} 个月"
                : $"{months} 个月 {remainingDays} 天";
        }
    }

    /// <summary>上次登录时间文本</summary>
    public string LastLoginTimeText
    {
        get
        {
            var lastLogin = _loginService.CurrentUser?.LastLoginAt;
            if (lastLogin == null) return "首次登录";
            var local = lastLogin.Value.ToLocalTime();
            return local.ToString("yyyy-MM-dd HH:mm:ss");
        }
    }

    // ================================================================
    //  用户名修改
    // ================================================================

    [ObservableProperty]
    private string _newUsername = string.Empty;

    /// <summary>用户名校验提示文字</summary>
    [ObservableProperty]
    private string _usernameHint = string.Empty;

    /// <summary>用户名校验提示颜色</summary>
    [ObservableProperty]
    private string _usernameHintColor = "#E74856";

    /// <summary>用户名是否通过校验</summary>
    public bool IsUsernameValid =>
        !string.IsNullOrWhiteSpace(NewUsername) && _isUsernameFormatValid;

    /// <summary>用户名是否可保存（通过校验且与当前不同）</summary>
    public bool CanSaveUsername =>
        IsUsernameValid && NewUsername != _loginService.CurrentUser?.Username;

    /// <summary>新旧用户名相同提示</summary>
    public string UsernameSameHint =>
        !string.IsNullOrWhiteSpace(NewUsername)
        && NewUsername == _loginService.CurrentUser?.Username
        ? "新用户名与当前用户名相同"
        : string.Empty;

    // ================================================================
    //  密码修改
    // ================================================================

    [ObservableProperty]
    private string _currentPassword = string.Empty;

    [ObservableProperty]
    private string _newPassword = string.Empty;

    [ObservableProperty]
    private string _confirmPassword = string.Empty;

    // ===== 密码强度（复用登录页逻辑） =====

    public int PasswordStrengthScore { get; private set; }
    [ObservableProperty]
    private double _passwordStrengthWidth;

    public string PasswordStrengthText => PasswordStrengthScore switch
    {
        0 => string.IsNullOrEmpty(NewPassword) ? string.Empty : "密码太弱：至少6个字符",
        1 => "密码强度：弱（建议混合大小写字母、数字和符号）",
        2 => "密码强度：中等",
        3 => "密码强度：强",
        _ => string.Empty
    };

    public string PasswordStrengthColor => PasswordStrengthScore switch
    {
        0 => "#E74856",
        1 => "#E74856",
        2 => "#FF9800",
        3 => "#4CAF50",
        _ => "#E74856"
    };

    public bool PasswordsMatch =>
        NewPassword == ConfirmPassword && !string.IsNullOrEmpty(ConfirmPassword);

    public string PasswordMismatchHint =>
        !string.IsNullOrEmpty(ConfirmPassword) && !PasswordsMatch ? "两次输入的密码不一致" : string.Empty;

    /// <summary>新旧密码相同提示</summary>
    public string PasswordSameHint =>
        !string.IsNullOrEmpty(NewPassword)
        && NewPassword == CurrentPassword
        ? "新密码与当前密码相同"
        : string.Empty;

    public bool CanSavePassword =>
        !string.IsNullOrEmpty(CurrentPassword)
        && !string.IsNullOrEmpty(NewPassword)
        && PasswordStrengthScore >= 2
        && PasswordsMatch
        && NewPassword != CurrentPassword;

    // ================================================================
    //  应用账号绑定（预留桩）
    // ================================================================

    /// <summary>应用账号绑定列表（桩数据）</summary>
    public IReadOnlyList<ThirdPartyBinding> ThirdPartyBindings { get; } = new List<ThirdPartyBinding>
    {
        new("AD 域账户", "\uE77B", false, "绑定 AD 域账户实现统一认证"),
        new("Kirara Media 账户", "\uE7F7", false, "绑定 Kirara Media 账户"),
    };

    // ================================================================
    //  构造函数
    // ================================================================

    public AccountSettingsViewModel(
        ILoginService loginService,
        IUserAvatarService avatarService)
    {
        _loginService = loginService;
        _avatarService = avatarService;

        // 必须先获取 UI 线程 DispatcherQueue（供登录状态回调安全调度刷新）
        _dispatcherQueue = Microsoft.UI.Dispatching.DispatcherQueue.GetForCurrentThread();

        // 初始化头像
        AvatarPath = _avatarService.CurrentAvatarPath;
        _avatarService.AvatarChanged += path => AvatarPath = path;

        // ★ [账户切换同步] 订阅登录状态变化：
        //   VM 由 MainPage 缓存复用，退出重登后构造函数不会重跑，
        //   必须在此订阅，切换账户时刷新名片信息（用户名/累计登录时长/上次登录时间），
        //   避免显示上一账户的数据。
        //   LoginStateChanged 可能在后台线程触发（自动登录），必须调度到 UI 线程刷新。
        _loginService.LoginStateChanged += _ =>
        {
            _dispatcherQueue?.TryEnqueue(RefreshAccountInfo);
        };
    }

    /// <summary>
    /// 刷新账户名片信息（用户名/累计登录时长/上次登录时间）。
    /// 登录状态变化时自动调用；打开设置面板时由 MainPage 主动调用兜底，
    /// 确保显示当前登录用户的最新数据。
    /// </summary>
    public void RefreshAccountInfo()
    {
        OnPropertyChanged(nameof(AccountDisplayName));
        OnPropertyChanged(nameof(TotalLoginDurationText));
        OnPropertyChanged(nameof(LastLoginTimeText));
    }

    // ================================================================
    //  变更通知链
    // ================================================================

    partial void OnIsAvatarUploadingChanged(bool value)
    {
        OnPropertyChanged(nameof(CanUploadAvatar));
    }

    partial void OnNewUsernameChanged(string value)
    {
        ValidateUsername(value);
        OnPropertyChanged(nameof(IsUsernameValid));
        OnPropertyChanged(nameof(CanSaveUsername));
        OnPropertyChanged(nameof(UsernameSameHint));
    }

    partial void OnCurrentPasswordChanged(string value)
    {
        OnPropertyChanged(nameof(CanSavePassword));
        OnPropertyChanged(nameof(PasswordSameHint));
    }

    partial void OnNewPasswordChanged(string value)
    {
        EvaluatePasswordStrength(value);
        OnPropertyChanged(nameof(PasswordsMatch));
        OnPropertyChanged(nameof(PasswordMismatchHint));
        OnPropertyChanged(nameof(CanSavePassword));
        OnPropertyChanged(nameof(PasswordSameHint));
    }

    partial void OnConfirmPasswordChanged(string value)
    {
        OnPropertyChanged(nameof(PasswordsMatch));
        OnPropertyChanged(nameof(PasswordMismatchHint));
        OnPropertyChanged(nameof(CanSavePassword));
    }

    // ================================================================
    //  用户名实时校验
    // ================================================================

    private void ValidateUsername(string username)
    {
        if (string.IsNullOrWhiteSpace(username))
        {
            UsernameHint = string.Empty;
            _isUsernameFormatValid = false;
            return;
        }

        string trimmed = username.Trim();

        if (trimmed.Any(c => ForbiddenChars.Contains(c)))
        {
            UsernameHint = "用户名包含非法字符（空格或特殊符号 # \\ / : * ? \" < > |）";
            _isUsernameFormatValid = false;
            return;
        }

        if (trimmed.Length < 3)
        {
            UsernameHint = "用户名至少需要 3 个字符";
            _isUsernameFormatValid = false;
            return;
        }

        if (trimmed.Length > 50)
        {
            UsernameHint = "用户名不能超过 50 个字符";
            _isUsernameFormatValid = false;
            return;
        }

        string? currentUsername = _loginService.CurrentUser?.Username;

        // 新旧用户名相同时，不清除校验文字让 UsernameSameHint 独占显示
        if (trimmed == currentUsername)
        {
            UsernameHint = string.Empty;
            _isUsernameFormatValid = true;
            return;
        }

        // 格式校验通过 — 不留提示文字
        UsernameHint = string.Empty;
        _isUsernameFormatValid = true;
    }

    // ================================================================
    //  密码强度评估（与登录页完全一致）
    // ================================================================

    private void EvaluatePasswordStrength(string password)
    {
        if (string.IsNullOrEmpty(password))
        {
            PasswordStrengthScore = 0;
            PasswordStrengthWidth = 0;
            goto notify;
        }

        if (password.Length < 6)
        {
            PasswordStrengthScore = 0;
            PasswordStrengthWidth = 0;
            goto notify;
        }

        bool hasLower = password.Any(char.IsLower);
        bool hasUpper = password.Any(char.IsUpper);
        bool hasDigit = password.Any(char.IsDigit);
        bool hasSpecial = password.Any(c => !char.IsLetterOrDigit(c));
        int length = password.Length;

        bool isSingleType = (hasLower || hasUpper) && !hasDigit && !hasSpecial;
        bool isAllDigits = hasDigit && !hasLower && !hasUpper && !hasSpecial;
        bool isAllSameChar = password.Distinct().Count() == 1;

        bool hasRepeatingPattern = false;
        for (int len = 2; len <= password.Length / 2; len++)
        {
            if (password.Length % len != 0) continue;
            string pattern = password[..len];
            bool matches = true;
            for (int i = len; i < password.Length; i += len)
            {
                if (password.Substring(i, len) != pattern) { matches = false; break; }
            }
            if (matches) { hasRepeatingPattern = true; break; }
        }

        bool hasSequential = false;
        for (int i = 0; i < password.Length - 2; i++)
        {
            if ((password[i] + 1 == password[i + 1] && password[i + 1] + 1 == password[i + 2]) ||
                (password[i] - 1 == password[i + 1] && password[i + 1] - 1 == password[i + 2]))
            { hasSequential = true; break; }
        }

        if (isAllSameChar || isAllDigits || isSingleType)
        {
            PasswordStrengthScore = 1;
            PasswordStrengthWidth = 100;
            goto notify;
        }

        int score = 0;
        if (length >= 8) score++;
        if (length >= 12) score++;
        if (length >= 16) score++;
        if (hasLower) score++;
        if (hasUpper) score++;
        if (hasDigit) score++;
        if (hasSpecial) score++;
        if (hasRepeatingPattern) score -= 2;
        if (hasSequential) score--;
        score = Math.Max(1, score);

        PasswordStrengthScore = score switch { <= 2 => 1, 3 or 4 => 2, _ => 3 };
        PasswordStrengthWidth = PasswordStrengthScore switch { 1 => 100, 2 => 280, 3 => 370, _ => 0 };

    notify:
        OnPropertyChanged(nameof(PasswordStrengthScore));
        OnPropertyChanged(nameof(PasswordStrengthText));
        OnPropertyChanged(nameof(PasswordStrengthColor));
        OnPropertyChanged(nameof(PasswordStrengthWidth));
    }

    // ================================================================
    //  命令
    // ================================================================

    /// <summary>
    /// 重置所有输入字段（由 MainPage 在关闭设置面板时调用）
    /// </summary>
    public void ResetFormFields()
    {
        NewUsername = string.Empty;
        UsernameHint = string.Empty;
        UsernameHintColor = "#E74856";
        CurrentPassword = string.Empty;
        NewPassword = string.Empty;
        ConfirmPassword = string.Empty;
        PasswordStrengthScore = 0;
        PasswordStrengthWidth = 0;

        OnPropertyChanged(nameof(UsernameHint));
        OnPropertyChanged(nameof(UsernameHintColor));
        OnPropertyChanged(nameof(IsUsernameValid));
        OnPropertyChanged(nameof(CanSaveUsername));
        OnPropertyChanged(nameof(UsernameSameHint));
        OnPropertyChanged(nameof(PasswordStrengthScore));
        OnPropertyChanged(nameof(PasswordStrengthText));
        OnPropertyChanged(nameof(PasswordStrengthColor));
        OnPropertyChanged(nameof(PasswordStrengthWidth));
        OnPropertyChanged(nameof(PasswordsMatch));
        OnPropertyChanged(nameof(PasswordMismatchHint));
        OnPropertyChanged(nameof(CanSavePassword));
        OnPropertyChanged(nameof(PasswordSameHint));
    }

    /// <summary>
    /// 选择并上传头像
    /// </summary>
    [RelayCommand]
    private async Task UploadAvatarAsync()
    {
        try
        {
            // 使用 Win32 原生 GetOpenFileNameW 文件选择器（Win32FileDialogHelper）：
            // Windows.Storage.Pickers.FileOpenPicker 在 WindowsAppSDKSelfContained
            // Unpackaged 模式下激活不可靠（实测选择器失效），Win32 对话框任何模式下都可靠。
            var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(MainWindow.Current);
            var filter = "图片文件 (*.jpg;*.jpeg;*.png;*.bmp;*.gif)|*.jpg;*.jpeg;*.png;*.bmp;*.gif|所有文件 (*.*)|*.*";
            var filePath = Helpers.Win32FileDialogHelper.ShowOpenFileDialog(filter, "选择头像图片", hwnd);

            if (string.IsNullOrEmpty(filePath))
                return;

            // 文件大小限制：10MB
            var fileInfo = new FileInfo(filePath);
            if (fileInfo.Length > 10 * 1024 * 1024) // 10 MB
            {
                OnResultNotification?.Invoke("文件过大", "头像文件大小不能超过 10MB，请选择更小的图片", false, null);
                return;
            }

            IsAvatarUploading = true;

            var imageBytes = await System.IO.File.ReadAllBytesAsync(filePath);

            var (success, error) = await _avatarService.UploadAvatarAsync(imageBytes);
            if (success)
            {
                OnResultNotification?.Invoke("头像更新成功", "您的头像已成功更新", true, null);
            }
            else
            {
                OnResultNotification?.Invoke("头像更新失败", error ?? "无法处理该图片，请尝试其他图片", false, null);
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[AccountSettingsVM] 头像上传异常: {ex}");
            OnResultNotification?.Invoke("头像上传错误", ex.Message, false, null);
        }
        finally
        {
            IsAvatarUploading = false;
        }
    }

    /// <summary>
    /// 保存用户名修改 — 通过 API 修改
    /// </summary>
    [RelayCommand]
    private async Task SaveUsernameAsync()
    {
        if (!CanSaveUsername) return;

        try
        {
            string newName = NewUsername.Trim();

            var (success, error) = await _loginService.ChangeUsernameAsync(newName);

            if (!success)
            {
                OnResultNotification?.Invoke("更新失败", error ?? "未知错误", false, null);
                return;
            }

            OnResultNotification?.Invoke("用户名已更新", $"您的新用户名为：{newName}，部分页面可能需要重新登录后生效", true, null);
            OnPropertyChanged(nameof(AccountDisplayName));

            // 清空输入框，避免修改后触发"新用户名与当前用户名相同"的警告
            NewUsername = string.Empty;
            UsernameHint = string.Empty;
            OnPropertyChanged(nameof(IsUsernameValid));
            OnPropertyChanged(nameof(CanSaveUsername));
            OnPropertyChanged(nameof(UsernameSameHint));
        }
        catch (Exception ex)
        {
            OnResultNotification?.Invoke("更新失败", ex.Message, false, null);
        }
    }

    /// <summary>
    /// 保存密码修改 — 通过 API 修改，成功后服务端吊销 Token 强制登出
    /// </summary>
    [RelayCommand]
    private async Task SavePasswordAsync()
    {
        if (!CanSavePassword) return;

        try
        {
            var (success, error) = await _loginService.ChangePasswordAsync(CurrentPassword, NewPassword);

            if (!success)
            {
                OnResultNotification?.Invoke("修改失败", error ?? "未知错误", false, null);
                return;
            }

            // 清空密码字段
            CurrentPassword = string.Empty;
            NewPassword = string.Empty;
            ConfirmPassword = string.Empty;

            // 密码修改成功后服务端已吊销 Token，但延迟到用户点击"确定"后才触发登出动画
            OnResultNotification?.Invoke(
                "密码已修改",
                "服务端已注销所有服务项，请重新登录",
                true,
                () => _loginService.NotifyPasswordChangeCompleted());
        }
        catch (Exception ex)
        {
            OnResultNotification?.Invoke("更新失败", ex.Message, false, null);
        }
    }

    /// <summary>
    /// 三方账号绑定（桩 — 提示功能开发中）
    /// </summary>
    [RelayCommand]
    private void BindThirdParty(ThirdPartyBinding binding)
    {
        OnResultNotification?.Invoke(
            "功能开发中",
            $"「{binding.Name}」绑定功能正在开发中，敬请期待!",
            false,
            null);
    }
}

/// <summary>
/// 三方账号绑定项（桩数据）
/// </summary>
public class ThirdPartyBinding
{
    public string Name { get; }
    public string IconGlyph { get; }
    public bool IsBound { get; set; }
    public string Description { get; }

    public ThirdPartyBinding(string name, string iconGlyph, bool isBound, string description)
    {
        Name = name;
        IconGlyph = iconGlyph;
        IsBound = isBound;
        Description = description;
    }
}
