using CommunityToolkit.Mvvm.ComponentModel;
using Microsoft.UI.Xaml.Media;
using Windows.UI;

namespace Kirara_Server_WinUI.ViewModels.Pages;

/// <summary>
/// 主题色色块项 VM — 纯数据驱动色块状态（选中/禁用/灰化），
/// 避免 code-behind 遍历视觉树带来的容器生成时机与命中测试问题。
/// </summary>
public partial class SwatchItemViewModel : ObservableObject
{
    /// <summary>色块原始颜色</summary>
    public Color Color { get; }

    /// <summary>色块画刷 — 禁用时自动降饱和（灰色滤镜效果），启用时恢复原始色</summary>
    public SolidColorBrush ColorBrush { get; }

    /// <summary>是否为当前主题色（选中态）</summary>
    [ObservableProperty]
    private bool _isSelected;

    /// <summary>是否可交互（跟随系统主题时 false）</summary>
    [ObservableProperty]
    private bool _isEnabled = true;

    /// <summary>
    /// 是否显示选中标记（勾选 + 预选框）— 需同时满足「选中」且「启用」
    /// </summary>
    public bool ShowCheck => IsSelected && IsEnabled;

    public SwatchItemViewModel(Color color, bool isSelected, bool isEnabled)
    {
        Color = color;
        ColorBrush = new SolidColorBrush(color);
        IsSelected = isSelected;
        IsEnabled = isEnabled; // 触发 OnIsEnabledChanged → 画刷同步为原始色/降饱和色
    }

    partial void OnIsSelectedChanged(bool value) => OnPropertyChanged(nameof(ShowCheck));

    partial void OnIsEnabledChanged(bool value)
    {
        // 禁用 → 降饱和灰色滤镜；启用 → 恢复原始色
        ColorBrush.Color = value ? Color : Desaturate(Color);
        OnPropertyChanged(nameof(ShowCheck));
    }

    /// <summary>
    /// 颜色降饱和 — 向灰度方向混合（60% 灰度 + 40% 原色），模拟灰色滤镜效果
    /// </summary>
    private static Color Desaturate(Color color)
    {
        float gray = 0.299f * color.R + 0.587f * color.G + 0.114f * color.B;
        return Color.FromArgb(color.A,
            (byte)(gray * 0.6f + color.R * 0.4f),
            (byte)(gray * 0.6f + color.G * 0.4f),
            (byte)(gray * 0.6f + color.B * 0.4f));
    }
}
