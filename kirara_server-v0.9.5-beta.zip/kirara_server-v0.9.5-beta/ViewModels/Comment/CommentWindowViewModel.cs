using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.ViewModels.Comment;

/// <summary>
/// 评论窗口 ViewModel — 管理评论列表、输入和加载逻辑
/// 通过 ICommentService 调用远程 API 获取数据
/// </summary>
public partial class CommentWindowViewModel : ObservableObject
{
    private readonly ICommentService _commentService;
    private readonly IHomepageCommentService? _homepageCommentService;
    private readonly CommentAvatarService _avatarService;

    /// <summary>当前资源键（URL 路径）</summary>
    [ObservableProperty]
    private string _resourceKey = string.Empty;

    /// <summary>当前方案 ID</summary>
    private Guid _schemeId;

    /// <summary>[首页分享功能] 当前实例 ID（用于“发送并分享”）</summary>
    private Guid _instanceId;

    /// <summary>[首页分享功能] 当前页面 URL（用于“发送并分享”时存入源地址）</summary>
    public string CurrentPageUrl { get; set; } = string.Empty;

    /// <summary>资源显示标题</summary>
    [ObservableProperty]
    private string _resourceTitle = "评论区";

    /// <summary>评论列表</summary>
    [ObservableProperty]
    private ObservableCollection<CommentItemViewModel> _comments = new();

    /// <summary>新评论内容输入（变化时刷新发送按钮可用状态）</summary>
    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(SubmitCommentCommand))]
    [NotifyCanExecuteChangedFor(nameof(SubmitAndShareCommand))]
    private string _newCommentInput = string.Empty;

    /// <summary>是否正在发送评论（发送期间禁用发送按钮，防止重复提交）</summary>
    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(SubmitCommentCommand))]
    [NotifyCanExecuteChangedFor(nameof(SubmitAndShareCommand))]
    private bool _isSubmitting;

    /// <summary>是否正在加载评论</summary>
    [ObservableProperty]
    private bool _isLoading;

    /// <summary>评论总数显示</summary>
    [ObservableProperty]
    private string _commentCountText = "0 条评论";

    /// <summary>空状态提示是否可见</summary>
    [ObservableProperty]
    private bool _isEmptyVisible = true;

    /// <summary>操作错误提示（短暂显示后自动清除）</summary>
    [ObservableProperty]
    private string? _errorMessage;

    public CommentWindowViewModel(
        ICommentService commentService,
        IHomepageCommentService? homepageCommentService = null,
        CommentAvatarService? avatarService = null)
    {
        _commentService = commentService;
        _homepageCommentService = homepageCommentService;
        // 评论作者头像服务（可选参数：既有调用点未传时从 DI 兜底获取）
        _avatarService = avatarService ?? App.Services.GetRequiredService<CommentAvatarService>();
    }

    /// <summary>
    /// 加载指定资源的评论列表
    /// </summary>
    [RelayCommand]
    private async Task LoadCommentsAsync()
    {
        if (string.IsNullOrEmpty(ResourceKey)) return;

        IsLoading = true;
        try
        {
            var list = await _commentService.GetCommentsAsync(ResourceKey);

            Comments.Clear();
            foreach (var item in list)
            {
                Comments.Add(new CommentItemViewModel(_commentService, _avatarService, item, GetEffectiveContentTitleAsync));
            }

            CommentCountText = Comments.Count == 0 ? "0 条评论" : $"{Comments.Count} 条评论";
            IsEmptyVisible = Comments.Count == 0;
        }
        finally
        {
            IsLoading = false;
        }
    }

    /// <summary>
    /// 设置资源上下文并加载评论
    /// </summary>
    public async Task SetContextAndLoadAsync(string resourceKey, Guid schemeId, string? resourceTitle, Guid instanceId = default)
    {
        ResourceKey = resourceKey;
        _schemeId = schemeId;
        _instanceId = instanceId;
        ResourceTitle = string.IsNullOrWhiteSpace(resourceTitle) ? "评论区" : resourceTitle;

        await LoadCommentsAsync();
    }

    /// <summary>
    /// 发送按钮可用判定：输入框有非空白内容且不在发送中
    /// （空输入 / 纯空白 / 发送中 → 按钮灰化不可点）
    /// </summary>
    private bool CanSubmitComment() =>
        !string.IsNullOrWhiteSpace(NewCommentInput) && !IsSubmitting;

    /// <summary>
    /// 页面标题获取器 — 由宿主（SchemeHostPage）注入，通过 WebView2 主动读取当前页面标题。
    /// 返回 null 表示无法获取（宿主未注入 / 页面未就绪 / 非 WebView2 方案）。
    /// v1.10 修复：不依赖 MutationObserver 被动推送（Jellyfin DOM 选择器失效时标题会一直缺失）。
    /// </summary>
    public Func<Task<string?>>? FetchPageTitleAsync { get; set; }

    /// <summary>
    /// 获取互动通知有效标题（v1.10 修复）。
    /// 优先级（由用户实测校准，2026-08-07）：
    ///   ① 评论区标题栏 ResourceTitle（MutationObserver 可见性过滤推送，实测 1s 内可靠识别）— 优先
    ///   ② 宿主探针 FetchPageTitleAsync（WebView2 主动查询，仅 UI 标题为兜底值时启用）
    ///   ③ 均不可用 → null（不污染通知文案）
    /// 公开：评论项 ViewModel（回复提交）也通过此方法获取标题。
    /// </summary>
    public async Task<string?> GetEffectiveContentTitleAsync()
    {
        // ① 优先已解析好的 UI 标题（评论区标题栏，用户实测可靠）
        if (!string.IsNullOrWhiteSpace(ResourceTitle) && ResourceTitle != "评论区")
        {
            System.Diagnostics.Debug.WriteLine(
                $"[评论] 标题来源: UI标题(ResourceTitle) = \"{ResourceTitle}\"");
            return ResourceTitle;
        }

        // ② 回退探针：页面 DOM 主动查询（MutationObserver 未推送时启用）
        try
        {
            if (FetchPageTitleAsync != null)
            {
                var fetched = await FetchPageTitleAsync();
                System.Diagnostics.Debug.WriteLine(
                    $"[评论] 标题来源: 页面探针 = \"{fetched ?? "null"}\"");
                if (!string.IsNullOrWhiteSpace(fetched))
                    return fetched;
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[评论] 页面标题获取失败: {ex.Message}");
        }

        System.Diagnostics.Debug.WriteLine(
            $"[评论] 标题来源: 无可用标题，ResourceTitle=\"{ResourceTitle}\"");
        return null;
    }

    /// <summary>
    /// 提交新评论
    /// </summary>
    [RelayCommand(CanExecute = nameof(CanSubmitComment))]
    private async Task SubmitComment()
    {
        if (string.IsNullOrWhiteSpace(NewCommentInput)) return;

        ErrorMessage = null;
        IsSubmitting = true;
        try
        {
            // v1.10 修复：从评论区已解析标题读取（优先 ResourceTitle，探针兜底）
            var contentTitle = await GetEffectiveContentTitleAsync();
            System.Diagnostics.Debug.WriteLine(
                $"[评论] 提交评论 contentTitle=\"{contentTitle ?? "null"}\" resourceKey={ResourceKey}");
            var comment = await _commentService.AddCommentAsync(
                ResourceKey, _schemeId, NewCommentInput, contentTitle);

            // 插入到列表顶部
            Comments.Insert(0, new CommentItemViewModel(_commentService, _avatarService, comment, GetEffectiveContentTitleAsync));

            NewCommentInput = string.Empty;
            CommentCountText = $"{Comments.Count} 条评论";
            IsEmptyVisible = false;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[评论] 发送评论失败: {ex.Message}");
            ErrorMessage = ex.Message;
        }
        finally
        {
            IsSubmitting = false;
        }
    }

    /// <summary>
    /// [首页分享功能] 发送评论并同时分享到首页
    /// </summary>
    [RelayCommand(CanExecute = nameof(CanSubmitComment))]
    private async Task SubmitAndShareAsync()
    {
        if (string.IsNullOrWhiteSpace(NewCommentInput)) return;

        ErrorMessage = null;
        IsSubmitting = true;
        try
        {
            // v1.10 修复：从评论区已解析标题读取（优先 ResourceTitle，探针兜底）
            var contentTitle = await GetEffectiveContentTitleAsync();
            System.Diagnostics.Debug.WriteLine(
                $"[评论] 提交并分享 contentTitle=\"{contentTitle ?? "null"}\" resourceKey={ResourceKey}");

            // 1. 发送评论
            var comment = await _commentService.AddCommentAsync(
                ResourceKey, _schemeId, NewCommentInput, contentTitle);

            // 插入到列表顶部
            Comments.Insert(0, new CommentItemViewModel(_commentService, _avatarService, comment, GetEffectiveContentTitleAsync));
            CommentCountText = $"{Comments.Count} 条评论";
            IsEmptyVisible = false;

            // 2. 分享到首页（将 instanceId/contentTitle/sourceUrl 编码进 resourceKey，服务端只存 resourceKey 列）
            if (_homepageCommentService != null && _instanceId != Guid.Empty)
            {
                try
                {
                    // 分享标题同源：优先有效标题，回退 UI 标题（避免"评论区"兜底值污染分享卡片）
                    var shareTitle = contentTitle ?? ResourceTitle;
                    var packedKey = Kirara_Server_WinUI.Helpers.ResourceKeyPacker.Pack(
                        ResourceKey, _instanceId, shareTitle, CurrentPageUrl);
                    await _homepageCommentService.CreateHomepageCommentAsync(
                        packedKey, _schemeId, _instanceId, shareTitle, CurrentPageUrl, NewCommentInput);
                }
                catch (Exception shareEx)
                {
                    System.Diagnostics.Debug.WriteLine($"[评论] 分享到首页失败: {shareEx.Message}");
                    // 分享失败不影响评论发送成功
                }
            }

            // 3. 清空输入框
            NewCommentInput = string.Empty;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[评论] 发送并分享失败: {ex.Message}");
            ErrorMessage = ex.Message;
        }
        finally
        {
            IsSubmitting = false;
        }
    }
}
