namespace Kirara_Server_WinUI.ViewModels.Comment;

/// <summary>
/// 首页分享“查看”跳转导航参数 — 携带实例 ID、方案 ID 和源 URL
/// 由 InstanceWorkspace.OnNavigatedTo 解析并执行跳转
/// </summary>
/// <param name="InstanceId">目标实例 ID</param>
/// <param name="SchemeId">目标方案 ID（用于定位方案标签）</param>
/// <param name="SourceUrl">分享时的页面 URL（加载后导航到该地址）</param>
public record SharedContentNavigationParameter(Guid InstanceId, Guid SchemeId, string SourceUrl);
