using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Schemes;
using Kirara_Server_WinUI.Services;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml.Media.Imaging;

namespace Kirara_Server_WinUI.ViewModels.Comment;

/// <summary>
/// 首页分享项 ViewModel — 表示首页分享列表中的一条分享卡片
/// 支持点赞和点击跳转到对应方案页面
/// </summary>
public partial class HomepageCommentItemViewModel : ObservableObject
{
    private readonly IHomepageCommentService _homepageCommentService;
    private readonly INavigationService _navigationService;

    /// <summary>分享唯一标识</summary>
    public Guid Id { get; }

    /// <summary>分享作者用户 ID（头像缓存键）</summary>
    public Guid AuthorUserId { get; }

    /// <summary>UI 线程调度器（头像同步回调来自线程池，需调度回 UI 线程更新绑定）</summary>
    private readonly DispatcherQueue _dispatcherQueue = DispatcherQueue.GetForCurrentThread();

    /// <summary>关联的资源标识键</summary>
    public string ResourceKey { get; }

    /// <summary>所属方案 ID</summary>
    public Guid SchemeId { get; }

    /// <summary>所属实例 ID（分享者本地 GUID，其他 PC 上可能无效）</summary>
    public Guid InstanceId { get; }

    /// <summary>
    /// [跨设备分享修复] 当前所在实例 ID（分享面板宿主注入）。
    /// 分享项来源实例无效时回退到当前实例打开。
    /// </summary>
    private readonly Guid _fallbackInstanceId;

    /// <summary>资源内容标题</summary>
    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(HasContentTitle))]
    private string _contentTitle = string.Empty;

    /// <summary>分享时的页面 URL（用于“查看”跳转）</summary>
    public string SourceUrl { get; } = string.Empty;

    /// <summary>内容标题是否非空（用于 UI 可见性绑定）</summary>
    public bool HasContentTitle => !string.IsNullOrWhiteSpace(ContentTitle);

    /// <summary>分享用户显示名</summary>
    [ObservableProperty]
    private string _authorName = string.Empty;

    /// <summary>分享用户头像首字母（用于显示）</summary>
    public string AuthorInitial => string.IsNullOrEmpty(AuthorName) ? "?" : AuthorName[0].ToString().ToUpper();

    /// <summary>分享用户头像图片（本地加密缓存加载；null 或加载失败时回退首字母圆头像）</summary>
    [ObservableProperty]
    private BitmapImage? _authorAvatarImage;

    /// <summary>分享用户评语</summary>
    [ObservableProperty]
    private string _content = string.Empty;

    /// <summary>点赞数</summary>
    [ObservableProperty]
    private int _likeCount;

    /// <summary>当前用户是否已点赞</summary>
    [ObservableProperty]
    private bool _isLiked;

    /// <summary>时间显示文本</summary>
    [ObservableProperty]
    private string _timeText = string.Empty;

    public HomepageCommentItemViewModel(
        IHomepageCommentService homepageCommentService,
        INavigationService navigationService,
        CommentAvatarService avatarService,
        HomepageCommentItem item,
        Guid fallbackInstanceId = default)
    {
        _homepageCommentService = homepageCommentService;
        _navigationService = navigationService;

        Id = item.Id;
        ResourceKey = item.ResourceKey;
        SchemeId = item.SchemeId;
        InstanceId = item.InstanceId;
        _fallbackInstanceId = fallbackInstanceId;
        AuthorUserId = item.AuthorUserId;
        ContentTitle = item.ContentTitle;
        SourceUrl = item.SourceUrl;
        AuthorName = item.AuthorName;
        Content = item.Content;
        LikeCount = item.LikeCount;
        IsLiked = item.IsLikedByUser;
        TimeText = FormatTime(item.CreatedAt);

        // [首页分享功能] 作者头像：本地加密缓存秒显 → 后台 ETag 同步
        LoadAvatar(avatarService);
    }

    /// <summary>
    /// [首页分享功能] 加载作者头像：先读本地加密缓存秒显，再后台同步服务端版本（LastModified 比对）
    /// </summary>
    private void LoadAvatar(CommentAvatarService avatarService)
    {
        if (AuthorUserId == Guid.Empty) return;

        // Step1: 本地缓存秒显
        var cachedPath = avatarService.GetCachedAvatarPath(AuthorUserId);
        if (cachedPath != null)
        {
            AuthorAvatarImage = CreateAvatarImage(cachedPath);
        }

        // Step2: 后台 ETag 同步（回调在线程池线程，调度回 UI 线程）
        _ = avatarService.SyncAvatarAsync(AuthorUserId, path =>
        {
            if (_dispatcherQueue != null && !_dispatcherQueue.HasThreadAccess)
                _dispatcherQueue.TryEnqueue(() => ApplyAvatarPath(path));
            else
                ApplyAvatarPath(path);
        });
    }

    /// <summary>应用头像路径（空串 = 清除显示，回退首字母）</summary>
    private void ApplyAvatarPath(string path)
    {
        AuthorAvatarImage = string.IsNullOrEmpty(path) ? null : CreateAvatarImage(path);
    }

    /// <summary>本地临时文件路径 → BitmapImage（URI 非法时返回 null）</summary>
    private static BitmapImage? CreateAvatarImage(string path)
    {
        try
        {
            return new BitmapImage(new Uri(path));
        }
        catch (UriFormatException)
        {
            return null;
        }
    }

    /// <summary>
    /// 切换点赞状态
    /// </summary>
    [RelayCommand]
    private async Task ToggleLike()
    {
        try
        {
            var result = await _homepageCommentService.ToggleLikeAsync(Id);
            IsLiked = result.Liked;
            LikeCount = result.LikeCount;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[首页分享] 点赞失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 点击跳转到对应方案页面
    /// 跳转前校验实例与方案绑定有效性：社区分享为全局列表，分享项可能指向
    /// 已删除实例或其他设备的实例，直接导航会导致工作区挂载空白页面
    /// （SchemeHostPage 显示"未能加载任何方案"误导文案）。
    /// [跨设备分享修复] 分享项携带的 InstanceId 是分享者本地数据库的 GUID，
    /// 其他 PC 上不存在该实例 → 降级查找本机绑定了相同方案的其他实例，
    /// 用本机实例打开分享（源 URL 主机为共享服务器地址，可直接访问）。
    /// </summary>
    [RelayCommand]
    private async Task NavigateToResource()
    {
        if (InstanceId == Guid.Empty) return;

        // [修复] 跳转前校验：实例必须存在且已绑定对应方案，无效时降级或提示
        try
        {
            var instanceService = App.Services.GetRequiredService<IInstanceService>();
            var instance = instanceService.GetInstance(InstanceId);
            var isDirectValid = instance != null &&
                instance.SchemeBindings.Any(b => b.SchemeId == SchemeId);

            if (!isDirectValid)
            {
                // [跨设备分享修复] 跳转目标实例不可用（其他 PC 创建的分享/实例已删除）时，
                // 按优先级回退：① 当前所在实例（用户正在分享面板中）→ ② 本机任意同方案实例
                // 内置方案 GUID 全客户端硬编码一致（如 media = a1000001-...），
                // 因此"当前实例是否绑定该方案"的检查跨设备有效。
                Instance? fallback = null;

                if (_fallbackInstanceId != Guid.Empty)
                {
                    var currentInstance = instanceService.GetInstance(_fallbackInstanceId);
                    if (currentInstance != null &&
                        currentInstance.SchemeBindings.Any(b => b.SchemeId == SchemeId && b.IsEnabled))
                    {
                        fallback = currentInstance;
                    }
                }

                fallback ??= instanceService.GetAllInstances()
                    .FirstOrDefault(i => i.SchemeBindings.Any(b => b.SchemeId == SchemeId && b.IsEnabled));

                if (fallback != null)
                {
                    // 用回退实例导航；源 URL 若指向分享者局域网/旧地址，则替换为本机方案的服务器地址
                    var url = NormalizeSourceUrl(SourceUrl, fallback);
                    _navigationService.NavigateTo(
                        typeof(Views.Instance.InstanceWorkspace),
                        new SharedContentNavigationParameter(fallback.Id, SchemeId, url));
                    return;
                }

                var msg = instance == null
                    ? "该分享对应的实例不存在，可能已被删除或来自其他设备；"
                    : "该分享对应的方案未绑定到此实例；";
                msg += "本机也没有找到可用的同方案实例，无法打开该分享。";
                await App.Services.GetRequiredService<IDialogService>()
                    .ShowMessageAsync("无法跳转", msg);
                return;
            }
        }
        catch (Exception ex)
        {
            // 校验失败不阻断跳转（保持原有行为），仅记录日志
            System.Diagnostics.Debug.WriteLine($"[首页分享] 跳转前校验失败: {ex.Message}");
        }

        var parameter = new SharedContentNavigationParameter(InstanceId, SchemeId, SourceUrl);
        _navigationService.NavigateTo(
            typeof(Views.Instance.InstanceWorkspace),
            parameter);
    }

    /// <summary>
    /// [跨设备分享修复] 规范化分享源 URL 的主机：
    /// 分享者 PC 上的 URL 可能指向其局域网/旧服务器地址，目标 PC 无法访问。
    /// 用目标实例对应方案的注册表服务器地址（跨设备同步，全局可达）替换主机与端口，
    /// 保留路径/查询/hash 片段；主机一致（共享服务器）时原样返回。
    /// </summary>
    private string NormalizeSourceUrl(string sourceUrl, Instance targetInstance)
    {
        if (string.IsNullOrWhiteSpace(sourceUrl)) return sourceUrl;

        try
        {
            // 目标实例中该方案的绑定 → 方案模型 → 方案名（URL 注册表键）
            var binding = targetInstance.SchemeBindings
                .FirstOrDefault(b => b.SchemeId == SchemeId);
            var scheme = binding != null
                ? App.Services.GetRequiredService<ISchemeService>().GetScheme(binding.SchemeId)
                : null;
            var localUrl = scheme != null
                ? BaseScheme.ServerUrlService?.GetDecryptedUrl(scheme.Name)
                : null;
            if (string.IsNullOrWhiteSpace(localUrl)) return sourceUrl;

            var source = new Uri(sourceUrl);
            var local = new Uri(localUrl);

            // 主机一致（共享服务器）：直接使用原 URL
            if (string.Equals(source.Host, local.Host, StringComparison.OrdinalIgnoreCase)
                && source.Port == local.Port)
                return sourceUrl;

            // 主机不同：替换为本地可达地址，保留路径/查询/hash
            var builder = new UriBuilder(source)
            {
                Scheme = local.Scheme,
                Host = local.Host,
            };
            if (!local.IsDefaultPort) builder.Port = local.Port;
            return builder.Uri.ToString();
        }
        catch (UriFormatException)
        {
            return sourceUrl;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[首页分享] URL 规范化失败: {ex.Message}");
            return sourceUrl;
        }
    }

    /// <summary>格式化时间为相对时间字符串</summary>
    private static string FormatTime(DateTime utcTime)
    {
        var localTime = utcTime.ToLocalTime();
        var diff = DateTime.Now - localTime;

        if (diff.TotalMinutes < 1) return "刚刚";
        if (diff.TotalMinutes < 60) return $"{(int)diff.TotalMinutes} 分钟前";
        if (diff.TotalHours < 24) return $"{(int)diff.TotalHours} 小时前";
        if (diff.TotalDays < 7) return $"{(int)diff.TotalDays} 天前";
        return localTime.ToString("yyyy-MM-dd");
    }
}
