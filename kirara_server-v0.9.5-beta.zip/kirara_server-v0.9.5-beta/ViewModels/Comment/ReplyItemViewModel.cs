using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Kirara_Server_WinUI.Services;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml.Media.Imaging;

namespace Kirara_Server_WinUI.ViewModels.Comment;

/// <summary>
/// 回复项 ViewModel — 表示评论下的一条回复
/// 支持点赞功能
/// </summary>
public partial class ReplyItemViewModel : ObservableObject
{
    private readonly ICommentService _commentService;
    private readonly CommentAvatarService _avatarService;

    /// <summary>回复 ID</summary>
    public Guid Id { get; }

    /// <summary>所属父评论 ID</summary>
    public Guid ParentCommentId { get; }

    /// <summary>作者用户 ID（头像缓存键）</summary>
    public Guid AuthorUserId { get; }

    /// <summary>UI 线程调度器（头像同步回调来自线程池，需调度回 UI 线程更新绑定）</summary>
    private readonly DispatcherQueue _dispatcherQueue = DispatcherQueue.GetForCurrentThread();

    /// <summary>回复作者名称</summary>
    [ObservableProperty]
    private string _authorName = string.Empty;

    /// <summary>回复内容</summary>
    [ObservableProperty]
    private string _content = string.Empty;

    /// <summary>时间显示文本</summary>
    [ObservableProperty]
    private string _timeText = string.Empty;

    /// <summary>点赞数</summary>
    [ObservableProperty]
    private int _likeCount;

    /// <summary>当前用户是否已点赞</summary>
    [ObservableProperty]
    private bool _isLiked;

    /// <summary>作者头像首字母（用于显示）</summary>
    public string AuthorInitial => string.IsNullOrEmpty(AuthorName) ? "?" : AuthorName[0].ToString().ToUpper();

    /// <summary>作者头像图片（服务端 URL 异步加载；null 或加载失败时回退首字母圆头像）</summary>
    [ObservableProperty]
    private BitmapImage? _authorAvatarImage;

    public ReplyItemViewModel(ICommentService commentService, CommentAvatarService avatarService, Guid parentCommentId, Models.ReplyItem reply)
    {
        _commentService = commentService;
        _avatarService = avatarService;
        ParentCommentId = parentCommentId;
        Id = reply.Id;
        AuthorUserId = reply.AuthorUserId;
        AuthorName = reply.AuthorName;
        Content = reply.Content;
        TimeText = FormatTime(reply.CreatedAt);
        LikeCount = reply.LikeCount;
        IsLiked = reply.IsLikedByUser;

        // [评论区功能] 作者头像：本地加密缓存秒显 → 后台 ETag 同步
        LoadAvatar();
    }

    /// <summary>
    /// [评论区功能] 加载作者头像：先读本地加密缓存秒显，再后台同步服务端版本（LastModified 比对）
    /// </summary>
    private void LoadAvatar()
    {
        if (AuthorUserId == Guid.Empty) return;

        // Step1: 本地缓存秒显
        var cachedPath = _avatarService.GetCachedAvatarPath(AuthorUserId);
        if (cachedPath != null)
        {
            AuthorAvatarImage = CreateAvatarImage(cachedPath);
        }

        // Step2: 后台 ETag 同步（回调在线程池线程，调度回 UI 线程）
        _ = _avatarService.SyncAvatarAsync(AuthorUserId, path =>
        {
            if (_dispatcherQueue != null && !_dispatcherQueue.HasThreadAccess)
                _dispatcherQueue.TryEnqueue(() => ApplyAvatarPath(path));
            else
                ApplyAvatarPath(path);
        });
    }

    /// <summary>应用头像路径（空串 = 清除显示，回退首字母）</summary>
    private void ApplyAvatarPath(string path)
    {
        AuthorAvatarImage = string.IsNullOrEmpty(path) ? null : CreateAvatarImage(path);
    }

    /// <summary>本地临时文件路径 → BitmapImage（URI 非法时返回 null）</summary>
    private static BitmapImage? CreateAvatarImage(string path)
    {
        try
        {
            return new BitmapImage(new Uri(path));
        }
        catch (UriFormatException)
        {
            return null;
        }
    }

    /// <summary>
    /// 切换点赞状态 — 信任服务端返回的最新结果
    /// </summary>
    [RelayCommand]
    private async Task ToggleLike()
    {
        try
        {
            var result = await _commentService.ToggleLikeReplyAsync(ParentCommentId, Id);
            IsLiked = result.Liked;
            LikeCount = result.LikeCount;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[评论] 回复点赞失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 格式化时间为相对时间字符串
    /// </summary>
    private static string FormatTime(DateTime utcTime)
    {
        var localTime = utcTime.ToLocalTime();
        var diff = DateTime.Now - localTime;

        if (diff.TotalMinutes < 1) return "刚刚";
        if (diff.TotalMinutes < 60) return $"{(int)diff.TotalMinutes} 分钟前";
        if (diff.TotalHours < 24) return $"{(int)diff.TotalHours} 小时前";
        if (diff.TotalDays < 7) return $"{(int)diff.TotalDays} 天前";
        return localTime.ToString("yyyy-MM-dd");
    }
}
