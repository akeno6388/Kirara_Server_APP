namespace Kirara_Server_WinUI.ViewModels.Comment;

/// <summary>
/// 通知跳转自动部署导航参数 — 由 NotificationJumpService 在目标实例未启动时构造，
/// 导航到 InstanceSummaryPage（先导页）后自动触发部署，部署完成自动进入工作区并跳转到目标资源。
/// </summary>
/// <param name="InstanceId">目标实例 ID</param>
/// <param name="JumpTarget">部署完成后的工作区跳转目标（携带实例/方案/源 URL）；null 时仅进入工作区</param>
public record AutoDeployNavigationParameter(Guid InstanceId, SharedContentNavigationParameter? JumpTarget);
