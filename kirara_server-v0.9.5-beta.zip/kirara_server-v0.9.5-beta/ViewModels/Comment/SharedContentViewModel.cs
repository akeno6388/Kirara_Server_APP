using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.ViewModels.Comment;

/// <summary>
/// 首页分享面板 ViewModel — 管理分享列表的加载与展示
/// 通过 IHomepageCommentService 获取首页分享数据
/// </summary>
public partial class SharedContentViewModel : ObservableObject
{
    private readonly IHomepageCommentService _homepageCommentService;
    private readonly INavigationService _navigationService;
    private readonly CommentAvatarService _avatarService;

    /// <summary>分享列表</summary>
    [ObservableProperty]
    private ObservableCollection<HomepageCommentItemViewModel> _items = new();

    /// <summary>是否正在加载</summary>
    [ObservableProperty]
    private bool _isLoading;

    /// <summary>空状态提示是否可见</summary>
    [ObservableProperty]
    private bool _isEmptyVisible = true;

    /// <summary>分享总数显示</summary>
    [ObservableProperty]
    private string _itemCountText = "0 条分享";

    /// <summary>
    /// [跨设备分享修复] 当前所在实例 ID（由宿主 SchemeHostPage 注入）。
    /// 分享面板只在实例工作区的方案宿主页内显示，用户点击"查看"时必然处于某个实例中；
    /// 分享项携带的 InstanceId 是分享者本地 GUID，其他 PC 上无效 → 回退到当前实例打开。
    /// </summary>
    public Guid CurrentInstanceId { get; set; }

    public SharedContentViewModel(
        IHomepageCommentService homepageCommentService,
        INavigationService navigationService,
        CommentAvatarService? avatarService = null)
    {
        _homepageCommentService = homepageCommentService;
        _navigationService = navigationService;
        // 分享作者头像服务（可选参数：既有调用点未传时从 DI 兜底获取）
        _avatarService = avatarService ?? App.Services.GetRequiredService<CommentAvatarService>();
    }

    /// <summary>
    /// 加载首页分享列表
    /// </summary>
    public async Task LoadHomepageCommentsAsync()
    {
        IsLoading = true;
        try
        {
            var list = await _homepageCommentService.GetHomepageCommentsAsync();

            Items.Clear();
            foreach (var item in list)
            {
                Items.Add(new HomepageCommentItemViewModel(
                    _homepageCommentService, _navigationService, _avatarService, item, CurrentInstanceId));
            }

            ItemCountText = Items.Count == 0 ? "0 条分享" : $"{Items.Count} 条分享";
            IsEmptyVisible = Items.Count == 0;
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[首页分享] 加载失败: {ex.Message}");
            IsEmptyVisible = true;
        }
        finally
        {
            IsLoading = false;
        }
    }

    /// <summary>
    /// 添加一条新分享（"发送并分享"后刷新列表）
    /// </summary>
    public void AddItem(HomepageCommentItem item)
    {
        Items.Insert(0, new HomepageCommentItemViewModel(
            _homepageCommentService, _navigationService, _avatarService, item, CurrentInstanceId));
        ItemCountText = $"{Items.Count} 条分享";
        IsEmptyVisible = false;
    }
}
