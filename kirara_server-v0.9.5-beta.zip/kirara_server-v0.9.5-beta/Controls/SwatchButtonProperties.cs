using Microsoft.UI.Xaml;

namespace Kirara_Server_WinUI.Controls;

/// <summary>
/// 主题色色块按钮附加属性 — 将选中状态挂载到 Button 上，
/// 供模板内 RelativeSource TemplatedParent 绑定解析（VM 属性无法直接用于 TemplatedParent 路径）。
/// </summary>
public static class SwatchButtonProperties
{
    /// <summary>色块选中状态（true → 白色预选框 + 勾选标记）</summary>
    public static readonly DependencyProperty IsSelectedProperty =
        DependencyProperty.RegisterAttached(
            "IsSelected",
            typeof(bool),
            typeof(SwatchButtonProperties),
            new PropertyMetadata(false));

    public static bool GetIsSelected(DependencyObject obj) =>
        (bool)obj.GetValue(IsSelectedProperty);

    public static void SetIsSelected(DependencyObject obj, bool value) =>
        obj.SetValue(IsSelectedProperty, value);
}
