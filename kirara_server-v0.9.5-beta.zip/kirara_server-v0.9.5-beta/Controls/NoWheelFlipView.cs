using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;

namespace Kirara_Server_WinUI.Controls;

/// <summary>
/// 滚轮驱动卡片横向翻页的 FlipView。
///
/// WinUI 的 FlipView 模板内部包含一个水平 ScrollViewer，滚轮事件在内部
/// ScrollViewer 处就被消费并触发翻页（FlipView 原生行为，恰好一页），
/// 因此这里不需要也不应该手动修改 SelectedIndex —— 否则会与内部翻页叠加
/// 导致一次滚轮翻两页。
///
/// 本控件的职责：
/// - 用 AddHandler(handledEventsToo: true) 捕获已被内部处理的滚轮事件
/// - 设置 e.Handled = true，阻止事件继续冒泡到父级垂直 ScrollViewer（页面不上下滚动）
/// - 边缘情况（第一张/最后一张）内部 ScrollViewer 不消费滚轮时，同样被 Handled 拦截
///
/// 翻页同样支持外部驱动：底部圆点导航 + 自动播放（SelectedIndex 绑定）。
/// 同时禁用鼠标拖拽翻页。
/// </summary>
public sealed class NoWheelFlipView : FlipView
{
    /// <summary>
    /// 是否允许触控滑动翻页（默认 true）。
    /// 设为 false 时禁用内部 ScrollViewer 的水平滑动，仅保留外部驱动翻页。
    /// </summary>
    public static readonly DependencyProperty IsSwipeEnabledProperty =
        DependencyProperty.Register(
            nameof(IsSwipeEnabled),
            typeof(bool),
            typeof(NoWheelFlipView),
            new PropertyMetadata(true, OnIsSwipeEnabledChanged));

    public bool IsSwipeEnabled
    {
        get => (bool)GetValue(IsSwipeEnabledProperty);
        set => SetValue(IsSwipeEnabledProperty, value);
    }

    public NoWheelFlipView()
    {
        // handledEventsToo=true：即使内部 ScrollViewer 已标记 Handled 也能收到
        AddHandler(PointerWheelChangedEvent, new PointerEventHandler(OnWheelIntercepted), true);
        Loaded += (_, _) => ApplySwipeSetting();
    }

    protected override void OnApplyTemplate()
    {
        base.OnApplyTemplate();
        ApplySwipeSetting();
    }

    private static void OnIsSwipeEnabledChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        ((NoWheelFlipView)d).ApplySwipeSetting();
    }

    /// <summary>
    /// 将 IsSwipeEnabled 应用到内部 ScrollViewer（控制触控滑动）。
    /// </summary>
    private void ApplySwipeSetting()
    {
        var sv = FindChildScrollViewer(this);
        if (sv == null) return;

        if (IsSwipeEnabled)
        {
            sv.HorizontalScrollMode = ScrollMode.Auto;
            sv.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
        }
        else
        {
            // 禁用水平滚动：触控滑动无法翻页（滚动被转交给父级垂直 ScrollViewer）
            sv.HorizontalScrollMode = ScrollMode.Disabled;
            sv.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
        }
    }

    /// <summary>
    /// 递归查找视觉树中的第一个 ScrollViewer（FlipView 模板内的滑动宿主）。
    /// </summary>
    private static ScrollViewer? FindChildScrollViewer(DependencyObject? root)
    {
        if (root == null) return null;
        int count = VisualTreeHelper.GetChildrenCount(root);
        for (int i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(root, i);
            if (child is ScrollViewer sv) return sv;
            var found = FindChildScrollViewer(child);
            if (found != null) return found;
        }
        return null;
    }

    /// <summary>
    /// 拦截滚轮：阻止事件冒泡到父级垂直 ScrollViewer（页面不上下滚动）。
    ///
    /// 翻页由 FlipView 内部 ScrollViewer 的滚轮处理完成（恰好一页）。
    /// 这里不手动修改 SelectedIndex —— 内部 ScrollViewer 已先翻页并标记 Handled，
    /// 手动再翻会导致一次滚轮翻两页。
    /// </summary>
    private void OnWheelIntercepted(object sender, PointerRoutedEventArgs e)
    {
        // 标记已处理：内部 ScrollViewer 已翻页；
        // 边缘情况（第一张/最后一张）内部不消费滚轮时，也在此拦截防止冒泡到父级页面
        e.Handled = true;
    }

    protected override void OnPointerPressed(PointerRoutedEventArgs e)
    {
        // 阻止 FlipView 捕获指针并进入拖拽翻页状态
        // 不调用 base，事件继续冒泡（父级 ScrollViewer 可正常拖动滚动）
    }

    protected override void OnPointerMoved(PointerRoutedEventArgs e)
    {
        // 阻止拖拽翻页
        // 不调用 base，事件继续冒泡
    }

    protected override void OnPointerReleased(PointerRoutedEventArgs e)
    {
        // 阻止拖拽翻页
        // 不调用 base，事件继续冒泡
    }
}
