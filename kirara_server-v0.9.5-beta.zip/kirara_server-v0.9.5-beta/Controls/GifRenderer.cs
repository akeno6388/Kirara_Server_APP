using System.Runtime.InteropServices.WindowsRuntime;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media.Imaging;
using Windows.Graphics.Imaging;
using Windows.Storage.Streams;

namespace Kirara_Server_WinUI.Controls;

/// <summary>
/// WinUI 3 GIF 动图渲染器。
/// 由于 WinUI 3 的 Image 控件不支持 GIF 动画，此渲染器通过
/// BitmapDecoder 预解码所有帧 + System.Threading.Timer 后台驱动 + 低优先级 UI 派发来实现流畅动画。
/// 
/// 性能优化要点：
/// - 加载时一次性预解码所有帧到 SoftwareBitmap[]，避免每帧实时解码
/// - 复用单个 SoftwareBitmapSource，通过 SetBitmapAsync 切换帧
/// - 使用 System.Threading.Timer（后台线程）替代 DispatcherQueueTimer，不占用 UI 线程调度
/// - 帧更新通过 TryEnqueue(Low priority) 派发，不跟 Storyboard 动画抢帧
/// - 支持 Pause/Resume，页面不可见时完全停止 GPU 纹理上传
/// </summary>
public class GifRenderer : IDisposable
{
    private readonly DispatcherQueue _dispatcherQueue;
    private readonly SoftwareBitmapSource _bitmapSource;
    private System.Threading.Timer? _timer;
    private SoftwareBitmap[]? _frames;
    private int[]? _delays;
    private int _frameIndex;
    private int _loadVersion;
    private bool _disposed;
    private bool _isPaused;
    private int _tickGuard;             // 防重入：确保同一时刻只有一个 tick 在处理
    private int _setBitmapInFlight;      // 防重入：确保同一时刻只有一个 SetBitmapAsync 在进行

    /// <summary>是否有动画（帧数大于 1）</summary>
    public bool IsAnimating { get; private set; }

    public GifRenderer(Image target)
    {
        _dispatcherQueue = target.DispatcherQueue;
        _bitmapSource = new SoftwareBitmapSource();
        target.Source = _bitmapSource;
    }

    /// <summary>
    /// 加载并自动播放 GIF 文件。
    /// 如果只有一帧，则作为静态图显示。
    /// </summary>
    public async Task LoadGifAsync(string filePath)
    {
        Stop();
        DisposeFrames();

        // 递增版本号：若多次并发调用，旧 Task.Run 的结果会被丢弃
        var version = ++_loadVersion;

        try
        {
            // 将所有重活（I/O + 解码）卸载到后台线程，不阻塞 UI
            var (frames, delays, frameCount) = await Task.Run(async () =>
            {
                var fileBytes = await File.ReadAllBytesAsync(filePath);
                var delays = ParseFrameDelays(fileBytes);

                using var memStream = new InMemoryRandomAccessStream();
                await memStream.WriteAsync(fileBytes.AsBuffer());
                memStream.Seek(0);
                var decoder = await BitmapDecoder.CreateAsync(BitmapDecoder.GifDecoderId, memStream);

                var frameCount = (int)decoder.FrameCount;
                var frames = new SoftwareBitmap[frameCount];

                for (int i = 0; i < frameCount; i++)
                {
                    var frame = await decoder.GetFrameAsync((uint)i);
                    var pixelData = await frame.GetPixelDataAsync(
                        BitmapPixelFormat.Bgra8,
                        BitmapAlphaMode.Premultiplied,
                        new BitmapTransform(),
                        ExifOrientationMode.IgnoreExifOrientation,
                        ColorManagementMode.DoNotColorManage);

                    frames[i] = SoftwareBitmap.CreateCopyFromBuffer(
                        pixelData.DetachPixelData().AsBuffer(),
                        BitmapPixelFormat.Bgra8,
                        (int)frame.PixelWidth,
                        (int)frame.PixelHeight,
                        BitmapAlphaMode.Premultiplied);
                }

                return (frames, delays, frameCount);
            });

            // Task.Run 期间可能被 Dispose 或新一轮 LoadGifAsync 覆盖
            if (_disposed || _loadVersion != version)
            {
                foreach (var f in frames)
                    f?.Dispose();
                return;
            }

            _frames = frames;
            _delays = delays;

            // 显示第一帧（SetBitmapAsync 需在 UI 线程）
            _frameIndex = 0;
            await _bitmapSource.SetBitmapAsync(_frames[0]);

            if (frameCount > 1)
            {
                StartAnimation();
            }
        }
        catch (Exception ex)
        {
            System.Diagnostics.Debug.WriteLine($"[GifRenderer] GIF 加载失败: {ex.Message}");
        }
    }

    /// <summary>
    /// 暂停动画（保留当前帧显示，停止定时器）。
    /// 页面不可见时调用，避免后台 GIF 纹理上传竞争 UI 线程和 GPU。
    /// </summary>
    public void Pause()
    {
        if (!IsAnimating || _isPaused || _disposed) return;
        _isPaused = true;
        _timer?.Change(Timeout.Infinite, Timeout.Infinite);
    }

    /// <summary>
    /// 恢复动画（从暂停状态继续播放）。
    /// </summary>
    public void Resume()
    {
        if (!_isPaused || !IsAnimating || _disposed) return;
        _isPaused = false;
        var delay = GetDelay(_frameIndex);
        _timer?.Change(delay, Timeout.Infinite);
    }

    /// <summary>
    /// 停止动画（保留最后一帧显示，不释放位图资源）。
    /// </summary>
    public void Stop()
    {
        _isPaused = false;
        if (_timer != null)
        {
            _timer.Dispose();
            _timer = null;
        }
        IsAnimating = false;
        _delays = null;
        // _frames 不在此释放：_bitmapSource 仍引用它们。
        // 由 DisposeFrames() 或下次 LoadGifAsync 释放。
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        Stop();
        DisposeFrames();
    }

    private void DisposeFrames()
    {
        if (_frames == null) return;
        foreach (var f in _frames)
            f?.Dispose();
        _frames = null;
    }

    // ================================================================
    //  内部实现
    // ================================================================

    private void StartAnimation()
    {
        if (_frames == null || _frames.Length <= 1 || _disposed) return;

        // 使用 System.Threading.Timer（后台线程触发），不占用 UI 线程调度配额。
        // 每次 tick 只做两件事：
        //   1. 以 DispatcherQueuePriority.Low 派发 SetBitmapAsync 到 UI 线程
        //   2. 调度下一次 tick
        _timer = new System.Threading.Timer(_ =>
        {
            if (_disposed || _frames == null || _isPaused) return;

            // 原子防重入：同一时刻只允许一个 tick 在处理
            if (Interlocked.CompareExchange(ref _tickGuard, 1, 0) != 0) return;

            try
            {
                _frameIndex = (_frameIndex + 1) % _frames.Length;
                var nextDelay = GetDelay(_frameIndex);

                // 低优先级派发到 UI 线程：不跟 Storyboard 动画 / 页面切换抢帧
                _dispatcherQueue.TryEnqueue(DispatcherQueuePriority.Low, async () =>
                {
                    // 防止多个 SetBitmapAsync 同时调用同一个 SoftwareBitmapSource，
                    // 后者不支持并发，前一个调用未完成时新调用会抛出 TaskCanceledException。
                    if (Interlocked.CompareExchange(ref _setBitmapInFlight, 1, 0) != 0) return;

                    try
                    {
                        if (!_disposed && _frames != null && !_isPaused)
                            await _bitmapSource.SetBitmapAsync(_frames[_frameIndex]);
                    }
                    catch (OperationCanceledException)
                    {
                        // SoftwareBitmapSource 不支持并发 SetBitmapAsync。
                        // 上一个调用尚未完成时新调用会被取消，这是预期行为，无需报错。
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"[GifRenderer] SetBitmapAsync 失败: {ex.Message}");
                    }
                    finally
                    {
                        Interlocked.Exchange(ref _setBitmapInFlight, 0);
                    }
                });

                // 调度下一次 tick（仅在未暂停时）
                if (!_isPaused && _timer != null)
                    _timer.Change(nextDelay, Timeout.Infinite);
            }
            finally
            {
                Interlocked.Exchange(ref _tickGuard, 0);
            }
        }, null, GetDelay(0), Timeout.Infinite);

        IsAnimating = true;
    }

    private int GetDelay(int index)
    {
        if (_delays == null || _delays.Length == 0)
            return 100;

        return _delays[index % _delays.Length];
    }

    /// <summary>
    /// 从 GIF 文件字节中解析每一帧的延迟时间（毫秒）。
    /// 解析 GIF 的 Graphics Control Extension 块中的 Delay Time 字段。
    /// </summary>
    private static int[] ParseFrameDelays(byte[] bytes)
    {
        var delays = new List<int>();
        try
        {
            if (bytes.Length < 13) return new[] { 100 };

            // 跳过 Header (6) + Logical Screen Descriptor (7) = 13
            int pos = 13;

            // 跳过全局颜色表
            byte packed = bytes[10];
            if ((packed & 0x80) != 0)
            {
                int tableSize = 3 * (2 << (packed & 0x07));
                pos += tableSize;
            }

            while (pos < bytes.Length)
            {
                byte blockType = bytes[pos];

                if (blockType == 0x21) // Extension introducer
                {
                    byte label = bytes[pos + 1];
                    if (label == 0xF9) // Graphics Control Extension
                    {
                        int delayCs = bytes[pos + 4] | (bytes[pos + 5] << 8);
                        int delayMs = Math.Max(delayCs * 10, 10); // 最少 10ms
                        delays.Add(delayMs);
                        pos += 8;
                    }
                    else
                    {
                        // 跳过其他扩展块
                        pos += 2;
                        while (pos < bytes.Length && bytes[pos] != 0x00)
                        {
                            int blockLen = bytes[pos];
                            pos += 1 + blockLen;
                        }
                        pos++; // 跳过 0x00 终止符
                    }
                }
                else if (blockType == 0x2C) // Image Descriptor
                {
                    pos += 10; // 跳过 descriptor 头部 (10 bytes)
                    // 检查局部颜色表
                    byte localPacked = bytes[pos - 1];
                    if ((localPacked & 0x80) != 0)
                    {
                        int tableSize = 3 * (2 << (localPacked & 0x07));
                        pos += tableSize;
                    }
                    pos++; // LZW minimum code size
                    while (pos < bytes.Length && bytes[pos] != 0x00)
                    {
                        int blockLen = bytes[pos];
                        pos += 1 + blockLen;
                    }
                    pos++; // 跳过 0x00 终止符
                }
                else if (blockType == 0x3B) // Trailer
                {
                    break;
                }
                else
                {
                    pos++;
                }
            }
        }
        catch
        {
            // 解析失败，使用默认值
        }

        if (delays.Count == 0)
            delays.Add(100);

        return delays.ToArray();
    }
}
