using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml;
using Windows.Foundation;

namespace Kirara_Server_WinUI.Controls;

/// <summary>
/// 自动换行面板 — 每行子元素居中对齐。
/// 当一行未排满时，子元素均匀分布在行中线两侧，而非左对齐。
/// </summary>
public class CenterWrapPanel : Panel
{
    public static readonly DependencyProperty ItemWidthProperty =
        DependencyProperty.Register(nameof(ItemWidth), typeof(double), typeof(CenterWrapPanel),
            new PropertyMetadata(double.NaN, OnLayoutPropertyChanged));

    public static readonly DependencyProperty ItemHeightProperty =
        DependencyProperty.Register(nameof(ItemHeight), typeof(double), typeof(CenterWrapPanel),
            new PropertyMetadata(double.NaN, OnLayoutPropertyChanged));

    public double ItemWidth
    {
        get => (double)GetValue(ItemWidthProperty);
        set => SetValue(ItemWidthProperty, value);
    }

    public double ItemHeight
    {
        get => (double)GetValue(ItemHeightProperty);
        set => SetValue(ItemHeightProperty, value);
    }

    private static void OnLayoutPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        => ((CenterWrapPanel)d).InvalidateMeasure();

    protected override Size MeasureOverride(Size availableSize)
    {
        var itemWidth = double.IsNaN(ItemWidth) ? 0 : ItemWidth;
        var itemHeight = double.IsNaN(ItemHeight) ? 0 : ItemHeight;

        var availableWidth = availableSize.Width;
        double totalHeight = 0;
        double rowWidth = 0;
        double rowMaxHeight = 0;

        foreach (var child in Children)
        {
            var childAvailable = new Size(
                itemWidth > 0 ? itemWidth : availableWidth,
                itemHeight > 0 ? itemHeight : double.PositiveInfinity);

            child.Measure(childAvailable);

            var desiredW = itemWidth > 0 ? itemWidth : child.DesiredSize.Width;
            var desiredH = itemHeight > 0 ? itemHeight : child.DesiredSize.Height;

            // 换行检测
            if (rowWidth + desiredW > availableWidth && rowWidth > 0)
            {
                totalHeight += rowMaxHeight;
                rowWidth = 0;
                rowMaxHeight = 0;
            }

            rowWidth += desiredW;
            rowMaxHeight = Math.Max(rowMaxHeight, desiredH);
        }

        // 最后一行
        totalHeight += rowMaxHeight;

        return new Size(availableSize.Width, totalHeight);
    }

    protected override Size ArrangeOverride(Size finalSize)
    {
        var itemWidth = double.IsNaN(ItemWidth) ? 0 : ItemWidth;
        var itemHeight = double.IsNaN(ItemHeight) ? 0 : ItemHeight;

        var availableWidth = finalSize.Width;

        // 第一遍：分行
        var rows = new List<List<UIElement>>();
        var currentRow = new List<UIElement>();
        double currentRowWidth = 0;

        foreach (var child in Children)
        {
            var desiredW = itemWidth > 0 ? itemWidth : child.DesiredSize.Width;

            if (currentRowWidth + desiredW > availableWidth && currentRow.Count > 0)
            {
                rows.Add(currentRow);
                currentRow = new List<UIElement>();
                currentRowWidth = 0;
            }

            currentRow.Add(child);
            currentRowWidth += desiredW;
        }

        if (currentRow.Count > 0)
            rows.Add(currentRow);

        // 第二遍：居中排列每行
        double yOffset = 0;

        foreach (var row in rows)
        {
            double rowTotalWidth = 0;
            double rowMaxHeight = 0;

            foreach (var child in row)
            {
                var desiredW = itemWidth > 0 ? itemWidth : child.DesiredSize.Width;
                var desiredH = itemHeight > 0 ? itemHeight : child.DesiredSize.Height;
                rowTotalWidth += desiredW;
                rowMaxHeight = Math.Max(rowMaxHeight, desiredH);
            }

            // 计算居中起始 X
            double xOffset = (availableWidth - rowTotalWidth) / 2;

            foreach (var child in row)
            {
                var w = itemWidth > 0 ? itemWidth : child.DesiredSize.Width;
                var h = itemHeight > 0 ? itemHeight : child.DesiredSize.Height;

                child.Arrange(new Rect(xOffset, yOffset, w, h));
                xOffset += w;
            }

            yOffset += rowMaxHeight;
        }

        return finalSize;
    }
}