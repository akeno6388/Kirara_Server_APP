namespace Kirara_Server_WinUI.Schemes.ThirdParty;

/// <summary>
/// 第三方方案扫描器（桩）
/// 负责扫描用户导入的可执行文件并注册为第三方方案
/// </summary>
public class ThirdPartySchemeLoader
{
    private readonly List<ThirdPartySchemeInfo> _schemes = new();

    public IReadOnlyList<ThirdPartySchemeInfo> LoadedSchemes => _schemes.AsReadOnly();

    public void RegisterScheme(string name, string executablePath, string? arguments = null)
    {
        _schemes.Add(new ThirdPartySchemeInfo
        {
            Name = name,
            ExecutablePath = executablePath,
            Arguments = arguments,
            RegisteredAt = DateTime.UtcNow
        });
    }

    public void RemoveScheme(string executablePath)
    {
        _schemes.RemoveAll(s => s.ExecutablePath.Equals(executablePath, StringComparison.OrdinalIgnoreCase));
    }
}

public class ThirdPartySchemeInfo
{
    public string Name { get; set; } = string.Empty;
    public string ExecutablePath { get; set; } = string.Empty;
    public string? Arguments { get; set; }
    public DateTime RegisteredAt { get; set; }
}
