using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.Views.Controls;

namespace Kirara_Server_WinUI.Schemes.Service;

/// <summary>
/// OpenVPN 方案（服务实例版）— 自研管理界面（CustomControl）+ openvpn.exe 子进程 + management 管理接口。
///
/// 与 <see cref="BuiltIn.OpenVpnScheme"/> 的关键差异：
/// - 【不】从服务器 API 下载配置文件：启动时【不】调用 OvpnConfigCacheService，
///   配置文件由用户在本方案管理界面中手动导入（每实例隔离，支持多份）；
/// - 自动登录凭据【不】来自创建实例时绑定的令牌，而是本方案本地保存的凭据
///   （用户勾选"自动登录"时加密保存；下次启动自动用它连接）；
/// - 不支持重链接令牌功能（方案标签栏菜单中已隐藏该选项）。
///
/// 设计要点：
/// - UIKind 为 CustomControl，通过 OpenVpnServiceControl 自研面板实现
///   配置导入/选择/账密输入/自动登录/连接/断开/状态/流量/日志展示。
/// - 服务器地址从所选 .ovpn 的 remote 指令解析（展示用；连接实际使用 .ovpn 内容）。
/// - 连接引擎：openvpn.exe 子进程 + --management-client 反向连接模式（详见 VpnConnectionService）。
/// </summary>
public class OpenVpnServiceScheme : BaseScheme
{
    public override Guid Id => Guid.Parse("b2000013-0000-0000-0000-000000000001");
    public override string Name => "openvpn-server";
    public override string DisplayName => "OpenVPN";
    public override string Description => "访问服务器内网资源，支持自定义配置文件";
    public override InstanceType InstanceType => InstanceType.ServiceInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.CustomControl;
    public override string IconGlyph => "\uE774";
    public override int SortOrder => 113;

    /// <summary>
    /// URL 注册表键（服务器地址回退来源；本方案连接实际使用 .ovpn 内容，此键仅占位）
    /// </summary>
    public override string? DefaultUrlKey => "openvpn-server";

    /// <summary>所属实例 ID（InitializeAsync 时记录，GetUI 时用于定位实例隔离的配置库）</summary>
    private Guid _instanceId;

    /// <summary>
    /// 初始化方案 — 服务版：仅记录实例 ID，【不】连接服务器 API 下载配置文件。
    /// 即使本地无任何配置文件也返回成功（面板以空列表呈现，由用户手动导入）。
    /// 自动登录凭据来自本方案本地保存的配置（OpenVpnProfileStore），与绑定令牌无关。
    /// </summary>
    public override Task<SchemeResult> InitializeAsync(SchemeBinding binding)
    {
        _instanceId = binding.InstanceId;
        return Task.FromResult(SchemeResult.Success());
    }

    /// <summary>
    /// 获取方案界面 — 返回服务版 OpenVPN 管理面板（配置导入/选择/账密/自动登录）
    /// </summary>
    public override SchemeUI GetUI()
    {
        SchemeUI ui = new() { Kind = SchemeUIKind.CustomControl };
        ui.CustomControl = new OpenVpnServiceControl(_instanceId, DisplayName);
        return ui;
    }

    /// <summary>
    /// 方案停用：断开活动 VPN 连接
    /// （当前宿主暂未调用此方法，保留完整实现供未来清理链路使用）
    /// </summary>
    public override async Task<SchemeResult> DeinitializeAsync()
    {
        var vpnService = App.Services.GetRequiredService<VpnConnectionService>();
        await vpnService.DisconnectAsync();
        return SchemeResult.Success();
    }
}
