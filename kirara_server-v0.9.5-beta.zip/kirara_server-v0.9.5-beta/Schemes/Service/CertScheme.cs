using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.Service;

/// <summary>
/// 证书签发平台方案（桩）
/// </summary>
public class CertScheme : BaseScheme
{
    public override Guid Id => Guid.Parse("b2000009-0000-0000-0000-000000000001");
    public override string Name => "cert";
    public override string DisplayName => "证书签发平台";
    public override string Description => "签发内网域名、IP证书";
    public override InstanceType InstanceType => InstanceType.ServiceInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uE7E1";
    public override int SortOrder => 109;
}
