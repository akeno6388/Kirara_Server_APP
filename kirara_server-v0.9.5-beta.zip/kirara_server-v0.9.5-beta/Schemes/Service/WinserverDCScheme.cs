using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.Service;

/// <summary>
/// Windows Server 域控管理方案（桩）
/// </summary>
public class WinserverDCScheme : BaseScheme
{
    public override Guid Id => Guid.Parse("b2000007-0000-0000-0000-000000000001");
    public override string Name => "winserver-dc";
    public override string DisplayName => "Winserver-DC 管理";
    public override string Description => "域控管理后台";
    public override InstanceType InstanceType => InstanceType.ServiceInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.RDP;
    public override string IconGlyph => "\uE7B8";
    public override int SortOrder => 107;
}
