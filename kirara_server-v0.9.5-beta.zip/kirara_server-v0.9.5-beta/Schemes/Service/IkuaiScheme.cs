using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.Service;

/// <summary>
/// 爱快 iKuai 路由管理方案
/// 单步登录：填用户名 + 密码 + 点击登录按钮
/// 基于 Ant Design (React) 框架，需 _valueTracker 预填序列
/// </summary>
public class IkuaiScheme : BaseScheme, IAutoLoginProvider
{
    public override Guid Id => Guid.Parse("b2000004-0000-0000-0000-000000000001");
    public override string Name => "ikuai";
    public override string DisplayName => "爱快路由";
    public override string Description => "爱快路由管理后台";
    public override InstanceType InstanceType => InstanceType.ServiceInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uE7B9";
    public override int SortOrder => 110;

    // ——— IAutoLoginProvider 实现 ———

    /// <summary>
    /// 页面就绪：用户名输入框出现
    /// </summary>
    public string? PageReadyDomSelector => "#email";

    /// <summary>
    /// 登录表单判据：用户名输入框（仅登录页存在，成功页无）→ 可见即未登录，优先于 URL 正向
    /// </summary>
    public string? LoginFormDomSelector => "#email";

    /// <summary>
    /// 单步登录：填用户名 + 密码 + 点击登录
    /// Ant Design React 受控组件，使用 _valueTracker 预填序列
    /// </summary>
    public string? GetAutoLoginScript(Token token)
    {
        if (string.IsNullOrWhiteSpace(token.AccountName) ||
            string.IsNullOrWhiteSpace(token.AccountPassword))
            return null;

        var escapedUser = EscapeForJsStringLiteral(token.AccountName);
        var escapedPass = EscapeForJsStringLiteral(token.AccountPassword);

        return $$"""
            (() => {
                const u = document.getElementById('email');
                const p = document.getElementById('password');
                const b = document.querySelector('button.ant-btn-primary');
                if (!u || !p || !b) return 'no_form';

                const ns = Object.getOwnPropertyDescriptor(
                    HTMLInputElement.prototype, 'value').set;

                // —— 预填用户名 ——
                u.focus();
                ns.call(u, 'a');
                u.dispatchEvent(new Event('input', { bubbles: true }));
                ns.call(u, '');
                u.dispatchEvent(new Event('input', { bubbles: true }));
                ns.call(u, '{{escapedUser}}');
                u.dispatchEvent(new Event('input', { bubbles: true }));
                u.dispatchEvent(new Event('change', { bubbles: true }));

                // —— 预填密码 ——
                p.focus();
                ns.call(p, 'a');
                p.dispatchEvent(new Event('input', { bubbles: true }));
                ns.call(p, '');
                p.dispatchEvent(new Event('input', { bubbles: true }));
                ns.call(p, '{{escapedPass}}');
                p.dispatchEvent(new Event('input', { bubbles: true }));
                p.dispatchEvent(new Event('change', { bubbles: true }));

                b.click();
                return 'ok';
            })();
            """;
    }

    /// <summary>
    /// 登录成功后 URL 特征：/ui/#/systemOverview
    /// </summary>
    public string? LoginSuccessUrlFragment => "#/systemOverview";

    /// <summary>
    /// 登录成功后 DOM 特征：内容容器（仅登录后出现）
    /// </summary>
    public string? LoginSuccessDomSelector => "#article";

    /// <summary>
    /// 通知/维护页面特征
    /// </summary>
    public string? NoticeUrlFragment => "notice";

    /// <summary>
    /// 登录页反向排除
    /// </summary>
    public string? LoginPageUrlFragment => "#/login";
}
