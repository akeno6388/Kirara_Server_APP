using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.Service;

/// <summary>
/// Lenovo IMM (Integrated Management Module) 服务器远程管理方案
/// Dojo Toolkit (dijit) 旧框架，标准 HTML POST 表单登录
/// 登录前：index.php，存在 #user / #password
/// 登录后：index-console.php，存在 #main
/// 加载较慢：登录页和成功页的 DOM 渲染都需要较长时间
/// </summary>
public class ImmScheme : BaseScheme, IAutoLoginProvider
{
    public override Guid Id => Guid.Parse("b2000006-0000-0000-0000-000000000001");
    public override string Name => "imm";
    public override string DisplayName => "IMM 管理";
    public override string Description => "Lenovo 服务器远程管理";
    public override InstanceType InstanceType => InstanceType.ServiceInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uE770";
    public override int SortOrder => 112;

    // ——— IAutoLoginProvider 实现 ———

    /// <summary>
    /// 页面就绪：用户名输入框出现（Dojo 渲染较慢，轮询等待足够）
    /// </summary>
    public string? PageReadyDomSelector => "#user";

    /// <summary>
    /// 登录表单判据：用户名输入框（仅登录页存在，成功页 console 无表单）→ 可见即未登录，优先于 URL 正向
    /// </summary>
    public string? LoginFormDomSelector => "#user";

    /// <summary>
    /// 延迟到工作区登录：IMM 登录页和成功页加载都极慢，
    /// 不阻塞多方案并行令牌链接阶段
    /// </summary>
    public bool DeferLoginToWorkspace => true;

    /// <summary>
    /// 登录后等待成功页渲染：IMM 的 console 页加载非常慢，给 20s 缓冲
    /// </summary>
    public int PostLoginDelayMs => 20000;

    /// <summary>
    /// 单步登录：填用户名 + 密码 + 点击登录
    /// Dojo 框架，标准 INPUT 元素，使用 NativeValueSetter + InputEvent
    /// </summary>
    public string? GetAutoLoginScript(Token token)
    {
        if (string.IsNullOrWhiteSpace(token.AccountName) ||
            string.IsNullOrWhiteSpace(token.AccountPassword))
            return null;

        var escapedUser = EscapeForJsStringLiteral(token.AccountName);
        var escapedPass = EscapeForJsStringLiteral(token.AccountPassword);

        return $$"""
            (() => {
                const u = document.getElementById('user');
                const p = document.getElementById('password');
                const btn = document.getElementById('btnLogin');
                if (!u || !p || !btn) return 'no_form';

                const ns = Object.getOwnPropertyDescriptor(
                    HTMLInputElement.prototype, 'value').set;

                // —— 填入用户名 ——
                ns.call(u, '{{escapedUser}}');
                u.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedUser}}' }));
                u.dispatchEvent(new Event('change', { bubbles: true }));
                u.dispatchEvent(new Event('blur', { bubbles: true }));

                // —— 填入密码 ——
                ns.call(p, '{{escapedPass}}');
                p.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedPass}}' }));
                p.dispatchEvent(new Event('change', { bubbles: true }));
                p.dispatchEvent(new Event('blur', { bubbles: true }));

                // —— 鼠标事件链触发 Dojo dijit 按钮 ——
                btn.dispatchEvent(new MouseEvent('mousedown',
                    { bubbles: true, cancelable: true }));
                btn.dispatchEvent(new MouseEvent('mouseup',
                    { bubbles: true, cancelable: true }));
                btn.dispatchEvent(new MouseEvent('click',
                    { bubbles: true, cancelable: true }));

                return 'ok';
            })();
            """;
    }

    /// <summary>
    /// 登录成功后 URL 跳转到 index-console.php
    /// </summary>
    public string? LoginSuccessUrlFragment => "index-console.php";

    /// <summary>
    /// 登录成功后 DOM 特征：主容器 #main（登录页不存在）
    /// </summary>
    public string? LoginSuccessDomSelector => "#main";

    /// <summary>
    /// 通知/维护页面特征
    /// </summary>
    public string? NoticeUrlFragment => "notice";

    /// <summary>
    /// 登录页 URL 特征
    /// </summary>
    public string? LoginPageUrlFragment => "index.php";
}
