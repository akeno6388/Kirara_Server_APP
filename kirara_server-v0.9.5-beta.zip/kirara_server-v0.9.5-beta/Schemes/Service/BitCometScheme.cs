using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.Service;

/// <summary>
/// BitComet 方案 — BitComet 下载服务器，支持远程下载。
/// WebView2 渲染（BitComet WebUI，Vuetify 3 框架）；单步自动登录。
///
/// 登录状态识别（实测）：
/// - 登录页与成功页 URL 相同（均为 /webui/）→ 无法用 URL 特征，完全依赖 DOM
/// - 登录页：input.v-field__input（placeholder"输入用户名"/"输入密码"）+ button[type="submit"]"登入"
/// - 登录成功：任务列表表格 .v-data-table（v-data-table__td、进度条）——登录页不存在
/// </summary>
public class BitCometScheme : BaseScheme, IAutoLoginProvider
{
    public override Guid Id => Guid.Parse("b2000014-0000-0000-0000-000000000001");
    public override string Name => "bitcomet";
    public override string DisplayName => "BitComet";
    public override string Description => "BitComet下载服务器，支持远程下载";
    public override InstanceType InstanceType => InstanceType.ServiceInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uE896";
    public override int SortOrder => 114;

    // ——— IAutoLoginProvider 实现（单步登录，Vuetify 3）———

    /// <summary>
    /// 页面就绪标志：密码输入框出现即表示登录页已渲染。
    /// 同时作为登录表单反向排除特征（成功页任务列表无密码框）。
    /// </summary>
    public string? PageReadyDomSelector => "input[type=\"password\"]";

    /// <summary>
    /// 登录表单判据：密码输入框（成功页任务列表无密码框）→ 可见即未登录，优先于 URL 正向
    /// </summary>
    public string? LoginFormDomSelector => "input[type=\"password\"]";

    /// <summary>
    /// 单步方案：无预登录步骤
    /// </summary>
    public string? GetPreLoginScript(Token? token) => null;

    /// <summary>
    /// 填入用户名/密码并点击"登入"按钮。
    /// Vuetify 3 为 Vue 受控组件，需原生 setter + InputEvent 触发双向绑定。
    /// </summary>
    public string? GetAutoLoginScript(Token token)
    {
        if (string.IsNullOrWhiteSpace(token.AccountName) ||
            string.IsNullOrWhiteSpace(token.AccountPassword))
            return null;

        var escapedUser = EscapeForJsStringLiteral(token.AccountName);
        var escapedPass = EscapeForJsStringLiteral(token.AccountPassword);

        return $$"""
            (() => {
                const u = document.querySelector('input.v-field__input[type="text"]');
                const p = document.querySelector('input.v-field__input[type="password"]');
                if (!u || !p) return 'no_form';

                const ns = Object.getOwnPropertyDescriptor(
                    HTMLInputElement.prototype, 'value').set;

                ns.call(u, '{{escapedUser}}');
                u.dispatchEvent(new InputEvent('input', { bubbles: true }));
                u.dispatchEvent(new Event('change', { bubbles: true }));

                ns.call(p, '{{escapedPass}}');
                p.dispatchEvent(new InputEvent('input', { bubbles: true }));
                p.dispatchEvent(new Event('change', { bubbles: true }));

                // 点击"登入"按钮（Vuetify：唯一 submit 按钮）
                const b = document.querySelector('button[type="submit"]');
                if (b) { b.click(); return 'clicked'; }
                return 'no_btn';
            })();
            """;
    }

    /// <summary>
    /// 登录成功 URL 特征：null（登录页与成功页 URL 相同，均为 /webui/，无法用 URL 区分）
    /// </summary>
    public string? LoginSuccessUrlFragment => null;

    /// <summary>
    /// 登录成功后任务列表表格（Vuetify v-data-table），登录页不存在。
    /// </summary>
    public string? LoginSuccessDomSelector => ".v-data-table";

    /// <summary>
    /// 登录页 URL 特征：null（登录页与成功页 URL 相同，无法反向排除，依赖 DOM 判据）
    /// </summary>
    public string? LoginPageUrlFragment => null;

    /// <summary>
    /// 维护通知页 URL 特征
    /// </summary>
    public string? NoticeUrlFragment => "notice";
}
