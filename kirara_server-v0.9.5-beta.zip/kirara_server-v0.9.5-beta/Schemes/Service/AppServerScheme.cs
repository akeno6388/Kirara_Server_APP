using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.Service;

/// <summary>
/// APP Server 管理方案（群晖 DSM）
/// 三步登录流程：输入用户名 → 下一步 → 输入密码 + 保持登录 → 登录
/// </summary>
public class AppServerScheme : BaseScheme, IAutoLoginProvider
{
    public override Guid Id => Guid.Parse("b2000001-0000-0000-0000-000000000001");
    public override string Name => "appserver";
    public override string DisplayName => "APP Server 管理";
    public override string Description => "应用服务器管理后台";
    public override InstanceType InstanceType => InstanceType.ServiceInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uE712";
    public override int SortOrder => 101;

    // ——— IAutoLoginProvider 实现 ———

    /// <summary>
    /// 登录页就绪标志：用户名 INPUT 出现即表示页面已渲染
    /// </summary>
    public string? PageReadyDomSelector => "[syno-id=\"account-panel-next-btn\"]";

    /// <summary>
    /// 登录表单判据：DSM 登录下一步按钮（成功页桌面无）→ 可见即未登录，优先于 URL 正向
    /// </summary>
    public string? LoginFormDomSelector => "[syno-id=\"account-panel-next-btn\"]";

    /// <summary>
    /// 【步骤1】填入用户名，用 InputEvent 让 React 受控组件识别，然后点击下一步
    /// </summary>
    public string? GetPreLoginScript(Token? token)
    {
        if (token == null || string.IsNullOrWhiteSpace(token.AccountName))
            return null;

        var escapedUser = EscapeForJsStringLiteral(token.AccountName);

        return $$"""
            (() => {
                const u = document.querySelector('[syno-id="username"]');
                const n = document.querySelector('[syno-id="account-panel-next-btn"]');
                if (!u || !n) return 'no_form';

                const ns = Object.getOwnPropertyDescriptor(
                    HTMLInputElement.prototype, 'value').set;

                ns.call(u, '{{escapedUser}}');
                u.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedUser}}' }));
                u.dispatchEvent(new Event('change', { bubbles: true }));

                n.click();
                return 'clicked';
            })();
            """;
    }

    /// <summary>
    /// 等 DSM React 处理填值 + 路由切换
    /// </summary>
    public int PreLoginDelayMs => 2000;

    /// <summary>
    /// 密码页就绪标志：密码 INPUT 出现
    /// </summary>
    public string? PasswordPageDomSelector => "[syno-id=\"password\"]";

    /// <summary>
    /// 【步骤2】填入密码，勾选"保持登录"，点击登录
    /// </summary>
    public string? GetAutoLoginScript(Token token)
    {
        if (string.IsNullOrWhiteSpace(token.AccountPassword))
            return null;

        var escapedPass = EscapeForJsStringLiteral(token.AccountPassword);

        return $$"""
            (() => {
                const p = document.querySelector('[syno-id="password"]');
                if (!p) return 'no_form';

                const ns = Object.getOwnPropertyDescriptor(
                    HTMLInputElement.prototype, 'value').set;

                ns.call(p, '{{escapedPass}}');
                p.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedPass}}' }));
                p.dispatchEvent(new Event('change', { bubbles: true }));

                // 勾选"保持登录"（点击内部原生 checkbox）
                const cb = document.querySelector('.login-checkbox input[type="checkbox"]');
                if (cb && !cb.checked) {
                    cb.click();
                }

                return 'ok';
            })();
            """;
    }

    /// <summary>
    /// 登录成功凭 DOM 检测（不依赖 URL，DSM hash 路由不可靠）
    /// </summary>
    public string? LoginSuccessUrlFragment => null;

    /// <summary>
    /// 登录成功后 DSM 桌面特征 DOM：sds-desktop 容器
    /// </summary>
    public string? LoginSuccessDomSelector => "#sds-desktop";

    /// <summary>
    /// 登录页 URL 特征（反向排除）：群晖登录后绝对不出现 signin
    /// </summary>
    public string? LoginPageUrlFragment => "signin";

    /// <summary>
    /// 维护通知页 URL 特征
    /// </summary>
    public string? NoticeUrlFragment => "notice";
}
