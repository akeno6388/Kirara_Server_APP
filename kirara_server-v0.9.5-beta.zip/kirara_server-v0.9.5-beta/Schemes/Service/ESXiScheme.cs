using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.Service;

/// <summary>
/// ESXi 管理方案
/// 单步登录：填用户名 + 密码 + 点击登录
/// </summary>
public class ESXiScheme : BaseScheme, IAutoLoginProvider
{
    public override Guid Id => Guid.Parse("b2000003-0000-0000-0000-000000000001");
    public override string Name => "esxi";
    public override string DisplayName => "ESXi 管理";
    public override string Description => "虚拟化平台管理后台";
    public override InstanceType InstanceType => InstanceType.ServiceInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uE7C1";
    public override int SortOrder => 103;

    // ——— IAutoLoginProvider 实现 ———

    /// <summary>
    /// 登录页就绪：用户名输入框出现
    /// </summary>
    public string? PageReadyDomSelector => "#username";

    /// <summary>
    /// 登录表单判据：用户名输入框（仅登录页存在，成功页无）→ 可见即未登录，优先于 URL 正向
    /// </summary>
    public string? LoginFormDomSelector => "#username";

    /// <summary>
    /// 单步登录：填入用户名 + 密码 + 点击登录
    /// </summary>
    public string? GetAutoLoginScript(Token token)
    {
        if (string.IsNullOrWhiteSpace(token.AccountName) ||
            string.IsNullOrWhiteSpace(token.AccountPassword))
            return null;

        var escapedUser = EscapeForJsStringLiteral(token.AccountName);
        var escapedPass = EscapeForJsStringLiteral(token.AccountPassword);

        return $$"""
            (() => {
                const u = document.getElementById('username');
                const p = document.getElementById('password');
                const b = document.getElementById('submit');
                if (!u || !p || !b) return 'no_form';

                const ns = Object.getOwnPropertyDescriptor(
                    HTMLInputElement.prototype, 'value').set;
                ns.call(u, '{{escapedUser}}');
                u.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedUser}}' }));
                ns.call(p, '{{escapedPass}}');
                p.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedPass}}' }));

                b.click();
                return 'ok';
            })();
            """;
    }

    /// <summary>
    /// 登录成功后 URL：/ui/#/host
    /// </summary>
    public string? LoginSuccessUrlFragment => "#/host";

    /// <summary>
    /// 登录成功后 DOM 特征：用户菜单链接（仅登录后出现）
    /// </summary>
    public string? LoginSuccessDomSelector => "#userMenuLink";

    /// <summary>
    /// 通知/维护页面特征
    /// </summary>
    public string? NoticeUrlFragment => "notice";

    /// <summary>
    /// 登录页 URL 特征（反向排除，兜底）：hash 路由 #/login
    /// 精确匹配 "#/login"，避免 "login" 子串误伤其他含 login 的路径/参数。
    /// </summary>
    public string? LoginPageUrlFragment => "#/login";
}
