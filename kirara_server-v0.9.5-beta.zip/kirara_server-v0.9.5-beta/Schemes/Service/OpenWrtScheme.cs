using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.Service;

/// <summary>
/// OpenWrt LuCI 路由管理方案
/// 经典 HTML 表单登录（非 SPA，无 React/Vue）
/// 登录前：body.node-main-login，存在 luci_username / luci_password
/// 登录后：body.logged-in，URL 不变，内容为概览页
/// 表单 POST 提交后会触发页面导航，登录成功检测 body.logged-in
/// </summary>
public class OpenWrtScheme : BaseScheme, IAutoLoginProvider
{
    public override Guid Id => Guid.Parse("b2000005-0000-0000-0000-000000000001");
    public override string Name => "openwrt";
    public override string DisplayName => "OpenWrt 路由";
    public override string Description => "OpenWrt LuCI 路由管理后台";
    public override InstanceType InstanceType => InstanceType.ServiceInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uE7B9";
    public override int SortOrder => 111;

    // ——— IAutoLoginProvider 实现 ———

    /// <summary>
    /// 页面就绪检测：LuCI 用户名输入框出现
    /// </summary>
    public string? PageReadyDomSelector => "input[name=\"luci_username\"]";

    /// <summary>
    /// 登录表单判据：LuCI 用户名输入框（仅登录页存在，成功页 body.logged-in 无表单）→ 可见即未登录，优先于 URL 正向
    /// </summary>
    public string? LoginFormDomSelector => "input[name=\"luci_username\"]";

    /// <summary>
    /// 单步登录：填入用户名 + 密码 + 点击提交
    /// LuCI 是纯 HTML 表单 POST，非 SPA，无需 _valueTracker 预填
    /// </summary>
    public string? GetAutoLoginScript(Token token)
    {
        if (string.IsNullOrWhiteSpace(token.AccountName) ||
            string.IsNullOrWhiteSpace(token.AccountPassword))
            return null;

        var escapedUser = EscapeForJsStringLiteral(token.AccountName);
        var escapedPass = EscapeForJsStringLiteral(token.AccountPassword);

        return $$"""
            (() => {
                const u = document.querySelector('input[name="luci_username"]');
                const p = document.querySelector('input[name="luci_password"]');
                const b = document.querySelector('input[type="submit"]');
                if (!u || !p || !b) return 'no_form';

                const ns = Object.getOwnPropertyDescriptor(
                    HTMLInputElement.prototype, 'value').set;
                ns.call(u, '{{escapedUser}}');
                u.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedUser}}' }));
                ns.call(p, '{{escapedPass}}');
                p.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedPass}}' }));

                b.click();
                return 'ok';
            })();
            """;
    }

    /// <summary>
    /// 登录后 URL 不变（同一路径，服务端通过 session 区分状态）
    /// 因此不设 UrlFragment，完全依赖 DOM 检测
    /// </summary>
    public string? LoginSuccessUrlFragment => null;

    /// <summary>
    /// 登录成功后 body 的 logged-in class
    /// </summary>
    public string? LoginSuccessDomSelector => "body.logged-in";

    /// <summary>
    /// 通知/维护页面特征
    /// </summary>
    public string? NoticeUrlFragment => "notice";

    /// <summary>
    /// 登录页面 body 特征 class（反向排除）
    /// </summary>
    public string? LoginPageUrlFragment => null;
}
