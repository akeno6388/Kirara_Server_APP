using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.Service;

/// <summary>
/// 虚拟化平台方案（群晖 DSM）
/// </summary>
public class VmmScheme : BaseScheme, IAutoLoginProvider
{
    public override Guid Id => Guid.Parse("b2000012-0000-0000-0000-000000000001");
    public override string Name => "vmm";
    public override string DisplayName => "虚拟化平台";
    public override string Description => "部署虚拟机等";
    public override InstanceType InstanceType => InstanceType.ServiceInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uE7C1";
    public override int SortOrder => 112;

    // ——— IAutoLoginProvider 实现 ———
    public string? PageReadyDomSelector => "[syno-id=\"account-panel-next-btn\"]";

    /// <summary>
    /// 登录表单判据：DSM 登录下一步按钮（成功页桌面无）→ 可见即未登录，优先于 URL 正向
    /// </summary>
    public string? LoginFormDomSelector => "[syno-id=\"account-panel-next-btn\"]";

    public string? GetPreLoginScript(Token? token)
    {
        if (token == null || string.IsNullOrWhiteSpace(token.AccountName))
            return null;
        var escapedUser = EscapeForJsStringLiteral(token.AccountName);
        return $$"""
            (() => {
                const u = document.querySelector('[syno-id="username"]');
                const n = document.querySelector('[syno-id="account-panel-next-btn"]');
                if (!u || !n) return 'no_form';
                const ns = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
                ns.call(u, '{{escapedUser}}');
                u.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: '{{escapedUser}}' }));
                u.dispatchEvent(new Event('change', { bubbles: true }));
                n.click();
                return 'clicked';
            })();
            """;
    }

    public int PreLoginDelayMs => 2000;
    public string? PasswordPageDomSelector => "[syno-id=\"password\"]";

    public string? GetAutoLoginScript(Token token)
    {
        if (string.IsNullOrWhiteSpace(token.AccountPassword)) return null;
        var escapedPass = EscapeForJsStringLiteral(token.AccountPassword);
        return $$"""
            (() => {
                const p = document.querySelector('[syno-id="password"]');
                if (!p) return 'no_form';
                const ns = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
                ns.call(p, '{{escapedPass}}');
                p.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: '{{escapedPass}}' }));
                p.dispatchEvent(new Event('change', { bubbles: true }));
                const cb = document.querySelector('.login-checkbox input[type="checkbox"]');
                if (cb && !cb.checked) cb.click();
                return 'ok';
            })();
            """;
    }

    public string? LoginSuccessUrlFragment => null;
    public string? LoginSuccessDomSelector => "#sds-desktop";
    public string? LoginPageUrlFragment => "signin";
    public string? NoticeUrlFragment => "notice";
}
