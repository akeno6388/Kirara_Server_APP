using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.Service;

/// <summary>
/// Windows Server 下载服务器管理方案（桩）
/// </summary>
public class WinserverDLScheme : BaseScheme
{
    public override Guid Id => Guid.Parse("b2000010-0000-0000-0000-000000000001");
    public override string Name => "winserver-dl";
    public override string DisplayName => "Winserver-DL 管理";
    public override string Description => "下载服务器管理后台";
    public override InstanceType InstanceType => InstanceType.ServiceInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.RDP;
    public override string IconGlyph => "\uE7B8";
    public override int SortOrder => 110;
}
