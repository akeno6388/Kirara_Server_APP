using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;

namespace Kirara_Server_WinUI.Schemes;

/// <summary>
/// 方案基类 — 提供默认实现的 IScheme 模板
/// [评论区功能] 实现 IResourceContextProvider 默认方法，方案可重写自定义资源标识
/// </summary>
public abstract class BaseScheme : IScheme, IResourceContextProvider
{
    /// <summary>
    /// 集中式 URL 管理服务（由 App 启动时注入）
    /// </summary>
    public static IServerUrlService? ServerUrlService { get; set; }

    public abstract Guid Id { get; }
    public abstract string Name { get; }
    public abstract string DisplayName { get; }
    public abstract string Description { get; }
    public abstract InstanceType InstanceType { get; }
    public abstract SchemeUIKind UIKind { get; }
    public abstract string IconGlyph { get; }

    /// <summary>排序权重（数值越小越靠前）</summary>
    public abstract int SortOrder { get; }

    /// <summary>
    /// 默认 URL 注册表键，方案通过此键从 ServerUrlService 获取服务器地址。
    /// 默认与 Name 同名，无需 URL 的方案应显式重写为 null。
    /// </summary>
    public virtual string? DefaultUrlKey => Name;

    public virtual Task<SchemeResult> InitializeAsync(SchemeBinding binding)
    {
        return Task.FromResult(SchemeResult.Success());
    }

    public virtual SchemeUI GetUI()
    {
        var ui = new SchemeUI { Kind = UIKind };

        // 如果方案声明了 DefaultUrlKey，从集中式注册表解析 URL
        if (!string.IsNullOrEmpty(DefaultUrlKey) && ServerUrlService != null)
        {
            var resolvedUrl = ServerUrlService.GetDecryptedUrl(DefaultUrlKey);
            if (!string.IsNullOrEmpty(resolvedUrl))
            {
                switch (UIKind)
                {
                    case SchemeUIKind.WebView2:
                        ui.WebViewUrl = resolvedUrl;
                        break;
                    case SchemeUIKind.RDP:
                        ui.RdpAddress = resolvedUrl;
                        break;
                }
            }
        }

        return ui;
    }

    public virtual Task<SchemeResult> DeinitializeAsync()
    {
        return Task.FromResult(SchemeResult.Success());
    }

    public virtual Task<TokenValidationResult> ValidateTokenAsync(Token token)
    {
        return Task.FromResult(TokenValidationResult.Valid());
    }

    public virtual SchemeStatus GetStatus() => SchemeStatus.Idle;

    // ===== [评论区功能] IResourceContextProvider 默认实现 =====

    /// <summary>
    /// 默认返回 null，表示使用 WebView2 当前 URL 路径作为资源键。
    /// 方案可重写此方法自定义资源标识（如媒体库中的视频 ID）。
    /// </summary>
    public virtual string? GetResourceKey() => null;

    /// <summary>
    /// 默认返回方案的 DisplayName，方案可重写自定义标题。
    /// </summary>
    public virtual string? GetResourceTitle() => DisplayName;

    /// <summary>
    /// 将字符串转义为可嵌入 JS 单引号字符串字面量的形式。
    /// 供所有 IAutoLoginProvider 方案复用的公共辅助方法。
    /// </summary>
    protected static string EscapeForJsStringLiteral(string raw)
    {
        return raw
            .Replace("\\", "\\\\")
            .Replace("'", "\\'")
            .Replace("\r", "\\r")
            .Replace("\n", "\\n")
            .Replace("\t", "\\t");
    }
}
