using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.BuiltIn;

/// <summary>
/// Kirara Alist 方案 — 基于 CDN 加速的高速资源分享平台。
/// WebView2 渲染；单步自动登录（用户名+密码同页 + 登录按钮，Hope UI 框架）。
///
/// 登录状态识别（实测）：
/// - 登录页：/@login（表单 input[name=username] + input[name=password] + 按钮"登录"）
/// - 登录成功①：/@manage（个人资料页，含 username/password/confirm-password 输入框 ——
///    ⚠️ 不能用"密码框数量"判断登录状态，此页有 2 个密码框！）
/// - 登录成功②：/（主页文件列表 .list-item 行）
/// 因此以 URL 特征为准：@login 未登录；@manage 或主页（非 @login）均为已登录。
/// </summary>
public class AlistScheme : BaseScheme, IAutoLoginProvider
{
    public override Guid Id => Guid.Parse("a1000010-0000-0000-0000-000000000001");
    public override string Name => "alist";
    public override string DisplayName => "Kirara Alist";
    public override string Description => "基于CDN加速的高速资源分享平台";
    public override InstanceType InstanceType => InstanceType.UserInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uE8B7";
    public override int SortOrder => 8;

    // ——— IAutoLoginProvider 实现（单步登录，Hope UI）———

    /// <summary>
    /// 页面就绪标志：用户名输入框出现即表示登录页已渲染
    /// </summary>
    public string? PageReadyDomSelector => "input[name=\"username\"]";

    /// <summary>
    /// 单步方案：无预登录步骤
    /// </summary>
    public string? GetPreLoginScript(Token? token) => null;

    /// <summary>
    /// 填入用户名/密码并点击登录按钮。
    /// Hope UI 为受控组件，需用原生 setter + InputEvent 触发双向绑定。
    /// </summary>
    public string? GetAutoLoginScript(Token token)
    {
        if (string.IsNullOrWhiteSpace(token.AccountName) ||
            string.IsNullOrWhiteSpace(token.AccountPassword))
            return null;

        var escapedUser = EscapeForJsStringLiteral(token.AccountName);
        var escapedPass = EscapeForJsStringLiteral(token.AccountPassword);

        return $$"""
            (() => {
                const u = document.querySelector('input[name="username"]');
                const p = document.querySelector('input[name="password"]');
                if (!u || !p) return 'no_form';

                const ns = Object.getOwnPropertyDescriptor(
                    HTMLInputElement.prototype, 'value').set;

                ns.call(u, '{{escapedUser}}');
                u.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedUser}}' }));
                u.dispatchEvent(new Event('change', { bubbles: true }));

                ns.call(p, '{{escapedPass}}');
                p.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedPass}}' }));
                p.dispatchEvent(new Event('change', { bubbles: true }));

                // 点击登录按钮（Hope UI：hope-button，文本"登录"）
                const btn = [...document.querySelectorAll('.hope-button')]
                    .find(b => (b.textContent || '').trim() === '登录');
                if (btn) { btn.click(); return 'clicked'; }
                return 'no_btn';
            })();
            """;
    }

    /// <summary>
    /// 登录成功 URL 特征：/@manage（个人资料页）或 /（主页文件列表）。
    /// ⚠️ 必须用 URL 特征：/@manage 页有 2 个密码框（个人资料修改密码表单），
    /// 用"密码框数量"或 #sds-desktop 等 DOM 判据会误判为登录页。
    /// </summary>
    public string? LoginSuccessUrlFragment => "@manage";

    /// <summary>
    /// 主页文件列表特征 DOM（兜底，登录成功②场景）：.list-item 文件行。
    /// </summary>
    public string? LoginSuccessDomSelector => ".list-item";

    /// <summary>
    /// 登录页 URL 特征（反向排除）：/@login
    /// </summary>
    public string? LoginPageUrlFragment => "@login";

    /// <summary>
    /// 维护通知页 URL 特征
    /// </summary>
    public string? NoticeUrlFragment => "notice";
}
