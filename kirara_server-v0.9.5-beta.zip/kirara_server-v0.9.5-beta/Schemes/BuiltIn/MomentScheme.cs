using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.BuiltIn;

/// <summary>
/// 三月相册方案（群晖 Synology Photos）
/// 与 AppServer 同款 DSM 登录流程：输入用户名 → 下一步 → 输入密码 + 保持登录 → 登录
/// 登录成功后进入 sds-desktop（SYNO.Foto 独立门户模式，已实测 #sds-desktop 存在）。
/// </summary>
public class MomentScheme : BaseScheme, IAutoLoginProvider
{
    public override Guid Id => Guid.Parse("a1000012-0000-0000-0000-000000000001");
    public override string Name => "moment";
    public override string DisplayName => "三月相册";
    public override string Description => "云相册，支持AI整理功能";
    public override InstanceType InstanceType => InstanceType.UserInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uEB9F";
    public override int SortOrder => 11;

    // ——— IAutoLoginProvider 实现（与 AppServerScheme 一致，DSM 7.2 登录页）———

    /// <summary>
    /// 登录页就绪标志：用户名页"下一步"按钮出现即表示页面已渲染
    /// </summary>
    public string? PageReadyDomSelector => "[syno-id=\"account-panel-next-btn\"]";

    /// <summary>
    /// 登录表单判据：DSM 登录下一步按钮（成功页桌面无）→ 可见即未登录，优先于 URL 正向
    /// </summary>
    public string? LoginFormDomSelector => "[syno-id=\"account-panel-next-btn\"]";

    /// <summary>
    /// 【步骤1】填入用户名，用 InputEvent 让 React 受控组件识别，然后点击下一步
    /// </summary>
    public string? GetPreLoginScript(Token? token)
    {
        if (token == null || string.IsNullOrWhiteSpace(token.AccountName))
            return null;

        var escapedUser = EscapeForJsStringLiteral(token.AccountName);

        return $$"""
            (() => {
                const u = document.querySelector('[syno-id="username"]');
                const n = document.querySelector('[syno-id="account-panel-next-btn"]');
                if (!u || !n) return 'no_form';

                const ns = Object.getOwnPropertyDescriptor(
                    HTMLInputElement.prototype, 'value').set;

                ns.call(u, '{{escapedUser}}');
                u.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedUser}}' }));
                u.dispatchEvent(new Event('change', { bubbles: true }));

                n.click();
                return 'clicked';
            })();
            """;
    }

    /// <summary>
    /// 等 DSM React 处理填值 + 路由切换
    /// </summary>
    public int PreLoginDelayMs => 2000;

    /// <summary>
    /// 密码页就绪标志：密码 INPUT 出现
    /// </summary>
    public string? PasswordPageDomSelector => "[syno-id=\"password\"]";

    /// <summary>
    /// 【步骤2】填入密码，勾选"保持登录"，点击登录
    /// </summary>
    public string? GetAutoLoginScript(Token token)
    {
        if (string.IsNullOrWhiteSpace(token.AccountPassword))
            return null;

        var escapedPass = EscapeForJsStringLiteral(token.AccountPassword);

        return $$"""
            (() => {
                const p = document.querySelector('[syno-id="password"]');
                if (!p) return 'no_form';

                const ns = Object.getOwnPropertyDescriptor(
                    HTMLInputElement.prototype, 'value').set;

                ns.call(p, '{{escapedPass}}');
                p.dispatchEvent(new InputEvent('input',
                    { bubbles: true, inputType: 'insertText', data: '{{escapedPass}}' }));
                p.dispatchEvent(new Event('change', { bubbles: true }));

                // 勾选"保持登录"（点击内部原生 checkbox）
                const cb = document.querySelector('.login-checkbox input[type="checkbox"]');
                if (cb && !cb.checked) {
                    cb.click();
                }

                return 'ok';
            })();
            """;
    }

    /// <summary>
    /// 登录成功 URL 特征：Synology Photos 登录成功后进入个人空间文件夹界面
    /// （实测 URL 为 ?launchApp=SYNO.Foto.AppInstance#/personal_space/folder/116）。
    /// </summary>
    public string? LoginSuccessUrlFragment => "personal_space";

    /// <summary>
    /// 登录成功后特有的 DOM：Synology Photos 顶部用户菜单按钮。
    /// ⚠️ 不能用 #sds-desktop！external_login 模式的登录页也渲染门户外壳（sds-desktop 存在），
    /// 且首次加载时 URL hash 未设置、登录表单未挂载存在竞态窗口 → 快速已登录检测会误判"已登录"跳过登录脚本。
    /// .synofoto-menu-button 是套件应用用户菜单（登录成功后才挂载），登录页不存在，无竞态。
    /// 检测原则：无确凿成功证据（本选择器或 personal_space URL）→ 默认未登录，继续令牌链接流程。
    /// </summary>
    public string? LoginSuccessDomSelector => ".synofoto-menu-button";

    /// <summary>
    /// 登录页 URL 特征（反向排除）：群晖登录后绝对不出现 signin
    /// </summary>
    public string? LoginPageUrlFragment => "signin";

    /// <summary>
    /// 维护通知页 URL 特征
    /// </summary>
    public string? NoticeUrlFragment => "notice";
}
