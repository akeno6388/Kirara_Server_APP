using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.BuiltIn;

/// <summary>
/// SRS 直播方案（桩）
/// </summary>
public class SRSLiveScheme : BaseScheme
{
    public override Guid Id => Guid.Parse("a1000003-0000-0000-0000-000000000001");
    public override string Name => "srslive";
    public override string DisplayName => "Kirara Live";
    public override string Description => "高效的直播、观看方案";
    public override InstanceType InstanceType => InstanceType.UserInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uEB9C";
    public override int SortOrder => 3;
}
