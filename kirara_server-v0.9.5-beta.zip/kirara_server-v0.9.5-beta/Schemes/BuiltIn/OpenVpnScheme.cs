using Kirara_Server_WinUI.Models;
using Kirara_Server_WinUI.Services;
using Kirara_Server_WinUI.Views.Controls;

namespace Kirara_Server_WinUI.Schemes.BuiltIn;

/// <summary>
/// OpenVPN 方案 — 自研管理界面（CustomControl）+ openvpn.exe 子进程 + management 管理接口。
///
/// 设计要点：
/// - UIKind 改为 CustomControl，通过 OpenVpnControl 自研面板实现连接/断开/状态/流量/日志展示。
/// - 凭据来源：绑定令牌（AccountName / AccountPassword，AES-256-GCM 加密存储，运行时解密）。
/// - 服务器地址：令牌 ServerUrl 优先，回退 URL 注册表 "openvpn" 键。
/// - 连接引擎：openvpn.exe 子进程 + --management-client 反向连接模式（详见 VpnConnectionService）。
/// </summary>
public class OpenVpnScheme : BaseScheme
{
    public override Guid Id => Guid.Parse("a1000002-0000-0000-0000-000000000001");
    public override string Name => "openvpn";
    public override string DisplayName => "OpenVPN";
    public override string Description => "访问服务器内网资源";
    public override InstanceType InstanceType => InstanceType.UserInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.CustomControl;
    public override string IconGlyph => "\uE774";
    public override int SortOrder => 2;

    /// <summary>
    /// URL 注册表键（服务器地址回退来源；主来源为绑定令牌的 ServerUrl 字段）
    /// </summary>
    public override string? DefaultUrlKey => "openvpn";

    // ===== 连接参数（InitializeAsync 时解析，GetUI 时使用） =====
    private string _accountName = string.Empty;
    private string? _accountPassword;
    private string _serverHost = string.Empty;
    private int _serverPort = VpnConnectionService.DefaultVpnPort;
    private string? _ovpnConfigPath;
    private bool _hasValidBinding;

    /// <summary>
    /// 初始化方案：解析绑定令牌凭据，并确保 .ovpn 配置可用（本地缓存 → 服务端同步）。
    /// 无降级链路：本地无缓存且服务器同步失败时直接中断（返回失败）。
    /// </summary>
    public override async Task<SchemeResult> InitializeAsync(SchemeBinding binding)
    {
        // 1. 解析绑定令牌（凭据来源）
        if (!binding.TokenId.HasValue)
        {
            return SchemeResult.Fail("未绑定令牌，请在实例配置中为 OpenVPN 方案绑定令牌");
        }

        var tokenService = App.Services.GetRequiredService<ITokenService>();
        Token? token = tokenService.LoadSecureToken(binding.TokenId.Value);
        if (token == null)
        {
            return SchemeResult.Fail("绑定令牌不存在或已删除");
        }

        _accountName = token.AccountName;
        _accountPassword = token.AccountPassword;

        // 2. 确保 .ovpn 配置可用（无降级链路）
        //    使用 EnsureConfigReadyAsync：等待后台同步（登录触发）完成后强制同步，
        //    避免 _syncInProgress 互斥导致同步被跳过、缓存未下载（硬重载后必现）
        var configCache = App.Services.GetRequiredService<OvpnConfigCacheService>();
        _ovpnConfigPath = await configCache.EnsureConfigReadyAsync();
        if (_ovpnConfigPath == null)
        {
            // 本地无缓存且服务器同步失败 → 直接中断连接过程
            return SchemeResult.Fail("无法获取 .ovpn 配置文件：本地无缓存且无法连接服务器，请检查网络连接后重试");
        }

        // 3. 解析展示用服务器地址：优先 .ovpn 内 remote 指令，回退令牌 ServerUrl / URL 注册表
        //    （仅用于界面展示与 OpenVPN Connect 降级模式；连接实际使用 .ovpn 内配置）
        (string host, int port) = TryParseRemoteFromConfig(_ovpnConfigPath)
            ?? ParseServerAddress(token.ServerUrl
                ?? ServerUrlService?.GetDecryptedUrl(DefaultUrlKey ?? string.Empty)
                ?? string.Empty);

        _serverHost = host;
        _serverPort = port;
        _hasValidBinding = true;
        return SchemeResult.Success();
    }

    /// <summary>
    /// 获取方案界面 — 返回自研 OpenVPN 管理面板
    /// </summary>
    public override SchemeUI GetUI()
    {
        SchemeUI ui = new() { Kind = SchemeUIKind.CustomControl };
        if (_hasValidBinding)
        {
            ui.CustomControl = new OpenVpnControl(
                _accountName, _accountPassword, _serverHost, _serverPort, DisplayName, _ovpnConfigPath);
        }
        return ui;
    }

    /// <summary>
    /// 方案停用：断开活动 VPN 连接
    /// （当前宿主暂未调用此方法，保留完整实现供未来清理链路使用）
    /// </summary>
    public override async Task<SchemeResult> DeinitializeAsync()
    {
        var vpnService = App.Services.GetRequiredService<VpnConnectionService>();
        await vpnService.DisconnectAsync();
        return SchemeResult.Success();
    }

    /// <summary>
    /// 解析服务器地址：去除协议前缀 + host:port 拆分，无端口时使用默认端口 1195。
    /// 注意：暂不支持 IPv6 字面量地址（冒号解析歧义）。
    /// </summary>
    private static (string host, int port) ParseServerAddress(string raw)
    {
        string s = raw.Trim();
        foreach (string prefix in new[] { "https://", "http://", "udp://", "tcp://" })
        {
            if (s.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            {
                s = s.Substring(prefix.Length);
                break;
            }
        }

        int lastColon = s.LastIndexOf(':');
        if (lastColon > 0)
        {
            string host = s.Substring(0, lastColon);
            string portStr = s.Substring(lastColon + 1);
            if (int.TryParse(portStr, out int port) && port > 0 && port < 65536)
            {
                return (host, port);
            }
        }

        return (s, VpnConnectionService.DefaultVpnPort);
    }

    /// <summary>
    /// 从 .ovpn 配置文件中解析 remote 指令（<c>remote &lt;host&gt; &lt;port&gt; [proto]</c>）。
    /// 用于界面展示服务器地址；解析失败返回 null（连接仍以 .ovpn 内容为准）。
    /// </summary>
    private static (string host, int port)? TryParseRemoteFromConfig(string configPath)
    {
        try
        {
            foreach (var line in File.ReadLines(configPath))
            {
                var trimmed = line.Trim();
                if (!trimmed.StartsWith("remote", StringComparison.OrdinalIgnoreCase))
                    continue;

                // remote 后按空格拆分：host [port [proto]]
                var parts = trimmed.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                if (parts.Length >= 2)
                {
                    string host = parts[1].Trim();
                    if (string.IsNullOrEmpty(host)) continue;

                    int port = VpnConnectionService.DefaultVpnPort;
                    if (parts.Length >= 3 && int.TryParse(parts[2], out int parsedPort) &&
                        parsedPort > 0 && parsedPort < 65536)
                    {
                        port = parsedPort;
                    }
                    return (host, port);
                }
            }
        }
        catch { /* 配置读取失败忽略 */ }
        return null;
    }
}
