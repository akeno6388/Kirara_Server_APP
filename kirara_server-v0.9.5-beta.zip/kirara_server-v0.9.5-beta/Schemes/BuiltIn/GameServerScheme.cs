using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.BuiltIn;

/// <summary>
/// 游戏服务器方案（桩）
/// </summary>
public class GameServerScheme : BaseScheme
{
    public override Guid Id => Guid.Parse("a1000009-0000-0000-0000-000000000001");
    public override string Name => "gameserver";
    public override string DisplayName => "游戏服务器";
    public override string Description => "私服游戏的辅助工具";
    public override InstanceType InstanceType => InstanceType.UserInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.ExternalProcess;
    public override string IconGlyph => "\uE7FC";
    public override int SortOrder => 9;
    public override string? DefaultUrlKey => null;
}
