using Kirara_Server_WinUI.Contracts;
using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.BuiltIn;

/// <summary>
/// Jellyfin 媒体应用方案
/// </summary>
public class MediaScheme : BaseScheme, IAutoLoginProvider
{
    public override Guid Id => Guid.Parse("a1000001-0000-0000-0000-000000000001");
    public override string Name => "media";
    public override string DisplayName => "Kirara Media";
    public override string Description => "流媒体服务，持续更新";
    public override InstanceType InstanceType => InstanceType.UserInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.WebView2;
    public override string IconGlyph => "\uE8B9";
    public override int SortOrder => 1;

    // ——— IAutoLoginProvider 实现 ———

    /// <summary>
    /// 登录页就绪标志："手动登录"按钮出现即表示 SPA 已渲染完成
    /// </summary>
    public string? PageReadyDomSelector => ".emby-button";

    /// <summary>
    /// 登录表单判据：手动登录用户名输入框 #txtManualName。
    /// ⚠️ 实测（2026-08-04）：登录成功页 #txtManualName 依然残留在 DOM 中（display:none），
    /// 因此存在性检测会把成功页误判为"仍在登录页"——必须配合 AutoLoginService 的
    /// 可见性三态检测（visible→未登录；hidden→配合 HiddenLoginFormIndicatesLoggedIn=true 判定已登录）。
    /// ⚠️ 不能用 #loginPage：登录成功页同样残留 #loginPage 容器。
    /// ⚠️ 不能用 PageReadyDomSelector（.emby-button 是 Jellyfin 通用按钮类，登录后首页同样存在）。
    /// </summary>
    public string? LoginFormDomSelector => "#txtManualName";

    /// <summary>
    /// Jellyfin 登录成功后将登录表单隐藏（display:none）而非从 DOM 移除：
    /// #txtManualName 在成功页存在但不可见 → 判定已登录。
    /// </summary>
    public bool HiddenLoginFormIndicatesLoggedIn => true;

    /// <summary>
    /// 【步骤1】确保登录表单已展开
    /// [v2.7] 用专属类 .btnManual 精确点击"手动登录"按钮。
    /// 实测登录页按钮结构：
    ///   [0] raised button-submit block emby-button "登录"       隐藏（提交按钮）
    ///   [1] raised cancel block btnCancel emby-button "取消"    隐藏 ← 陷阱！
    ///   [2] raised cancel block btnManual emby-button "手动登录" 可见 ← 目标
    ///   [3] raised cancel block btnQuick emby-button            可见
    ///   [4] raised cancel block btnForgotPassword emby-button   可见
    ///   [5] raised block btnSelectServer emby-button hide       隐藏
    /// v2.6 用 .emby-button:not(.hide):not(.button-submit) 会匹配到 [1] btnCancel——
    /// 它无 .hide class（靠父容器隐藏），querySelector 的 :not() 只看 class 不看可见性，
    /// 点击"取消"无效 → 表单永不展开 → clicked_no_form → 令牌链接失败。
    /// 表单展开判定：#txtManualName 折叠态已在 DOM（隐藏），展开后变为可见。
    /// </summary>
    public string? GetPreLoginScript(Token? token)
    {
        return """
            (async () => {
                const wait = (ms) => new Promise(r => setTimeout(r, ms));
                const isVisible = (el) => el && el.getClientRects().length > 0;

                // 表单已展开（用户名输入框可见）→ 无需点击
                if (isVisible(document.getElementById('txtManualName'))) return 'already';

                // 折叠态：点击"手动登录"按钮（Jellyfin 专属类 .btnManual）
                const btn = document.querySelector('.btnManual');
                if (!btn || !isVisible(btn)) return 'no_btn';
                btn.click();

                // 轮询等待表单展开（最多 5s）
                const t0 = Date.now();
                while (Date.now() - t0 < 5000) {
                    if (isVisible(document.getElementById('txtManualName'))) return 'expanded';
                    await wait(150);
                }
                return 'clicked_no_form';
            })();
            """;
    }

    /// <summary>
    /// 预登录后缓冲（预登录脚本已内部轮询等待展开，此处仅小缓冲）
    /// </summary>
    public int PreLoginDelayMs => 200;

    /// <summary>
    /// 【步骤2】填入用户名/密码并提交登录表单
    /// </summary>
    public string? GetAutoLoginScript(Token token)
    {
        if (string.IsNullOrWhiteSpace(token.AccountName) ||
            string.IsNullOrWhiteSpace(token.AccountPassword))
            return null;

        // 对凭据做 JS 字符串转义（单引号 / 反斜杠 / 换行等）
        var escapedUser = EscapeForJsStringLiteral(token.AccountName);
        var escapedPass = EscapeForJsStringLiteral(token.AccountPassword);

        return $$"""
            (() => {
                const u = document.getElementById('txtManualName');
                const p = document.getElementById('txtManualPassword');
                const b = document.querySelector('.raised.button-submit.block.emby-button');
                if (!u || !p || !b) return 'no_form';
                // [v2.2] 可见性保护：成功页残留隐藏的登录表单（display:none），
                // 此时不应填充凭据/点击提交（会触发重新认证或破坏会话）
                if (u.getClientRects().length === 0) return 'no_form';

                // 以原生方式设置值并触发事件（兼容框架的双向绑定）
                const setNative = (el, v) => {
                    const s = Object.getOwnPropertyDescriptor(
                        HTMLInputElement.prototype, 'value').set;
                    s.call(el, v);
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                };
                setNative(u, '{{escapedUser}}');
                setNative(p, '{{escapedPass}}');
                b.click();
                return 'ok';
            })();
            """;
    }

    /// <summary>
    /// 登录成功 URL 特征：**null（放弃 URL 判据）**。
    /// [v2.4] 实测：Jellyfin 的 URL 无法区分登录状态——
    /// 未登录访问 #/home.html 路由时 SPA 先渲染登录视图，hash 重定向到 #/login.html 是异步的；
    /// 且 URL 在 DOM 渲染前就已设置为 #/home.html，URL 正向判据会假阳性短路（"界面加载完成"）。
    /// 完全依赖 DOM 可见性判据：表单可见→未登录；表单隐藏（成功页残留 display:none）→已登录；
    /// .homePage 兜底。
    /// </summary>
    public string? LoginSuccessUrlFragment => null;

    /// <summary>
    /// Emby/Jellyfin 首页特征 DOM。
    /// ⚠️ 实测（2026-08-04）：只保留 .homePage（登录页 not_found、成功页 FOUND）；
    /// .dashboardSection 在本版本不存在（not_found）；.libraryPage 在成功页 home 视图也存在，
    /// 与登录页无互斥性，不能作为成功判据。
    /// </summary>
    public string? LoginSuccessDomSelector => ".homePage";

    /// <summary>
    /// 维护通知页特征 URL 片段
    /// </summary>
    public string? NoticeUrlFragment => "notice";

    /// <summary>
    /// 登录页 URL 特征（反向排除，兜底）：hash 路由 #/login.html（含 url=%2Fhome.html query）。
    /// 精确匹配 "#/login.html"，避免 "login" 子串误伤其他含 login 的路径/参数。
    /// </summary>
    public string? LoginPageUrlFragment => "#/login.html";
}
