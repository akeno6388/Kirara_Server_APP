using Kirara_Server_WinUI.Models;

namespace Kirara_Server_WinUI.Schemes.BuiltIn;

/// <summary>
/// 议题方案 — 打开评论区（独立子窗口）
/// [评论区功能] 此方案加载时通过 SchemeHostPage 打开评论面板，
/// 评论内容通过 WebView2 当前 URL 路径与资源关联。
/// 方案实现 IResourceContextProvider（继承自 BaseScheme）可自定义资源标识。
/// </summary>
public class TopicScheme : BaseScheme
{
    public override Guid Id => Guid.Parse("a1000004-0000-0000-0000-000000000001");
    public override string Name => "topic";
    public override string DisplayName => "议题";
    public override string Description => "评论与工单提交";
    public override InstanceType InstanceType => InstanceType.UserInstance;
    public override SchemeUIKind UIKind => SchemeUIKind.Overlay;
    public override string IconGlyph => "\uE8BD";
    public override int SortOrder => 4;
    public override string? DefaultUrlKey => null;

    // [评论区功能] 自定义资源标题
    public override string? GetResourceTitle() => DisplayName;
}
